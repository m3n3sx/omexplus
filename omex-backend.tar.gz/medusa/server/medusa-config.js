"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
(0, utils_1.loadEnv)(process.env.NODE_ENV || 'development', process.cwd());
module.exports = (0, utils_1.defineConfig)({
    projectConfig: {
        databaseUrl: process.env.DATABASE_URL,
        http: {
            storeCors: process.env.STORE_CORS,
            adminCors: process.env.ADMIN_CORS,
            authCors: process.env.AUTH_CORS,
            jwtSecret: process.env.JWT_SECRET || "supersecret",
            cookieSecret: process.env.COOKIE_SECRET || "supersecret",
        }
    },
    modules: [
        {
            resolve: "./src/modules/product-review",
        },
        {
            resolve: "./src/modules/wishlist",
        },
        {
            resolve: "./src/modules/loyalty",
        },
        {
            resolve: "./src/modules/cms",
        },
        {
            resolve: "./src/modules/i18n",
        },
        {
            resolve: "./src/modules/omex-product",
        },
        {
            resolve: "./src/modules/omex-category",
        },
        {
            resolve: "./src/modules/omex-translation",
        },
        {
            resolve: "./src/modules/omex-pricing",
        },
        {
            resolve: "./src/modules/omex-inventory",
        },
        {
            resolve: "./src/modules/omex-order",
        },
        {
            resolve: "./src/modules/omex-search",
        },
        {
            resolve: "./src/modules/omex-manufacturer",
        },
        {
            resolve: "./src/modules/omex-seo",
        },
        {
            resolve: "./src/modules/omex-b2b",
        },
        {
            resolve: "./src/modules/omex-documentation",
        },
        {
            resolve: "./src/modules/omex-bulk-import",
        },
    ],
    plugins: [
    // Stripe plugin temporarily disabled - uncomment when needed
    // {
    //   resolve: "./src/plugins/stripe",
    //   options: {
    //     apiKey: process.env.STRIPE_SECRET_KEY,
    //     webhookSecret: process.env.STRIPE_WEBHOOK_SECRET,
    //     apiVersion: process.env.STRIPE_API_VERSION || '2023-10-16',
    //   },
    // },
    ],
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVkdXNhLWNvbmZpZy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL21lZHVzYS1jb25maWcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBaUU7QUFFakUsSUFBQSxlQUFPLEVBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLElBQUksYUFBYSxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFBO0FBRTdELE1BQU0sQ0FBQyxPQUFPLEdBQUcsSUFBQSxvQkFBWSxFQUFDO0lBQzVCLGFBQWEsRUFBRTtRQUNiLFdBQVcsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVk7UUFDckMsSUFBSSxFQUFFO1lBQ0osU0FBUyxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVztZQUNsQyxTQUFTLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFXO1lBQ2xDLFFBQVEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVU7WUFDaEMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxJQUFJLGFBQWE7WUFDbEQsWUFBWSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxJQUFJLGFBQWE7U0FDekQ7S0FDRjtJQUNELE9BQU8sRUFBRTtRQUNQO1lBQ0UsT0FBTyxFQUFFLDhCQUE4QjtTQUN4QztRQUNEO1lBQ0UsT0FBTyxFQUFFLHdCQUF3QjtTQUNsQztRQUNEO1lBQ0UsT0FBTyxFQUFFLHVCQUF1QjtTQUNqQztRQUNEO1lBQ0UsT0FBTyxFQUFFLG1CQUFtQjtTQUM3QjtRQUNEO1lBQ0UsT0FBTyxFQUFFLG9CQUFvQjtTQUM5QjtRQUNEO1lBQ0UsT0FBTyxFQUFFLDRCQUE0QjtTQUN0QztRQUNEO1lBQ0UsT0FBTyxFQUFFLDZCQUE2QjtTQUN2QztRQUNEO1lBQ0UsT0FBTyxFQUFFLGdDQUFnQztTQUMxQztRQUNEO1lBQ0UsT0FBTyxFQUFFLDRCQUE0QjtTQUN0QztRQUNEO1lBQ0UsT0FBTyxFQUFFLDhCQUE4QjtTQUN4QztRQUNEO1lBQ0UsT0FBTyxFQUFFLDBCQUEwQjtTQUNwQztRQUNEO1lBQ0UsT0FBTyxFQUFFLDJCQUEyQjtTQUNyQztRQUNEO1lBQ0UsT0FBTyxFQUFFLGlDQUFpQztTQUMzQztRQUNEO1lBQ0UsT0FBTyxFQUFFLHdCQUF3QjtTQUNsQztRQUNEO1lBQ0UsT0FBTyxFQUFFLHdCQUF3QjtTQUNsQztRQUNEO1lBQ0UsT0FBTyxFQUFFLGtDQUFrQztTQUM1QztRQUNEO1lBQ0UsT0FBTyxFQUFFLGdDQUFnQztTQUMxQztLQUNGO0lBQ0QsT0FBTyxFQUFFO0lBQ1AsNkRBQTZEO0lBQzdELElBQUk7SUFDSixxQ0FBcUM7SUFDckMsZUFBZTtJQUNmLDZDQUE2QztJQUM3Qyx3REFBd0Q7SUFDeEQsa0VBQWtFO0lBQ2xFLE9BQU87SUFDUCxLQUFLO0tBQ047Q0FDRixDQUFDLENBQUEifQ==