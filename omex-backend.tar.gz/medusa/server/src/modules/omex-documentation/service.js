"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class DocumentationService extends (0, utils_1.MedusaService)({}) {
    /**
     * Create a technical document
     */
    async createDocument(data) {
        if (!data.title || !data.document_type || !data.file_url) {
            throw new Error("Title, document type, and file URL are required");
        }
        const validTypes = ["datasheet", "manual", "guide", "warranty", "certification", "catalog"];
        if (!validTypes.includes(data.document_type)) {
            throw new Error(`Invalid document type. Must be one of: ${validTypes.join(", ")}`);
        }
        const documentData = {
            id: `doc_${Date.now()}`,
            manufacturer_id: data.manufacturer_id,
            title: data.title,
            document_type: data.document_type,
            file_url: data.file_url,
            file_size: data.file_size,
            mime_type: data.mime_type || this.detectMimeType(data.file_url),
            products: data.products || [],
            created_at: new Date(),
            updated_at: new Date(),
        };
        // In real implementation, save to database
        return documentData;
    }
    /**
     * Update a technical document
     */
    async updateDocument(documentId, data) {
        if (!documentId) {
            throw new Error("Document ID is required");
        }
        // In real implementation, update in database
        return {
            id: documentId,
            ...data,
            updated_at: new Date(),
        };
    }
    /**
     * Get documents for a product
     */
    async getProductDocuments(productId) {
        if (!productId) {
            throw new Error("Product ID is required");
        }
        // In real implementation, query documents where products array contains productId
        // Using PostgreSQL: WHERE products @> '["product_id"]'::jsonb
        return [];
    }
    /**
     * Get documents for a manufacturer
     */
    async getManufacturerDocuments(manufacturerId, documentType) {
        if (!manufacturerId) {
            throw new Error("Manufacturer ID is required");
        }
        const conditions = [`manufacturer_id = '${manufacturerId}'`];
        if (documentType) {
            conditions.push(`document_type = '${documentType}'`);
        }
        // In real implementation, query database
        return [];
    }
    /**
     * Associate document with products
     */
    async associateWithProducts(documentId, productIds) {
        if (!documentId || !productIds || productIds.length === 0) {
            throw new Error("Document ID and product IDs are required");
        }
        // In real implementation, update document's products array
        return {
            document_id: documentId,
            products: productIds,
            updated_at: new Date(),
        };
    }
    /**
     * Remove document association from products
     */
    async removeFromProducts(documentId, productIds) {
        if (!documentId || !productIds || productIds.length === 0) {
            throw new Error("Document ID and product IDs are required");
        }
        // In real implementation, remove product IDs from document's products array
        return {
            document_id: documentId,
            removed_products: productIds,
            updated_at: new Date(),
        };
    }
    /**
     * Upload document (placeholder for file upload logic)
     */
    async uploadDocument(file, filename, manufacturerId) {
        if (!file || !filename) {
            throw new Error("File and filename are required");
        }
        // In real implementation:
        // 1. Upload file to S3 or local storage
        // 2. Get file URL
        // 3. Create document record
        const fileUrl = `/uploads/documents/${filename}`;
        const fileSize = file.length;
        return {
            file_url: fileUrl,
            file_size: fileSize,
            mime_type: this.detectMimeType(filename),
        };
    }
    /**
     * Delete a document
     */
    async deleteDocument(documentId) {
        if (!documentId) {
            throw new Error("Document ID is required");
        }
        // In real implementation:
        // 1. Get document from database
        // 2. Delete file from storage
        // 3. Delete database record
        return {
            deleted: true,
            id: documentId,
        };
    }
    /**
     * Search documents
     */
    async searchDocuments(query, filters = {}) {
        if (!query || query.trim().length === 0) {
            throw new Error("Search query is required");
        }
        const conditions = [`title ILIKE '%${query}%'`];
        if (filters.document_type) {
            conditions.push(`document_type = '${filters.document_type}'`);
        }
        if (filters.manufacturer_id) {
            conditions.push(`manufacturer_id = '${filters.manufacturer_id}'`);
        }
        // In real implementation, query database
        return [];
    }
    /**
     * Get document statistics
     */
    async getDocumentStats(manufacturerId) {
        // In real implementation, aggregate document counts by type
        const stats = {
            total: 0,
            by_type: {
                datasheet: 0,
                manual: 0,
                guide: 0,
                warranty: 0,
                certification: 0,
                catalog: 0,
            },
            total_size: 0,
        };
        return stats;
    }
    // Helper methods
    detectMimeType(filename) {
        const ext = filename.split(".").pop()?.toLowerCase();
        const mimeTypes = {
            pdf: "application/pdf",
            doc: "application/msword",
            docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            xls: "application/vnd.ms-excel",
            xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            jpg: "image/jpeg",
            jpeg: "image/jpeg",
            png: "image/png",
            gif: "image/gif",
            zip: "application/zip",
        };
        return mimeTypes[ext || ""] || "application/octet-stream";
    }
}
exports.default = DocumentationService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL29tZXgtZG9jdW1lbnRhdGlvbi9zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEscURBQXlEO0FBY3pELE1BQU0sb0JBQXFCLFNBQVEsSUFBQSxxQkFBYSxFQUFDLEVBQUUsQ0FBQztJQUNsRDs7T0FFRztJQUNILEtBQUssQ0FBQyxjQUFjLENBQUMsSUFBdUI7UUFDMUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3pELE1BQU0sSUFBSSxLQUFLLENBQUMsaURBQWlELENBQUMsQ0FBQTtRQUNwRSxDQUFDO1FBRUQsTUFBTSxVQUFVLEdBQUcsQ0FBQyxXQUFXLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsZUFBZSxFQUFFLFNBQVMsQ0FBQyxDQUFBO1FBQzNGLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDO1lBQzdDLE1BQU0sSUFBSSxLQUFLLENBQUMsMENBQTBDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBQ3BGLENBQUM7UUFFRCxNQUFNLFlBQVksR0FBRztZQUNuQixFQUFFLEVBQUUsT0FBTyxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUU7WUFDdkIsZUFBZSxFQUFFLElBQUksQ0FBQyxlQUFlO1lBQ3JDLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztZQUNqQixhQUFhLEVBQUUsSUFBSSxDQUFDLGFBQWE7WUFDakMsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO1lBQ3ZCLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztZQUN6QixTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7WUFDL0QsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRLElBQUksRUFBRTtZQUM3QixVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUU7WUFDdEIsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFO1NBQ3ZCLENBQUE7UUFFRCwyQ0FBMkM7UUFDM0MsT0FBTyxZQUFZLENBQUE7SUFDckIsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGNBQWMsQ0FBQyxVQUFrQixFQUFFLElBQXVCO1FBQzlELElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNoQixNQUFNLElBQUksS0FBSyxDQUFDLHlCQUF5QixDQUFDLENBQUE7UUFDNUMsQ0FBQztRQUVELDZDQUE2QztRQUM3QyxPQUFPO1lBQ0wsRUFBRSxFQUFFLFVBQVU7WUFDZCxHQUFHLElBQUk7WUFDUCxVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDdkIsQ0FBQTtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxTQUFpQjtRQUN6QyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDZixNQUFNLElBQUksS0FBSyxDQUFDLHdCQUF3QixDQUFDLENBQUE7UUFDM0MsQ0FBQztRQUVELGtGQUFrRjtRQUNsRiw4REFBOEQ7UUFDOUQsT0FBTyxFQUFFLENBQUE7SUFDWCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsd0JBQXdCLENBQUMsY0FBc0IsRUFBRSxZQUFxQjtRQUMxRSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDcEIsTUFBTSxJQUFJLEtBQUssQ0FBQyw2QkFBNkIsQ0FBQyxDQUFBO1FBQ2hELENBQUM7UUFFRCxNQUFNLFVBQVUsR0FBRyxDQUFDLHNCQUFzQixjQUFjLEdBQUcsQ0FBQyxDQUFBO1FBRTVELElBQUksWUFBWSxFQUFFLENBQUM7WUFDakIsVUFBVSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsWUFBWSxHQUFHLENBQUMsQ0FBQTtRQUN0RCxDQUFDO1FBRUQseUNBQXlDO1FBQ3pDLE9BQU8sRUFBRSxDQUFBO0lBQ1gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLHFCQUFxQixDQUFDLFVBQWtCLEVBQUUsVUFBb0I7UUFDbEUsSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLFVBQVUsSUFBSSxVQUFVLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQzFELE1BQU0sSUFBSSxLQUFLLENBQUMsMENBQTBDLENBQUMsQ0FBQTtRQUM3RCxDQUFDO1FBRUQsMkRBQTJEO1FBQzNELE9BQU87WUFDTCxXQUFXLEVBQUUsVUFBVTtZQUN2QixRQUFRLEVBQUUsVUFBVTtZQUNwQixVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDdkIsQ0FBQTtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxVQUFrQixFQUFFLFVBQW9CO1FBQy9ELElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxVQUFVLElBQUksVUFBVSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUMxRCxNQUFNLElBQUksS0FBSyxDQUFDLDBDQUEwQyxDQUFDLENBQUE7UUFDN0QsQ0FBQztRQUVELDRFQUE0RTtRQUM1RSxPQUFPO1lBQ0wsV0FBVyxFQUFFLFVBQVU7WUFDdkIsZ0JBQWdCLEVBQUUsVUFBVTtZQUM1QixVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDdkIsQ0FBQTtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxjQUFjLENBQUMsSUFBWSxFQUFFLFFBQWdCLEVBQUUsY0FBdUI7UUFDMUUsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3ZCLE1BQU0sSUFBSSxLQUFLLENBQUMsZ0NBQWdDLENBQUMsQ0FBQTtRQUNuRCxDQUFDO1FBRUQsMEJBQTBCO1FBQzFCLHdDQUF3QztRQUN4QyxrQkFBa0I7UUFDbEIsNEJBQTRCO1FBRTVCLE1BQU0sT0FBTyxHQUFHLHNCQUFzQixRQUFRLEVBQUUsQ0FBQTtRQUNoRCxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFBO1FBRTVCLE9BQU87WUFDTCxRQUFRLEVBQUUsT0FBTztZQUNqQixTQUFTLEVBQUUsUUFBUTtZQUNuQixTQUFTLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUM7U0FDekMsQ0FBQTtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxjQUFjLENBQUMsVUFBa0I7UUFDckMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2hCLE1BQU0sSUFBSSxLQUFLLENBQUMseUJBQXlCLENBQUMsQ0FBQTtRQUM1QyxDQUFDO1FBRUQsMEJBQTBCO1FBQzFCLGdDQUFnQztRQUNoQyw4QkFBOEI7UUFDOUIsNEJBQTRCO1FBRTVCLE9BQU87WUFDTCxPQUFPLEVBQUUsSUFBSTtZQUNiLEVBQUUsRUFBRSxVQUFVO1NBQ2YsQ0FBQTtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxlQUFlLENBQUMsS0FBYSxFQUFFLFVBQWdFLEVBQUU7UUFDckcsSUFBSSxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ3hDLE1BQU0sSUFBSSxLQUFLLENBQUMsMEJBQTBCLENBQUMsQ0FBQTtRQUM3QyxDQUFDO1FBRUQsTUFBTSxVQUFVLEdBQUcsQ0FBQyxpQkFBaUIsS0FBSyxJQUFJLENBQUMsQ0FBQTtRQUUvQyxJQUFJLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUMxQixVQUFVLENBQUMsSUFBSSxDQUFDLG9CQUFvQixPQUFPLENBQUMsYUFBYSxHQUFHLENBQUMsQ0FBQTtRQUMvRCxDQUFDO1FBRUQsSUFBSSxPQUFPLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDNUIsVUFBVSxDQUFDLElBQUksQ0FBQyxzQkFBc0IsT0FBTyxDQUFDLGVBQWUsR0FBRyxDQUFDLENBQUE7UUFDbkUsQ0FBQztRQUVELHlDQUF5QztRQUN6QyxPQUFPLEVBQUUsQ0FBQTtJQUNYLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxjQUF1QjtRQUM1Qyw0REFBNEQ7UUFDNUQsTUFBTSxLQUFLLEdBQUc7WUFDWixLQUFLLEVBQUUsQ0FBQztZQUNSLE9BQU8sRUFBRTtnQkFDUCxTQUFTLEVBQUUsQ0FBQztnQkFDWixNQUFNLEVBQUUsQ0FBQztnQkFDVCxLQUFLLEVBQUUsQ0FBQztnQkFDUixRQUFRLEVBQUUsQ0FBQztnQkFDWCxhQUFhLEVBQUUsQ0FBQztnQkFDaEIsT0FBTyxFQUFFLENBQUM7YUFDWDtZQUNELFVBQVUsRUFBRSxDQUFDO1NBQ2QsQ0FBQTtRQUVELE9BQU8sS0FBSyxDQUFBO0lBQ2QsQ0FBQztJQUVELGlCQUFpQjtJQUVULGNBQWMsQ0FBQyxRQUFnQjtRQUNyQyxNQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLFdBQVcsRUFBRSxDQUFBO1FBRXBELE1BQU0sU0FBUyxHQUEyQjtZQUN4QyxHQUFHLEVBQUUsaUJBQWlCO1lBQ3RCLEdBQUcsRUFBRSxvQkFBb0I7WUFDekIsSUFBSSxFQUFFLHlFQUF5RTtZQUMvRSxHQUFHLEVBQUUsMEJBQTBCO1lBQy9CLElBQUksRUFBRSxtRUFBbUU7WUFDekUsR0FBRyxFQUFFLFlBQVk7WUFDakIsSUFBSSxFQUFFLFlBQVk7WUFDbEIsR0FBRyxFQUFFLFdBQVc7WUFDaEIsR0FBRyxFQUFFLFdBQVc7WUFDaEIsR0FBRyxFQUFFLGlCQUFpQjtTQUN2QixDQUFBO1FBRUQsT0FBTyxTQUFTLENBQUMsR0FBRyxJQUFJLEVBQUUsQ0FBQyxJQUFJLDBCQUEwQixDQUFBO0lBQzNELENBQUM7Q0FDRjtBQUVELGtCQUFlLG9CQUFvQixDQUFBIn0=