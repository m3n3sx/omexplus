"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class LoyaltyService extends (0, utils_1.MedusaService)({}) {
    async addPoints(customerId, points, reason) {
        return {
            customerId,
            points,
            reason,
            createdAt: new Date(),
        };
    }
    async getPoints(customerId) {
        return { customerId, totalPoints: 0 };
    }
    async redeemPoints(customerId, points) {
        return { success: true, remainingPoints: 0 };
    }
}
exports.default = LoyaltyService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL2xveWFsdHkvc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHFEQUF5RDtBQUV6RCxNQUFNLGNBQWUsU0FBUSxJQUFBLHFCQUFhLEVBQUMsRUFBRSxDQUFDO0lBQzVDLEtBQUssQ0FBQyxTQUFTLENBQUMsVUFBa0IsRUFBRSxNQUFjLEVBQUUsTUFBYztRQUNoRSxPQUFPO1lBQ0wsVUFBVTtZQUNWLE1BQU07WUFDTixNQUFNO1lBQ04sU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFO1NBQ3RCLENBQUE7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLFNBQVMsQ0FBQyxVQUFrQjtRQUNoQyxPQUFPLEVBQUUsVUFBVSxFQUFFLFdBQVcsRUFBRSxDQUFDLEVBQUUsQ0FBQTtJQUN2QyxDQUFDO0lBRUQsS0FBSyxDQUFDLFlBQVksQ0FBQyxVQUFrQixFQUFFLE1BQWM7UUFDbkQsT0FBTyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFLENBQUMsRUFBRSxDQUFBO0lBQzlDLENBQUM7Q0FDRjtBQUVELGtCQUFlLGNBQWMsQ0FBQSJ9