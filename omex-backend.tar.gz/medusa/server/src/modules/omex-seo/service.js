"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class SEOService extends (0, utils_1.MedusaService)({}) {
    constructor() {
        super(...arguments);
        this.BASE_URL = process.env.STORE_URL || "https://omex.pl";
    }
    /**
     * Generate SEO meta tags for a product
     */
    async generateMetaTags(product) {
        const title = this.truncate(product.title || product.name, 60);
        const description = this.truncate(product.description || "", 160);
        return {
            meta_title: `${title} | OMEX`,
            meta_description: description,
            meta_keywords: this.extractKeywords(product),
            og_title: title,
            og_description: description,
            og_image: product.thumbnail || product.image_url,
            canonical_url: this.generateCanonicalUrl(product),
        };
    }
    /**
     * Generate canonical URL for a product
     */
    generateCanonicalUrl(product) {
        const slug = product.slug || this.slugify(product.title || product.name);
        const category = product.category_slug || "produkty";
        return `${this.BASE_URL}/${category}/${slug}`;
    }
    /**
     * Generate structured data (JSON-LD) for Google Rich Snippets
     */
    generateStructuredData(product) {
        const structuredData = {
            "@context": "https://schema.org",
            "@type": "Product",
            name: product.title || product.name,
            description: product.description,
            image: product.thumbnail || product.image_url,
            sku: product.sku,
        };
        // Add brand if available
        if (product.manufacturer_name || product.brand) {
            structuredData.brand = {
                "@type": "Brand",
                name: product.manufacturer_name || product.brand,
            };
        }
        // Add offers (price)
        if (product.price !== undefined) {
            structuredData.offers = {
                "@type": "Offer",
                price: product.price,
                priceCurrency: "PLN",
                availability: product.stock_available > 0
                    ? "https://schema.org/InStock"
                    : "https://schema.org/OutOfStock",
                url: this.generateCanonicalUrl(product),
            };
        }
        return structuredData;
    }
    /**
     * Validate meta tags
     */
    validateMetaTags(metaTags) {
        const warnings = [];
        if (!metaTags.meta_title) {
            warnings.push("Missing meta_title");
        }
        else if (metaTags.meta_title.length > 60) {
            warnings.push(`meta_title too long (${metaTags.meta_title.length} chars, max 60)`);
        }
        if (!metaTags.meta_description) {
            warnings.push("Missing meta_description");
        }
        else if (metaTags.meta_description.length > 160) {
            warnings.push(`meta_description too long (${metaTags.meta_description.length} chars, max 160)`);
        }
        if (!metaTags.canonical_url) {
            warnings.push("Missing canonical_url");
        }
        if (!metaTags.og_title) {
            warnings.push("Missing og_title (Open Graph)");
        }
        if (!metaTags.og_description) {
            warnings.push("Missing og_description (Open Graph)");
        }
        if (!metaTags.og_image) {
            warnings.push("Missing og_image (Open Graph)");
        }
        return {
            valid: warnings.length === 0,
            warnings,
        };
    }
    /**
     * Generate sitemap.xml for all products
     */
    async generateSitemap(options = {}) {
        const { includeCategories = true, includeManufacturers = true } = options;
        let sitemap = '<?xml version="1.0" encoding="UTF-8"?>\n';
        sitemap += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
        // Add homepage
        sitemap += this.generateSitemapUrl(this.BASE_URL, new Date(), "daily", "1.0");
        // Add products
        // In real implementation, fetch all products from database
        const products = []; // Would be populated from query
        for (const product of products) {
            const url = this.generateCanonicalUrl(product);
            sitemap += this.generateSitemapUrl(url, product.updated_at, "weekly", "0.8");
        }
        // Add categories
        if (includeCategories) {
            const categories = []; // Would be populated from query
            for (const category of categories) {
                const url = `${this.BASE_URL}/kategoria/${category.slug}`;
                sitemap += this.generateSitemapUrl(url, category.updated_at, "weekly", "0.7");
            }
        }
        // Add manufacturers
        if (includeManufacturers) {
            const manufacturers = []; // Would be populated from query
            for (const manufacturer of manufacturers) {
                const url = `${this.BASE_URL}/producent/${manufacturer.slug}`;
                sitemap += this.generateSitemapUrl(url, manufacturer.updated_at, "monthly", "0.6");
            }
        }
        sitemap += '</urlset>';
        return sitemap;
    }
    /**
     * Generate robots.txt
     */
    generateRobotsTxt() {
        return `User-agent: *
Allow: /
Disallow: /admin/
Disallow: /api/
Disallow: /checkout/
Disallow: /account/

Sitemap: ${this.BASE_URL}/sitemap.xml
`;
    }
    /**
     * Update SEO fields for a product
     */
    async updateProductSEO(productId, seoData) {
        if (!productId) {
            throw new Error("Product ID is required");
        }
        // Validate meta tags
        const validation = this.validateMetaTags(seoData);
        if (!validation.valid) {
            console.warn("SEO validation warnings:", validation.warnings);
        }
        // In real implementation, update product in database
        return {
            product_id: productId,
            ...seoData,
            updated_at: new Date(),
        };
    }
    /**
     * Auto-generate SEO fields for products without them
     */
    async autoGenerateSEO(productId) {
        if (!productId) {
            throw new Error("Product ID is required");
        }
        // In real implementation, fetch product from database
        const product = {}; // Would be populated from query
        const metaTags = await this.generateMetaTags(product);
        const structuredData = this.generateStructuredData(product);
        return this.updateProductSEO(productId, {
            ...metaTags,
            structured_data: structuredData,
        });
    }
    // Helper methods
    truncate(text, maxLength) {
        if (text.length <= maxLength) {
            return text;
        }
        return text.substring(0, maxLength - 3) + "...";
    }
    slugify(text) {
        return text
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, "-")
            .replace(/^-+|-+$/g, "");
    }
    extractKeywords(product) {
        const keywords = [];
        if (product.title) {
            keywords.push(...product.title.split(/\s+/).filter((w) => w.length > 3));
        }
        if (product.category_name) {
            keywords.push(product.category_name);
        }
        if (product.manufacturer_name) {
            keywords.push(product.manufacturer_name);
        }
        if (product.equipment_type) {
            keywords.push(product.equipment_type);
        }
        // Remove duplicates and limit to 10
        return [...new Set(keywords)].slice(0, 10);
    }
    generateSitemapUrl(url, lastmod, changefreq, priority) {
        return `  <url>
    <loc>${url}</loc>
    <lastmod>${lastmod.toISOString().split("T")[0]}</lastmod>
    <changefreq>${changefreq}</changefreq>
    <priority>${priority}</priority>
  </url>\n`;
    }
}
exports.default = SEOService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL29tZXgtc2VvL3NlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBeUQ7QUFnQ3pELE1BQU0sVUFBVyxTQUFRLElBQUEscUJBQWEsRUFBQyxFQUFFLENBQUM7SUFBMUM7O1FBQ21CLGFBQVEsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsSUFBSSxpQkFBaUIsQ0FBQTtJQW1ReEUsQ0FBQztJQWpRQzs7T0FFRztJQUNILEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFZO1FBQ2pDLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssSUFBSSxPQUFPLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFBO1FBQzlELE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFdBQVcsSUFBSSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUE7UUFFakUsT0FBTztZQUNMLFVBQVUsRUFBRSxHQUFHLEtBQUssU0FBUztZQUM3QixnQkFBZ0IsRUFBRSxXQUFXO1lBQzdCLGFBQWEsRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQztZQUM1QyxRQUFRLEVBQUUsS0FBSztZQUNmLGNBQWMsRUFBRSxXQUFXO1lBQzNCLFFBQVEsRUFBRSxPQUFPLENBQUMsU0FBUyxJQUFJLE9BQU8sQ0FBQyxTQUFTO1lBQ2hELGFBQWEsRUFBRSxJQUFJLENBQUMsb0JBQW9CLENBQUMsT0FBTyxDQUFDO1NBQ2xELENBQUE7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxvQkFBb0IsQ0FBQyxPQUFZO1FBQy9CLE1BQU0sSUFBSSxHQUFHLE9BQU8sQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxJQUFJLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQTtRQUN4RSxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsYUFBYSxJQUFJLFVBQVUsQ0FBQTtRQUVwRCxPQUFPLEdBQUcsSUFBSSxDQUFDLFFBQVEsSUFBSSxRQUFRLElBQUksSUFBSSxFQUFFLENBQUE7SUFDL0MsQ0FBQztJQUVEOztPQUVHO0lBQ0gsc0JBQXNCLENBQUMsT0FBWTtRQUNqQyxNQUFNLGNBQWMsR0FBMEI7WUFDNUMsVUFBVSxFQUFFLG9CQUFvQjtZQUNoQyxPQUFPLEVBQUUsU0FBUztZQUNsQixJQUFJLEVBQUUsT0FBTyxDQUFDLEtBQUssSUFBSSxPQUFPLENBQUMsSUFBSTtZQUNuQyxXQUFXLEVBQUUsT0FBTyxDQUFDLFdBQVc7WUFDaEMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxTQUFTLElBQUksT0FBTyxDQUFDLFNBQVM7WUFDN0MsR0FBRyxFQUFFLE9BQU8sQ0FBQyxHQUFHO1NBQ2pCLENBQUE7UUFFRCx5QkFBeUI7UUFDekIsSUFBSSxPQUFPLENBQUMsaUJBQWlCLElBQUksT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQy9DLGNBQWMsQ0FBQyxLQUFLLEdBQUc7Z0JBQ3JCLE9BQU8sRUFBRSxPQUFPO2dCQUNoQixJQUFJLEVBQUUsT0FBTyxDQUFDLGlCQUFpQixJQUFJLE9BQU8sQ0FBQyxLQUFLO2FBQ2pELENBQUE7UUFDSCxDQUFDO1FBRUQscUJBQXFCO1FBQ3JCLElBQUksT0FBTyxDQUFDLEtBQUssS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUNoQyxjQUFjLENBQUMsTUFBTSxHQUFHO2dCQUN0QixPQUFPLEVBQUUsT0FBTztnQkFDaEIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLO2dCQUNwQixhQUFhLEVBQUUsS0FBSztnQkFDcEIsWUFBWSxFQUFFLE9BQU8sQ0FBQyxlQUFlLEdBQUcsQ0FBQztvQkFDdkMsQ0FBQyxDQUFDLDRCQUE0QjtvQkFDOUIsQ0FBQyxDQUFDLCtCQUErQjtnQkFDbkMsR0FBRyxFQUFFLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLENBQUM7YUFDeEMsQ0FBQTtRQUNILENBQUM7UUFFRCxPQUFPLGNBQWMsQ0FBQTtJQUN2QixDQUFDO0lBRUQ7O09BRUc7SUFDSCxnQkFBZ0IsQ0FBQyxRQUFxQjtRQUNwQyxNQUFNLFFBQVEsR0FBYSxFQUFFLENBQUE7UUFFN0IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUN6QixRQUFRLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLENBQUE7UUFDckMsQ0FBQzthQUFNLElBQUksUUFBUSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsRUFBRSxFQUFFLENBQUM7WUFDM0MsUUFBUSxDQUFDLElBQUksQ0FBQyx3QkFBd0IsUUFBUSxDQUFDLFVBQVUsQ0FBQyxNQUFNLGlCQUFpQixDQUFDLENBQUE7UUFDcEYsQ0FBQztRQUVELElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUMvQixRQUFRLENBQUMsSUFBSSxDQUFDLDBCQUEwQixDQUFDLENBQUE7UUFDM0MsQ0FBQzthQUFNLElBQUksUUFBUSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sR0FBRyxHQUFHLEVBQUUsQ0FBQztZQUNsRCxRQUFRLENBQUMsSUFBSSxDQUFDLDhCQUE4QixRQUFRLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxrQkFBa0IsQ0FBQyxDQUFBO1FBQ2pHLENBQUM7UUFFRCxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQzVCLFFBQVEsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQTtRQUN4QyxDQUFDO1FBRUQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUN2QixRQUFRLENBQUMsSUFBSSxDQUFDLCtCQUErQixDQUFDLENBQUE7UUFDaEQsQ0FBQztRQUVELElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDN0IsUUFBUSxDQUFDLElBQUksQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFBO1FBQ3RELENBQUM7UUFFRCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3ZCLFFBQVEsQ0FBQyxJQUFJLENBQUMsK0JBQStCLENBQUMsQ0FBQTtRQUNoRCxDQUFDO1FBRUQsT0FBTztZQUNMLEtBQUssRUFBRSxRQUFRLENBQUMsTUFBTSxLQUFLLENBQUM7WUFDNUIsUUFBUTtTQUNULENBQUE7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsZUFBZSxDQUFDLFVBQTJFLEVBQUU7UUFDakcsTUFBTSxFQUFFLGlCQUFpQixHQUFHLElBQUksRUFBRSxvQkFBb0IsR0FBRyxJQUFJLEVBQUUsR0FBRyxPQUFPLENBQUE7UUFFekUsSUFBSSxPQUFPLEdBQUcsMENBQTBDLENBQUE7UUFDeEQsT0FBTyxJQUFJLGdFQUFnRSxDQUFBO1FBRTNFLGVBQWU7UUFDZixPQUFPLElBQUksSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxJQUFJLEVBQUUsRUFBRSxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFN0UsZUFBZTtRQUNmLDJEQUEyRDtRQUMzRCxNQUFNLFFBQVEsR0FBVSxFQUFFLENBQUEsQ0FBQyxnQ0FBZ0M7UUFDM0QsS0FBSyxNQUFNLE9BQU8sSUFBSSxRQUFRLEVBQUUsQ0FBQztZQUMvQixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsT0FBTyxDQUFDLENBQUE7WUFDOUMsT0FBTyxJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLFVBQVUsRUFBRSxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDOUUsQ0FBQztRQUVELGlCQUFpQjtRQUNqQixJQUFJLGlCQUFpQixFQUFFLENBQUM7WUFDdEIsTUFBTSxVQUFVLEdBQVUsRUFBRSxDQUFBLENBQUMsZ0NBQWdDO1lBQzdELEtBQUssTUFBTSxRQUFRLElBQUksVUFBVSxFQUFFLENBQUM7Z0JBQ2xDLE1BQU0sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFFBQVEsY0FBYyxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUE7Z0JBQ3pELE9BQU8sSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxFQUFFLFFBQVEsQ0FBQyxVQUFVLEVBQUUsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFBO1lBQy9FLENBQUM7UUFDSCxDQUFDO1FBRUQsb0JBQW9CO1FBQ3BCLElBQUksb0JBQW9CLEVBQUUsQ0FBQztZQUN6QixNQUFNLGFBQWEsR0FBVSxFQUFFLENBQUEsQ0FBQyxnQ0FBZ0M7WUFDaEUsS0FBSyxNQUFNLFlBQVksSUFBSSxhQUFhLEVBQUUsQ0FBQztnQkFDekMsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsUUFBUSxjQUFjLFlBQVksQ0FBQyxJQUFJLEVBQUUsQ0FBQTtnQkFDN0QsT0FBTyxJQUFJLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLEVBQUUsWUFBWSxDQUFDLFVBQVUsRUFBRSxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUE7WUFDcEYsQ0FBQztRQUNILENBQUM7UUFFRCxPQUFPLElBQUksV0FBVyxDQUFBO1FBRXRCLE9BQU8sT0FBTyxDQUFBO0lBQ2hCLENBQUM7SUFFRDs7T0FFRztJQUNILGlCQUFpQjtRQUNmLE9BQU87Ozs7Ozs7V0FPQSxJQUFJLENBQUMsUUFBUTtDQUN2QixDQUFBO0lBQ0MsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGdCQUFnQixDQUFDLFNBQWlCLEVBQUUsT0FBb0I7UUFDNUQsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ2YsTUFBTSxJQUFJLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxDQUFBO1FBQzNDLENBQUM7UUFFRCxxQkFBcUI7UUFDckIsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFBO1FBQ2pELElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDdEIsT0FBTyxDQUFDLElBQUksQ0FBQywwQkFBMEIsRUFBRSxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUE7UUFDL0QsQ0FBQztRQUVELHFEQUFxRDtRQUNyRCxPQUFPO1lBQ0wsVUFBVSxFQUFFLFNBQVM7WUFDckIsR0FBRyxPQUFPO1lBQ1YsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFO1NBQ3ZCLENBQUE7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsZUFBZSxDQUFDLFNBQWlCO1FBQ3JDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUNmLE1BQU0sSUFBSSxLQUFLLENBQUMsd0JBQXdCLENBQUMsQ0FBQTtRQUMzQyxDQUFDO1FBRUQsc0RBQXNEO1FBQ3RELE1BQU0sT0FBTyxHQUFRLEVBQUUsQ0FBQSxDQUFDLGdDQUFnQztRQUV4RCxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQTtRQUNyRCxNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLENBQUE7UUFFM0QsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFFO1lBQ3RDLEdBQUcsUUFBUTtZQUNYLGVBQWUsRUFBRSxjQUFxQjtTQUN2QyxDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsaUJBQWlCO0lBRVQsUUFBUSxDQUFDLElBQVksRUFBRSxTQUFpQjtRQUM5QyxJQUFJLElBQUksQ0FBQyxNQUFNLElBQUksU0FBUyxFQUFFLENBQUM7WUFDN0IsT0FBTyxJQUFJLENBQUE7UUFDYixDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxTQUFTLEdBQUcsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFBO0lBQ2pELENBQUM7SUFFTyxPQUFPLENBQUMsSUFBWTtRQUMxQixPQUFPLElBQUk7YUFDUixXQUFXLEVBQUU7YUFDYixPQUFPLENBQUMsYUFBYSxFQUFFLEdBQUcsQ0FBQzthQUMzQixPQUFPLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQyxDQUFBO0lBQzVCLENBQUM7SUFFTyxlQUFlLENBQUMsT0FBWTtRQUNsQyxNQUFNLFFBQVEsR0FBYSxFQUFFLENBQUE7UUFFN0IsSUFBSSxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDbEIsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQVMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBQ2xGLENBQUM7UUFFRCxJQUFJLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUMxQixRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQTtRQUN0QyxDQUFDO1FBRUQsSUFBSSxPQUFPLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztZQUM5QixRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFBO1FBQzFDLENBQUM7UUFFRCxJQUFJLE9BQU8sQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUMzQixRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQTtRQUN2QyxDQUFDO1FBRUQsb0NBQW9DO1FBQ3BDLE9BQU8sQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQTtJQUM1QyxDQUFDO0lBRU8sa0JBQWtCLENBQ3hCLEdBQVcsRUFDWCxPQUFhLEVBQ2IsVUFBa0IsRUFDbEIsUUFBZ0I7UUFFaEIsT0FBTztXQUNBLEdBQUc7ZUFDQyxPQUFPLENBQUMsV0FBVyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztrQkFDaEMsVUFBVTtnQkFDWixRQUFRO1dBQ2IsQ0FBQTtJQUNULENBQUM7Q0FDRjtBQUVELGtCQUFlLFVBQVUsQ0FBQSJ9