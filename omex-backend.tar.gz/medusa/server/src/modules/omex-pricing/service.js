"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class OmexPricingService extends (0, utils_1.MedusaService)({}) {
    async getPrice(productId, customerType, quantity) {
        if (!productId) {
            throw new Error("Product ID is required");
        }
        if (quantity < 1) {
            throw new Error("Quantity must be at least 1");
        }
        // In real implementation, fetch price tiers from database
        const tiers = await this.getPriceTiers(productId, customerType);
        // Find applicable tier based on quantity
        const applicableTier = this.findApplicableTier(tiers, quantity);
        if (!applicableTier) {
            throw new Error(`No price tier found for product ${productId}, customer type ${customerType}, quantity ${quantity}`);
        }
        return {
            amount: applicableTier.price,
            currency: 'PLN',
            customer_type: customerType,
            quantity,
        };
    }
    async setTieredPricing(productId, tiers) {
        if (!productId) {
            throw new Error("Product ID is required");
        }
        if (!tiers || tiers.length === 0) {
            throw new Error("At least one price tier is required");
        }
        // Validate tiers
        for (const tier of tiers) {
            if (tier.quantity_min < 1) {
                throw new Error("Minimum quantity must be at least 1");
            }
            if (tier.quantity_max && tier.quantity_max < tier.quantity_min) {
                throw new Error("Maximum quantity must be greater than minimum quantity");
            }
            if (tier.price <= 0) {
                throw new Error("Price must be greater than 0");
            }
        }
        // Check for overlapping tiers
        this.validateNoOverlaps(tiers);
        return {
            product_id: productId,
            tiers,
            updated_at: new Date(),
        };
    }
    async calculateCartTotal(cart, customerType) {
        if (!cart || !cart.items || cart.items.length === 0) {
            return {
                subtotal: 0,
                tax: 0,
                shipping: 0,
                total: 0,
            };
        }
        let subtotal = 0;
        for (const item of cart.items) {
            const price = await this.getPrice(item.product_id, customerType, item.quantity);
            subtotal += price.amount * item.quantity;
        }
        // Apply wholesale discount if applicable
        if (customerType === 'wholesale') {
            subtotal = this.applyWholesaleDiscount(subtotal);
        }
        const tax = subtotal * 0.23; // 23% VAT in Poland
        const shipping = this.calculateShipping(cart);
        return {
            subtotal,
            tax,
            shipping,
            total: subtotal + tax + shipping,
        };
    }
    async applyDiscount(amount, discountCode) {
        if (!discountCode) {
            return amount;
        }
        // In real implementation, fetch discount from database
        // For now, return original amount
        return amount;
    }
    async getPriceTiers(productId, customerType) {
        // In real implementation, fetch from price_tier table
        // WHERE product_id = productId AND customer_type = customerType
        return [];
    }
    findApplicableTier(tiers, quantity) {
        for (const tier of tiers) {
            const meetsMin = quantity >= tier.quantity_min;
            const meetsMax = !tier.quantity_max || quantity <= tier.quantity_max;
            if (meetsMin && meetsMax) {
                return tier;
            }
        }
        return null;
    }
    validateNoOverlaps(tiers) {
        // Sort tiers by quantity_min
        const sorted = [...tiers].sort((a, b) => a.quantity_min - b.quantity_min);
        for (let i = 0; i < sorted.length - 1; i++) {
            const current = sorted[i];
            const next = sorted[i + 1];
            if (current.quantity_max && current.quantity_max >= next.quantity_min) {
                throw new Error(`Overlapping price tiers: [${current.quantity_min}-${current.quantity_max}] and [${next.quantity_min}-${next.quantity_max || '∞'}]`);
            }
        }
    }
    applyWholesaleDiscount(amount) {
        // Apply 10% wholesale discount
        return amount * 0.9;
    }
    calculateShipping(cart) {
        // Simple shipping calculation
        // In real implementation, integrate with shipping providers
        return 15; // Fixed 15 PLN shipping
    }
}
exports.default = OmexPricingService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL29tZXgtcHJpY2luZy9zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEscURBQXlEO0FBa0J6RCxNQUFNLGtCQUFtQixTQUFRLElBQUEscUJBQWEsRUFBQyxFQUFFLENBQUM7SUFDaEQsS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFpQixFQUFFLFlBQTBCLEVBQUUsUUFBZ0I7UUFDNUUsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ2YsTUFBTSxJQUFJLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxDQUFBO1FBQzNDLENBQUM7UUFFRCxJQUFJLFFBQVEsR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNqQixNQUFNLElBQUksS0FBSyxDQUFDLDZCQUE2QixDQUFDLENBQUE7UUFDaEQsQ0FBQztRQUVELDBEQUEwRDtRQUMxRCxNQUFNLEtBQUssR0FBRyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFBO1FBRS9ELHlDQUF5QztRQUN6QyxNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxDQUFBO1FBRS9ELElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUNwQixNQUFNLElBQUksS0FBSyxDQUFDLG1DQUFtQyxTQUFTLG1CQUFtQixZQUFZLGNBQWMsUUFBUSxFQUFFLENBQUMsQ0FBQTtRQUN0SCxDQUFDO1FBRUQsT0FBTztZQUNMLE1BQU0sRUFBRSxjQUFjLENBQUMsS0FBSztZQUM1QixRQUFRLEVBQUUsS0FBSztZQUNmLGFBQWEsRUFBRSxZQUFZO1lBQzNCLFFBQVE7U0FDVCxDQUFBO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFpQixFQUFFLEtBQWtCO1FBQzFELElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUNmLE1BQU0sSUFBSSxLQUFLLENBQUMsd0JBQXdCLENBQUMsQ0FBQTtRQUMzQyxDQUFDO1FBRUQsSUFBSSxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ2pDLE1BQU0sSUFBSSxLQUFLLENBQUMscUNBQXFDLENBQUMsQ0FBQTtRQUN4RCxDQUFDO1FBRUQsaUJBQWlCO1FBQ2pCLEtBQUssTUFBTSxJQUFJLElBQUksS0FBSyxFQUFFLENBQUM7WUFDekIsSUFBSSxJQUFJLENBQUMsWUFBWSxHQUFHLENBQUMsRUFBRSxDQUFDO2dCQUMxQixNQUFNLElBQUksS0FBSyxDQUFDLHFDQUFxQyxDQUFDLENBQUE7WUFDeEQsQ0FBQztZQUVELElBQUksSUFBSSxDQUFDLFlBQVksSUFBSSxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDL0QsTUFBTSxJQUFJLEtBQUssQ0FBQyx3REFBd0QsQ0FBQyxDQUFBO1lBQzNFLENBQUM7WUFFRCxJQUFJLElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxFQUFFLENBQUM7Z0JBQ3BCLE1BQU0sSUFBSSxLQUFLLENBQUMsOEJBQThCLENBQUMsQ0FBQTtZQUNqRCxDQUFDO1FBQ0gsQ0FBQztRQUVELDhCQUE4QjtRQUM5QixJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUE7UUFFOUIsT0FBTztZQUNMLFVBQVUsRUFBRSxTQUFTO1lBQ3JCLEtBQUs7WUFDTCxVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDdkIsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBUyxFQUFFLFlBQTBCO1FBQzVELElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ3BELE9BQU87Z0JBQ0wsUUFBUSxFQUFFLENBQUM7Z0JBQ1gsR0FBRyxFQUFFLENBQUM7Z0JBQ04sUUFBUSxFQUFFLENBQUM7Z0JBQ1gsS0FBSyxFQUFFLENBQUM7YUFDVCxDQUFBO1FBQ0gsQ0FBQztRQUVELElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQTtRQUVoQixLQUFLLE1BQU0sSUFBSSxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUM5QixNQUFNLEtBQUssR0FBRyxNQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxZQUFZLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFBO1lBQy9FLFFBQVEsSUFBSSxLQUFLLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUE7UUFDMUMsQ0FBQztRQUVELHlDQUF5QztRQUN6QyxJQUFJLFlBQVksS0FBSyxXQUFXLEVBQUUsQ0FBQztZQUNqQyxRQUFRLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFFBQVEsQ0FBQyxDQUFBO1FBQ2xELENBQUM7UUFFRCxNQUFNLEdBQUcsR0FBRyxRQUFRLEdBQUcsSUFBSSxDQUFBLENBQUMsb0JBQW9CO1FBQ2hELE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQTtRQUU3QyxPQUFPO1lBQ0wsUUFBUTtZQUNSLEdBQUc7WUFDSCxRQUFRO1lBQ1IsS0FBSyxFQUFFLFFBQVEsR0FBRyxHQUFHLEdBQUcsUUFBUTtTQUNqQyxDQUFBO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxhQUFhLENBQUMsTUFBYyxFQUFFLFlBQW9CO1FBQ3RELElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUNsQixPQUFPLE1BQU0sQ0FBQTtRQUNmLENBQUM7UUFFRCx1REFBdUQ7UUFDdkQsa0NBQWtDO1FBQ2xDLE9BQU8sTUFBTSxDQUFBO0lBQ2YsQ0FBQztJQUVPLEtBQUssQ0FBQyxhQUFhLENBQUMsU0FBaUIsRUFBRSxZQUEwQjtRQUN2RSxzREFBc0Q7UUFDdEQsZ0VBQWdFO1FBQ2hFLE9BQU8sRUFBRSxDQUFBO0lBQ1gsQ0FBQztJQUVPLGtCQUFrQixDQUFDLEtBQWtCLEVBQUUsUUFBZ0I7UUFDN0QsS0FBSyxNQUFNLElBQUksSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUN6QixNQUFNLFFBQVEsR0FBRyxRQUFRLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQTtZQUM5QyxNQUFNLFFBQVEsR0FBRyxDQUFDLElBQUksQ0FBQyxZQUFZLElBQUksUUFBUSxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUE7WUFFcEUsSUFBSSxRQUFRLElBQUksUUFBUSxFQUFFLENBQUM7Z0JBQ3pCLE9BQU8sSUFBSSxDQUFBO1lBQ2IsQ0FBQztRQUNILENBQUM7UUFFRCxPQUFPLElBQUksQ0FBQTtJQUNiLENBQUM7SUFFTyxrQkFBa0IsQ0FBQyxLQUFrQjtRQUMzQyw2QkFBNkI7UUFDN0IsTUFBTSxNQUFNLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFBO1FBRXpFLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQzNDLE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUN6QixNQUFNLElBQUksR0FBRyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFBO1lBRTFCLElBQUksT0FBTyxDQUFDLFlBQVksSUFBSSxPQUFPLENBQUMsWUFBWSxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDdEUsTUFBTSxJQUFJLEtBQUssQ0FDYiw2QkFBNkIsT0FBTyxDQUFDLFlBQVksSUFBSSxPQUFPLENBQUMsWUFBWSxVQUFVLElBQUksQ0FBQyxZQUFZLElBQUksSUFBSSxDQUFDLFlBQVksSUFBSSxHQUFHLEdBQUcsQ0FDcEksQ0FBQTtZQUNILENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVPLHNCQUFzQixDQUFDLE1BQWM7UUFDM0MsK0JBQStCO1FBQy9CLE9BQU8sTUFBTSxHQUFHLEdBQUcsQ0FBQTtJQUNyQixDQUFDO0lBRU8saUJBQWlCLENBQUMsSUFBUztRQUNqQyw4QkFBOEI7UUFDOUIsNERBQTREO1FBQzVELE9BQU8sRUFBRSxDQUFBLENBQUMsd0JBQXdCO0lBQ3BDLENBQUM7Q0FDRjtBQUVELGtCQUFlLGtCQUFrQixDQUFBIn0=