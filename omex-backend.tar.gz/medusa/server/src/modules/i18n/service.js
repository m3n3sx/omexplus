"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUPPORTED_LANGUAGES = void 0;
const utils_1 = require("@medusajs/framework/utils");
exports.SUPPORTED_LANGUAGES = {
    pl: { name: "Polski", nativeName: "Polski", flag: "🇵🇱" },
    en: { name: "English", nativeName: "English", flag: "🇬🇧" },
    de: { name: "German", nativeName: "Deutsch", flag: "🇩🇪" },
    uk: { name: "Ukrainian", nativeName: "Українська", flag: "🇺🇦" },
};
class I18nService extends (0, utils_1.MedusaService)({}) {
    async getTranslations(locale, namespace) {
        // Pobierz tłumaczenia dla danego języka
        return {};
    }
    async setTranslation(locale, key, value) {
        return { locale, key, value };
    }
    async getSupportedLanguages() {
        return exports.SUPPORTED_LANGUAGES;
    }
    async getDefaultLanguage() {
        return "pl";
    }
    async translateContent(content, targetLocale) {
        // Tłumaczenie treści CMS
        return content;
    }
    async importTranslations(locale, translations) {
        // Import tłumaczeń z pliku
        return { imported: Object.keys(translations).length };
    }
    async exportTranslations(locale, format = "json") {
        // Eksport tłumaczeń
        return {};
    }
}
exports.default = I18nService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL2kxOG4vc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxREFBeUQ7QUFFNUMsUUFBQSxtQkFBbUIsR0FBRztJQUNqQyxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRTtJQUMxRCxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRTtJQUM1RCxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRTtJQUMzRCxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRTtDQUNsRSxDQUFBO0FBRUQsTUFBTSxXQUFZLFNBQVEsSUFBQSxxQkFBYSxFQUFDLEVBQUUsQ0FBQztJQUN6QyxLQUFLLENBQUMsZUFBZSxDQUFDLE1BQWMsRUFBRSxTQUFrQjtRQUN0RCx3Q0FBd0M7UUFDeEMsT0FBTyxFQUFFLENBQUE7SUFDWCxDQUFDO0lBRUQsS0FBSyxDQUFDLGNBQWMsQ0FBQyxNQUFjLEVBQUUsR0FBVyxFQUFFLEtBQWE7UUFDN0QsT0FBTyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLENBQUE7SUFDL0IsQ0FBQztJQUVELEtBQUssQ0FBQyxxQkFBcUI7UUFDekIsT0FBTywyQkFBbUIsQ0FBQTtJQUM1QixDQUFDO0lBRUQsS0FBSyxDQUFDLGtCQUFrQjtRQUN0QixPQUFPLElBQUksQ0FBQTtJQUNiLENBQUM7SUFFRCxLQUFLLENBQUMsZ0JBQWdCLENBQUMsT0FBWSxFQUFFLFlBQW9CO1FBQ3ZELHlCQUF5QjtRQUN6QixPQUFPLE9BQU8sQ0FBQTtJQUNoQixDQUFDO0lBRUQsS0FBSyxDQUFDLGtCQUFrQixDQUFDLE1BQWMsRUFBRSxZQUFpQjtRQUN4RCwyQkFBMkI7UUFDM0IsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFBO0lBQ3ZELENBQUM7SUFFRCxLQUFLLENBQUMsa0JBQWtCLENBQUMsTUFBYyxFQUFFLFNBQWlCLE1BQU07UUFDOUQsb0JBQW9CO1FBQ3BCLE9BQU8sRUFBRSxDQUFBO0lBQ1gsQ0FBQztDQUNGO0FBRUQsa0JBQWUsV0FBVyxDQUFBIn0=