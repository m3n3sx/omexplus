"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class OmexTranslationService extends (0, utils_1.MedusaService)({}) {
    constructor() {
        super(...arguments);
        this.SUPPORTED_LOCALES = ['pl', 'en', 'de'];
        this.DEFAULT_LOCALE = 'pl';
        this.FALLBACK_LOCALE = 'en';
    }
    async addProductTranslation(productId, locale, translation) {
        this.validateLocale(locale);
        if (!productId) {
            throw new Error("Product ID is required");
        }
        if (!translation.title) {
            throw new Error("Title is required for product translation");
        }
        return {
            id: `prod_trans_${Date.now()}`,
            product_id: productId,
            locale,
            title: translation.title,
            description: translation.description,
            created_at: new Date(),
        };
    }
    async addCategoryTranslation(categoryId, locale, translation) {
        this.validateLocale(locale);
        if (!categoryId) {
            throw new Error("Category ID is required");
        }
        if (!translation.name) {
            throw new Error("Name is required for category translation");
        }
        return {
            id: `cat_trans_${Date.now()}`,
            category_id: categoryId,
            locale,
            name: translation.name,
            description: translation.description,
            created_at: new Date(),
        };
    }
    async getProductTranslation(productId, locale) {
        this.validateLocale(locale);
        if (!productId) {
            throw new Error("Product ID is required");
        }
        // In real implementation, fetch from product_translation table
        // If not found, try fallback locale
        const translation = null; // await this.fetchProductTranslation(productId, locale)
        if (!translation && locale !== this.FALLBACK_LOCALE) {
            // Try fallback locale
            return this.getProductTranslation(productId, this.FALLBACK_LOCALE);
        }
        return translation;
    }
    async getCategoryTranslation(categoryId, locale) {
        this.validateLocale(locale);
        if (!categoryId) {
            throw new Error("Category ID is required");
        }
        // In real implementation, fetch from category_translation table
        const translation = null; // await this.fetchCategoryTranslation(categoryId, locale)
        if (!translation && locale !== this.FALLBACK_LOCALE) {
            // Try fallback locale
            return this.getCategoryTranslation(categoryId, this.FALLBACK_LOCALE);
        }
        return translation;
    }
    async validateAllLanguagesPresent(entityId, entityType) {
        // Check if translations exist for all supported locales
        const missingLocales = [];
        for (const locale of this.SUPPORTED_LOCALES) {
            let translation;
            if (entityType === 'product') {
                translation = await this.getProductTranslation(entityId, locale);
            }
            else {
                translation = await this.getCategoryTranslation(entityId, locale);
            }
            if (!translation) {
                missingLocales.push(locale);
            }
        }
        if (missingLocales.length > 0) {
            throw new Error(`Missing translations for ${entityType} ${entityId} in languages: ${missingLocales.join(', ')}`);
        }
        return true;
    }
    async bulkAddTranslations(entityId, entityType, translations) {
        const results = [];
        for (const [locale, translation] of Object.entries(translations)) {
            try {
                let result;
                if (entityType === 'product') {
                    result = await this.addProductTranslation(entityId, locale, translation);
                }
                else {
                    result = await this.addCategoryTranslation(entityId, locale, translation);
                }
                results.push(result);
            }
            catch (error) {
                console.error(`Failed to add ${locale} translation:`, error);
                throw error;
            }
        }
        return results;
    }
    validateLocale(locale) {
        if (!this.SUPPORTED_LOCALES.includes(locale)) {
            throw new Error(`Invalid locale: ${locale}. Supported locales are: ${this.SUPPORTED_LOCALES.join(', ')}`);
        }
    }
    getSupportedLocales() {
        return [...this.SUPPORTED_LOCALES];
    }
    getDefaultLocale() {
        return this.DEFAULT_LOCALE;
    }
    getFallbackLocale() {
        return this.FALLBACK_LOCALE;
    }
}
exports.default = OmexTranslationService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL29tZXgtdHJhbnNsYXRpb24vc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHFEQUF5RDtBQVV6RCxNQUFNLHNCQUF1QixTQUFRLElBQUEscUJBQWEsRUFBQyxFQUFFLENBQUM7SUFBdEQ7O1FBQ21CLHNCQUFpQixHQUFhLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQTtRQUNoRCxtQkFBYyxHQUFXLElBQUksQ0FBQTtRQUM3QixvQkFBZSxHQUFXLElBQUksQ0FBQTtJQXVKakQsQ0FBQztJQXJKQyxLQUFLLENBQUMscUJBQXFCLENBQUMsU0FBaUIsRUFBRSxNQUFjLEVBQUUsV0FBd0I7UUFDckYsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUUzQixJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDZixNQUFNLElBQUksS0FBSyxDQUFDLHdCQUF3QixDQUFDLENBQUE7UUFDM0MsQ0FBQztRQUVELElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDdkIsTUFBTSxJQUFJLEtBQUssQ0FBQywyQ0FBMkMsQ0FBQyxDQUFBO1FBQzlELENBQUM7UUFFRCxPQUFPO1lBQ0wsRUFBRSxFQUFFLGNBQWMsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO1lBQzlCLFVBQVUsRUFBRSxTQUFTO1lBQ3JCLE1BQU07WUFDTixLQUFLLEVBQUUsV0FBVyxDQUFDLEtBQUs7WUFDeEIsV0FBVyxFQUFFLFdBQVcsQ0FBQyxXQUFXO1lBQ3BDLFVBQVUsRUFBRSxJQUFJLElBQUksRUFBRTtTQUN2QixDQUFBO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxVQUFrQixFQUFFLE1BQWMsRUFBRSxXQUF3QjtRQUN2RixJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFBO1FBRTNCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNoQixNQUFNLElBQUksS0FBSyxDQUFDLHlCQUF5QixDQUFDLENBQUE7UUFDNUMsQ0FBQztRQUVELElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDdEIsTUFBTSxJQUFJLEtBQUssQ0FBQywyQ0FBMkMsQ0FBQyxDQUFBO1FBQzlELENBQUM7UUFFRCxPQUFPO1lBQ0wsRUFBRSxFQUFFLGFBQWEsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO1lBQzdCLFdBQVcsRUFBRSxVQUFVO1lBQ3ZCLE1BQU07WUFDTixJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUk7WUFDdEIsV0FBVyxFQUFFLFdBQVcsQ0FBQyxXQUFXO1lBQ3BDLFVBQVUsRUFBRSxJQUFJLElBQUksRUFBRTtTQUN2QixDQUFBO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxTQUFpQixFQUFFLE1BQWM7UUFDM0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUUzQixJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDZixNQUFNLElBQUksS0FBSyxDQUFDLHdCQUF3QixDQUFDLENBQUE7UUFDM0MsQ0FBQztRQUVELCtEQUErRDtRQUMvRCxvQ0FBb0M7UUFDcEMsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFBLENBQUMsd0RBQXdEO1FBRWpGLElBQUksQ0FBQyxXQUFXLElBQUksTUFBTSxLQUFLLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUNwRCxzQkFBc0I7WUFDdEIsT0FBTyxJQUFJLENBQUMscUJBQXFCLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQTtRQUNwRSxDQUFDO1FBRUQsT0FBTyxXQUFXLENBQUE7SUFDcEIsQ0FBQztJQUVELEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxVQUFrQixFQUFFLE1BQWM7UUFDN0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUUzQixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDaEIsTUFBTSxJQUFJLEtBQUssQ0FBQyx5QkFBeUIsQ0FBQyxDQUFBO1FBQzVDLENBQUM7UUFFRCxnRUFBZ0U7UUFDaEUsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFBLENBQUMsMERBQTBEO1FBRW5GLElBQUksQ0FBQyxXQUFXLElBQUksTUFBTSxLQUFLLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUNwRCxzQkFBc0I7WUFDdEIsT0FBTyxJQUFJLENBQUMsc0JBQXNCLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQTtRQUN0RSxDQUFDO1FBRUQsT0FBTyxXQUFXLENBQUE7SUFDcEIsQ0FBQztJQUVELEtBQUssQ0FBQywyQkFBMkIsQ0FBQyxRQUFnQixFQUFFLFVBQWtDO1FBQ3BGLHdEQUF3RDtRQUN4RCxNQUFNLGNBQWMsR0FBYSxFQUFFLENBQUE7UUFFbkMsS0FBSyxNQUFNLE1BQU0sSUFBSSxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztZQUM1QyxJQUFJLFdBQVcsQ0FBQTtZQUNmLElBQUksVUFBVSxLQUFLLFNBQVMsRUFBRSxDQUFDO2dCQUM3QixXQUFXLEdBQUcsTUFBTSxJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFBO1lBQ2xFLENBQUM7aUJBQU0sQ0FBQztnQkFDTixXQUFXLEdBQUcsTUFBTSxJQUFJLENBQUMsc0JBQXNCLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFBO1lBQ25FLENBQUM7WUFFRCxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ2pCLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUE7WUFDN0IsQ0FBQztRQUNILENBQUM7UUFFRCxJQUFJLGNBQWMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDOUIsTUFBTSxJQUFJLEtBQUssQ0FDYiw0QkFBNEIsVUFBVSxJQUFJLFFBQVEsa0JBQWtCLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FDaEcsQ0FBQTtRQUNILENBQUM7UUFFRCxPQUFPLElBQUksQ0FBQTtJQUNiLENBQUM7SUFFRCxLQUFLLENBQUMsbUJBQW1CLENBQ3ZCLFFBQWdCLEVBQ2hCLFVBQWtDLEVBQ2xDLFlBQXlDO1FBRXpDLE1BQU0sT0FBTyxHQUFHLEVBQUUsQ0FBQTtRQUVsQixLQUFLLE1BQU0sQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDO1lBQ2pFLElBQUksQ0FBQztnQkFDSCxJQUFJLE1BQU0sQ0FBQTtnQkFDVixJQUFJLFVBQVUsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDN0IsTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsRUFBRSxNQUFnQixFQUFFLFdBQVcsQ0FBQyxDQUFBO2dCQUNwRixDQUFDO3FCQUFNLENBQUM7b0JBQ04sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLHNCQUFzQixDQUFDLFFBQVEsRUFBRSxNQUFnQixFQUFFLFdBQVcsQ0FBQyxDQUFBO2dCQUNyRixDQUFDO2dCQUNELE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUE7WUFDdEIsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsTUFBTSxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUE7Z0JBQzVELE1BQU0sS0FBSyxDQUFBO1lBQ2IsQ0FBQztRQUNILENBQUM7UUFFRCxPQUFPLE9BQU8sQ0FBQTtJQUNoQixDQUFDO0lBRU8sY0FBYyxDQUFDLE1BQWM7UUFDbkMsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsTUFBZ0IsQ0FBQyxFQUFFLENBQUM7WUFDdkQsTUFBTSxJQUFJLEtBQUssQ0FDYixtQkFBbUIsTUFBTSw0QkFBNEIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUN6RixDQUFBO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFRCxtQkFBbUI7UUFDakIsT0FBTyxDQUFDLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUE7SUFDcEMsQ0FBQztJQUVELGdCQUFnQjtRQUNkLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQTtJQUM1QixDQUFDO0lBRUQsaUJBQWlCO1FBQ2YsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFBO0lBQzdCLENBQUM7Q0FDRjtBQUVELGtCQUFlLHNCQUFzQixDQUFBIn0=