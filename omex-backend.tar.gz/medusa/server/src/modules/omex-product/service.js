"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class OmexProductService extends (0, utils_1.MedusaService)({}) {
    async createProduct(data) {
        // Validate required fields
        if (!data.title || !data.sku) {
            throw new Error("Title and SKU are required");
        }
        // Set defaults
        const productData = {
            ...data,
            min_order_qty: data.min_order_qty || 1,
            created_at: new Date(),
            updated_at: new Date(),
        };
        // In real implementation, this would use Medusa's product service
        // For now, return the data structure
        return {
            id: `prod_${Date.now()}`,
            ...productData,
        };
    }
    async updateProduct(id, data) {
        if (!id) {
            throw new Error("Product ID is required");
        }
        return {
            id,
            ...data,
            updated_at: new Date(),
        };
    }
    async retrieveProduct(id, locale) {
        if (!id) {
            throw new Error("Product ID is required");
        }
        // In real implementation, fetch from database with translations
        return {
            id,
            locale: locale || 'pl',
        };
    }
    async listProducts(filters = {}, pagination = {}) {
        const limit = pagination.limit || 12;
        const offset = pagination.offset || 0;
        // In real implementation, build query with filters
        return {
            products: [],
            count: 0,
            limit,
            offset,
        };
    }
    async searchProducts(query, filters = {}) {
        if (!query || query.trim().length === 0) {
            return [];
        }
        // In real implementation, full-text search across:
        // - title
        // - description
        // - sku
        // - part_number
        return [];
    }
    async deleteProduct(id) {
        if (!id) {
            throw new Error("Product ID is required");
        }
        // Soft delete
        return { deleted: true, id };
    }
    async addTranslation(productId, locale, translation) {
        if (!productId || !locale || !translation.title) {
            throw new Error("Product ID, locale, and title are required");
        }
        const validLocales = ['pl', 'en', 'de'];
        if (!validLocales.includes(locale)) {
            throw new Error(`Invalid locale. Must be one of: ${validLocales.join(', ')}`);
        }
        return {
            id: `trans_${Date.now()}`,
            product_id: productId,
            locale,
            ...translation,
            created_at: new Date(),
        };
    }
    async setTechnicalSpecs(productId, specs) {
        if (!productId) {
            throw new Error("Product ID is required");
        }
        if (typeof specs !== 'object') {
            throw new Error("Technical specs must be a valid JSON object");
        }
        return {
            product_id: productId,
            technical_specs: specs,
            updated_at: new Date(),
        };
    }
    async assignCategories(productId, categoryIds) {
        if (!productId || !categoryIds || categoryIds.length === 0) {
            throw new Error("Product ID and at least one category are required");
        }
        return {
            product_id: productId,
            categories: categoryIds,
            updated_at: new Date(),
        };
    }
}
exports.default = OmexProductService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL29tZXgtcHJvZHVjdC9zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEscURBQXlEO0FBK0J6RCxNQUFNLGtCQUFtQixTQUFRLElBQUEscUJBQWEsRUFBQyxFQUFFLENBQUM7SUFDaEQsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFzQjtRQUN4QywyQkFBMkI7UUFDM0IsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDN0IsTUFBTSxJQUFJLEtBQUssQ0FBQyw0QkFBNEIsQ0FBQyxDQUFBO1FBQy9DLENBQUM7UUFFRCxlQUFlO1FBQ2YsTUFBTSxXQUFXLEdBQUc7WUFDbEIsR0FBRyxJQUFJO1lBQ1AsYUFBYSxFQUFFLElBQUksQ0FBQyxhQUFhLElBQUksQ0FBQztZQUN0QyxVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUU7WUFDdEIsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFO1NBQ3ZCLENBQUE7UUFFRCxrRUFBa0U7UUFDbEUscUNBQXFDO1FBQ3JDLE9BQU87WUFDTCxFQUFFLEVBQUUsUUFBUSxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUU7WUFDeEIsR0FBRyxXQUFXO1NBQ2YsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsYUFBYSxDQUFDLEVBQVUsRUFBRSxJQUFzQjtRQUNwRCxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDUixNQUFNLElBQUksS0FBSyxDQUFDLHdCQUF3QixDQUFDLENBQUE7UUFDM0MsQ0FBQztRQUVELE9BQU87WUFDTCxFQUFFO1lBQ0YsR0FBRyxJQUFJO1lBQ1AsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFO1NBQ3ZCLENBQUE7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLGVBQWUsQ0FBQyxFQUFVLEVBQUUsTUFBZTtRQUMvQyxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDUixNQUFNLElBQUksS0FBSyxDQUFDLHdCQUF3QixDQUFDLENBQUE7UUFDM0MsQ0FBQztRQUVELGdFQUFnRTtRQUNoRSxPQUFPO1lBQ0wsRUFBRTtZQUNGLE1BQU0sRUFBRSxNQUFNLElBQUksSUFBSTtTQUN2QixDQUFBO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxZQUFZLENBQUMsVUFBMEIsRUFBRSxFQUFFLGFBQXlCLEVBQUU7UUFDMUUsTUFBTSxLQUFLLEdBQUcsVUFBVSxDQUFDLEtBQUssSUFBSSxFQUFFLENBQUE7UUFDcEMsTUFBTSxNQUFNLEdBQUcsVUFBVSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUE7UUFFckMsbURBQW1EO1FBQ25ELE9BQU87WUFDTCxRQUFRLEVBQUUsRUFBRTtZQUNaLEtBQUssRUFBRSxDQUFDO1lBQ1IsS0FBSztZQUNMLE1BQU07U0FDUCxDQUFBO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxjQUFjLENBQUMsS0FBYSxFQUFFLFVBQTBCLEVBQUU7UUFDOUQsSUFBSSxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ3hDLE9BQU8sRUFBRSxDQUFBO1FBQ1gsQ0FBQztRQUVELG1EQUFtRDtRQUNuRCxVQUFVO1FBQ1YsZ0JBQWdCO1FBQ2hCLFFBQVE7UUFDUixnQkFBZ0I7UUFDaEIsT0FBTyxFQUFFLENBQUE7SUFDWCxDQUFDO0lBRUQsS0FBSyxDQUFDLGFBQWEsQ0FBQyxFQUFVO1FBQzVCLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUNSLE1BQU0sSUFBSSxLQUFLLENBQUMsd0JBQXdCLENBQUMsQ0FBQTtRQUMzQyxDQUFDO1FBRUQsY0FBYztRQUNkLE9BQU8sRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEVBQUUsRUFBRSxDQUFBO0lBQzlCLENBQUM7SUFFRCxLQUFLLENBQUMsY0FBYyxDQUFDLFNBQWlCLEVBQUUsTUFBYyxFQUFFLFdBQW9EO1FBQzFHLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDaEQsTUFBTSxJQUFJLEtBQUssQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFBO1FBQy9ELENBQUM7UUFFRCxNQUFNLFlBQVksR0FBRyxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUE7UUFDdkMsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztZQUNuQyxNQUFNLElBQUksS0FBSyxDQUFDLG1DQUFtQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUMvRSxDQUFDO1FBRUQsT0FBTztZQUNMLEVBQUUsRUFBRSxTQUFTLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtZQUN6QixVQUFVLEVBQUUsU0FBUztZQUNyQixNQUFNO1lBQ04sR0FBRyxXQUFXO1lBQ2QsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFO1NBQ3ZCLENBQUE7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLGlCQUFpQixDQUFDLFNBQWlCLEVBQUUsS0FBVTtRQUNuRCxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDZixNQUFNLElBQUksS0FBSyxDQUFDLHdCQUF3QixDQUFDLENBQUE7UUFDM0MsQ0FBQztRQUVELElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxFQUFFLENBQUM7WUFDOUIsTUFBTSxJQUFJLEtBQUssQ0FBQyw2Q0FBNkMsQ0FBQyxDQUFBO1FBQ2hFLENBQUM7UUFFRCxPQUFPO1lBQ0wsVUFBVSxFQUFFLFNBQVM7WUFDckIsZUFBZSxFQUFFLEtBQUs7WUFDdEIsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFO1NBQ3ZCLENBQUE7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLGdCQUFnQixDQUFDLFNBQWlCLEVBQUUsV0FBcUI7UUFDN0QsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLFdBQVcsSUFBSSxXQUFXLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQzNELE1BQU0sSUFBSSxLQUFLLENBQUMsbURBQW1ELENBQUMsQ0FBQTtRQUN0RSxDQUFDO1FBRUQsT0FBTztZQUNMLFVBQVUsRUFBRSxTQUFTO1lBQ3JCLFVBQVUsRUFBRSxXQUFXO1lBQ3ZCLFVBQVUsRUFBRSxJQUFJLElBQUksRUFBRTtTQUN2QixDQUFBO0lBQ0gsQ0FBQztDQUNGO0FBRUQsa0JBQWUsa0JBQWtCLENBQUEifQ==