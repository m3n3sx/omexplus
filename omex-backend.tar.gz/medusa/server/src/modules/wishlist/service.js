"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class WishlistService extends (0, utils_1.MedusaService)({}) {
    async addToWishlist(customerId, productId) {
        return {
            id: `wishlist_${Date.now()}`,
            customerId,
            productId,
            createdAt: new Date(),
        };
    }
    async removeFromWishlist(customerId, productId) {
        return { success: true };
    }
    async getWishlist(customerId) {
        return [];
    }
}
exports.default = WishlistService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL3dpc2hsaXN0L3NlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBeUQ7QUFFekQsTUFBTSxlQUFnQixTQUFRLElBQUEscUJBQWEsRUFBQyxFQUFFLENBQUM7SUFDN0MsS0FBSyxDQUFDLGFBQWEsQ0FBQyxVQUFrQixFQUFFLFNBQWlCO1FBQ3ZELE9BQU87WUFDTCxFQUFFLEVBQUUsWUFBWSxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUU7WUFDNUIsVUFBVTtZQUNWLFNBQVM7WUFDVCxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDdEIsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsa0JBQWtCLENBQUMsVUFBa0IsRUFBRSxTQUFpQjtRQUM1RCxPQUFPLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxDQUFBO0lBQzFCLENBQUM7SUFFRCxLQUFLLENBQUMsV0FBVyxDQUFDLFVBQWtCO1FBQ2xDLE9BQU8sRUFBRSxDQUFBO0lBQ1gsQ0FBQztDQUNGO0FBRUQsa0JBQWUsZUFBZSxDQUFBIn0=