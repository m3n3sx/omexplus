"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class OmexCategoryService extends (0, utils_1.MedusaService)({}) {
    async createCategory(data) {
        if (!data.name || !data.slug) {
            throw new Error("Name and slug are required");
        }
        // Validate parent exists if parent_id provided
        if (data.parent_id) {
            // In real implementation, check if parent exists
        }
        return {
            id: `cat_${Date.now()}`,
            ...data,
            created_at: new Date(),
            updated_at: new Date(),
        };
    }
    async updateCategory(id, data) {
        if (!id) {
            throw new Error("Category ID is required");
        }
        return {
            id,
            ...data,
            updated_at: new Date(),
        };
    }
    async retrieveCategory(id) {
        if (!id) {
            throw new Error("Category ID is required");
        }
        return {
            id,
            name: "Sample Category",
        };
    }
    async listTree() {
        // In real implementation, fetch all categories and build tree
        // This is a recursive structure where each category can have children
        // Example structure:
        // [
        //   {
        //     id: "cat_1",
        //     name: "Hydraulika",
        //     children: [
        //       { id: "cat_2", name: "Pompy", parent_id: "cat_1", children: [...] }
        //     ]
        //   }
        // ]
        return [];
    }
    async getChildren(parentId) {
        if (!parentId) {
            throw new Error("Parent ID is required");
        }
        // In real implementation, fetch categories where parent_id = parentId
        return [];
    }
    async getProductsByCategory(categoryId, includeSubcategories = true) {
        if (!categoryId) {
            throw new Error("Category ID is required");
        }
        if (includeSubcategories) {
            // Get all descendant category IDs
            const descendantIds = await this.getDescendantIds(categoryId);
            // Fetch products from all these categories
            // In real implementation, query products where category_id IN (categoryId, ...descendantIds)
        }
        return [];
    }
    async deleteCategory(id, cascade = false) {
        if (!id) {
            throw new Error("Category ID is required");
        }
        // Check if category has children
        const children = await this.getChildren(id);
        if (children.length > 0 && !cascade) {
            throw new Error(`Category has ${children.length} subcategories. ` +
                `Set cascade=true to delete all subcategories, or move them to another parent first.`);
        }
        return { deleted: true, id, cascade };
    }
    async generatePath(categoryId) {
        if (!categoryId) {
            throw new Error("Category ID is required");
        }
        // In real implementation, traverse up the tree to build path
        // Example: /hydraulika/pompy/pompy-tlokowe
        const path = [];
        let currentId = categoryId;
        // Traverse up to root (max 10 levels to prevent infinite loop)
        for (let i = 0; i < 10; i++) {
            const category = await this.retrieveCategory(currentId);
            if (!category)
                break;
            path.unshift(category.slug || category.name.toLowerCase().replace(/\s+/g, '-'));
            if (!category.parent_id)
                break;
            currentId = category.parent_id;
        }
        return '/' + path.join('/');
    }
    async getDescendantIds(categoryId) {
        // Recursive function to get all descendant category IDs
        const descendants = [];
        const children = await this.getChildren(categoryId);
        for (const child of children) {
            descendants.push(child.id);
            const childDescendants = await this.getDescendantIds(child.id);
            descendants.push(...childDescendants);
        }
        return descendants;
    }
    async buildTree(categories, parentId = null) {
        // Helper to build hierarchical tree from flat list
        const tree = [];
        for (const category of categories) {
            if (category.parent_id === parentId) {
                const children = await this.buildTree(categories, category.id);
                tree.push({
                    ...category,
                    children: children.length > 0 ? children : undefined,
                });
            }
        }
        return tree;
    }
}
exports.default = OmexCategoryService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL29tZXgtY2F0ZWdvcnkvc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHFEQUF5RDtBQXNCekQsTUFBTSxtQkFBb0IsU0FBUSxJQUFBLHFCQUFhLEVBQUMsRUFBRSxDQUFDO0lBQ2pELEtBQUssQ0FBQyxjQUFjLENBQUMsSUFBdUI7UUFDMUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDN0IsTUFBTSxJQUFJLEtBQUssQ0FBQyw0QkFBNEIsQ0FBQyxDQUFBO1FBQy9DLENBQUM7UUFFRCwrQ0FBK0M7UUFDL0MsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDbkIsaURBQWlEO1FBQ25ELENBQUM7UUFFRCxPQUFPO1lBQ0wsRUFBRSxFQUFFLE9BQU8sSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO1lBQ3ZCLEdBQUcsSUFBSTtZQUNQLFVBQVUsRUFBRSxJQUFJLElBQUksRUFBRTtZQUN0QixVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDdkIsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsY0FBYyxDQUFDLEVBQVUsRUFBRSxJQUF1QjtRQUN0RCxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDUixNQUFNLElBQUksS0FBSyxDQUFDLHlCQUF5QixDQUFDLENBQUE7UUFDNUMsQ0FBQztRQUVELE9BQU87WUFDTCxFQUFFO1lBQ0YsR0FBRyxJQUFJO1lBQ1AsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFO1NBQ3ZCLENBQUE7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLGdCQUFnQixDQUFDLEVBQVU7UUFDL0IsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQ1IsTUFBTSxJQUFJLEtBQUssQ0FBQyx5QkFBeUIsQ0FBQyxDQUFBO1FBQzVDLENBQUM7UUFFRCxPQUFPO1lBQ0wsRUFBRTtZQUNGLElBQUksRUFBRSxpQkFBaUI7U0FDeEIsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsUUFBUTtRQUNaLDhEQUE4RDtRQUM5RCxzRUFBc0U7UUFFdEUscUJBQXFCO1FBQ3JCLElBQUk7UUFDSixNQUFNO1FBQ04sbUJBQW1CO1FBQ25CLDBCQUEwQjtRQUMxQixrQkFBa0I7UUFDbEIsNEVBQTRFO1FBQzVFLFFBQVE7UUFDUixNQUFNO1FBQ04sSUFBSTtRQUVKLE9BQU8sRUFBRSxDQUFBO0lBQ1gsQ0FBQztJQUVELEtBQUssQ0FBQyxXQUFXLENBQUMsUUFBZ0I7UUFDaEMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ2QsTUFBTSxJQUFJLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFBO1FBQzFDLENBQUM7UUFFRCxzRUFBc0U7UUFDdEUsT0FBTyxFQUFFLENBQUE7SUFDWCxDQUFDO0lBRUQsS0FBSyxDQUFDLHFCQUFxQixDQUFDLFVBQWtCLEVBQUUsdUJBQWdDLElBQUk7UUFDbEYsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2hCLE1BQU0sSUFBSSxLQUFLLENBQUMseUJBQXlCLENBQUMsQ0FBQTtRQUM1QyxDQUFDO1FBRUQsSUFBSSxvQkFBb0IsRUFBRSxDQUFDO1lBQ3pCLGtDQUFrQztZQUNsQyxNQUFNLGFBQWEsR0FBRyxNQUFNLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsQ0FBQTtZQUU3RCwyQ0FBMkM7WUFDM0MsNkZBQTZGO1FBQy9GLENBQUM7UUFFRCxPQUFPLEVBQUUsQ0FBQTtJQUNYLENBQUM7SUFFRCxLQUFLLENBQUMsY0FBYyxDQUFDLEVBQVUsRUFBRSxVQUFtQixLQUFLO1FBQ3ZELElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUNSLE1BQU0sSUFBSSxLQUFLLENBQUMseUJBQXlCLENBQUMsQ0FBQTtRQUM1QyxDQUFDO1FBRUQsaUNBQWlDO1FBQ2pDLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUUzQyxJQUFJLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDcEMsTUFBTSxJQUFJLEtBQUssQ0FDYixnQkFBZ0IsUUFBUSxDQUFDLE1BQU0sa0JBQWtCO2dCQUNqRCxxRkFBcUYsQ0FDdEYsQ0FBQTtRQUNILENBQUM7UUFFRCxPQUFPLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLENBQUE7SUFDdkMsQ0FBQztJQUVELEtBQUssQ0FBQyxZQUFZLENBQUMsVUFBa0I7UUFDbkMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2hCLE1BQU0sSUFBSSxLQUFLLENBQUMseUJBQXlCLENBQUMsQ0FBQTtRQUM1QyxDQUFDO1FBRUQsNkRBQTZEO1FBQzdELDJDQUEyQztRQUUzQyxNQUFNLElBQUksR0FBYSxFQUFFLENBQUE7UUFDekIsSUFBSSxTQUFTLEdBQUcsVUFBVSxDQUFBO1FBRTFCLCtEQUErRDtRQUMvRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDNUIsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUE7WUFDdkQsSUFBSSxDQUFDLFFBQVE7Z0JBQUUsTUFBSztZQUVwQixJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUE7WUFFL0UsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTO2dCQUFFLE1BQUs7WUFDOUIsU0FBUyxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUE7UUFDaEMsQ0FBQztRQUVELE9BQU8sR0FBRyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7SUFDN0IsQ0FBQztJQUVPLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFrQjtRQUMvQyx3REFBd0Q7UUFDeEQsTUFBTSxXQUFXLEdBQWEsRUFBRSxDQUFBO1FBQ2hDLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQTtRQUVuRCxLQUFLLE1BQU0sS0FBSyxJQUFJLFFBQVEsRUFBRSxDQUFDO1lBQzdCLFdBQVcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFBO1lBQzFCLE1BQU0sZ0JBQWdCLEdBQUcsTUFBTSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFBO1lBQzlELFdBQVcsQ0FBQyxJQUFJLENBQUMsR0FBRyxnQkFBZ0IsQ0FBQyxDQUFBO1FBQ3ZDLENBQUM7UUFFRCxPQUFPLFdBQVcsQ0FBQTtJQUNwQixDQUFDO0lBRU8sS0FBSyxDQUFDLFNBQVMsQ0FBQyxVQUFzQixFQUFFLFdBQTBCLElBQUk7UUFDNUUsbURBQW1EO1FBQ25ELE1BQU0sSUFBSSxHQUFlLEVBQUUsQ0FBQTtRQUUzQixLQUFLLE1BQU0sUUFBUSxJQUFJLFVBQVUsRUFBRSxDQUFDO1lBQ2xDLElBQUksUUFBUSxDQUFDLFNBQVMsS0FBSyxRQUFRLEVBQUUsQ0FBQztnQkFDcEMsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUE7Z0JBQzlELElBQUksQ0FBQyxJQUFJLENBQUM7b0JBQ1IsR0FBRyxRQUFRO29CQUNYLFFBQVEsRUFBRSxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTO2lCQUNyRCxDQUFDLENBQUE7WUFDSixDQUFDO1FBQ0gsQ0FBQztRQUVELE9BQU8sSUFBSSxDQUFBO0lBQ2IsQ0FBQztDQUNGO0FBRUQsa0JBQWUsbUJBQW1CLENBQUEifQ==