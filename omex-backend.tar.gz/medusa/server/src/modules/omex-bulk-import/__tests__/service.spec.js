"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const service_1 = __importDefault(require("../service"));
describe("OmexBulkImportService", () => {
    let service;
    beforeEach(() => {
        service = new service_1.default({});
    });
    describe("validateRow", () => {
        it("should validate a correct row", () => {
            const row = {
                sku: "HYD-001",
                name_pl: "Pompa hydrauliczna",
                name_en: "Hydraulic pump",
                name_de: "Hydraulische Pumpe",
                desc_pl: "Opis",
                desc_en: "Description",
                desc_de: "Beschreibung",
                price: "599.99",
                cost: "299.99",
                category_id: "cat-hydraulika",
                equipment_type: "Hydraulika",
                min_order_qty: "1",
                technical_specs_json: '{"power": "5kW"}',
            };
            const result = service.validateRow(row, 2);
            expect(result.valid).toBe(true);
            expect(result.errors).toHaveLength(0);
        });
        it("should detect missing required fields", () => {
            const row = {
                sku: "",
                name_pl: "",
                name_en: "",
                name_de: "",
                desc_pl: "",
                desc_en: "",
                desc_de: "",
                price: "",
                cost: "",
                category_id: "",
                equipment_type: "",
                min_order_qty: "",
                technical_specs_json: "",
            };
            const result = service.validateRow(row, 2);
            expect(result.valid).toBe(false);
            expect(result.errors.length).toBeGreaterThan(0);
            expect(result.errors.some((e) => e.field === "sku")).toBe(true);
            expect(result.errors.some((e) => e.field === "name_pl")).toBe(true);
            expect(result.errors.some((e) => e.field === "price")).toBe(true);
            expect(result.errors.some((e) => e.field === "category_id")).toBe(true);
        });
        it("should detect invalid SKU format", () => {
            const row = {
                sku: "INVALID-SKU",
                name_pl: "Pompa",
                name_en: "Pump",
                name_de: "Pumpe",
                desc_pl: "",
                desc_en: "",
                desc_de: "",
                price: "599.99",
                cost: "",
                category_id: "cat-hydraulika",
                equipment_type: "",
                min_order_qty: "",
                technical_specs_json: "",
            };
            const result = service.validateRow(row, 2);
            expect(result.valid).toBe(false);
            expect(result.errors.some((e) => e.field === "sku")).toBe(true);
            expect(result.errors.find((e) => e.field === "sku").reason).toContain("format");
        });
        it("should detect invalid price", () => {
            const row = {
                sku: "HYD-001",
                name_pl: "Pompa",
                name_en: "Pump",
                name_de: "Pumpe",
                desc_pl: "",
                desc_en: "",
                desc_de: "",
                price: "-599.99",
                cost: "",
                category_id: "cat-hydraulika",
                equipment_type: "",
                min_order_qty: "",
                technical_specs_json: "",
            };
            const result = service.validateRow(row, 2);
            expect(result.valid).toBe(false);
            expect(result.errors.some((e) => e.field === "price")).toBe(true);
        });
        it("should detect invalid cost", () => {
            const row = {
                sku: "HYD-001",
                name_pl: "Pompa",
                name_en: "Pump",
                name_de: "Pumpe",
                desc_pl: "",
                desc_en: "",
                desc_de: "",
                price: "599.99",
                cost: "invalid",
                category_id: "cat-hydraulika",
                equipment_type: "",
                min_order_qty: "",
                technical_specs_json: "",
            };
            const result = service.validateRow(row, 2);
            expect(result.valid).toBe(false);
            expect(result.errors.some((e) => e.field === "cost")).toBe(true);
        });
        it("should detect invalid min_order_qty", () => {
            const row = {
                sku: "HYD-001",
                name_pl: "Pompa",
                name_en: "Pump",
                name_de: "Pumpe",
                desc_pl: "",
                desc_en: "",
                desc_de: "",
                price: "599.99",
                cost: "",
                category_id: "cat-hydraulika",
                equipment_type: "",
                min_order_qty: "0",
                technical_specs_json: "",
            };
            const result = service.validateRow(row, 2);
            expect(result.valid).toBe(false);
            expect(result.errors.some((e) => e.field === "min_order_qty")).toBe(true);
        });
        it("should detect invalid JSON in technical specs", () => {
            const row = {
                sku: "HYD-001",
                name_pl: "Pompa",
                name_en: "Pump",
                name_de: "Pumpe",
                desc_pl: "",
                desc_en: "",
                desc_de: "",
                price: "599.99",
                cost: "",
                category_id: "cat-hydraulika",
                equipment_type: "",
                min_order_qty: "",
                technical_specs_json: "{invalid json}",
            };
            const result = service.validateRow(row, 2);
            expect(result.valid).toBe(false);
            expect(result.errors.some((e) => e.field === "technical_specs_json")).toBe(true);
        });
    });
    describe("processRow", () => {
        it("should process a valid row", () => {
            const row = {
                sku: "HYD-001",
                name_pl: "Pompa hydrauliczna",
                name_en: "Hydraulic pump",
                name_de: "Hydraulische Pumpe",
                desc_pl: "Opis PL",
                desc_en: "Description EN",
                desc_de: "Beschreibung DE",
                price: "599.99",
                cost: "299.99",
                category_id: "cat-hydraulika",
                equipment_type: "Hydraulika",
                min_order_qty: "2",
                technical_specs_json: '{"power": "5kW", "pressure": "250bar"}',
            };
            const result = service.processRow(row);
            expect(result.sku).toBe("HYD-001");
            expect(result.title).toBe("Pompa hydrauliczna");
            expect(result.price).toBe(599.99);
            expect(result.cost).toBe(299.99);
            expect(result.min_order_qty).toBe(2);
            expect(result.technical_specs).toEqual({
                power: "5kW",
                pressure: "250bar",
            });
            expect(result.translations.pl.title).toBe("Pompa hydrauliczna");
            expect(result.translations.en.title).toBe("Hydraulic pump");
            expect(result.translations.de.title).toBe("Hydraulische Pumpe");
        });
        it("should use defaults for missing optional fields", () => {
            const row = {
                sku: "HYD-001",
                name_pl: "Pompa",
                name_en: "",
                name_de: "",
                desc_pl: "",
                desc_en: "",
                desc_de: "",
                price: "599.99",
                cost: "",
                category_id: "cat-hydraulika",
                equipment_type: "",
                min_order_qty: "",
                technical_specs_json: "",
            };
            const result = service.processRow(row);
            expect(result.cost).toBe(0);
            expect(result.min_order_qty).toBe(1);
            expect(result.technical_specs).toEqual({});
            expect(result.translations.en.title).toBe("Pompa"); // Fallback to PL
            expect(result.translations.de.title).toBe("Pompa"); // Fallback to PL
        });
        it("should fallback translations to Polish", () => {
            const row = {
                sku: "HYD-001",
                name_pl: "Pompa hydrauliczna",
                name_en: "",
                name_de: "",
                desc_pl: "Opis polski",
                desc_en: "",
                desc_de: "",
                price: "599.99",
                cost: "",
                category_id: "cat-hydraulika",
                equipment_type: "",
                min_order_qty: "",
                technical_specs_json: "",
            };
            const result = service.processRow(row);
            expect(result.translations.en.title).toBe("Pompa hydrauliczna");
            expect(result.translations.de.title).toBe("Pompa hydrauliczna");
            expect(result.translations.en.description).toBe("Opis polski");
            expect(result.translations.de.description).toBe("Opis polski");
        });
    });
    describe("generateErrorReport", () => {
        it("should generate a formatted error report", () => {
            const errors = [
                {
                    line: 15,
                    field: "price",
                    reason: "Price must be a positive number",
                    value: "invalid",
                },
                {
                    line: 42,
                    field: "sku",
                    reason: "SKU must match format XXX-000",
                    value: "INVALID-SKU",
                },
                {
                    line: 67,
                    field: "price",
                    reason: "Price must be a positive number",
                    value: "-100",
                },
            ];
            const report = service.generateErrorReport(errors);
            expect(report).toContain("Import Error Report");
            expect(report).toContain("Total Errors: 3");
            expect(report).toContain("Errors by Field:");
            expect(report).toContain("price: 2 errors");
            expect(report).toContain("sku: 1 errors");
            expect(report).toContain("Line 15: price");
            expect(report).toContain("Line 42: sku");
            expect(report).toContain("Line 67: price");
        });
        it("should handle empty error list", () => {
            const report = service.generateErrorReport([]);
            expect(report).toContain("Total Errors: 0");
        });
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL21vZHVsZXMvb21leC1idWxrLWltcG9ydC9fX3Rlc3RzX18vc2VydmljZS5zcGVjLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEseURBQThDO0FBRzlDLFFBQVEsQ0FBQyx1QkFBdUIsRUFBRSxHQUFHLEVBQUU7SUFDckMsSUFBSSxPQUE4QixDQUFBO0lBRWxDLFVBQVUsQ0FBQyxHQUFHLEVBQUU7UUFDZCxPQUFPLEdBQUcsSUFBSSxpQkFBcUIsQ0FBQyxFQUFTLENBQUMsQ0FBQTtJQUNoRCxDQUFDLENBQUMsQ0FBQTtJQUVGLFFBQVEsQ0FBQyxhQUFhLEVBQUUsR0FBRyxFQUFFO1FBQzNCLEVBQUUsQ0FBQywrQkFBK0IsRUFBRSxHQUFHLEVBQUU7WUFDdkMsTUFBTSxHQUFHLEdBQXFCO2dCQUM1QixHQUFHLEVBQUUsU0FBUztnQkFDZCxPQUFPLEVBQUUsb0JBQW9CO2dCQUM3QixPQUFPLEVBQUUsZ0JBQWdCO2dCQUN6QixPQUFPLEVBQUUsb0JBQW9CO2dCQUM3QixPQUFPLEVBQUUsTUFBTTtnQkFDZixPQUFPLEVBQUUsYUFBYTtnQkFDdEIsT0FBTyxFQUFFLGNBQWM7Z0JBQ3ZCLEtBQUssRUFBRSxRQUFRO2dCQUNmLElBQUksRUFBRSxRQUFRO2dCQUNkLFdBQVcsRUFBRSxnQkFBZ0I7Z0JBQzdCLGNBQWMsRUFBRSxZQUFZO2dCQUM1QixhQUFhLEVBQUUsR0FBRztnQkFDbEIsb0JBQW9CLEVBQUUsa0JBQWtCO2FBQ3pDLENBQUE7WUFFRCxNQUFNLE1BQU0sR0FBSSxPQUFlLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQTtZQUVuRCxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQTtZQUMvQixNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUN2QyxDQUFDLENBQUMsQ0FBQTtRQUVGLEVBQUUsQ0FBQyx1Q0FBdUMsRUFBRSxHQUFHLEVBQUU7WUFDL0MsTUFBTSxHQUFHLEdBQXFCO2dCQUM1QixHQUFHLEVBQUUsRUFBRTtnQkFDUCxPQUFPLEVBQUUsRUFBRTtnQkFDWCxPQUFPLEVBQUUsRUFBRTtnQkFDWCxPQUFPLEVBQUUsRUFBRTtnQkFDWCxPQUFPLEVBQUUsRUFBRTtnQkFDWCxPQUFPLEVBQUUsRUFBRTtnQkFDWCxPQUFPLEVBQUUsRUFBRTtnQkFDWCxLQUFLLEVBQUUsRUFBRTtnQkFDVCxJQUFJLEVBQUUsRUFBRTtnQkFDUixXQUFXLEVBQUUsRUFBRTtnQkFDZixjQUFjLEVBQUUsRUFBRTtnQkFDbEIsYUFBYSxFQUFFLEVBQUU7Z0JBQ2pCLG9CQUFvQixFQUFFLEVBQUU7YUFDekIsQ0FBQTtZQUVELE1BQU0sTUFBTSxHQUFJLE9BQWUsQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFBO1lBRW5ELE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBO1lBQ2hDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUMvQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFNLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUE7WUFDcEUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFBO1lBQ3hFLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQU0sRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQTtZQUN0RSxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFNLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssYUFBYSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQ3BFLElBQUksQ0FDTCxDQUFBO1FBQ0gsQ0FBQyxDQUFDLENBQUE7UUFFRixFQUFFLENBQUMsa0NBQWtDLEVBQUUsR0FBRyxFQUFFO1lBQzFDLE1BQU0sR0FBRyxHQUFxQjtnQkFDNUIsR0FBRyxFQUFFLGFBQWE7Z0JBQ2xCLE9BQU8sRUFBRSxPQUFPO2dCQUNoQixPQUFPLEVBQUUsTUFBTTtnQkFDZixPQUFPLEVBQUUsT0FBTztnQkFDaEIsT0FBTyxFQUFFLEVBQUU7Z0JBQ1gsT0FBTyxFQUFFLEVBQUU7Z0JBQ1gsT0FBTyxFQUFFLEVBQUU7Z0JBQ1gsS0FBSyxFQUFFLFFBQVE7Z0JBQ2YsSUFBSSxFQUFFLEVBQUU7Z0JBQ1IsV0FBVyxFQUFFLGdCQUFnQjtnQkFDN0IsY0FBYyxFQUFFLEVBQUU7Z0JBQ2xCLGFBQWEsRUFBRSxFQUFFO2dCQUNqQixvQkFBb0IsRUFBRSxFQUFFO2FBQ3pCLENBQUE7WUFFRCxNQUFNLE1BQU0sR0FBSSxPQUFlLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQTtZQUVuRCxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQTtZQUNoQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFNLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUE7WUFDcEUsTUFBTSxDQUNKLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FDekQsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUE7UUFDdkIsQ0FBQyxDQUFDLENBQUE7UUFFRixFQUFFLENBQUMsNkJBQTZCLEVBQUUsR0FBRyxFQUFFO1lBQ3JDLE1BQU0sR0FBRyxHQUFxQjtnQkFDNUIsR0FBRyxFQUFFLFNBQVM7Z0JBQ2QsT0FBTyxFQUFFLE9BQU87Z0JBQ2hCLE9BQU8sRUFBRSxNQUFNO2dCQUNmLE9BQU8sRUFBRSxPQUFPO2dCQUNoQixPQUFPLEVBQUUsRUFBRTtnQkFDWCxPQUFPLEVBQUUsRUFBRTtnQkFDWCxPQUFPLEVBQUUsRUFBRTtnQkFDWCxLQUFLLEVBQUUsU0FBUztnQkFDaEIsSUFBSSxFQUFFLEVBQUU7Z0JBQ1IsV0FBVyxFQUFFLGdCQUFnQjtnQkFDN0IsY0FBYyxFQUFFLEVBQUU7Z0JBQ2xCLGFBQWEsRUFBRSxFQUFFO2dCQUNqQixvQkFBb0IsRUFBRSxFQUFFO2FBQ3pCLENBQUE7WUFFRCxNQUFNLE1BQU0sR0FBSSxPQUFlLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQTtZQUVuRCxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQTtZQUNoQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFNLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUE7UUFDeEUsQ0FBQyxDQUFDLENBQUE7UUFFRixFQUFFLENBQUMsNEJBQTRCLEVBQUUsR0FBRyxFQUFFO1lBQ3BDLE1BQU0sR0FBRyxHQUFxQjtnQkFDNUIsR0FBRyxFQUFFLFNBQVM7Z0JBQ2QsT0FBTyxFQUFFLE9BQU87Z0JBQ2hCLE9BQU8sRUFBRSxNQUFNO2dCQUNmLE9BQU8sRUFBRSxPQUFPO2dCQUNoQixPQUFPLEVBQUUsRUFBRTtnQkFDWCxPQUFPLEVBQUUsRUFBRTtnQkFDWCxPQUFPLEVBQUUsRUFBRTtnQkFDWCxLQUFLLEVBQUUsUUFBUTtnQkFDZixJQUFJLEVBQUUsU0FBUztnQkFDZixXQUFXLEVBQUUsZ0JBQWdCO2dCQUM3QixjQUFjLEVBQUUsRUFBRTtnQkFDbEIsYUFBYSxFQUFFLEVBQUU7Z0JBQ2pCLG9CQUFvQixFQUFFLEVBQUU7YUFDekIsQ0FBQTtZQUVELE1BQU0sTUFBTSxHQUFJLE9BQWUsQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFBO1lBRW5ELE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBO1lBQ2hDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQU0sRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQTtRQUN2RSxDQUFDLENBQUMsQ0FBQTtRQUVGLEVBQUUsQ0FBQyxxQ0FBcUMsRUFBRSxHQUFHLEVBQUU7WUFDN0MsTUFBTSxHQUFHLEdBQXFCO2dCQUM1QixHQUFHLEVBQUUsU0FBUztnQkFDZCxPQUFPLEVBQUUsT0FBTztnQkFDaEIsT0FBTyxFQUFFLE1BQU07Z0JBQ2YsT0FBTyxFQUFFLE9BQU87Z0JBQ2hCLE9BQU8sRUFBRSxFQUFFO2dCQUNYLE9BQU8sRUFBRSxFQUFFO2dCQUNYLE9BQU8sRUFBRSxFQUFFO2dCQUNYLEtBQUssRUFBRSxRQUFRO2dCQUNmLElBQUksRUFBRSxFQUFFO2dCQUNSLFdBQVcsRUFBRSxnQkFBZ0I7Z0JBQzdCLGNBQWMsRUFBRSxFQUFFO2dCQUNsQixhQUFhLEVBQUUsR0FBRztnQkFDbEIsb0JBQW9CLEVBQUUsRUFBRTthQUN6QixDQUFBO1lBRUQsTUFBTSxNQUFNLEdBQUksT0FBZSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUE7WUFFbkQsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUE7WUFDaEMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxLQUFLLGVBQWUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUN0RSxJQUFJLENBQ0wsQ0FBQTtRQUNILENBQUMsQ0FBQyxDQUFBO1FBRUYsRUFBRSxDQUFDLCtDQUErQyxFQUFFLEdBQUcsRUFBRTtZQUN2RCxNQUFNLEdBQUcsR0FBcUI7Z0JBQzVCLEdBQUcsRUFBRSxTQUFTO2dCQUNkLE9BQU8sRUFBRSxPQUFPO2dCQUNoQixPQUFPLEVBQUUsTUFBTTtnQkFDZixPQUFPLEVBQUUsT0FBTztnQkFDaEIsT0FBTyxFQUFFLEVBQUU7Z0JBQ1gsT0FBTyxFQUFFLEVBQUU7Z0JBQ1gsT0FBTyxFQUFFLEVBQUU7Z0JBQ1gsS0FBSyxFQUFFLFFBQVE7Z0JBQ2YsSUFBSSxFQUFFLEVBQUU7Z0JBQ1IsV0FBVyxFQUFFLGdCQUFnQjtnQkFDN0IsY0FBYyxFQUFFLEVBQUU7Z0JBQ2xCLGFBQWEsRUFBRSxFQUFFO2dCQUNqQixvQkFBb0IsRUFBRSxnQkFBZ0I7YUFDdkMsQ0FBQTtZQUVELE1BQU0sTUFBTSxHQUFJLE9BQWUsQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFBO1lBRW5ELE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBO1lBQ2hDLE1BQU0sQ0FDSixNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQU0sRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxzQkFBc0IsQ0FBQyxDQUNuRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQTtRQUNkLENBQUMsQ0FBQyxDQUFBO0lBQ0osQ0FBQyxDQUFDLENBQUE7SUFFRixRQUFRLENBQUMsWUFBWSxFQUFFLEdBQUcsRUFBRTtRQUMxQixFQUFFLENBQUMsNEJBQTRCLEVBQUUsR0FBRyxFQUFFO1lBQ3BDLE1BQU0sR0FBRyxHQUFxQjtnQkFDNUIsR0FBRyxFQUFFLFNBQVM7Z0JBQ2QsT0FBTyxFQUFFLG9CQUFvQjtnQkFDN0IsT0FBTyxFQUFFLGdCQUFnQjtnQkFDekIsT0FBTyxFQUFFLG9CQUFvQjtnQkFDN0IsT0FBTyxFQUFFLFNBQVM7Z0JBQ2xCLE9BQU8sRUFBRSxnQkFBZ0I7Z0JBQ3pCLE9BQU8sRUFBRSxpQkFBaUI7Z0JBQzFCLEtBQUssRUFBRSxRQUFRO2dCQUNmLElBQUksRUFBRSxRQUFRO2dCQUNkLFdBQVcsRUFBRSxnQkFBZ0I7Z0JBQzdCLGNBQWMsRUFBRSxZQUFZO2dCQUM1QixhQUFhLEVBQUUsR0FBRztnQkFDbEIsb0JBQW9CLEVBQUUsd0NBQXdDO2FBQy9ELENBQUE7WUFFRCxNQUFNLE1BQU0sR0FBSSxPQUFlLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFBO1lBRS9DLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFBO1lBQ2xDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLENBQUE7WUFDL0MsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUE7WUFDakMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUE7WUFDaEMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7WUFDcEMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQyxPQUFPLENBQUM7Z0JBQ3JDLEtBQUssRUFBRSxLQUFLO2dCQUNaLFFBQVEsRUFBRSxRQUFRO2FBQ25CLENBQUMsQ0FBQTtZQUNGLE1BQU0sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQTtZQUMvRCxNQUFNLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUE7WUFDM0QsTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFBO1FBQ2pFLENBQUMsQ0FBQyxDQUFBO1FBRUYsRUFBRSxDQUFDLGlEQUFpRCxFQUFFLEdBQUcsRUFBRTtZQUN6RCxNQUFNLEdBQUcsR0FBcUI7Z0JBQzVCLEdBQUcsRUFBRSxTQUFTO2dCQUNkLE9BQU8sRUFBRSxPQUFPO2dCQUNoQixPQUFPLEVBQUUsRUFBRTtnQkFDWCxPQUFPLEVBQUUsRUFBRTtnQkFDWCxPQUFPLEVBQUUsRUFBRTtnQkFDWCxPQUFPLEVBQUUsRUFBRTtnQkFDWCxPQUFPLEVBQUUsRUFBRTtnQkFDWCxLQUFLLEVBQUUsUUFBUTtnQkFDZixJQUFJLEVBQUUsRUFBRTtnQkFDUixXQUFXLEVBQUUsZ0JBQWdCO2dCQUM3QixjQUFjLEVBQUUsRUFBRTtnQkFDbEIsYUFBYSxFQUFFLEVBQUU7Z0JBQ2pCLG9CQUFvQixFQUFFLEVBQUU7YUFDekIsQ0FBQTtZQUVELE1BQU0sTUFBTSxHQUFJLE9BQWUsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUE7WUFFL0MsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7WUFDM0IsTUFBTSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7WUFDcEMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUE7WUFDMUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQSxDQUFDLGlCQUFpQjtZQUNwRSxNQUFNLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBLENBQUMsaUJBQWlCO1FBQ3RFLENBQUMsQ0FBQyxDQUFBO1FBRUYsRUFBRSxDQUFDLHdDQUF3QyxFQUFFLEdBQUcsRUFBRTtZQUNoRCxNQUFNLEdBQUcsR0FBcUI7Z0JBQzVCLEdBQUcsRUFBRSxTQUFTO2dCQUNkLE9BQU8sRUFBRSxvQkFBb0I7Z0JBQzdCLE9BQU8sRUFBRSxFQUFFO2dCQUNYLE9BQU8sRUFBRSxFQUFFO2dCQUNYLE9BQU8sRUFBRSxhQUFhO2dCQUN0QixPQUFPLEVBQUUsRUFBRTtnQkFDWCxPQUFPLEVBQUUsRUFBRTtnQkFDWCxLQUFLLEVBQUUsUUFBUTtnQkFDZixJQUFJLEVBQUUsRUFBRTtnQkFDUixXQUFXLEVBQUUsZ0JBQWdCO2dCQUM3QixjQUFjLEVBQUUsRUFBRTtnQkFDbEIsYUFBYSxFQUFFLEVBQUU7Z0JBQ2pCLG9CQUFvQixFQUFFLEVBQUU7YUFDekIsQ0FBQTtZQUVELE1BQU0sTUFBTSxHQUFJLE9BQWUsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUE7WUFFL0MsTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFBO1lBQy9ELE1BQU0sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQTtZQUMvRCxNQUFNLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFBO1lBQzlELE1BQU0sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUE7UUFDaEUsQ0FBQyxDQUFDLENBQUE7SUFDSixDQUFDLENBQUMsQ0FBQTtJQUVGLFFBQVEsQ0FBQyxxQkFBcUIsRUFBRSxHQUFHLEVBQUU7UUFDbkMsRUFBRSxDQUFDLDBDQUEwQyxFQUFFLEdBQUcsRUFBRTtZQUNsRCxNQUFNLE1BQU0sR0FBRztnQkFDYjtvQkFDRSxJQUFJLEVBQUUsRUFBRTtvQkFDUixLQUFLLEVBQUUsT0FBTztvQkFDZCxNQUFNLEVBQUUsaUNBQWlDO29CQUN6QyxLQUFLLEVBQUUsU0FBUztpQkFDakI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLEVBQUU7b0JBQ1IsS0FBSyxFQUFFLEtBQUs7b0JBQ1osTUFBTSxFQUFFLCtCQUErQjtvQkFDdkMsS0FBSyxFQUFFLGFBQWE7aUJBQ3JCO2dCQUNEO29CQUNFLElBQUksRUFBRSxFQUFFO29CQUNSLEtBQUssRUFBRSxPQUFPO29CQUNkLE1BQU0sRUFBRSxpQ0FBaUM7b0JBQ3pDLEtBQUssRUFBRSxNQUFNO2lCQUNkO2FBQ0YsQ0FBQTtZQUVELE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQTtZQUVsRCxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLHFCQUFxQixDQUFDLENBQUE7WUFDL0MsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFBO1lBQzNDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsa0JBQWtCLENBQUMsQ0FBQTtZQUM1QyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLENBQUE7WUFDM0MsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsQ0FBQTtZQUN6QyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLENBQUE7WUFDMUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQTtZQUN4QyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLENBQUE7UUFDNUMsQ0FBQyxDQUFDLENBQUE7UUFFRixFQUFFLENBQUMsZ0NBQWdDLEVBQUUsR0FBRyxFQUFFO1lBQ3hDLE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFLENBQUMsQ0FBQTtZQUU5QyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLENBQUE7UUFDN0MsQ0FBQyxDQUFDLENBQUE7SUFDSixDQUFDLENBQUMsQ0FBQTtBQUNKLENBQUMsQ0FBQyxDQUFBIn0=