"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const stream_1 = require("stream");
const csv_parse_1 = require("csv-parse");
class OmexBulkImportService extends (0, utils_1.MedusaService)({}) {
    constructor() {
        super(...arguments);
        this.CHUNK_SIZE = 1000;
        this.REQUIRED_FIELDS = ['sku', 'name_pl', 'price', 'category_id'];
    }
    async importFromCSV(fileBuffer, onProgress) {
        const startTime = Date.now();
        const progress = {
            status: 'processing',
            total: 0,
            successful: 0,
            failed: 0,
            errors: [],
            current_line: 0,
        };
        try {
            const stream = stream_1.Readable.from(fileBuffer);
            const parser = stream.pipe((0, csv_parse_1.parse)({
                columns: true,
                skip_empty_lines: true,
                trim: true,
            }));
            let chunk = [];
            let lineNumber = 1; // Header is line 0
            for await (const row of parser) {
                lineNumber++;
                progress.current_line = lineNumber;
                progress.total++;
                // Validate row
                const validation = this.validateRow(row, lineNumber);
                if (!validation.valid) {
                    progress.failed++;
                    progress.errors.push(...validation.errors);
                    if (onProgress) {
                        onProgress({ ...progress });
                    }
                    continue;
                }
                // Process row
                try {
                    const product = this.processRow(row);
                    chunk.push(product);
                    // Process chunk when it reaches CHUNK_SIZE
                    if (chunk.length >= this.CHUNK_SIZE) {
                        await this.processChunk(chunk);
                        progress.successful += chunk.length;
                        chunk = [];
                        if (onProgress) {
                            onProgress({ ...progress });
                        }
                    }
                }
                catch (error) {
                    progress.failed++;
                    progress.errors.push({
                        line: lineNumber,
                        field: 'processing',
                        reason: error.message,
                    });
                    if (onProgress) {
                        onProgress({ ...progress });
                    }
                }
            }
            // Process remaining chunk
            if (chunk.length > 0) {
                await this.processChunk(chunk);
                progress.successful += chunk.length;
            }
            progress.status = 'completed';
            progress.duration_ms = Date.now() - startTime;
            if (onProgress) {
                onProgress({ ...progress });
            }
            return progress;
        }
        catch (error) {
            progress.status = 'failed';
            progress.duration_ms = Date.now() - startTime;
            progress.errors.push({
                line: 0,
                field: 'file',
                reason: `File processing error: ${error.message}`,
            });
            if (onProgress) {
                onProgress({ ...progress });
            }
            return progress;
        }
    }
    validateRow(row, lineNumber) {
        const errors = [];
        // Check required fields
        for (const field of this.REQUIRED_FIELDS) {
            if (!row[field] || row[field].trim() === '') {
                errors.push({
                    line: lineNumber,
                    field,
                    reason: `Required field is missing or empty`,
                    value: row[field],
                });
            }
        }
        // Validate SKU format
        if (row.sku && !/^[A-Z]{3}-\d{3}$/.test(row.sku)) {
            errors.push({
                line: lineNumber,
                field: 'sku',
                reason: 'SKU must match format XXX-000 (e.g., HYD-001)',
                value: row.sku,
            });
        }
        // Validate price
        if (row.price) {
            const price = parseFloat(row.price);
            if (isNaN(price) || price < 0) {
                errors.push({
                    line: lineNumber,
                    field: 'price',
                    reason: 'Price must be a positive number',
                    value: row.price,
                });
            }
        }
        // Validate cost
        if (row.cost) {
            const cost = parseFloat(row.cost);
            if (isNaN(cost) || cost < 0) {
                errors.push({
                    line: lineNumber,
                    field: 'cost',
                    reason: 'Cost must be a positive number',
                    value: row.cost,
                });
            }
        }
        // Validate min_order_qty
        if (row.min_order_qty) {
            const qty = parseInt(row.min_order_qty);
            if (isNaN(qty) || qty < 1) {
                errors.push({
                    line: lineNumber,
                    field: 'min_order_qty',
                    reason: 'Minimum order quantity must be a positive integer',
                    value: row.min_order_qty,
                });
            }
        }
        // Validate technical_specs_json
        if (row.technical_specs_json && row.technical_specs_json.trim() !== '') {
            try {
                JSON.parse(row.technical_specs_json);
            }
            catch {
                errors.push({
                    line: lineNumber,
                    field: 'technical_specs_json',
                    reason: 'Technical specs must be valid JSON',
                    value: row.technical_specs_json,
                });
            }
        }
        return {
            valid: errors.length === 0,
            errors,
        };
    }
    processRow(row) {
        const technicalSpecs = row.technical_specs_json && row.technical_specs_json.trim() !== ''
            ? JSON.parse(row.technical_specs_json)
            : {};
        return {
            sku: row.sku.trim(),
            title: row.name_pl.trim(),
            description: row.desc_pl?.trim() || '',
            price: parseFloat(row.price),
            cost: row.cost ? parseFloat(row.cost) : 0,
            category_id: row.category_id.trim(),
            equipment_type: row.equipment_type?.trim() || '',
            min_order_qty: row.min_order_qty ? parseInt(row.min_order_qty) : 1,
            technical_specs: technicalSpecs,
            translations: {
                pl: {
                    title: row.name_pl.trim(),
                    description: row.desc_pl?.trim() || '',
                },
                en: {
                    title: row.name_en?.trim() || row.name_pl.trim(),
                    description: row.desc_en?.trim() || row.desc_pl?.trim() || '',
                },
                de: {
                    title: row.name_de?.trim() || row.name_pl.trim(),
                    description: row.desc_de?.trim() || row.desc_pl?.trim() || '',
                },
            },
        };
    }
    async processChunk(products) {
        console.log(`Processing chunk of ${products.length} products`);
        // Extract SKUs for duplicate checking
        const skus = products.map(p => p.sku);
        const duplicates = await this.checkDuplicateSKUs(skus);
        if (duplicates.length > 0) {
            throw new Error(`Duplicate SKUs found in database: ${duplicates.join(', ')}`);
        }
        // Extract category IDs for validation
        const categoryIds = [...new Set(products.map(p => p.category_id))];
        const invalidCategories = await this.validateCategories(categoryIds);
        if (invalidCategories.length > 0) {
            throw new Error(`Invalid category IDs: ${invalidCategories.join(', ')}`);
        }
        // Process each product in the chunk
        for (const product of products) {
            try {
                // Create product using omex-product service
                const createdProduct = await this.createProductWithTranslations(product);
                console.log(`✓ Created product: ${product.sku}`);
            }
            catch (error) {
                console.error(`✗ Failed to create product ${product.sku}:`, error.message);
                throw error;
            }
        }
    }
    async createProductWithTranslations(product) {
        // This will be implemented when we integrate with actual Medusa services
        // For now, return a mock response
        return {
            id: `prod_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            sku: product.sku,
            title: product.title,
            price: product.price,
            created_at: new Date(),
        };
    }
    async checkDuplicateSKUs(skus) {
        // In production, query database for existing SKUs
        // Return array of duplicate SKUs
        return [];
    }
    async validateCategories(categoryIds) {
        // In production, query database for existing categories
        // Return array of invalid category IDs
        return [];
    }
    generateErrorReport(errors) {
        let report = 'Import Error Report\n';
        report += '===================\n\n';
        report += `Total Errors: ${errors.length}\n\n`;
        // Group errors by type
        const errorsByField = new Map();
        errors.forEach(error => {
            const existing = errorsByField.get(error.field) || [];
            existing.push(error);
            errorsByField.set(error.field, existing);
        });
        // Summary by field
        report += 'Errors by Field:\n';
        errorsByField.forEach((fieldErrors, field) => {
            report += `  ${field}: ${fieldErrors.length} errors\n`;
        });
        report += '\n';
        // Detailed errors
        report += 'Detailed Errors:\n';
        report += '================\n\n';
        errors.forEach(error => {
            report += `Line ${error.line}: ${error.field}\n`;
            report += `  Reason: ${error.reason}\n`;
            if (error.value !== undefined) {
                report += `  Value: ${error.value}\n`;
            }
            report += '\n';
        });
        return report;
    }
    async validateCSV(fileBuffer) {
        const errors = [];
        const warnings = [];
        const skus = new Set();
        const duplicateSkus = [];
        const categories = new Set();
        let missingTranslations = 0;
        let total = 0;
        try {
            const stream = stream_1.Readable.from(fileBuffer);
            const parser = stream.pipe((0, csv_parse_1.parse)({
                columns: true,
                skip_empty_lines: true,
                trim: true,
            }));
            let lineNumber = 1;
            for await (const row of parser) {
                lineNumber++;
                total++;
                // Validate row
                const validation = this.validateRow(row, lineNumber);
                errors.push(...validation.errors);
                // Check for duplicate SKUs within file
                if (row.sku) {
                    if (skus.has(row.sku)) {
                        duplicateSkus.push(row.sku);
                        errors.push({
                            line: lineNumber,
                            field: 'sku',
                            reason: 'Duplicate SKU within file',
                            value: row.sku,
                        });
                    }
                    skus.add(row.sku);
                }
                // Track categories
                if (row.category_id) {
                    categories.add(row.category_id);
                }
                // Check for missing translations
                if (!row.name_en || !row.name_de) {
                    missingTranslations++;
                }
            }
            // Check for duplicate SKUs in database
            const dbDuplicates = await this.checkDuplicateSKUs(Array.from(skus));
            // Validate categories exist
            const invalidCategories = await this.validateCategories(Array.from(categories));
            return {
                total,
                errors,
                warnings,
                duplicate_skus: [...duplicateSkus, ...dbDuplicates],
                invalid_categories: invalidCategories,
                missing_translations: missingTranslations,
            };
        }
        catch (error) {
            throw new Error(`CSV validation failed: ${error.message}`);
        }
    }
    async getImportStatistics() {
        // In production, query import_history table
        return {
            total_imports: 0,
            successful_products: 0,
            failed_products: 0,
            last_import_date: null,
        };
    }
    async saveImportHistory(progress, filename, userId) {
        // In production, save to import_history table
        console.log('Import completed:', {
            filename,
            userId,
            status: progress.status,
            total: progress.total,
            successful: progress.successful,
            failed: progress.failed,
            duration_ms: progress.duration_ms,
        });
    }
}
exports.default = OmexBulkImportService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL29tZXgtYnVsay1pbXBvcnQvc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHFEQUF5RDtBQUN6RCxtQ0FBaUM7QUFDakMseUNBQWlDO0FBU2pDLE1BQU0scUJBQXNCLFNBQVEsSUFBQSxxQkFBYSxFQUFDLEVBQUUsQ0FBQztJQUFyRDs7UUFDbUIsZUFBVSxHQUFHLElBQUksQ0FBQTtRQUNqQixvQkFBZSxHQUFHLENBQUMsS0FBSyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsYUFBYSxDQUFDLENBQUE7SUEwYS9FLENBQUM7SUFuYUMsS0FBSyxDQUFDLGFBQWEsQ0FDakIsVUFBa0IsRUFDbEIsVUFBK0M7UUFFL0MsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFBO1FBQzVCLE1BQU0sUUFBUSxHQUFtQjtZQUMvQixNQUFNLEVBQUUsWUFBWTtZQUNwQixLQUFLLEVBQUUsQ0FBQztZQUNSLFVBQVUsRUFBRSxDQUFDO1lBQ2IsTUFBTSxFQUFFLENBQUM7WUFDVCxNQUFNLEVBQUUsRUFBRTtZQUNWLFlBQVksRUFBRSxDQUFDO1NBQ2hCLENBQUE7UUFFRCxJQUFJLENBQUM7WUFDSCxNQUFNLE1BQU0sR0FBRyxpQkFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQTtZQUN4QyxNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsSUFBSSxDQUN4QixJQUFBLGlCQUFLLEVBQUM7Z0JBQ0osT0FBTyxFQUFFLElBQUk7Z0JBQ2IsZ0JBQWdCLEVBQUUsSUFBSTtnQkFDdEIsSUFBSSxFQUFFLElBQUk7YUFDWCxDQUFDLENBQ0gsQ0FBQTtZQUVELElBQUksS0FBSyxHQUF1QixFQUFFLENBQUE7WUFDbEMsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFBLENBQUMsbUJBQW1CO1lBRXRDLElBQUksS0FBSyxFQUFFLE1BQU0sR0FBRyxJQUFJLE1BQU0sRUFBRSxDQUFDO2dCQUMvQixVQUFVLEVBQUUsQ0FBQTtnQkFDWixRQUFRLENBQUMsWUFBWSxHQUFHLFVBQVUsQ0FBQTtnQkFDbEMsUUFBUSxDQUFDLEtBQUssRUFBRSxDQUFBO2dCQUVoQixlQUFlO2dCQUNmLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBdUIsRUFBRSxVQUFVLENBQUMsQ0FBQTtnQkFFeEUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztvQkFDdEIsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFBO29CQUNqQixRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQTtvQkFFMUMsSUFBSSxVQUFVLEVBQUUsQ0FBQzt3QkFDZixVQUFVLENBQUMsRUFBRSxHQUFHLFFBQVEsRUFBRSxDQUFDLENBQUE7b0JBQzdCLENBQUM7b0JBQ0QsU0FBUTtnQkFDVixDQUFDO2dCQUVELGNBQWM7Z0JBQ2QsSUFBSSxDQUFDO29CQUNILE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBdUIsQ0FBQyxDQUFBO29CQUN4RCxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO29CQUVuQiwyQ0FBMkM7b0JBQzNDLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7d0JBQ3BDLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQTt3QkFDOUIsUUFBUSxDQUFDLFVBQVUsSUFBSSxLQUFLLENBQUMsTUFBTSxDQUFBO3dCQUNuQyxLQUFLLEdBQUcsRUFBRSxDQUFBO3dCQUVWLElBQUksVUFBVSxFQUFFLENBQUM7NEJBQ2YsVUFBVSxDQUFDLEVBQUUsR0FBRyxRQUFRLEVBQUUsQ0FBQyxDQUFBO3dCQUM3QixDQUFDO29CQUNILENBQUM7Z0JBQ0gsQ0FBQztnQkFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO29CQUNwQixRQUFRLENBQUMsTUFBTSxFQUFFLENBQUE7b0JBQ2pCLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO3dCQUNuQixJQUFJLEVBQUUsVUFBVTt3QkFDaEIsS0FBSyxFQUFFLFlBQVk7d0JBQ25CLE1BQU0sRUFBRSxLQUFLLENBQUMsT0FBTztxQkFDdEIsQ0FBQyxDQUFBO29CQUVGLElBQUksVUFBVSxFQUFFLENBQUM7d0JBQ2YsVUFBVSxDQUFDLEVBQUUsR0FBRyxRQUFRLEVBQUUsQ0FBQyxDQUFBO29CQUM3QixDQUFDO2dCQUNILENBQUM7WUFDSCxDQUFDO1lBRUQsMEJBQTBCO1lBQzFCLElBQUksS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDckIsTUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFBO2dCQUM5QixRQUFRLENBQUMsVUFBVSxJQUFJLEtBQUssQ0FBQyxNQUFNLENBQUE7WUFDckMsQ0FBQztZQUVELFFBQVEsQ0FBQyxNQUFNLEdBQUcsV0FBVyxDQUFBO1lBQzdCLFFBQVEsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLFNBQVMsQ0FBQTtZQUU3QyxJQUFJLFVBQVUsRUFBRSxDQUFDO2dCQUNmLFVBQVUsQ0FBQyxFQUFFLEdBQUcsUUFBUSxFQUFFLENBQUMsQ0FBQTtZQUM3QixDQUFDO1lBRUQsT0FBTyxRQUFRLENBQUE7UUFDakIsQ0FBQztRQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7WUFDcEIsUUFBUSxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUE7WUFDMUIsUUFBUSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsU0FBUyxDQUFBO1lBQzdDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUNuQixJQUFJLEVBQUUsQ0FBQztnQkFDUCxLQUFLLEVBQUUsTUFBTTtnQkFDYixNQUFNLEVBQUUsMEJBQTBCLEtBQUssQ0FBQyxPQUFPLEVBQUU7YUFDbEQsQ0FBQyxDQUFBO1lBRUYsSUFBSSxVQUFVLEVBQUUsQ0FBQztnQkFDZixVQUFVLENBQUMsRUFBRSxHQUFHLFFBQVEsRUFBRSxDQUFDLENBQUE7WUFDN0IsQ0FBQztZQUVELE9BQU8sUUFBUSxDQUFBO1FBQ2pCLENBQUM7SUFDSCxDQUFDO0lBRU8sV0FBVyxDQUFDLEdBQXFCLEVBQUUsVUFBa0I7UUFDM0QsTUFBTSxNQUFNLEdBQWtCLEVBQUUsQ0FBQTtRQUVoQyx3QkFBd0I7UUFDeEIsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDekMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUErQixDQUFDLElBQUksR0FBRyxDQUFDLEtBQStCLENBQUMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQztnQkFDaEcsTUFBTSxDQUFDLElBQUksQ0FBQztvQkFDVixJQUFJLEVBQUUsVUFBVTtvQkFDaEIsS0FBSztvQkFDTCxNQUFNLEVBQUUsb0NBQW9DO29CQUM1QyxLQUFLLEVBQUUsR0FBRyxDQUFDLEtBQStCLENBQUM7aUJBQzVDLENBQUMsQ0FBQTtZQUNKLENBQUM7UUFDSCxDQUFDO1FBRUQsc0JBQXNCO1FBQ3RCLElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNqRCxNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUNWLElBQUksRUFBRSxVQUFVO2dCQUNoQixLQUFLLEVBQUUsS0FBSztnQkFDWixNQUFNLEVBQUUsK0NBQStDO2dCQUN2RCxLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7YUFDZixDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsaUJBQWlCO1FBQ2pCLElBQUksR0FBRyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ2QsTUFBTSxLQUFLLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQTtZQUNuQyxJQUFJLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxFQUFFLENBQUM7Z0JBQzlCLE1BQU0sQ0FBQyxJQUFJLENBQUM7b0JBQ1YsSUFBSSxFQUFFLFVBQVU7b0JBQ2hCLEtBQUssRUFBRSxPQUFPO29CQUNkLE1BQU0sRUFBRSxpQ0FBaUM7b0JBQ3pDLEtBQUssRUFBRSxHQUFHLENBQUMsS0FBSztpQkFDakIsQ0FBQyxDQUFBO1lBQ0osQ0FBQztRQUNILENBQUM7UUFFRCxnQkFBZ0I7UUFDaEIsSUFBSSxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDYixNQUFNLElBQUksR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFBO1lBQ2pDLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDNUIsTUFBTSxDQUFDLElBQUksQ0FBQztvQkFDVixJQUFJLEVBQUUsVUFBVTtvQkFDaEIsS0FBSyxFQUFFLE1BQU07b0JBQ2IsTUFBTSxFQUFFLGdDQUFnQztvQkFDeEMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxJQUFJO2lCQUNoQixDQUFDLENBQUE7WUFDSixDQUFDO1FBQ0gsQ0FBQztRQUVELHlCQUF5QjtRQUN6QixJQUFJLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUN0QixNQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFBO1lBQ3ZDLElBQUksS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDMUIsTUFBTSxDQUFDLElBQUksQ0FBQztvQkFDVixJQUFJLEVBQUUsVUFBVTtvQkFDaEIsS0FBSyxFQUFFLGVBQWU7b0JBQ3RCLE1BQU0sRUFBRSxtREFBbUQ7b0JBQzNELEtBQUssRUFBRSxHQUFHLENBQUMsYUFBYTtpQkFDekIsQ0FBQyxDQUFBO1lBQ0osQ0FBQztRQUNILENBQUM7UUFFRCxnQ0FBZ0M7UUFDaEMsSUFBSSxHQUFHLENBQUMsb0JBQW9CLElBQUksR0FBRyxDQUFDLG9CQUFvQixDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDO1lBQ3ZFLElBQUksQ0FBQztnQkFDSCxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFBO1lBQ3RDLENBQUM7WUFBQyxNQUFNLENBQUM7Z0JBQ1AsTUFBTSxDQUFDLElBQUksQ0FBQztvQkFDVixJQUFJLEVBQUUsVUFBVTtvQkFDaEIsS0FBSyxFQUFFLHNCQUFzQjtvQkFDN0IsTUFBTSxFQUFFLG9DQUFvQztvQkFDNUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxvQkFBb0I7aUJBQ2hDLENBQUMsQ0FBQTtZQUNKLENBQUM7UUFDSCxDQUFDO1FBRUQsT0FBTztZQUNMLEtBQUssRUFBRSxNQUFNLENBQUMsTUFBTSxLQUFLLENBQUM7WUFDMUIsTUFBTTtTQUNQLENBQUE7SUFDSCxDQUFDO0lBRU8sVUFBVSxDQUFDLEdBQXFCO1FBQ3RDLE1BQU0sY0FBYyxHQUFHLEdBQUcsQ0FBQyxvQkFBb0IsSUFBSSxHQUFHLENBQUMsb0JBQW9CLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRTtZQUN2RixDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUM7WUFDdEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQTtRQUVOLE9BQU87WUFDTCxHQUFHLEVBQUUsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUU7WUFDbkIsS0FBSyxFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFO1lBQ3pCLFdBQVcsRUFBRSxHQUFHLENBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUU7WUFDdEMsS0FBSyxFQUFFLFVBQVUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO1lBQzVCLElBQUksRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3pDLFdBQVcsRUFBRSxHQUFHLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRTtZQUNuQyxjQUFjLEVBQUUsR0FBRyxDQUFDLGNBQWMsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFO1lBQ2hELGFBQWEsRUFBRSxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2xFLGVBQWUsRUFBRSxjQUFjO1lBQy9CLFlBQVksRUFBRTtnQkFDWixFQUFFLEVBQUU7b0JBQ0YsS0FBSyxFQUFFLEdBQUcsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFO29CQUN6QixXQUFXLEVBQUUsR0FBRyxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFO2lCQUN2QztnQkFDRCxFQUFFLEVBQUU7b0JBQ0YsS0FBSyxFQUFFLEdBQUcsQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLElBQUksR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUU7b0JBQ2hELFdBQVcsRUFBRSxHQUFHLENBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLEdBQUcsQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRTtpQkFDOUQ7Z0JBQ0QsRUFBRSxFQUFFO29CQUNGLEtBQUssRUFBRSxHQUFHLENBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLEdBQUcsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFO29CQUNoRCxXQUFXLEVBQUUsR0FBRyxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxHQUFHLENBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUU7aUJBQzlEO2FBQ0Y7U0FDRixDQUFBO0lBQ0gsQ0FBQztJQUVPLEtBQUssQ0FBQyxZQUFZLENBQUMsUUFBNEI7UUFDckQsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsUUFBUSxDQUFDLE1BQU0sV0FBVyxDQUFDLENBQUE7UUFFOUQsc0NBQXNDO1FBQ3RDLE1BQU0sSUFBSSxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUE7UUFDckMsTUFBTSxVQUFVLEdBQUcsTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBQUE7UUFFdEQsSUFBSSxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQzFCLE1BQU0sSUFBSSxLQUFLLENBQUMscUNBQXFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBQy9FLENBQUM7UUFFRCxzQ0FBc0M7UUFDdEMsTUFBTSxXQUFXLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBQ2xFLE1BQU0saUJBQWlCLEdBQUcsTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDLENBQUE7UUFFcEUsSUFBSSxpQkFBaUIsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDakMsTUFBTSxJQUFJLEtBQUssQ0FBQyx5QkFBeUIsaUJBQWlCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUMxRSxDQUFDO1FBRUQsb0NBQW9DO1FBQ3BDLEtBQUssTUFBTSxPQUFPLElBQUksUUFBUSxFQUFFLENBQUM7WUFDL0IsSUFBSSxDQUFDO2dCQUNILDRDQUE0QztnQkFDNUMsTUFBTSxjQUFjLEdBQUcsTUFBTSxJQUFJLENBQUMsNkJBQTZCLENBQUMsT0FBTyxDQUFDLENBQUE7Z0JBQ3hFLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFBO1lBQ2xELENBQUM7WUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO2dCQUNwQixPQUFPLENBQUMsS0FBSyxDQUFDLDhCQUE4QixPQUFPLENBQUMsR0FBRyxHQUFHLEVBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFBO2dCQUMxRSxNQUFNLEtBQUssQ0FBQTtZQUNiLENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVPLEtBQUssQ0FBQyw2QkFBNkIsQ0FBQyxPQUF5QjtRQUNuRSx5RUFBeUU7UUFDekUsa0NBQWtDO1FBQ2xDLE9BQU87WUFDTCxFQUFFLEVBQUUsUUFBUSxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFO1lBQ25FLEdBQUcsRUFBRSxPQUFPLENBQUMsR0FBRztZQUNoQixLQUFLLEVBQUUsT0FBTyxDQUFDLEtBQUs7WUFDcEIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLO1lBQ3BCLFVBQVUsRUFBRSxJQUFJLElBQUksRUFBRTtTQUN2QixDQUFBO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxJQUFjO1FBQ3JDLGtEQUFrRDtRQUNsRCxpQ0FBaUM7UUFDakMsT0FBTyxFQUFFLENBQUE7SUFDWCxDQUFDO0lBRUQsS0FBSyxDQUFDLGtCQUFrQixDQUFDLFdBQXFCO1FBQzVDLHdEQUF3RDtRQUN4RCx1Q0FBdUM7UUFDdkMsT0FBTyxFQUFFLENBQUE7SUFDWCxDQUFDO0lBRUQsbUJBQW1CLENBQUMsTUFBcUI7UUFDdkMsSUFBSSxNQUFNLEdBQUcsdUJBQXVCLENBQUE7UUFDcEMsTUFBTSxJQUFJLHlCQUF5QixDQUFBO1FBQ25DLE1BQU0sSUFBSSxpQkFBaUIsTUFBTSxDQUFDLE1BQU0sTUFBTSxDQUFBO1FBRTlDLHVCQUF1QjtRQUN2QixNQUFNLGFBQWEsR0FBRyxJQUFJLEdBQUcsRUFBeUIsQ0FBQTtRQUN0RCxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ3JCLE1BQU0sUUFBUSxHQUFHLGFBQWEsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQTtZQUNyRCxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBO1lBQ3BCLGFBQWEsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsQ0FBQTtRQUMxQyxDQUFDLENBQUMsQ0FBQTtRQUVGLG1CQUFtQjtRQUNuQixNQUFNLElBQUksb0JBQW9CLENBQUE7UUFDOUIsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFdBQVcsRUFBRSxLQUFLLEVBQUUsRUFBRTtZQUMzQyxNQUFNLElBQUksS0FBSyxLQUFLLEtBQUssV0FBVyxDQUFDLE1BQU0sV0FBVyxDQUFBO1FBQ3hELENBQUMsQ0FBQyxDQUFBO1FBQ0YsTUFBTSxJQUFJLElBQUksQ0FBQTtRQUVkLGtCQUFrQjtRQUNsQixNQUFNLElBQUksb0JBQW9CLENBQUE7UUFDOUIsTUFBTSxJQUFJLHNCQUFzQixDQUFBO1FBQ2hDLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDckIsTUFBTSxJQUFJLFFBQVEsS0FBSyxDQUFDLElBQUksS0FBSyxLQUFLLENBQUMsS0FBSyxJQUFJLENBQUE7WUFDaEQsTUFBTSxJQUFJLGFBQWEsS0FBSyxDQUFDLE1BQU0sSUFBSSxDQUFBO1lBQ3ZDLElBQUksS0FBSyxDQUFDLEtBQUssS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDOUIsTUFBTSxJQUFJLFlBQVksS0FBSyxDQUFDLEtBQUssSUFBSSxDQUFBO1lBQ3ZDLENBQUM7WUFDRCxNQUFNLElBQUksSUFBSSxDQUFBO1FBQ2hCLENBQUMsQ0FBQyxDQUFBO1FBRUYsT0FBTyxNQUFNLENBQUE7SUFDZixDQUFDO0lBRUQsS0FBSyxDQUFDLFdBQVcsQ0FBQyxVQUFrQjtRQVFsQyxNQUFNLE1BQU0sR0FBa0IsRUFBRSxDQUFBO1FBQ2hDLE1BQU0sUUFBUSxHQUFhLEVBQUUsQ0FBQTtRQUM3QixNQUFNLElBQUksR0FBRyxJQUFJLEdBQUcsRUFBVSxDQUFBO1FBQzlCLE1BQU0sYUFBYSxHQUFhLEVBQUUsQ0FBQTtRQUNsQyxNQUFNLFVBQVUsR0FBRyxJQUFJLEdBQUcsRUFBVSxDQUFBO1FBQ3BDLElBQUksbUJBQW1CLEdBQUcsQ0FBQyxDQUFBO1FBQzNCLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQTtRQUViLElBQUksQ0FBQztZQUNILE1BQU0sTUFBTSxHQUFHLGlCQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFBO1lBQ3hDLE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQ3hCLElBQUEsaUJBQUssRUFBQztnQkFDSixPQUFPLEVBQUUsSUFBSTtnQkFDYixnQkFBZ0IsRUFBRSxJQUFJO2dCQUN0QixJQUFJLEVBQUUsSUFBSTthQUNYLENBQUMsQ0FDSCxDQUFBO1lBRUQsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFBO1lBRWxCLElBQUksS0FBSyxFQUFFLE1BQU0sR0FBRyxJQUFJLE1BQU0sRUFBRSxDQUFDO2dCQUMvQixVQUFVLEVBQUUsQ0FBQTtnQkFDWixLQUFLLEVBQUUsQ0FBQTtnQkFFUCxlQUFlO2dCQUNmLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBdUIsRUFBRSxVQUFVLENBQUMsQ0FBQTtnQkFDeEUsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQTtnQkFFakMsdUNBQXVDO2dCQUN2QyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztvQkFDWixJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7d0JBQ3RCLGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFBO3dCQUMzQixNQUFNLENBQUMsSUFBSSxDQUFDOzRCQUNWLElBQUksRUFBRSxVQUFVOzRCQUNoQixLQUFLLEVBQUUsS0FBSzs0QkFDWixNQUFNLEVBQUUsMkJBQTJCOzRCQUNuQyxLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7eUJBQ2YsQ0FBQyxDQUFBO29CQUNKLENBQUM7b0JBQ0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUE7Z0JBQ25CLENBQUM7Z0JBRUQsbUJBQW1CO2dCQUNuQixJQUFJLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQztvQkFDcEIsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUE7Z0JBQ2pDLENBQUM7Z0JBRUQsaUNBQWlDO2dCQUNqQyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsQ0FBQztvQkFDakMsbUJBQW1CLEVBQUUsQ0FBQTtnQkFDdkIsQ0FBQztZQUNILENBQUM7WUFFRCx1Q0FBdUM7WUFDdkMsTUFBTSxZQUFZLEdBQUcsTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFBO1lBRXBFLDRCQUE0QjtZQUM1QixNQUFNLGlCQUFpQixHQUFHLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQTtZQUUvRSxPQUFPO2dCQUNMLEtBQUs7Z0JBQ0wsTUFBTTtnQkFDTixRQUFRO2dCQUNSLGNBQWMsRUFBRSxDQUFDLEdBQUcsYUFBYSxFQUFFLEdBQUcsWUFBWSxDQUFDO2dCQUNuRCxrQkFBa0IsRUFBRSxpQkFBaUI7Z0JBQ3JDLG9CQUFvQixFQUFFLG1CQUFtQjthQUMxQyxDQUFBO1FBQ0gsQ0FBQztRQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7WUFDcEIsTUFBTSxJQUFJLEtBQUssQ0FBQywwQkFBMEIsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUE7UUFDNUQsQ0FBQztJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsbUJBQW1CO1FBTXZCLDRDQUE0QztRQUM1QyxPQUFPO1lBQ0wsYUFBYSxFQUFFLENBQUM7WUFDaEIsbUJBQW1CLEVBQUUsQ0FBQztZQUN0QixlQUFlLEVBQUUsQ0FBQztZQUNsQixnQkFBZ0IsRUFBRSxJQUFJO1NBQ3ZCLENBQUE7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLGlCQUFpQixDQUFDLFFBQXdCLEVBQUUsUUFBZ0IsRUFBRSxNQUFlO1FBQ2pGLDhDQUE4QztRQUM5QyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixFQUFFO1lBQy9CLFFBQVE7WUFDUixNQUFNO1lBQ04sTUFBTSxFQUFFLFFBQVEsQ0FBQyxNQUFNO1lBQ3ZCLEtBQUssRUFBRSxRQUFRLENBQUMsS0FBSztZQUNyQixVQUFVLEVBQUUsUUFBUSxDQUFDLFVBQVU7WUFDL0IsTUFBTSxFQUFFLFFBQVEsQ0FBQyxNQUFNO1lBQ3ZCLFdBQVcsRUFBRSxRQUFRLENBQUMsV0FBVztTQUNsQyxDQUFDLENBQUE7SUFDSixDQUFDO0NBQ0Y7QUFFRCxrQkFBZSxxQkFBcUIsQ0FBQSJ9