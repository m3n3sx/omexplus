"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class B2BService extends (0, utils_1.MedusaService)({}) {
    /**
     * Get pricing tier for a product based on quantity
     */
    async getPricingTier(productId, quantity) {
        if (!productId || quantity <= 0) {
            throw new Error("Valid product ID and quantity are required");
        }
        // In real implementation, fetch product with b2b_pricing_tiers
        const product = {}; // Would be populated from query
        const tiers = product.b2b_pricing_tiers || [];
        // Find applicable tier
        const applicableTier = tiers.find(tier => quantity >= tier.qty_min && (tier.qty_max === null || quantity <= tier.qty_max));
        if (applicableTier) {
            return {
                price: applicableTier.price,
                discount: applicableTier.discount_percentage || 0,
            };
        }
        // Return base price if no tier matches
        return {
            price: product.price || 0,
            discount: 0,
        };
    }
    /**
     * Calculate B2B pricing for multiple items
     */
    async calculateB2BPricing(items) {
        const pricedItems = [];
        let totalAmount = 0;
        for (const item of items) {
            const pricing = await this.getPricingTier(item.product_id, item.quantity);
            const itemTotal = pricing.price * item.quantity;
            pricedItems.push({
                product_id: item.product_id,
                quantity: item.quantity,
                unit_price: pricing.price,
                discount_percentage: pricing.discount,
                total: itemTotal,
            });
            totalAmount += itemTotal;
        }
        return {
            items: pricedItems,
            total_amount: totalAmount,
        };
    }
    /**
     * Create a quote for B2B customer
     */
    async createQuote(data) {
        if (!data.customer_id || !data.items || data.items.length === 0) {
            throw new Error("Customer ID and items are required");
        }
        // Calculate total
        const totalAmount = data.items.reduce((sum, item) => sum + item.total, 0);
        // Set default valid_until (30 days from now)
        const validUntil = data.valid_until || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
        const quoteData = {
            id: `quote_${Date.now()}`,
            customer_id: data.customer_id,
            items: data.items,
            total_amount: totalAmount,
            valid_until: validUntil,
            status: "draft",
            notes: data.notes,
            created_at: new Date(),
            updated_at: new Date(),
        };
        // In real implementation, save to database
        return quoteData;
    }
    /**
     * Update quote status
     */
    async updateQuoteStatus(quoteId, status) {
        if (!quoteId) {
            throw new Error("Quote ID is required");
        }
        const validStatuses = ["draft", "sent", "accepted", "rejected", "expired"];
        if (!validStatuses.includes(status)) {
            throw new Error(`Invalid status. Must be one of: ${validStatuses.join(", ")}`);
        }
        // In real implementation, update in database
        return {
            id: quoteId,
            status,
            updated_at: new Date(),
        };
    }
    /**
     * Get quotes for a customer
     */
    async getCustomerQuotes(customerId, filters = {}) {
        if (!customerId) {
            throw new Error("Customer ID is required");
        }
        // In real implementation, query database
        return {
            quotes: [],
            count: 0,
        };
    }
    /**
     * Create a purchase order
     */
    async createPurchaseOrder(data) {
        if (!data.customer_id || !data.po_number || !data.items || data.items.length === 0) {
            throw new Error("Customer ID, PO number, and items are required");
        }
        // Check if PO number already exists
        const existing = await this.findPurchaseOrderByNumber(data.po_number);
        if (existing) {
            throw new Error(`Purchase order with number "${data.po_number}" already exists`);
        }
        // Calculate total
        const totalAmount = data.items.reduce((sum, item) => sum + item.total, 0);
        const poData = {
            id: `po_${Date.now()}`,
            customer_id: data.customer_id,
            po_number: data.po_number,
            items: data.items,
            total_amount: totalAmount,
            payment_terms: data.payment_terms || "NET30",
            delivery_date: data.delivery_date,
            status: "pending",
            notes: data.notes,
            created_at: new Date(),
            updated_at: new Date(),
        };
        // In real implementation, save to database
        return poData;
    }
    /**
     * Update purchase order status
     */
    async updatePurchaseOrderStatus(poId, status) {
        if (!poId) {
            throw new Error("Purchase order ID is required");
        }
        const validStatuses = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"];
        if (!validStatuses.includes(status)) {
            throw new Error(`Invalid status. Must be one of: ${validStatuses.join(", ")}`);
        }
        // In real implementation, update in database
        return {
            id: poId,
            status,
            updated_at: new Date(),
        };
    }
    /**
     * Get purchase orders for a customer
     */
    async getCustomerPurchaseOrders(customerId, filters = {}) {
        if (!customerId) {
            throw new Error("Customer ID is required");
        }
        // In real implementation, query database
        return {
            purchase_orders: [],
            count: 0,
        };
    }
    /**
     * Find purchase order by PO number
     */
    async findPurchaseOrderByNumber(poNumber) {
        if (!poNumber) {
            return null;
        }
        // In real implementation, query database
        return null;
    }
    /**
     * Validate B2B order (check min quantities, stock, etc.)
     */
    async validateB2BOrder(items) {
        const errors = [];
        const warnings = [];
        for (const item of items) {
            // In real implementation, fetch product from database
            const product = {}; // Would be populated from query
            // Check minimum quantity
            if (product.b2b_min_quantity && item.quantity < product.b2b_min_quantity) {
                errors.push(`Product ${item.product_id} requires minimum quantity of ${product.b2b_min_quantity}`);
            }
            // Check stock availability
            if (product.stock_available < item.quantity) {
                warnings.push(`Product ${item.product_id} has only ${product.stock_available} units available (requested: ${item.quantity})`);
            }
            // Check if quote is required
            if (product.requires_quote) {
                warnings.push(`Product ${item.product_id} requires a custom quote`);
            }
        }
        return {
            valid: errors.length === 0,
            errors,
            warnings,
        };
    }
    /**
     * Create or update B2B customer group
     */
    async createCustomerGroup(data) {
        if (!data.name) {
            throw new Error("Customer group name is required");
        }
        const groupData = {
            id: `b2b_group_${Date.now()}`,
            name: data.name,
            discount_percentage: data.discount_percentage || 0,
            min_order_value: data.min_order_value || 0,
            payment_terms: data.payment_terms || "NET30",
            custom_catalog_ids: data.custom_catalog_ids || [],
            created_at: new Date(),
            updated_at: new Date(),
        };
        // In real implementation, save to database
        return groupData;
    }
    /**
     * Get customer group discount
     */
    async getCustomerGroupDiscount(customerId) {
        if (!customerId) {
            return 0;
        }
        // In real implementation, fetch customer's group and return discount
        return 0;
    }
}
exports.default = B2BService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL29tZXgtYjJiL3NlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBeUQ7QUFnQ3pELE1BQU0sVUFBVyxTQUFRLElBQUEscUJBQWEsRUFBQyxFQUFFLENBQUM7SUFDeEM7O09BRUc7SUFDSCxLQUFLLENBQUMsY0FBYyxDQUFDLFNBQWlCLEVBQUUsUUFBZ0I7UUFDdEQsSUFBSSxDQUFDLFNBQVMsSUFBSSxRQUFRLElBQUksQ0FBQyxFQUFFLENBQUM7WUFDaEMsTUFBTSxJQUFJLEtBQUssQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFBO1FBQy9ELENBQUM7UUFFRCwrREFBK0Q7UUFDL0QsTUFBTSxPQUFPLEdBQVEsRUFBRSxDQUFBLENBQUMsZ0NBQWdDO1FBRXhELE1BQU0sS0FBSyxHQUFrQixPQUFPLENBQUMsaUJBQWlCLElBQUksRUFBRSxDQUFBO1FBRTVELHVCQUF1QjtRQUN2QixNQUFNLGNBQWMsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUMvQixJQUFJLENBQUMsRUFBRSxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sS0FBSyxJQUFJLElBQUksUUFBUSxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FDeEYsQ0FBQTtRQUVELElBQUksY0FBYyxFQUFFLENBQUM7WUFDbkIsT0FBTztnQkFDTCxLQUFLLEVBQUUsY0FBYyxDQUFDLEtBQUs7Z0JBQzNCLFFBQVEsRUFBRSxjQUFjLENBQUMsbUJBQW1CLElBQUksQ0FBQzthQUNsRCxDQUFBO1FBQ0gsQ0FBQztRQUVELHVDQUF1QztRQUN2QyxPQUFPO1lBQ0wsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLLElBQUksQ0FBQztZQUN6QixRQUFRLEVBQUUsQ0FBQztTQUNaLENBQUE7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsbUJBQW1CLENBQUMsS0FBc0Q7UUFDOUUsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFBO1FBQ3RCLElBQUksV0FBVyxHQUFHLENBQUMsQ0FBQTtRQUVuQixLQUFLLE1BQU0sSUFBSSxJQUFJLEtBQUssRUFBRSxDQUFDO1lBQ3pCLE1BQU0sT0FBTyxHQUFHLE1BQU0sSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQTtZQUN6RSxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUE7WUFFL0MsV0FBVyxDQUFDLElBQUksQ0FBQztnQkFDZixVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7Z0JBQzNCLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTtnQkFDdkIsVUFBVSxFQUFFLE9BQU8sQ0FBQyxLQUFLO2dCQUN6QixtQkFBbUIsRUFBRSxPQUFPLENBQUMsUUFBUTtnQkFDckMsS0FBSyxFQUFFLFNBQVM7YUFDakIsQ0FBQyxDQUFBO1lBRUYsV0FBVyxJQUFJLFNBQVMsQ0FBQTtRQUMxQixDQUFDO1FBRUQsT0FBTztZQUNMLEtBQUssRUFBRSxXQUFXO1lBQ2xCLFlBQVksRUFBRSxXQUFXO1NBQzFCLENBQUE7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsV0FBVyxDQUFDLElBQW9CO1FBQ3BDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNoRSxNQUFNLElBQUksS0FBSyxDQUFDLG9DQUFvQyxDQUFDLENBQUE7UUFDdkQsQ0FBQztRQUVELGtCQUFrQjtRQUNsQixNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFBO1FBRXpFLDZDQUE2QztRQUM3QyxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUE7UUFFdEYsTUFBTSxTQUFTLEdBQUc7WUFDaEIsRUFBRSxFQUFFLFNBQVMsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO1lBQ3pCLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVztZQUM3QixLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7WUFDakIsWUFBWSxFQUFFLFdBQVc7WUFDekIsV0FBVyxFQUFFLFVBQVU7WUFDdkIsTUFBTSxFQUFFLE9BQU87WUFDZixLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7WUFDakIsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFO1lBQ3RCLFVBQVUsRUFBRSxJQUFJLElBQUksRUFBRTtTQUN2QixDQUFBO1FBRUQsMkNBQTJDO1FBQzNDLE9BQU8sU0FBUyxDQUFBO0lBQ2xCLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxPQUFlLEVBQUUsTUFBOEQ7UUFDckcsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2IsTUFBTSxJQUFJLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxDQUFBO1FBQ3pDLENBQUM7UUFFRCxNQUFNLGFBQWEsR0FBRyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRSxTQUFTLENBQUMsQ0FBQTtRQUMxRSxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1lBQ3BDLE1BQU0sSUFBSSxLQUFLLENBQUMsbUNBQW1DLGFBQWEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBQ2hGLENBQUM7UUFFRCw2Q0FBNkM7UUFDN0MsT0FBTztZQUNMLEVBQUUsRUFBRSxPQUFPO1lBQ1gsTUFBTTtZQUNOLFVBQVUsRUFBRSxJQUFJLElBQUksRUFBRTtTQUN2QixDQUFBO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGlCQUFpQixDQUFDLFVBQWtCLEVBQUUsVUFBK0IsRUFBRTtRQUMzRSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDaEIsTUFBTSxJQUFJLEtBQUssQ0FBQyx5QkFBeUIsQ0FBQyxDQUFBO1FBQzVDLENBQUM7UUFFRCx5Q0FBeUM7UUFDekMsT0FBTztZQUNMLE1BQU0sRUFBRSxFQUFFO1lBQ1YsS0FBSyxFQUFFLENBQUM7U0FDVCxDQUFBO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLG1CQUFtQixDQUFDLElBQTRCO1FBQ3BELElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDbkYsTUFBTSxJQUFJLEtBQUssQ0FBQyxnREFBZ0QsQ0FBQyxDQUFBO1FBQ25FLENBQUM7UUFFRCxvQ0FBb0M7UUFDcEMsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFBO1FBQ3JFLElBQUksUUFBUSxFQUFFLENBQUM7WUFDYixNQUFNLElBQUksS0FBSyxDQUFDLCtCQUErQixJQUFJLENBQUMsU0FBUyxrQkFBa0IsQ0FBQyxDQUFBO1FBQ2xGLENBQUM7UUFFRCxrQkFBa0I7UUFDbEIsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQTtRQUV6RSxNQUFNLE1BQU0sR0FBRztZQUNiLEVBQUUsRUFBRSxNQUFNLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtZQUN0QixXQUFXLEVBQUUsSUFBSSxDQUFDLFdBQVc7WUFDN0IsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO1lBQ3pCLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztZQUNqQixZQUFZLEVBQUUsV0FBVztZQUN6QixhQUFhLEVBQUUsSUFBSSxDQUFDLGFBQWEsSUFBSSxPQUFPO1lBQzVDLGFBQWEsRUFBRSxJQUFJLENBQUMsYUFBYTtZQUNqQyxNQUFNLEVBQUUsU0FBUztZQUNqQixLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7WUFDakIsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFO1lBQ3RCLFVBQVUsRUFBRSxJQUFJLElBQUksRUFBRTtTQUN2QixDQUFBO1FBRUQsMkNBQTJDO1FBQzNDLE9BQU8sTUFBTSxDQUFBO0lBQ2YsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLHlCQUF5QixDQUM3QixJQUFZLEVBQ1osTUFBc0Y7UUFFdEYsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ1YsTUFBTSxJQUFJLEtBQUssQ0FBQywrQkFBK0IsQ0FBQyxDQUFBO1FBQ2xELENBQUM7UUFFRCxNQUFNLGFBQWEsR0FBRyxDQUFDLFNBQVMsRUFBRSxXQUFXLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUE7UUFDakcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztZQUNwQyxNQUFNLElBQUksS0FBSyxDQUFDLG1DQUFtQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUNoRixDQUFDO1FBRUQsNkNBQTZDO1FBQzdDLE9BQU87WUFDTCxFQUFFLEVBQUUsSUFBSTtZQUNSLE1BQU07WUFDTixVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDdkIsQ0FBQTtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyx5QkFBeUIsQ0FBQyxVQUFrQixFQUFFLFVBQStCLEVBQUU7UUFDbkYsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2hCLE1BQU0sSUFBSSxLQUFLLENBQUMseUJBQXlCLENBQUMsQ0FBQTtRQUM1QyxDQUFDO1FBRUQseUNBQXlDO1FBQ3pDLE9BQU87WUFDTCxlQUFlLEVBQUUsRUFBRTtZQUNuQixLQUFLLEVBQUUsQ0FBQztTQUNULENBQUE7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMseUJBQXlCLENBQUMsUUFBZ0I7UUFDOUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ2QsT0FBTyxJQUFJLENBQUE7UUFDYixDQUFDO1FBRUQseUNBQXlDO1FBQ3pDLE9BQU8sSUFBSSxDQUFBO0lBQ2IsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGdCQUFnQixDQUFDLEtBQXNEO1FBQzNFLE1BQU0sTUFBTSxHQUFhLEVBQUUsQ0FBQTtRQUMzQixNQUFNLFFBQVEsR0FBYSxFQUFFLENBQUE7UUFFN0IsS0FBSyxNQUFNLElBQUksSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUN6QixzREFBc0Q7WUFDdEQsTUFBTSxPQUFPLEdBQVEsRUFBRSxDQUFBLENBQUMsZ0NBQWdDO1lBRXhELHlCQUF5QjtZQUN6QixJQUFJLE9BQU8sQ0FBQyxnQkFBZ0IsSUFBSSxJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO2dCQUN6RSxNQUFNLENBQUMsSUFBSSxDQUNULFdBQVcsSUFBSSxDQUFDLFVBQVUsaUNBQWlDLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxDQUN0RixDQUFBO1lBQ0gsQ0FBQztZQUVELDJCQUEyQjtZQUMzQixJQUFJLE9BQU8sQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO2dCQUM1QyxRQUFRLENBQUMsSUFBSSxDQUNYLFdBQVcsSUFBSSxDQUFDLFVBQVUsYUFBYSxPQUFPLENBQUMsZUFBZSxnQ0FBZ0MsSUFBSSxDQUFDLFFBQVEsR0FBRyxDQUMvRyxDQUFBO1lBQ0gsQ0FBQztZQUVELDZCQUE2QjtZQUM3QixJQUFJLE9BQU8sQ0FBQyxjQUFjLEVBQUUsQ0FBQztnQkFDM0IsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLElBQUksQ0FBQyxVQUFVLDBCQUEwQixDQUFDLENBQUE7WUFDckUsQ0FBQztRQUNILENBQUM7UUFFRCxPQUFPO1lBQ0wsS0FBSyxFQUFFLE1BQU0sQ0FBQyxNQUFNLEtBQUssQ0FBQztZQUMxQixNQUFNO1lBQ04sUUFBUTtTQUNULENBQUE7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsbUJBQW1CLENBQUMsSUFNekI7UUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2YsTUFBTSxJQUFJLEtBQUssQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFBO1FBQ3BELENBQUM7UUFFRCxNQUFNLFNBQVMsR0FBRztZQUNoQixFQUFFLEVBQUUsYUFBYSxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUU7WUFDN0IsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO1lBQ2YsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixJQUFJLENBQUM7WUFDbEQsZUFBZSxFQUFFLElBQUksQ0FBQyxlQUFlLElBQUksQ0FBQztZQUMxQyxhQUFhLEVBQUUsSUFBSSxDQUFDLGFBQWEsSUFBSSxPQUFPO1lBQzVDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxrQkFBa0IsSUFBSSxFQUFFO1lBQ2pELFVBQVUsRUFBRSxJQUFJLElBQUksRUFBRTtZQUN0QixVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDdkIsQ0FBQTtRQUVELDJDQUEyQztRQUMzQyxPQUFPLFNBQVMsQ0FBQTtJQUNsQixDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsd0JBQXdCLENBQUMsVUFBa0I7UUFDL0MsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2hCLE9BQU8sQ0FBQyxDQUFBO1FBQ1YsQ0FBQztRQUVELHFFQUFxRTtRQUNyRSxPQUFPLENBQUMsQ0FBQTtJQUNWLENBQUM7Q0FDRjtBQUVELGtCQUFlLFVBQVUsQ0FBQSJ9