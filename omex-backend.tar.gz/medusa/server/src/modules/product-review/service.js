"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class ProductReviewService extends (0, utils_1.MedusaService)({}) {
    async createReview(data) {
        // Implementacja tworzenia recenzji
        return {
            id: `review_${Date.now()}`,
            ...data,
            createdAt: new Date(),
        };
    }
    async getProductReviews(productId) {
        // Implementacja pobierania recenzji produktu
        return [];
    }
    async getAverageRating(productId) {
        // Implementacja obliczania średniej oceny
        return 0;
    }
}
exports.default = ProductReviewService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL3Byb2R1Y3QtcmV2aWV3L3NlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBeUQ7QUFFekQsTUFBTSxvQkFBcUIsU0FBUSxJQUFBLHFCQUFhLEVBQUMsRUFBRSxDQUFDO0lBQ2xELEtBQUssQ0FBQyxZQUFZLENBQUMsSUFLbEI7UUFDQyxtQ0FBbUM7UUFDbkMsT0FBTztZQUNMLEVBQUUsRUFBRSxVQUFVLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtZQUMxQixHQUFHLElBQUk7WUFDUCxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDdEIsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsaUJBQWlCLENBQUMsU0FBaUI7UUFDdkMsNkNBQTZDO1FBQzdDLE9BQU8sRUFBRSxDQUFBO0lBQ1gsQ0FBQztJQUVELEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFpQjtRQUN0QywwQ0FBMEM7UUFDMUMsT0FBTyxDQUFDLENBQUE7SUFDVixDQUFDO0NBQ0Y7QUFFRCxrQkFBZSxvQkFBb0IsQ0FBQSJ9