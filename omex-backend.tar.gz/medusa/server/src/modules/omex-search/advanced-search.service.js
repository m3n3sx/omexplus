"use strict";
/**
 * Advanced Search Service - 5 Search Methods
 * Implementation of szukajka.md specification
 */
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class AdvancedSearchService extends (0, utils_1.MedusaService)({}) {
    // ============================================================================
    // METHOD 1: Machine-Based Search (5-step wizard)
    // ============================================================================
    /**
     * Get available brands for step 1
     */
    async getMachineBrands() {
        return [
            'CAT',
            'Komatsu',
            'Hitachi',
            'Volvo',
            'JCB',
            'Kobelco',
            'Hyundai',
            'Bobcat',
            'Doosan',
            'Yuchai',
            'Atlas',
            'Liebherr',
            'Terex',
            'Case',
            'New Holland',
        ];
    }
    /**
     * Get available machine types for step 2
     */
    async getMachineTypes(brand) {
        // In real implementation, query database for available types
        return [
            { value: 'excavator', label: 'Koparka', count: 1500 },
            { value: 'loader', label: 'Ładowarka', count: 800 },
            { value: 'backhoe', label: 'Koparka-ładowarka', count: 400 },
            { value: 'dozer', label: 'Spychacz', count: 300 },
            { value: 'telehandler', label: 'Ładowarka teleskopowa', count: 200 },
            { value: 'compactor', label: 'Walcarka', count: 150 },
            { value: 'mini-excavator', label: 'Mini koparka', count: 600 },
            { value: 'wheel-excavator', label: 'Koparka kołowa', count: 250 },
        ];
    }
    /**
     * Get available models for step 3
     */
    async getMachineModels(brand, type) {
        // In real implementation, query machine database
        // Example for CAT excavators:
        if (brand === 'CAT' && type === 'excavator') {
            return [
                {
                    id: 'cat-301',
                    brand: 'CAT',
                    type: 'excavator',
                    model: '301.7D',
                    series: 'D',
                    frame: 'small',
                    weight: 1.7,
                    yearFrom: 2015,
                    yearTo: 2024,
                    compatibleParts: [],
                },
                {
                    id: 'cat-320',
                    brand: 'CAT',
                    type: 'excavator',
                    model: '320D',
                    series: 'D',
                    frame: 'standard',
                    weight: 20,
                    yearFrom: 2005,
                    yearTo: 2015,
                    compatibleParts: [],
                },
                // ... more models
            ];
        }
        return [];
    }
    /**
     * Search parts by machine (complete 5-step search)
     */
    async searchByMachine(params) {
        const { brand, machineType, model, series, frame, engine } = params;
        // Build query to find compatible parts
        const query = `
      SELECT DISTINCT p.*
      FROM product p
      JOIN product_compatibility pc ON p.id = pc.product_id
      JOIN machine_definition md ON pc.machine_id = md.id
      WHERE md.brand = $1
        AND md.type = $2
        AND md.model = $3
        ${series ? 'AND md.series = $4' : ''}
        ${frame ? 'AND md.frame = $5' : ''}
        ${engine ? 'AND md.engine = $6' : ''}
      ORDER BY p.popularity DESC
    `;
        // In real implementation, execute query and return results
        return {
            products: [],
            total: 0,
            page: 1,
            limit: 50,
            hasMore: false,
            searchTime: 0,
        };
    }
    // ============================================================================
    // METHOD 2: Part Number Search
    // ============================================================================
    /**
     * Search by OEM part number with alternatives
     */
    async searchByPartNumber(params) {
        const { partNumber, includeAlternatives = true, exactMatch = false } = params;
        // Normalize part number (remove spaces, dashes, etc.)
        const normalized = this.normalizePartNumber(partNumber);
        // Search for exact match
        const exactQuery = `
      SELECT p.*, 
        CASE 
          WHEN p.part_number = $1 THEN 100
          WHEN p.sku = $1 THEN 90
          WHEN p.ean = $1 THEN 80
          ELSE 0
        END as match_score
      FROM product p
      WHERE p.part_number = $1 
         OR p.sku = $1 
         OR p.ean = $1
      ORDER BY match_score DESC
      LIMIT 1
    `;
        // Search for alternatives if requested
        let alternatives = [];
        if (includeAlternatives) {
            const altQuery = `
        SELECT p.*, pa.compatibility_score
        FROM product p
        JOIN product_alternative pa ON p.id = pa.alternative_id
        WHERE pa.original_part_number = $1
        ORDER BY pa.compatibility_score DESC, p.price ASC
        LIMIT 10
      `;
            // Execute query
        }
        // Get similar part numbers for suggestions
        const suggestions = await this.getSimilarPartNumbers(normalized);
        return {
            exact: undefined, // Would be populated from query
            alternatives: [],
            suggestions,
        };
    }
    /**
     * Normalize part number for better matching
     */
    normalizePartNumber(partNumber) {
        return partNumber
            .toUpperCase()
            .replace(/[\s\-_]/g, '')
            .trim();
    }
    /**
     * Find similar part numbers (fuzzy matching)
     */
    async getSimilarPartNumbers(partNumber, limit = 5) {
        // Use PostgreSQL similarity or Levenshtein distance
        const query = `
      SELECT DISTINCT part_number
      FROM product
      WHERE similarity(part_number, $1) > 0.3
      ORDER BY similarity(part_number, $1) DESC
      LIMIT $2
    `;
        return [];
    }
    // ============================================================================
    // METHOD 3: Visual Search (Image-based)
    // ============================================================================
    /**
     * Search by image upload
     */
    async searchByImage(params) {
        const { image, detectOCR = true } = params;
        let ocrResults = [];
        let detectedPartType;
        // Step 1: OCR - Try to read part numbers from image
        if (detectOCR) {
            ocrResults = await this.performOCR(image);
            // If we found part numbers, search by them
            if (ocrResults.length > 0) {
                const partNumberResults = await this.searchByPartNumber({
                    partNumber: ocrResults[0],
                    includeAlternatives: true,
                });
                return {
                    ocrResults,
                    similarParts: partNumberResults.alternatives,
                    confidence: 0.9,
                };
            }
        }
        // Step 2: AI Image Recognition - Detect part type
        detectedPartType = await this.detectPartType(image);
        // Step 3: Visual similarity search
        const similarParts = await this.findVisualSimilarParts(image);
        return {
            detectedPartType,
            ocrResults,
            similarParts,
            confidence: 0.7,
        };
    }
    /**
     * Perform OCR on image to extract text/part numbers
     */
    async performOCR(image) {
        // In real implementation:
        // - Use Tesseract.js or Google Vision API
        // - Extract text from image
        // - Filter for part number patterns (e.g., "320-8134", "6D-8752")
        return [];
    }
    /**
     * Detect part type using AI/ML
     */
    async detectPartType(image) {
        // In real implementation:
        // - Use TensorFlow.js or custom ML model
        // - Classify image into part categories
        // - Return detected category
        return undefined;
    }
    /**
     * Find visually similar parts
     */
    async findVisualSimilarParts(image) {
        // In real implementation:
        // - Generate image embedding/vector
        // - Search vector database for similar images
        // - Return matching products
        return [];
    }
    // ============================================================================
    // METHOD 4: Text Search (Natural Language)
    // ============================================================================
    /**
     * Natural language search with intelligent parsing
     */
    async searchByText(params) {
        const { query, language = 'pl', fuzzy = true } = params;
        // Parse the query to extract structured data
        const parsed = await this.parseNaturalLanguageQuery(query, language);
        // Build search based on parsed components
        let searchQuery = query;
        // If we detected specific brands/models, use machine search
        if (parsed.brands && parsed.brands.length > 0 && parsed.models && parsed.models.length > 0) {
            return this.searchByMachine({
                brand: parsed.brands[0],
                machineType: 'excavator', // Would be detected from query
                model: parsed.models[0],
            });
        }
        // If we detected OEM numbers, use part number search
        if (parsed.oemNumbers && parsed.oemNumbers.length > 0) {
            const result = await this.searchByPartNumber({
                partNumber: parsed.oemNumbers[0],
                includeAlternatives: true,
            });
            return {
                products: result.alternatives,
                total: result.alternatives.length,
                page: 1,
                limit: 50,
                hasMore: false,
                parsedQuery: parsed,
            };
        }
        // Otherwise, do full-text search
        return this.fullTextSearch(searchQuery, parsed, fuzzy);
    }
    /**
     * Parse natural language query into structured data
     */
    async parseNaturalLanguageQuery(query, language) {
        const parsed = {
            brands: [],
            models: [],
            partTypes: [],
            parameters: {},
            oemNumbers: [],
        };
        const lowerQuery = query.toLowerCase();
        // Detect brands
        const brands = ['cat', 'komatsu', 'hitachi', 'volvo', 'jcb', 'kobelco', 'hyundai', 'bobcat'];
        for (const brand of brands) {
            if (lowerQuery.includes(brand)) {
                parsed.brands?.push(brand.toUpperCase());
            }
        }
        // Detect models (e.g., "320d", "pc200", "zx210")
        const modelPattern = /\b([a-z]{1,3}\d{2,4}[a-z]?)\b/gi;
        const modelMatches = query.match(modelPattern);
        if (modelMatches) {
            parsed.models = modelMatches.map(m => m.toUpperCase());
        }
        // Detect OEM part numbers (e.g., "320-8134", "6D-8752")
        const oemPattern = /\b(\d{1,4}[-_]?\d{4})\b/g;
        const oemMatches = query.match(oemPattern);
        if (oemMatches) {
            parsed.oemNumbers = oemMatches;
        }
        // Detect part types (in Polish)
        const partTypes = {
            'pompa': 'pump',
            'filtr': 'filter',
            'gąsienica': 'track',
            'cylinder': 'cylinder',
            'zawór': 'valve',
            'silnik': 'engine',
            'młot': 'hammer',
        };
        for (const [pl, en] of Object.entries(partTypes)) {
            if (lowerQuery.includes(pl)) {
                parsed.partTypes?.push(en);
            }
        }
        // Detect parameters (e.g., "3 tony", "600mm")
        const weightPattern = /(\d+)\s*(ton[ya]?|kg)/gi;
        const weightMatch = query.match(weightPattern);
        if (weightMatch) {
            parsed.parameters.weight = weightMatch[0];
        }
        return parsed;
    }
    /**
     * Full-text search implementation
     */
    async fullTextSearch(query, parsed, fuzzy) {
        const searchTerms = query.trim().split(/\s+/).join(fuzzy ? ' | ' : ' & ');
        const sql = `
      SELECT p.*,
        ts_rank(
          to_tsvector('simple', 
            COALESCE(p.title, '') || ' ' || 
            COALESCE(p.description, '') || ' ' ||
            COALESCE(p.part_number, '') || ' ' ||
            COALESCE(p.sku, '')
          ),
          to_tsquery('simple', $1)
        ) as rank
      FROM product p
      WHERE to_tsvector('simple', 
        COALESCE(p.title, '') || ' ' || 
        COALESCE(p.description, '') || ' ' ||
        COALESCE(p.part_number, '') || ' ' ||
        COALESCE(p.sku, '')
      ) @@ to_tsquery('simple', $1)
      ORDER BY rank DESC
      LIMIT 50
    `;
        return {
            products: [],
            total: 0,
            page: 1,
            limit: 50,
            hasMore: false,
            parsedQuery: parsed,
        };
    }
    // ============================================================================
    // METHOD 5: Advanced Filters
    // ============================================================================
    /**
     * Search with advanced filters
     */
    async searchWithFilters(filters) {
        const conditions = [];
        const params = [];
        let paramIndex = 1;
        // Category filter
        if (filters.categoryIds && filters.categoryIds.length > 0) {
            if (filters.includeSubcategories) {
                // Get all descendant categories
                const allCategoryIds = await this.getAllDescendantCategories(filters.categoryIds);
                conditions.push(`p.category_id = ANY($${paramIndex})`);
                params.push(allCategoryIds);
            }
            else {
                conditions.push(`p.category_id = ANY($${paramIndex})`);
                params.push(filters.categoryIds);
            }
            paramIndex++;
        }
        // Machine brand filter
        if (filters.machineBrands && filters.machineBrands.length > 0) {
            conditions.push(`p.machine_brand = ANY($${paramIndex})`);
            params.push(filters.machineBrands);
            paramIndex++;
        }
        // Availability filter
        if (filters.availability && filters.availability.length > 0) {
            conditions.push(`p.availability = ANY($${paramIndex})`);
            params.push(filters.availability);
            paramIndex++;
        }
        // Price range
        if (filters.minPrice !== undefined) {
            conditions.push(`p.price >= $${paramIndex}`);
            params.push(filters.minPrice);
            paramIndex++;
        }
        if (filters.maxPrice !== undefined) {
            conditions.push(`p.price <= $${paramIndex}`);
            params.push(filters.maxPrice);
            paramIndex++;
        }
        // Part type (OEM vs alternatives)
        if (filters.partTypes && filters.partTypes.length > 0) {
            conditions.push(`p.part_type = ANY($${paramIndex})`);
            params.push(filters.partTypes);
            paramIndex++;
        }
        // Manufacturer
        if (filters.manufacturers && filters.manufacturers.length > 0) {
            conditions.push(`p.manufacturer = ANY($${paramIndex})`);
            params.push(filters.manufacturers);
            paramIndex++;
        }
        // Rating filter
        if (filters.minRating) {
            conditions.push(`p.rating >= $${paramIndex}`);
            params.push(filters.minRating);
            paramIndex++;
        }
        if (filters.minReviews) {
            conditions.push(`p.review_count >= $${paramIndex}`);
            params.push(filters.minReviews);
            paramIndex++;
        }
        // Build final query
        const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
        const orderBy = this.buildOrderByClause(filters.sortBy);
        const sql = `
      SELECT p.*
      FROM product p
      ${whereClause}
      ${orderBy}
      LIMIT 50
    `;
        return {
            products: [],
            total: 0,
            page: 1,
            limit: 50,
            hasMore: false,
            filters,
        };
    }
    /**
     * Get all descendant category IDs
     */
    async getAllDescendantCategories(categoryIds) {
        // Recursive CTE to get all descendants
        const query = `
      WITH RECURSIVE category_tree AS (
        SELECT id FROM product_category WHERE id = ANY($1)
        UNION
        SELECT pc.id FROM product_category pc
        INNER JOIN category_tree ct ON pc.parent_category_id = ct.id
      )
      SELECT id FROM category_tree
    `;
        return categoryIds; // Would be populated from query
    }
    /**
     * Build ORDER BY clause based on sort option
     */
    buildOrderByClause(sortBy) {
        switch (sortBy) {
            case 'newest':
                return 'ORDER BY p.created_at DESC';
            case 'best-selling':
                return 'ORDER BY p.sales_count DESC';
            case 'price-asc':
                return 'ORDER BY p.price ASC';
            case 'price-desc':
                return 'ORDER BY p.price DESC';
            case 'rating':
                return 'ORDER BY p.rating DESC, p.review_count DESC';
            default:
                return 'ORDER BY p.popularity DESC';
        }
    }
    // ============================================================================
    // Autocomplete & Suggestions
    // ============================================================================
    /**
     * Get search suggestions for autocomplete
     */
    async getSuggestions(query, limit = 10) {
        if (query.length < 2)
            return [];
        const suggestions = [];
        // Search products
        const productQuery = `
      SELECT title, 'product' as type, COUNT(*) as count
      FROM product
      WHERE title ILIKE $1
      GROUP BY title
      LIMIT 5
    `;
        // Search categories
        const categoryQuery = `
      SELECT name as title, 'category' as type, COUNT(*) as count
      FROM product_category
      WHERE name ILIKE $1
      GROUP BY name
      LIMIT 3
    `;
        // Search part numbers
        const partNumberQuery = `
      SELECT part_number as title, 'part-number' as type, 1 as count
      FROM product
      WHERE part_number ILIKE $1
      LIMIT 2
    `;
        return suggestions;
    }
}
exports.default = AdvancedSearchService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWR2YW5jZWQtc2VhcmNoLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9vbWV4LXNlYXJjaC9hZHZhbmNlZC1zZWFyY2guc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7OztHQUdHOztBQUVILHFEQUF5RDtBQWV6RCxNQUFNLHFCQUFzQixTQUFRLElBQUEscUJBQWEsRUFBQyxFQUFFLENBQUM7SUFDbkQsK0VBQStFO0lBQy9FLGlEQUFpRDtJQUNqRCwrRUFBK0U7SUFFL0U7O09BRUc7SUFDSCxLQUFLLENBQUMsZ0JBQWdCO1FBQ3BCLE9BQU87WUFDTCxLQUFLO1lBQ0wsU0FBUztZQUNULFNBQVM7WUFDVCxPQUFPO1lBQ1AsS0FBSztZQUNMLFNBQVM7WUFDVCxTQUFTO1lBQ1QsUUFBUTtZQUNSLFFBQVE7WUFDUixRQUFRO1lBQ1IsT0FBTztZQUNQLFVBQVU7WUFDVixPQUFPO1lBQ1AsTUFBTTtZQUNOLGFBQWE7U0FDZCxDQUFBO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGVBQWUsQ0FBQyxLQUFjO1FBQ2xDLDZEQUE2RDtRQUM3RCxPQUFPO1lBQ0wsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRTtZQUNyRCxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFO1lBQ25ELEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsbUJBQW1CLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRTtZQUM1RCxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFO1lBQ2pELEVBQUUsS0FBSyxFQUFFLGFBQWEsRUFBRSxLQUFLLEVBQUUsdUJBQXVCLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRTtZQUNwRSxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFO1lBQ3JELEVBQUUsS0FBSyxFQUFFLGdCQUFnQixFQUFFLEtBQUssRUFBRSxjQUFjLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRTtZQUM5RCxFQUFFLEtBQUssRUFBRSxpQkFBaUIsRUFBRSxLQUFLLEVBQUUsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRTtTQUNsRSxDQUFBO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGdCQUFnQixDQUFDLEtBQWEsRUFBRSxJQUFZO1FBQ2hELGlEQUFpRDtRQUNqRCw4QkFBOEI7UUFDOUIsSUFBSSxLQUFLLEtBQUssS0FBSyxJQUFJLElBQUksS0FBSyxXQUFXLEVBQUUsQ0FBQztZQUM1QyxPQUFPO2dCQUNMO29CQUNFLEVBQUUsRUFBRSxTQUFTO29CQUNiLEtBQUssRUFBRSxLQUFLO29CQUNaLElBQUksRUFBRSxXQUFXO29CQUNqQixLQUFLLEVBQUUsUUFBUTtvQkFDZixNQUFNLEVBQUUsR0FBRztvQkFDWCxLQUFLLEVBQUUsT0FBTztvQkFDZCxNQUFNLEVBQUUsR0FBRztvQkFDWCxRQUFRLEVBQUUsSUFBSTtvQkFDZCxNQUFNLEVBQUUsSUFBSTtvQkFDWixlQUFlLEVBQUUsRUFBRTtpQkFDcEI7Z0JBQ0Q7b0JBQ0UsRUFBRSxFQUFFLFNBQVM7b0JBQ2IsS0FBSyxFQUFFLEtBQUs7b0JBQ1osSUFBSSxFQUFFLFdBQVc7b0JBQ2pCLEtBQUssRUFBRSxNQUFNO29CQUNiLE1BQU0sRUFBRSxHQUFHO29CQUNYLEtBQUssRUFBRSxVQUFVO29CQUNqQixNQUFNLEVBQUUsRUFBRTtvQkFDVixRQUFRLEVBQUUsSUFBSTtvQkFDZCxNQUFNLEVBQUUsSUFBSTtvQkFDWixlQUFlLEVBQUUsRUFBRTtpQkFDcEI7Z0JBQ0Qsa0JBQWtCO2FBQ25CLENBQUE7UUFDSCxDQUFDO1FBRUQsT0FBTyxFQUFFLENBQUE7SUFDWCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsZUFBZSxDQUFDLE1BQTJCO1FBQy9DLE1BQU0sRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sQ0FBQTtRQUVuRSx1Q0FBdUM7UUFDdkMsTUFBTSxLQUFLLEdBQUc7Ozs7Ozs7O1VBUVIsTUFBTSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsRUFBRTtVQUNsQyxLQUFLLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxFQUFFO1VBQ2hDLE1BQU0sQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLEVBQUU7O0tBRXZDLENBQUE7UUFFRCwyREFBMkQ7UUFDM0QsT0FBTztZQUNMLFFBQVEsRUFBRSxFQUFFO1lBQ1osS0FBSyxFQUFFLENBQUM7WUFDUixJQUFJLEVBQUUsQ0FBQztZQUNQLEtBQUssRUFBRSxFQUFFO1lBQ1QsT0FBTyxFQUFFLEtBQUs7WUFDZCxVQUFVLEVBQUUsQ0FBQztTQUNkLENBQUE7SUFDSCxDQUFDO0lBRUQsK0VBQStFO0lBQy9FLCtCQUErQjtJQUMvQiwrRUFBK0U7SUFFL0U7O09BRUc7SUFDSCxLQUFLLENBQUMsa0JBQWtCLENBQUMsTUFBOEI7UUFDckQsTUFBTSxFQUFFLFVBQVUsRUFBRSxtQkFBbUIsR0FBRyxJQUFJLEVBQUUsVUFBVSxHQUFHLEtBQUssRUFBRSxHQUFHLE1BQU0sQ0FBQTtRQUU3RSxzREFBc0Q7UUFDdEQsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFVBQVUsQ0FBQyxDQUFBO1FBRXZELHlCQUF5QjtRQUN6QixNQUFNLFVBQVUsR0FBRzs7Ozs7Ozs7Ozs7Ozs7S0FjbEIsQ0FBQTtRQUVELHVDQUF1QztRQUN2QyxJQUFJLFlBQVksR0FBRyxFQUFFLENBQUE7UUFDckIsSUFBSSxtQkFBbUIsRUFBRSxDQUFDO1lBQ3hCLE1BQU0sUUFBUSxHQUFHOzs7Ozs7O09BT2hCLENBQUE7WUFDRCxnQkFBZ0I7UUFDbEIsQ0FBQztRQUVELDJDQUEyQztRQUMzQyxNQUFNLFdBQVcsR0FBRyxNQUFNLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxVQUFVLENBQUMsQ0FBQTtRQUVoRSxPQUFPO1lBQ0wsS0FBSyxFQUFFLFNBQVMsRUFBRSxnQ0FBZ0M7WUFDbEQsWUFBWSxFQUFFLEVBQUU7WUFDaEIsV0FBVztTQUNaLENBQUE7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxtQkFBbUIsQ0FBQyxVQUFrQjtRQUM1QyxPQUFPLFVBQVU7YUFDZCxXQUFXLEVBQUU7YUFDYixPQUFPLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQzthQUN2QixJQUFJLEVBQUUsQ0FBQTtJQUNYLENBQUM7SUFFRDs7T0FFRztJQUNLLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxVQUFrQixFQUFFLFFBQWdCLENBQUM7UUFDdkUsb0RBQW9EO1FBQ3BELE1BQU0sS0FBSyxHQUFHOzs7Ozs7S0FNYixDQUFBO1FBQ0QsT0FBTyxFQUFFLENBQUE7SUFDWCxDQUFDO0lBRUQsK0VBQStFO0lBQy9FLHdDQUF3QztJQUN4QywrRUFBK0U7SUFFL0U7O09BRUc7SUFDSCxLQUFLLENBQUMsYUFBYSxDQUFDLE1BQTBCO1FBQzVDLE1BQU0sRUFBRSxLQUFLLEVBQUUsU0FBUyxHQUFHLElBQUksRUFBRSxHQUFHLE1BQU0sQ0FBQTtRQUUxQyxJQUFJLFVBQVUsR0FBYSxFQUFFLENBQUE7UUFDN0IsSUFBSSxnQkFBb0MsQ0FBQTtRQUV4QyxvREFBb0Q7UUFDcEQsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUNkLFVBQVUsR0FBRyxNQUFNLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUE7WUFFekMsMkNBQTJDO1lBQzNDLElBQUksVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDMUIsTUFBTSxpQkFBaUIsR0FBRyxNQUFNLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztvQkFDdEQsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUM7b0JBQ3pCLG1CQUFtQixFQUFFLElBQUk7aUJBQzFCLENBQUMsQ0FBQTtnQkFFRixPQUFPO29CQUNMLFVBQVU7b0JBQ1YsWUFBWSxFQUFFLGlCQUFpQixDQUFDLFlBQVk7b0JBQzVDLFVBQVUsRUFBRSxHQUFHO2lCQUNoQixDQUFBO1lBQ0gsQ0FBQztRQUNILENBQUM7UUFFRCxrREFBa0Q7UUFDbEQsZ0JBQWdCLEdBQUcsTUFBTSxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFBO1FBRW5ELG1DQUFtQztRQUNuQyxNQUFNLFlBQVksR0FBRyxNQUFNLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxLQUFLLENBQUMsQ0FBQTtRQUU3RCxPQUFPO1lBQ0wsZ0JBQWdCO1lBQ2hCLFVBQVU7WUFDVixZQUFZO1lBQ1osVUFBVSxFQUFFLEdBQUc7U0FDaEIsQ0FBQTtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNLLEtBQUssQ0FBQyxVQUFVLENBQUMsS0FBc0I7UUFDN0MsMEJBQTBCO1FBQzFCLDBDQUEwQztRQUMxQyw0QkFBNEI7UUFDNUIsa0VBQWtFO1FBRWxFLE9BQU8sRUFBRSxDQUFBO0lBQ1gsQ0FBQztJQUVEOztPQUVHO0lBQ0ssS0FBSyxDQUFDLGNBQWMsQ0FBQyxLQUFzQjtRQUNqRCwwQkFBMEI7UUFDMUIseUNBQXlDO1FBQ3pDLHdDQUF3QztRQUN4Qyw2QkFBNkI7UUFFN0IsT0FBTyxTQUFTLENBQUE7SUFDbEIsQ0FBQztJQUVEOztPQUVHO0lBQ0ssS0FBSyxDQUFDLHNCQUFzQixDQUFDLEtBQXNCO1FBQ3pELDBCQUEwQjtRQUMxQixvQ0FBb0M7UUFDcEMsOENBQThDO1FBQzlDLDZCQUE2QjtRQUU3QixPQUFPLEVBQUUsQ0FBQTtJQUNYLENBQUM7SUFFRCwrRUFBK0U7SUFDL0UsMkNBQTJDO0lBQzNDLCtFQUErRTtJQUUvRTs7T0FFRztJQUNILEtBQUssQ0FBQyxZQUFZLENBQUMsTUFBd0I7UUFDekMsTUFBTSxFQUFFLEtBQUssRUFBRSxRQUFRLEdBQUcsSUFBSSxFQUFFLEtBQUssR0FBRyxJQUFJLEVBQUUsR0FBRyxNQUFNLENBQUE7UUFFdkQsNkNBQTZDO1FBQzdDLE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLHlCQUF5QixDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsQ0FBQTtRQUVwRSwwQ0FBMEM7UUFDMUMsSUFBSSxXQUFXLEdBQUcsS0FBSyxDQUFBO1FBRXZCLDREQUE0RDtRQUM1RCxJQUFJLE1BQU0sQ0FBQyxNQUFNLElBQUksTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxNQUFNLElBQUksTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDM0YsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDO2dCQUMxQixLQUFLLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQ3ZCLFdBQVcsRUFBRSxXQUFXLEVBQUUsK0JBQStCO2dCQUN6RCxLQUFLLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7YUFDeEIsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUVELHFEQUFxRDtRQUNyRCxJQUFJLE1BQU0sQ0FBQyxVQUFVLElBQUksTUFBTSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDdEQsTUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQUM7Z0JBQzNDLFVBQVUsRUFBRSxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztnQkFDaEMsbUJBQW1CLEVBQUUsSUFBSTthQUMxQixDQUFDLENBQUE7WUFFRixPQUFPO2dCQUNMLFFBQVEsRUFBRSxNQUFNLENBQUMsWUFBWTtnQkFDN0IsS0FBSyxFQUFFLE1BQU0sQ0FBQyxZQUFZLENBQUMsTUFBTTtnQkFDakMsSUFBSSxFQUFFLENBQUM7Z0JBQ1AsS0FBSyxFQUFFLEVBQUU7Z0JBQ1QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsV0FBVyxFQUFFLE1BQU07YUFDcEIsQ0FBQTtRQUNILENBQUM7UUFFRCxpQ0FBaUM7UUFDakMsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsRUFBRSxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUE7SUFDeEQsQ0FBQztJQUVEOztPQUVHO0lBQ0ssS0FBSyxDQUFDLHlCQUF5QixDQUFDLEtBQWEsRUFBRSxRQUFnQjtRQUNyRSxNQUFNLE1BQU0sR0FBZ0I7WUFDMUIsTUFBTSxFQUFFLEVBQUU7WUFDVixNQUFNLEVBQUUsRUFBRTtZQUNWLFNBQVMsRUFBRSxFQUFFO1lBQ2IsVUFBVSxFQUFFLEVBQUU7WUFDZCxVQUFVLEVBQUUsRUFBRTtTQUNmLENBQUE7UUFFRCxNQUFNLFVBQVUsR0FBRyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUE7UUFFdEMsZ0JBQWdCO1FBQ2hCLE1BQU0sTUFBTSxHQUFHLENBQUMsS0FBSyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFFBQVEsQ0FBQyxDQUFBO1FBQzVGLEtBQUssTUFBTSxLQUFLLElBQUksTUFBTSxFQUFFLENBQUM7WUFDM0IsSUFBSSxVQUFVLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQy9CLE1BQU0sQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFBO1lBQzFDLENBQUM7UUFDSCxDQUFDO1FBRUQsaURBQWlEO1FBQ2pELE1BQU0sWUFBWSxHQUFHLGlDQUFpQyxDQUFBO1FBQ3RELE1BQU0sWUFBWSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUE7UUFDOUMsSUFBSSxZQUFZLEVBQUUsQ0FBQztZQUNqQixNQUFNLENBQUMsTUFBTSxHQUFHLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQTtRQUN4RCxDQUFDO1FBRUQsd0RBQXdEO1FBQ3hELE1BQU0sVUFBVSxHQUFHLDBCQUEwQixDQUFBO1FBQzdDLE1BQU0sVUFBVSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUE7UUFDMUMsSUFBSSxVQUFVLEVBQUUsQ0FBQztZQUNmLE1BQU0sQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFBO1FBQ2hDLENBQUM7UUFFRCxnQ0FBZ0M7UUFDaEMsTUFBTSxTQUFTLEdBQUc7WUFDaEIsT0FBTyxFQUFFLE1BQU07WUFDZixPQUFPLEVBQUUsUUFBUTtZQUNqQixXQUFXLEVBQUUsT0FBTztZQUNwQixVQUFVLEVBQUUsVUFBVTtZQUN0QixPQUFPLEVBQUUsT0FBTztZQUNoQixRQUFRLEVBQUUsUUFBUTtZQUNsQixNQUFNLEVBQUUsUUFBUTtTQUNqQixDQUFBO1FBRUQsS0FBSyxNQUFNLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztZQUNqRCxJQUFJLFVBQVUsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQztnQkFDNUIsTUFBTSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUE7WUFDNUIsQ0FBQztRQUNILENBQUM7UUFFRCw4Q0FBOEM7UUFDOUMsTUFBTSxhQUFhLEdBQUcseUJBQXlCLENBQUE7UUFDL0MsTUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQTtRQUM5QyxJQUFJLFdBQVcsRUFBRSxDQUFDO1lBQ2hCLE1BQU0sQ0FBQyxVQUFXLENBQUMsTUFBTSxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUM1QyxDQUFDO1FBRUQsT0FBTyxNQUFNLENBQUE7SUFDZixDQUFDO0lBRUQ7O09BRUc7SUFDSyxLQUFLLENBQUMsY0FBYyxDQUFDLEtBQWEsRUFBRSxNQUFtQixFQUFFLEtBQWM7UUFDN0UsTUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFBO1FBRXpFLE1BQU0sR0FBRyxHQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztLQW9CWCxDQUFBO1FBRUQsT0FBTztZQUNMLFFBQVEsRUFBRSxFQUFFO1lBQ1osS0FBSyxFQUFFLENBQUM7WUFDUixJQUFJLEVBQUUsQ0FBQztZQUNQLEtBQUssRUFBRSxFQUFFO1lBQ1QsT0FBTyxFQUFFLEtBQUs7WUFDZCxXQUFXLEVBQUUsTUFBTTtTQUNwQixDQUFBO0lBQ0gsQ0FBQztJQUVELCtFQUErRTtJQUMvRSw2QkFBNkI7SUFDN0IsK0VBQStFO0lBRS9FOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGlCQUFpQixDQUFDLE9BQThCO1FBQ3BELE1BQU0sVUFBVSxHQUFhLEVBQUUsQ0FBQTtRQUMvQixNQUFNLE1BQU0sR0FBVSxFQUFFLENBQUE7UUFDeEIsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFBO1FBRWxCLGtCQUFrQjtRQUNsQixJQUFJLE9BQU8sQ0FBQyxXQUFXLElBQUksT0FBTyxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDMUQsSUFBSSxPQUFPLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztnQkFDakMsZ0NBQWdDO2dCQUNoQyxNQUFNLGNBQWMsR0FBRyxNQUFNLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUE7Z0JBQ2pGLFVBQVUsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLFVBQVUsR0FBRyxDQUFDLENBQUE7Z0JBQ3RELE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUE7WUFDN0IsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLFVBQVUsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLFVBQVUsR0FBRyxDQUFDLENBQUE7Z0JBQ3RELE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFBO1lBQ2xDLENBQUM7WUFDRCxVQUFVLEVBQUUsQ0FBQTtRQUNkLENBQUM7UUFFRCx1QkFBdUI7UUFDdkIsSUFBSSxPQUFPLENBQUMsYUFBYSxJQUFJLE9BQU8sQ0FBQyxhQUFhLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQzlELFVBQVUsQ0FBQyxJQUFJLENBQUMsMEJBQTBCLFVBQVUsR0FBRyxDQUFDLENBQUE7WUFDeEQsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUE7WUFDbEMsVUFBVSxFQUFFLENBQUE7UUFDZCxDQUFDO1FBRUQsc0JBQXNCO1FBQ3RCLElBQUksT0FBTyxDQUFDLFlBQVksSUFBSSxPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUM1RCxVQUFVLENBQUMsSUFBSSxDQUFDLHlCQUF5QixVQUFVLEdBQUcsQ0FBQyxDQUFBO1lBQ3ZELE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFBO1lBQ2pDLFVBQVUsRUFBRSxDQUFBO1FBQ2QsQ0FBQztRQUVELGNBQWM7UUFDZCxJQUFJLE9BQU8sQ0FBQyxRQUFRLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDbkMsVUFBVSxDQUFDLElBQUksQ0FBQyxlQUFlLFVBQVUsRUFBRSxDQUFDLENBQUE7WUFDNUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUE7WUFDN0IsVUFBVSxFQUFFLENBQUE7UUFDZCxDQUFDO1FBRUQsSUFBSSxPQUFPLENBQUMsUUFBUSxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQ25DLFVBQVUsQ0FBQyxJQUFJLENBQUMsZUFBZSxVQUFVLEVBQUUsQ0FBQyxDQUFBO1lBQzVDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFBO1lBQzdCLFVBQVUsRUFBRSxDQUFBO1FBQ2QsQ0FBQztRQUVELGtDQUFrQztRQUNsQyxJQUFJLE9BQU8sQ0FBQyxTQUFTLElBQUksT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDdEQsVUFBVSxDQUFDLElBQUksQ0FBQyxzQkFBc0IsVUFBVSxHQUFHLENBQUMsQ0FBQTtZQUNwRCxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQTtZQUM5QixVQUFVLEVBQUUsQ0FBQTtRQUNkLENBQUM7UUFFRCxlQUFlO1FBQ2YsSUFBSSxPQUFPLENBQUMsYUFBYSxJQUFJLE9BQU8sQ0FBQyxhQUFhLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQzlELFVBQVUsQ0FBQyxJQUFJLENBQUMseUJBQXlCLFVBQVUsR0FBRyxDQUFDLENBQUE7WUFDdkQsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUE7WUFDbEMsVUFBVSxFQUFFLENBQUE7UUFDZCxDQUFDO1FBRUQsZ0JBQWdCO1FBQ2hCLElBQUksT0FBTyxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ3RCLFVBQVUsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLFVBQVUsRUFBRSxDQUFDLENBQUE7WUFDN0MsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUE7WUFDOUIsVUFBVSxFQUFFLENBQUE7UUFDZCxDQUFDO1FBRUQsSUFBSSxPQUFPLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDdkIsVUFBVSxDQUFDLElBQUksQ0FBQyxzQkFBc0IsVUFBVSxFQUFFLENBQUMsQ0FBQTtZQUNuRCxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQTtZQUMvQixVQUFVLEVBQUUsQ0FBQTtRQUNkLENBQUM7UUFFRCxvQkFBb0I7UUFDcEIsTUFBTSxXQUFXLEdBQUcsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUE7UUFDcEYsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUV2RCxNQUFNLEdBQUcsR0FBRzs7O1FBR1IsV0FBVztRQUNYLE9BQU87O0tBRVYsQ0FBQTtRQUVELE9BQU87WUFDTCxRQUFRLEVBQUUsRUFBRTtZQUNaLEtBQUssRUFBRSxDQUFDO1lBQ1IsSUFBSSxFQUFFLENBQUM7WUFDUCxLQUFLLEVBQUUsRUFBRTtZQUNULE9BQU8sRUFBRSxLQUFLO1lBQ2QsT0FBTztTQUNSLENBQUE7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxLQUFLLENBQUMsMEJBQTBCLENBQUMsV0FBcUI7UUFDNUQsdUNBQXVDO1FBQ3ZDLE1BQU0sS0FBSyxHQUFHOzs7Ozs7OztLQVFiLENBQUE7UUFFRCxPQUFPLFdBQVcsQ0FBQSxDQUFDLGdDQUFnQztJQUNyRCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxrQkFBa0IsQ0FBQyxNQUFlO1FBQ3hDLFFBQVEsTUFBTSxFQUFFLENBQUM7WUFDZixLQUFLLFFBQVE7Z0JBQ1gsT0FBTyw0QkFBNEIsQ0FBQTtZQUNyQyxLQUFLLGNBQWM7Z0JBQ2pCLE9BQU8sNkJBQTZCLENBQUE7WUFDdEMsS0FBSyxXQUFXO2dCQUNkLE9BQU8sc0JBQXNCLENBQUE7WUFDL0IsS0FBSyxZQUFZO2dCQUNmLE9BQU8sdUJBQXVCLENBQUE7WUFDaEMsS0FBSyxRQUFRO2dCQUNYLE9BQU8sNkNBQTZDLENBQUE7WUFDdEQ7Z0JBQ0UsT0FBTyw0QkFBNEIsQ0FBQTtRQUN2QyxDQUFDO0lBQ0gsQ0FBQztJQUVELCtFQUErRTtJQUMvRSw2QkFBNkI7SUFDN0IsK0VBQStFO0lBRS9FOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGNBQWMsQ0FBQyxLQUFhLEVBQUUsUUFBZ0IsRUFBRTtRQUNwRCxJQUFJLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQztZQUFFLE9BQU8sRUFBRSxDQUFBO1FBRS9CLE1BQU0sV0FBVyxHQUF1QixFQUFFLENBQUE7UUFFMUMsa0JBQWtCO1FBQ2xCLE1BQU0sWUFBWSxHQUFHOzs7Ozs7S0FNcEIsQ0FBQTtRQUVELG9CQUFvQjtRQUNwQixNQUFNLGFBQWEsR0FBRzs7Ozs7O0tBTXJCLENBQUE7UUFFRCxzQkFBc0I7UUFDdEIsTUFBTSxlQUFlLEdBQUc7Ozs7O0tBS3ZCLENBQUE7UUFFRCxPQUFPLFdBQVcsQ0FBQTtJQUNwQixDQUFDO0NBQ0Y7QUFFRCxrQkFBZSxxQkFBcUIsQ0FBQSJ9