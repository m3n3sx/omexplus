"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdvancedSearchService = exports.OMEX_SEARCH_MODULE = void 0;
const utils_1 = require("@medusajs/framework/utils");
const service_1 = __importDefault(require("./service"));
const advanced_search_service_1 = __importDefault(require("./advanced-search.service"));
exports.AdvancedSearchService = advanced_search_service_1.default;
exports.OMEX_SEARCH_MODULE = "omexSearch";
exports.default = (0, utils_1.Module)(exports.OMEX_SEARCH_MODULE, {
    service: service_1.default,
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9vbWV4LXNlYXJjaC9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxxREFBa0Q7QUFDbEQsd0RBQXlDO0FBQ3pDLHdGQUE2RDtBQVNwRCxnQ0FURixpQ0FBcUIsQ0FTRTtBQVBqQixRQUFBLGtCQUFrQixHQUFHLFlBQVksQ0FBQTtBQUU5QyxrQkFBZSxJQUFBLGNBQU0sRUFBQywwQkFBa0IsRUFBRTtJQUN4QyxPQUFPLEVBQUUsaUJBQWlCO0NBQzNCLENBQUMsQ0FBQSJ9