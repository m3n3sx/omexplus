"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class OmexSearchService extends (0, utils_1.MedusaService)({}) {
    constructor() {
        super(...arguments);
        this.DEFAULT_LIMIT = 12;
        this.MAX_LIMIT = 100;
    }
    async search(query, filters = {}, sort = { field: 'popularity', order: 'desc' }, pagination = {}) {
        if (!query || query.trim().length === 0) {
            throw new Error("Search query is required");
        }
        const page = pagination.page || 1;
        const limit = Math.min(pagination.limit || this.DEFAULT_LIMIT, this.MAX_LIMIT);
        const offset = (page - 1) * limit;
        // In real implementation:
        // 1. Build full-text search query across:
        //    - product.title
        //    - product.description
        //    - product.sku
        //    - product.part_number
        //    - product_translation.title
        //    - product_translation.description
        // 2. Apply filters
        // 3. Apply sorting
        // 4. Apply pagination
        // 5. Include product relations (categories, images, etc.)
        const searchQuery = this.buildSearchQuery(query, filters, sort);
        return {
            products: [],
            total: 0,
            page,
            limit,
            filters_applied: filters,
        };
    }
    async filterProducts(filters, pagination = {}) {
        const page = pagination.page || 1;
        const limit = Math.min(pagination.limit || this.DEFAULT_LIMIT, this.MAX_LIMIT);
        const offset = (page - 1) * limit;
        // Build filter query
        const conditions = [];
        if (filters.category_id) {
            // Include products from category and all subcategories
            conditions.push(`category_id IN (${await this.getCategoryAndDescendants(filters.category_id)})`);
        }
        if (filters.min_price !== undefined) {
            conditions.push(`price >= ${filters.min_price}`);
        }
        if (filters.max_price !== undefined) {
            conditions.push(`price <= ${filters.max_price}`);
        }
        if (filters.brand && filters.brand.length > 0) {
            conditions.push(`brand IN (${filters.brand.map(b => `'${b}'`).join(',')})`);
        }
        if (filters.equipment_type && filters.equipment_type.length > 0) {
            conditions.push(`equipment_type IN (${filters.equipment_type.map(e => `'${e}'`).join(',')})`);
        }
        if (filters.in_stock) {
            // Check inventory table for available stock
            conditions.push(`EXISTS (SELECT 1 FROM inventory WHERE product_id = product.id AND (quantity - reserved) > 0)`);
        }
        return {
            products: [],
            total: 0,
            page,
            limit,
            filters_applied: filters,
        };
    }
    async sortProducts(products, sort) {
        const { field, order } = sort;
        return products.sort((a, b) => {
            let comparison = 0;
            switch (field) {
                case 'price':
                    comparison = a.price - b.price;
                    break;
                case 'created_at':
                    comparison = new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
                    break;
                case 'popularity':
                    // In real implementation, use sales count or view count
                    comparison = (a.sales_count || 0) - (b.sales_count || 0);
                    break;
                case 'name':
                    comparison = a.title.localeCompare(b.title);
                    break;
            }
            return order === 'asc' ? comparison : -comparison;
        });
    }
    async getSuggestions(query, limit = 5) {
        if (!query || query.trim().length < 2) {
            return [];
        }
        // In real implementation:
        // 1. Search for products matching query
        // 2. Extract unique titles/names
        // 3. Return top N suggestions
        return [];
    }
    /**
     * Search by manufacturer SKU
     */
    async searchByManufacturerSKU(manufacturerSku, manufacturerId) {
        if (!manufacturerSku) {
            throw new Error("Manufacturer SKU is required");
        }
        // In real implementation:
        // Query manufacturer_part table and join with product
        // WHERE manufacturer_sku = $1 AND (manufacturer_id = $2 OR $2 IS NULL)
        return [];
    }
    /**
     * Search by catalog page
     */
    async searchByCatalogPage(manufacturerId, pageNumber) {
        if (!manufacturerId || pageNumber === undefined) {
            throw new Error("Manufacturer ID and page number are required");
        }
        // In real implementation:
        // Query manufacturer_part table
        // WHERE manufacturer_id = $1 AND catalog_page = $2
        return [];
    }
    /**
     * Get similar products
     */
    async similarProducts(productId, limit = 5) {
        if (!productId) {
            throw new Error("Product ID is required");
        }
        // In real implementation:
        // 1. Get product details
        // 2. Find products in same category with similar price
        // 3. Order by similarity score
        return [];
    }
    /**
     * Get related products (cross-sell)
     */
    async relatedProducts(productId, limit = 5) {
        if (!productId) {
            throw new Error("Product ID is required");
        }
        // In real implementation:
        // 1. Get product's comparable_products array
        // 2. Find complementary products
        // 3. Return top matches
        return [];
    }
    /**
     * Autocomplete suggestions
     */
    async autocomplete(prefix, limit = 10) {
        if (!prefix || prefix.length < 2) {
            return [];
        }
        // In real implementation:
        // 1. Search products where title starts with prefix
        // 2. Search categories
        // 3. Search manufacturers
        // 4. Combine and rank results
        return [];
    }
    /**
     * Faceted search - get available filters
     */
    async getFacets(categoryId) {
        const facets = {
            categories: [],
            manufacturers: [],
            price_ranges: [
                { min: 0, max: 100, count: 0 },
                { min: 100, max: 500, count: 0 },
                { min: 500, max: 1000, count: 0 },
                { min: 1000, max: 5000, count: 0 },
                { min: 5000, max: null, count: 0 },
            ],
            equipment_types: [],
            availability: [
                { value: "in_stock", label: "W magazynie", count: 0 },
                { value: "low_stock", label: "Niski stan", count: 0 },
                { value: "out_of_stock", label: "Brak w magazynie", count: 0 },
            ],
        };
        // In real implementation, count products for each facet
        return facets;
    }
    async getPopularSearches(limit = 10) {
        // In real implementation:
        // 1. Track search queries in database
        // 2. Return most frequent searches
        return [];
    }
    async trackSearch(query, resultsCount, userId) {
        // Track search for analytics
        return {
            query,
            results_count: resultsCount,
            user_id: userId,
            searched_at: new Date(),
        };
    }
    buildSearchQuery(query, filters, sort) {
        // Build PostgreSQL full-text search query
        // Using ts_vector and ts_query for better performance
        const searchTerms = query.trim().split(/\s+/).join(' & ');
        let sql = `
      SELECT DISTINCT p.*,
        ts_rank(
          to_tsvector('english', 
            COALESCE(p.title, '') || ' ' || 
            COALESCE(p.description, '') || ' ' ||
            COALESCE(p.sku, '') || ' ' ||
            COALESCE(p.part_number, '')
          ),
          to_tsquery('english', '${searchTerms}')
        ) as rank
      FROM product p
      WHERE to_tsvector('english', 
        COALESCE(p.title, '') || ' ' || 
        COALESCE(p.description, '') || ' ' ||
        COALESCE(p.sku, '') || ' ' ||
        COALESCE(p.part_number, '')
      ) @@ to_tsquery('english', '${searchTerms}')
    `;
        // Add filters
        if (filters.category_id) {
            sql += ` AND p.category_id = '${filters.category_id}'`;
        }
        if (filters.min_price !== undefined) {
            sql += ` AND p.price >= ${filters.min_price}`;
        }
        if (filters.max_price !== undefined) {
            sql += ` AND p.price <= ${filters.max_price}`;
        }
        // Add sorting
        sql += ` ORDER BY ${sort.field === 'popularity' ? 'rank' : sort.field} ${sort.order}`;
        return sql;
    }
    async getCategoryAndDescendants(categoryId) {
        // In real implementation, recursively get all descendant category IDs
        // Return as comma-separated string for SQL IN clause
        return `'${categoryId}'`;
    }
}
exports.default = OmexSearchService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL29tZXgtc2VhcmNoL3NlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBeUQ7QUF3QnpELE1BQU0saUJBQWtCLFNBQVEsSUFBQSxxQkFBYSxFQUFDLEVBQUUsQ0FBQztJQUFqRDs7UUFDbUIsa0JBQWEsR0FBRyxFQUFFLENBQUE7UUFDbEIsY0FBUyxHQUFHLEdBQUcsQ0FBQTtJQXdTbEMsQ0FBQztJQXRTQyxLQUFLLENBQUMsTUFBTSxDQUNWLEtBQWEsRUFDYixVQUF5QixFQUFFLEVBQzNCLE9BQW9CLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLEVBQzFELGFBQWdELEVBQUU7UUFHbEQsSUFBSSxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ3hDLE1BQU0sSUFBSSxLQUFLLENBQUMsMEJBQTBCLENBQUMsQ0FBQTtRQUM3QyxDQUFDO1FBRUQsTUFBTSxJQUFJLEdBQUcsVUFBVSxDQUFDLElBQUksSUFBSSxDQUFDLENBQUE7UUFDakMsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFBO1FBQzlFLE1BQU0sTUFBTSxHQUFHLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQTtRQUVqQywwQkFBMEI7UUFDMUIsMENBQTBDO1FBQzFDLHFCQUFxQjtRQUNyQiwyQkFBMkI7UUFDM0IsbUJBQW1CO1FBQ25CLDJCQUEyQjtRQUMzQixpQ0FBaUM7UUFDakMsdUNBQXVDO1FBQ3ZDLG1CQUFtQjtRQUNuQixtQkFBbUI7UUFDbkIsc0JBQXNCO1FBQ3RCLDBEQUEwRDtRQUUxRCxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQTtRQUUvRCxPQUFPO1lBQ0wsUUFBUSxFQUFFLEVBQUU7WUFDWixLQUFLLEVBQUUsQ0FBQztZQUNSLElBQUk7WUFDSixLQUFLO1lBQ0wsZUFBZSxFQUFFLE9BQU87U0FDekIsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsY0FBYyxDQUFDLE9BQXNCLEVBQUUsYUFBZ0QsRUFBRTtRQUM3RixNQUFNLElBQUksR0FBRyxVQUFVLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQTtRQUNqQyxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUE7UUFDOUUsTUFBTSxNQUFNLEdBQUcsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFBO1FBRWpDLHFCQUFxQjtRQUNyQixNQUFNLFVBQVUsR0FBYSxFQUFFLENBQUE7UUFFL0IsSUFBSSxPQUFPLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDeEIsdURBQXVEO1lBQ3ZELFVBQVUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLE1BQU0sSUFBSSxDQUFDLHlCQUF5QixDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUE7UUFDbEcsQ0FBQztRQUVELElBQUksT0FBTyxDQUFDLFNBQVMsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUNwQyxVQUFVLENBQUMsSUFBSSxDQUFDLFlBQVksT0FBTyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUE7UUFDbEQsQ0FBQztRQUVELElBQUksT0FBTyxDQUFDLFNBQVMsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUNwQyxVQUFVLENBQUMsSUFBSSxDQUFDLFlBQVksT0FBTyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUE7UUFDbEQsQ0FBQztRQUVELElBQUksT0FBTyxDQUFDLEtBQUssSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUM5QyxVQUFVLENBQUMsSUFBSSxDQUFDLGFBQWEsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQTtRQUM3RSxDQUFDO1FBRUQsSUFBSSxPQUFPLENBQUMsY0FBYyxJQUFJLE9BQU8sQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQ2hFLFVBQVUsQ0FBQyxJQUFJLENBQUMsc0JBQXNCLE9BQU8sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUE7UUFDL0YsQ0FBQztRQUVELElBQUksT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3JCLDRDQUE0QztZQUM1QyxVQUFVLENBQUMsSUFBSSxDQUFDLDhGQUE4RixDQUFDLENBQUE7UUFDakgsQ0FBQztRQUVELE9BQU87WUFDTCxRQUFRLEVBQUUsRUFBRTtZQUNaLEtBQUssRUFBRSxDQUFDO1lBQ1IsSUFBSTtZQUNKLEtBQUs7WUFDTCxlQUFlLEVBQUUsT0FBTztTQUN6QixDQUFBO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxZQUFZLENBQUMsUUFBZSxFQUFFLElBQWlCO1FBQ25ELE1BQU0sRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFBO1FBRTdCLE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUM1QixJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUE7WUFFbEIsUUFBUSxLQUFLLEVBQUUsQ0FBQztnQkFDZCxLQUFLLE9BQU87b0JBQ1YsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQTtvQkFDOUIsTUFBSztnQkFDUCxLQUFLLFlBQVk7b0JBQ2YsVUFBVSxHQUFHLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxPQUFPLEVBQUUsR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUE7b0JBQ2hGLE1BQUs7Z0JBQ1AsS0FBSyxZQUFZO29CQUNmLHdEQUF3RDtvQkFDeEQsVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDLFdBQVcsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxXQUFXLElBQUksQ0FBQyxDQUFDLENBQUE7b0JBQ3hELE1BQUs7Z0JBQ1AsS0FBSyxNQUFNO29CQUNULFVBQVUsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUE7b0JBQzNDLE1BQUs7WUFDVCxDQUFDO1lBRUQsT0FBTyxLQUFLLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFBO1FBQ25ELENBQUMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELEtBQUssQ0FBQyxjQUFjLENBQUMsS0FBYSxFQUFFLFFBQWdCLENBQUM7UUFDbkQsSUFBSSxDQUFDLEtBQUssSUFBSSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQ3RDLE9BQU8sRUFBRSxDQUFBO1FBQ1gsQ0FBQztRQUVELDBCQUEwQjtRQUMxQix3Q0FBd0M7UUFDeEMsaUNBQWlDO1FBQ2pDLDhCQUE4QjtRQUU5QixPQUFPLEVBQUUsQ0FBQTtJQUNYLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxlQUF1QixFQUFFLGNBQXVCO1FBQzVFLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUNyQixNQUFNLElBQUksS0FBSyxDQUFDLDhCQUE4QixDQUFDLENBQUE7UUFDakQsQ0FBQztRQUVELDBCQUEwQjtRQUMxQixzREFBc0Q7UUFDdEQsdUVBQXVFO1FBRXZFLE9BQU8sRUFBRSxDQUFBO0lBQ1gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLG1CQUFtQixDQUFDLGNBQXNCLEVBQUUsVUFBa0I7UUFDbEUsSUFBSSxDQUFDLGNBQWMsSUFBSSxVQUFVLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDaEQsTUFBTSxJQUFJLEtBQUssQ0FBQyw4Q0FBOEMsQ0FBQyxDQUFBO1FBQ2pFLENBQUM7UUFFRCwwQkFBMEI7UUFDMUIsZ0NBQWdDO1FBQ2hDLG1EQUFtRDtRQUVuRCxPQUFPLEVBQUUsQ0FBQTtJQUNYLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxlQUFlLENBQUMsU0FBaUIsRUFBRSxRQUFnQixDQUFDO1FBQ3hELElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUNmLE1BQU0sSUFBSSxLQUFLLENBQUMsd0JBQXdCLENBQUMsQ0FBQTtRQUMzQyxDQUFDO1FBRUQsMEJBQTBCO1FBQzFCLHlCQUF5QjtRQUN6Qix1REFBdUQ7UUFDdkQsK0JBQStCO1FBRS9CLE9BQU8sRUFBRSxDQUFBO0lBQ1gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGVBQWUsQ0FBQyxTQUFpQixFQUFFLFFBQWdCLENBQUM7UUFDeEQsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ2YsTUFBTSxJQUFJLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxDQUFBO1FBQzNDLENBQUM7UUFFRCwwQkFBMEI7UUFDMUIsNkNBQTZDO1FBQzdDLGlDQUFpQztRQUNqQyx3QkFBd0I7UUFFeEIsT0FBTyxFQUFFLENBQUE7SUFDWCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsWUFBWSxDQUFDLE1BQWMsRUFBRSxRQUFnQixFQUFFO1FBQ25ELElBQUksQ0FBQyxNQUFNLElBQUksTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNqQyxPQUFPLEVBQUUsQ0FBQTtRQUNYLENBQUM7UUFFRCwwQkFBMEI7UUFDMUIsb0RBQW9EO1FBQ3BELHVCQUF1QjtRQUN2QiwwQkFBMEI7UUFDMUIsOEJBQThCO1FBRTlCLE9BQU8sRUFBRSxDQUFBO0lBQ1gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLFNBQVMsQ0FBQyxVQUFtQjtRQUNqQyxNQUFNLE1BQU0sR0FBRztZQUNiLFVBQVUsRUFBRSxFQUFFO1lBQ2QsYUFBYSxFQUFFLEVBQUU7WUFDakIsWUFBWSxFQUFFO2dCQUNaLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUU7Z0JBQzlCLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUU7Z0JBQ2hDLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUU7Z0JBQ2pDLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUU7Z0JBQ2xDLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUU7YUFDbkM7WUFDRCxlQUFlLEVBQUUsRUFBRTtZQUNuQixZQUFZLEVBQUU7Z0JBQ1osRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxhQUFhLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRTtnQkFDckQsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRTtnQkFDckQsRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFFLEtBQUssRUFBRSxrQkFBa0IsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFO2FBQy9EO1NBQ0YsQ0FBQTtRQUVELHdEQUF3RDtRQUN4RCxPQUFPLE1BQU0sQ0FBQTtJQUNmLENBQUM7SUFFRCxLQUFLLENBQUMsa0JBQWtCLENBQUMsUUFBZ0IsRUFBRTtRQUN6QywwQkFBMEI7UUFDMUIsc0NBQXNDO1FBQ3RDLG1DQUFtQztRQUVuQyxPQUFPLEVBQUUsQ0FBQTtJQUNYLENBQUM7SUFFRCxLQUFLLENBQUMsV0FBVyxDQUFDLEtBQWEsRUFBRSxZQUFvQixFQUFFLE1BQWU7UUFDcEUsNkJBQTZCO1FBQzdCLE9BQU87WUFDTCxLQUFLO1lBQ0wsYUFBYSxFQUFFLFlBQVk7WUFDM0IsT0FBTyxFQUFFLE1BQU07WUFDZixXQUFXLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDeEIsQ0FBQTtJQUNILENBQUM7SUFFTyxnQkFBZ0IsQ0FBQyxLQUFhLEVBQUUsT0FBc0IsRUFBRSxJQUFpQjtRQUMvRSwwQ0FBMEM7UUFDMUMsc0RBQXNEO1FBRXRELE1BQU0sV0FBVyxHQUFHLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBO1FBRXpELElBQUksR0FBRyxHQUFHOzs7Ozs7Ozs7bUNBU3FCLFdBQVc7Ozs7Ozs7O29DQVFWLFdBQVc7S0FDMUMsQ0FBQTtRQUVELGNBQWM7UUFDZCxJQUFJLE9BQU8sQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUN4QixHQUFHLElBQUkseUJBQXlCLE9BQU8sQ0FBQyxXQUFXLEdBQUcsQ0FBQTtRQUN4RCxDQUFDO1FBRUQsSUFBSSxPQUFPLENBQUMsU0FBUyxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQ3BDLEdBQUcsSUFBSSxtQkFBbUIsT0FBTyxDQUFDLFNBQVMsRUFBRSxDQUFBO1FBQy9DLENBQUM7UUFFRCxJQUFJLE9BQU8sQ0FBQyxTQUFTLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDcEMsR0FBRyxJQUFJLG1CQUFtQixPQUFPLENBQUMsU0FBUyxFQUFFLENBQUE7UUFDL0MsQ0FBQztRQUVELGNBQWM7UUFDZCxHQUFHLElBQUksYUFBYSxJQUFJLENBQUMsS0FBSyxLQUFLLFlBQVksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQTtRQUVyRixPQUFPLEdBQUcsQ0FBQTtJQUNaLENBQUM7SUFFTyxLQUFLLENBQUMseUJBQXlCLENBQUMsVUFBa0I7UUFDeEQsc0VBQXNFO1FBQ3RFLHFEQUFxRDtRQUNyRCxPQUFPLElBQUksVUFBVSxHQUFHLENBQUE7SUFDMUIsQ0FBQztDQUNGO0FBRUQsa0JBQWUsaUJBQWlCLENBQUEifQ==