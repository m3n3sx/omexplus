"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class OmexOrderService extends (0, utils_1.MedusaService)({}) {
    async createOrderFromCart(data) {
        if (!data.customer_id || !data.cart_id) {
            throw new Error("Customer ID and Cart ID are required");
        }
        // In real implementation:
        // 1. Fetch cart with items
        // 2. Validate stock availability
        // 3. Reserve stock
        // 4. Create order
        // 5. Create order items
        // 6. Clear cart
        const order = {
            id: `order_${Date.now()}`,
            order_number: this.generateOrderNumber(),
            customer_id: data.customer_id,
            purchase_order_number: data.purchase_order_number,
            delivery_date: data.delivery_date,
            payment_terms: data.payment_terms || 'immediate',
            warehouse_id: data.warehouse_id,
            status: 'pending',
            payment_status: 'pending',
            created_at: new Date(),
            status_history: [
                {
                    status: 'pending',
                    changed_at: new Date(),
                    changed_by: 'system',
                }
            ],
        };
        return order;
    }
    async updateOrderStatus(orderId, newStatus, changedBy, note) {
        if (!orderId || !newStatus) {
            throw new Error("Order ID and new status are required");
        }
        const validStatuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
        if (!validStatuses.includes(newStatus)) {
            throw new Error(`Invalid status. Must be one of: ${validStatuses.join(', ')}`);
        }
        // In real implementation:
        // 1. Fetch current order
        // 2. Validate status transition
        // 3. Update order status
        // 4. Add to status history
        // 5. Trigger webhooks/notifications
        const historyEntry = {
            status: newStatus,
            changed_at: new Date(),
            changed_by: changedBy,
            note,
        };
        return {
            order_id: orderId,
            status: newStatus,
            history_entry: historyEntry,
            updated_at: new Date(),
        };
    }
    async getStatusHistory(orderId) {
        if (!orderId) {
            throw new Error("Order ID is required");
        }
        // In real implementation, fetch from order_status_history table
        // ORDER BY changed_at ASC
        return [];
    }
    async cancelOrder(orderId, reason, cancelledBy) {
        if (!orderId) {
            throw new Error("Order ID is required");
        }
        // In real implementation:
        // 1. Fetch order with items
        // 2. Check if order can be cancelled (not shipped/delivered)
        // 3. Release stock reservations
        // 4. Return stock to warehouse
        // 5. Update order status to cancelled
        // 6. Process refund if payment was made
        // 7. Send cancellation email
        const order = await this.getOrder(orderId);
        if (order.status === 'shipped' || order.status === 'delivered') {
            throw new Error(`Cannot cancel order in status: ${order.status}`);
        }
        // Return stock
        await this.returnStockToWarehouse(orderId);
        // Update status
        await this.updateOrderStatus(orderId, 'cancelled', cancelledBy, reason);
        return {
            order_id: orderId,
            cancelled: true,
            reason,
            cancelled_at: new Date(),
        };
    }
    async generateInvoice(orderId) {
        if (!orderId) {
            throw new Error("Order ID is required");
        }
        // In real implementation:
        // 1. Fetch order with all details
        // 2. Generate PDF using template
        // 3. Store PDF in file storage
        // 4. Return URL
        return {
            pdf_url: `/invoices/order_${orderId}.pdf`,
        };
    }
    async listOrders(filters = {}, pagination = {}) {
        const limit = pagination.limit || 20;
        const offset = pagination.offset || 0;
        // In real implementation, build query with filters
        // Apply pagination
        // Include customer and items
        return {
            orders: [],
            count: 0,
            limit,
            offset,
        };
    }
    async getOrder(orderId) {
        if (!orderId) {
            throw new Error("Order ID is required");
        }
        // In real implementation, fetch order with:
        // - Customer details
        // - Order items with products
        // - Shipping address
        // - Billing address
        // - Status history
        // - Fulfillments
        return {
            id: orderId,
            status: 'pending',
            payment_status: 'pending',
        };
    }
    generateOrderNumber() {
        // Generate unique order number
        // Format: ORD-YYYYMMDD-XXXX
        const date = new Date();
        const dateStr = date.toISOString().slice(0, 10).replace(/-/g, '');
        const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
        return `ORD-${dateStr}-${random}`;
    }
    async returnStockToWarehouse(orderId) {
        // In real implementation:
        // 1. Fetch order items
        // 2. For each item, increase warehouse stock
        // 3. Release reservations
        return { returned: true };
    }
}
exports.default = OmexOrderService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL29tZXgtb3JkZXIvc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHFEQUF5RDtBQXFCekQsTUFBTSxnQkFBaUIsU0FBUSxJQUFBLHFCQUFhLEVBQUMsRUFBRSxDQUFDO0lBQzlDLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxJQUFvQjtRQUM1QyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUN2QyxNQUFNLElBQUksS0FBSyxDQUFDLHNDQUFzQyxDQUFDLENBQUE7UUFDekQsQ0FBQztRQUVELDBCQUEwQjtRQUMxQiwyQkFBMkI7UUFDM0IsaUNBQWlDO1FBQ2pDLG1CQUFtQjtRQUNuQixrQkFBa0I7UUFDbEIsd0JBQXdCO1FBQ3hCLGdCQUFnQjtRQUVoQixNQUFNLEtBQUssR0FBRztZQUNaLEVBQUUsRUFBRSxTQUFTLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtZQUN6QixZQUFZLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixFQUFFO1lBQ3hDLFdBQVcsRUFBRSxJQUFJLENBQUMsV0FBVztZQUM3QixxQkFBcUIsRUFBRSxJQUFJLENBQUMscUJBQXFCO1lBQ2pELGFBQWEsRUFBRSxJQUFJLENBQUMsYUFBYTtZQUNqQyxhQUFhLEVBQUUsSUFBSSxDQUFDLGFBQWEsSUFBSSxXQUFXO1lBQ2hELFlBQVksRUFBRSxJQUFJLENBQUMsWUFBWTtZQUMvQixNQUFNLEVBQUUsU0FBd0I7WUFDaEMsY0FBYyxFQUFFLFNBQTBCO1lBQzFDLFVBQVUsRUFBRSxJQUFJLElBQUksRUFBRTtZQUN0QixjQUFjLEVBQUU7Z0JBQ2Q7b0JBQ0UsTUFBTSxFQUFFLFNBQVM7b0JBQ2pCLFVBQVUsRUFBRSxJQUFJLElBQUksRUFBRTtvQkFDdEIsVUFBVSxFQUFFLFFBQVE7aUJBQ3JCO2FBQ0Y7U0FDRixDQUFBO1FBRUQsT0FBTyxLQUFLLENBQUE7SUFDZCxDQUFDO0lBRUQsS0FBSyxDQUFDLGlCQUFpQixDQUFDLE9BQWUsRUFBRSxTQUFzQixFQUFFLFNBQWlCLEVBQUUsSUFBYTtRQUMvRixJQUFJLENBQUMsT0FBTyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDM0IsTUFBTSxJQUFJLEtBQUssQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFBO1FBQ3pELENBQUM7UUFFRCxNQUFNLGFBQWEsR0FBa0IsQ0FBQyxTQUFTLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUUsV0FBVyxDQUFDLENBQUE7UUFDbkcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztZQUN2QyxNQUFNLElBQUksS0FBSyxDQUFDLG1DQUFtQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUNoRixDQUFDO1FBRUQsMEJBQTBCO1FBQzFCLHlCQUF5QjtRQUN6QixnQ0FBZ0M7UUFDaEMseUJBQXlCO1FBQ3pCLDJCQUEyQjtRQUMzQixvQ0FBb0M7UUFFcEMsTUFBTSxZQUFZLEdBQXVCO1lBQ3ZDLE1BQU0sRUFBRSxTQUFTO1lBQ2pCLFVBQVUsRUFBRSxJQUFJLElBQUksRUFBRTtZQUN0QixVQUFVLEVBQUUsU0FBUztZQUNyQixJQUFJO1NBQ0wsQ0FBQTtRQUVELE9BQU87WUFDTCxRQUFRLEVBQUUsT0FBTztZQUNqQixNQUFNLEVBQUUsU0FBUztZQUNqQixhQUFhLEVBQUUsWUFBWTtZQUMzQixVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDdkIsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsZ0JBQWdCLENBQUMsT0FBZTtRQUNwQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDYixNQUFNLElBQUksS0FBSyxDQUFDLHNCQUFzQixDQUFDLENBQUE7UUFDekMsQ0FBQztRQUVELGdFQUFnRTtRQUNoRSwwQkFBMEI7UUFFMUIsT0FBTyxFQUFFLENBQUE7SUFDWCxDQUFDO0lBRUQsS0FBSyxDQUFDLFdBQVcsQ0FBQyxPQUFlLEVBQUUsTUFBYyxFQUFFLFdBQW1CO1FBQ3BFLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNiLE1BQU0sSUFBSSxLQUFLLENBQUMsc0JBQXNCLENBQUMsQ0FBQTtRQUN6QyxDQUFDO1FBRUQsMEJBQTBCO1FBQzFCLDRCQUE0QjtRQUM1Qiw2REFBNkQ7UUFDN0QsZ0NBQWdDO1FBQ2hDLCtCQUErQjtRQUMvQixzQ0FBc0M7UUFDdEMsd0NBQXdDO1FBQ3hDLDZCQUE2QjtRQUU3QixNQUFNLEtBQUssR0FBRyxNQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUE7UUFFMUMsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLFNBQVMsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRSxDQUFDO1lBQy9ELE1BQU0sSUFBSSxLQUFLLENBQUMsa0NBQWtDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFBO1FBQ25FLENBQUM7UUFFRCxlQUFlO1FBQ2YsTUFBTSxJQUFJLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLENBQUE7UUFFMUMsZ0JBQWdCO1FBQ2hCLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sRUFBRSxXQUFXLEVBQUUsV0FBVyxFQUFFLE1BQU0sQ0FBQyxDQUFBO1FBRXZFLE9BQU87WUFDTCxRQUFRLEVBQUUsT0FBTztZQUNqQixTQUFTLEVBQUUsSUFBSTtZQUNmLE1BQU07WUFDTixZQUFZLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDekIsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsZUFBZSxDQUFDLE9BQWU7UUFDbkMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2IsTUFBTSxJQUFJLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxDQUFBO1FBQ3pDLENBQUM7UUFFRCwwQkFBMEI7UUFDMUIsa0NBQWtDO1FBQ2xDLGlDQUFpQztRQUNqQywrQkFBK0I7UUFDL0IsZ0JBQWdCO1FBRWhCLE9BQU87WUFDTCxPQUFPLEVBQUUsbUJBQW1CLE9BQU8sTUFBTTtTQUMxQyxDQUFBO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxVQUFVLENBQUMsVUFNYixFQUFFLEVBQUUsYUFBa0QsRUFBRTtRQUMxRCxNQUFNLEtBQUssR0FBRyxVQUFVLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQTtRQUNwQyxNQUFNLE1BQU0sR0FBRyxVQUFVLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQTtRQUVyQyxtREFBbUQ7UUFDbkQsbUJBQW1CO1FBQ25CLDZCQUE2QjtRQUU3QixPQUFPO1lBQ0wsTUFBTSxFQUFFLEVBQUU7WUFDVixLQUFLLEVBQUUsQ0FBQztZQUNSLEtBQUs7WUFDTCxNQUFNO1NBQ1AsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQWU7UUFDNUIsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2IsTUFBTSxJQUFJLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxDQUFBO1FBQ3pDLENBQUM7UUFFRCw0Q0FBNEM7UUFDNUMscUJBQXFCO1FBQ3JCLDhCQUE4QjtRQUM5QixxQkFBcUI7UUFDckIsb0JBQW9CO1FBQ3BCLG1CQUFtQjtRQUNuQixpQkFBaUI7UUFFakIsT0FBTztZQUNMLEVBQUUsRUFBRSxPQUFPO1lBQ1gsTUFBTSxFQUFFLFNBQXdCO1lBQ2hDLGNBQWMsRUFBRSxTQUEwQjtTQUMzQyxDQUFBO0lBQ0gsQ0FBQztJQUVPLG1CQUFtQjtRQUN6QiwrQkFBK0I7UUFDL0IsNEJBQTRCO1FBQzVCLE1BQU0sSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUE7UUFDdkIsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQTtRQUNqRSxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxLQUFLLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFBO1FBQzVFLE9BQU8sT0FBTyxPQUFPLElBQUksTUFBTSxFQUFFLENBQUE7SUFDbkMsQ0FBQztJQUVPLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxPQUFlO1FBQ2xELDBCQUEwQjtRQUMxQix1QkFBdUI7UUFDdkIsNkNBQTZDO1FBQzdDLDBCQUEwQjtRQUUxQixPQUFPLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxDQUFBO0lBQzNCLENBQUM7Q0FDRjtBQUVELGtCQUFlLGdCQUFnQixDQUFBIn0=