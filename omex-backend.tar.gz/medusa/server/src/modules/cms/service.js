"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class CmsService extends (0, utils_1.MedusaService)({}) {
    // Zarządzanie stronami
    async createPage(data) {
        return {
            id: `page_${Date.now()}`,
            ...data,
            createdAt: new Date(),
            updatedAt: new Date(),
        };
    }
    async updatePage(id, data) {
        return { id, ...data, updatedAt: new Date() };
    }
    async getPage(id) {
        return null;
    }
    async listPages(filters) {
        return [];
    }
    async deletePage(id) {
        return { success: true };
    }
    // Zarządzanie blokami treści
    async createBlock(data) {
        return {
            id: `block_${Date.now()}`,
            ...data,
            createdAt: new Date(),
        };
    }
    async updateBlock(id, data) {
        return { id, ...data, updatedAt: new Date() };
    }
    async getBlock(id) {
        return null;
    }
    async listBlocks(filters) {
        return [];
    }
    // Zarządzanie menu
    async createMenu(data) {
        return {
            id: `menu_${Date.now()}`,
            ...data,
            createdAt: new Date(),
        };
    }
    async updateMenu(id, data) {
        return { id, ...data, updatedAt: new Date() };
    }
    async getMenu(id) {
        return null;
    }
    // Zarządzanie banerami
    async createBanner(data) {
        return {
            id: `banner_${Date.now()}`,
            ...data,
            createdAt: new Date(),
        };
    }
    async updateBanner(id, data) {
        return { id, ...data, updatedAt: new Date() };
    }
    async listBanners(filters) {
        return [];
    }
    // Zarządzanie FAQ
    async createFaq(data) {
        return {
            id: `faq_${Date.now()}`,
            ...data,
            createdAt: new Date(),
        };
    }
    async updateFaq(id, data) {
        return { id, ...data, updatedAt: new Date() };
    }
    async listFaqs(filters) {
        return [];
    }
    // Zarządzanie blogiem
    async createBlogPost(data) {
        return {
            id: `post_${Date.now()}`,
            ...data,
            createdAt: new Date(),
            published: false,
        };
    }
    async updateBlogPost(id, data) {
        return { id, ...data, updatedAt: new Date() };
    }
    async getBlogPost(slug) {
        return null;
    }
    async listBlogPosts(filters) {
        return [];
    }
    // Ustawienia globalne
    async getSettings() {
        return {
            siteName: "",
            siteDescription: "",
            logo: "",
            favicon: "",
            socialMedia: {},
            contactInfo: {},
            seo: {},
        };
    }
    async updateSettings(data) {
        return { ...data, updatedAt: new Date() };
    }
}
exports.default = CmsService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL2Ntcy9zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEscURBQXlEO0FBRXpELE1BQU0sVUFBVyxTQUFRLElBQUEscUJBQWEsRUFBQyxFQUFFLENBQUM7SUFDeEMsdUJBQXVCO0lBQ3ZCLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBUztRQUN4QixPQUFPO1lBQ0wsRUFBRSxFQUFFLFFBQVEsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO1lBQ3hCLEdBQUcsSUFBSTtZQUNQLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRTtZQUNyQixTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDdEIsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsVUFBVSxDQUFDLEVBQVUsRUFBRSxJQUFTO1FBQ3BDLE9BQU8sRUFBRSxFQUFFLEVBQUUsR0FBRyxJQUFJLEVBQUUsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLEVBQUUsQ0FBQTtJQUMvQyxDQUFDO0lBRUQsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFVO1FBQ3RCLE9BQU8sSUFBSSxDQUFBO0lBQ2IsQ0FBQztJQUVELEtBQUssQ0FBQyxTQUFTLENBQUMsT0FBYTtRQUMzQixPQUFPLEVBQUUsQ0FBQTtJQUNYLENBQUM7SUFFRCxLQUFLLENBQUMsVUFBVSxDQUFDLEVBQVU7UUFDekIsT0FBTyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsQ0FBQTtJQUMxQixDQUFDO0lBRUQsNkJBQTZCO0lBQzdCLEtBQUssQ0FBQyxXQUFXLENBQUMsSUFBUztRQUN6QixPQUFPO1lBQ0wsRUFBRSxFQUFFLFNBQVMsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO1lBQ3pCLEdBQUcsSUFBSTtZQUNQLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRTtTQUN0QixDQUFBO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxXQUFXLENBQUMsRUFBVSxFQUFFLElBQVM7UUFDckMsT0FBTyxFQUFFLEVBQUUsRUFBRSxHQUFHLElBQUksRUFBRSxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUUsRUFBRSxDQUFBO0lBQy9DLENBQUM7SUFFRCxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQVU7UUFDdkIsT0FBTyxJQUFJLENBQUE7SUFDYixDQUFDO0lBRUQsS0FBSyxDQUFDLFVBQVUsQ0FBQyxPQUFhO1FBQzVCLE9BQU8sRUFBRSxDQUFBO0lBQ1gsQ0FBQztJQUVELG1CQUFtQjtJQUNuQixLQUFLLENBQUMsVUFBVSxDQUFDLElBQVM7UUFDeEIsT0FBTztZQUNMLEVBQUUsRUFBRSxRQUFRLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtZQUN4QixHQUFHLElBQUk7WUFDUCxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDdEIsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsVUFBVSxDQUFDLEVBQVUsRUFBRSxJQUFTO1FBQ3BDLE9BQU8sRUFBRSxFQUFFLEVBQUUsR0FBRyxJQUFJLEVBQUUsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLEVBQUUsQ0FBQTtJQUMvQyxDQUFDO0lBRUQsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFVO1FBQ3RCLE9BQU8sSUFBSSxDQUFBO0lBQ2IsQ0FBQztJQUVELHVCQUF1QjtJQUN2QixLQUFLLENBQUMsWUFBWSxDQUFDLElBQVM7UUFDMUIsT0FBTztZQUNMLEVBQUUsRUFBRSxVQUFVLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtZQUMxQixHQUFHLElBQUk7WUFDUCxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDdEIsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQVUsRUFBRSxJQUFTO1FBQ3RDLE9BQU8sRUFBRSxFQUFFLEVBQUUsR0FBRyxJQUFJLEVBQUUsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLEVBQUUsQ0FBQTtJQUMvQyxDQUFDO0lBRUQsS0FBSyxDQUFDLFdBQVcsQ0FBQyxPQUFhO1FBQzdCLE9BQU8sRUFBRSxDQUFBO0lBQ1gsQ0FBQztJQUVELGtCQUFrQjtJQUNsQixLQUFLLENBQUMsU0FBUyxDQUFDLElBQVM7UUFDdkIsT0FBTztZQUNMLEVBQUUsRUFBRSxPQUFPLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtZQUN2QixHQUFHLElBQUk7WUFDUCxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDdEIsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsU0FBUyxDQUFDLEVBQVUsRUFBRSxJQUFTO1FBQ25DLE9BQU8sRUFBRSxFQUFFLEVBQUUsR0FBRyxJQUFJLEVBQUUsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLEVBQUUsQ0FBQTtJQUMvQyxDQUFDO0lBRUQsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFhO1FBQzFCLE9BQU8sRUFBRSxDQUFBO0lBQ1gsQ0FBQztJQUVELHNCQUFzQjtJQUN0QixLQUFLLENBQUMsY0FBYyxDQUFDLElBQVM7UUFDNUIsT0FBTztZQUNMLEVBQUUsRUFBRSxRQUFRLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtZQUN4QixHQUFHLElBQUk7WUFDUCxTQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7WUFDckIsU0FBUyxFQUFFLEtBQUs7U0FDakIsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsY0FBYyxDQUFDLEVBQVUsRUFBRSxJQUFTO1FBQ3hDLE9BQU8sRUFBRSxFQUFFLEVBQUUsR0FBRyxJQUFJLEVBQUUsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLEVBQUUsQ0FBQTtJQUMvQyxDQUFDO0lBRUQsS0FBSyxDQUFDLFdBQVcsQ0FBQyxJQUFZO1FBQzVCLE9BQU8sSUFBSSxDQUFBO0lBQ2IsQ0FBQztJQUVELEtBQUssQ0FBQyxhQUFhLENBQUMsT0FBYTtRQUMvQixPQUFPLEVBQUUsQ0FBQTtJQUNYLENBQUM7SUFFRCxzQkFBc0I7SUFDdEIsS0FBSyxDQUFDLFdBQVc7UUFDZixPQUFPO1lBQ0wsUUFBUSxFQUFFLEVBQUU7WUFDWixlQUFlLEVBQUUsRUFBRTtZQUNuQixJQUFJLEVBQUUsRUFBRTtZQUNSLE9BQU8sRUFBRSxFQUFFO1lBQ1gsV0FBVyxFQUFFLEVBQUU7WUFDZixXQUFXLEVBQUUsRUFBRTtZQUNmLEdBQUcsRUFBRSxFQUFFO1NBQ1IsQ0FBQTtJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsY0FBYyxDQUFDLElBQVM7UUFDNUIsT0FBTyxFQUFFLEdBQUcsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxFQUFFLENBQUE7SUFDM0MsQ0FBQztDQUNGO0FBRUQsa0JBQWUsVUFBVSxDQUFBIn0=