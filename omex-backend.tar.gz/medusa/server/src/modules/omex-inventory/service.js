"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
class OmexInventoryService extends (0, utils_1.MedusaService)({}) {
    constructor() {
        super(...arguments);
        this.LOW_STOCK_THRESHOLD = 10;
    }
    async getStock(productId, warehouseId) {
        if (!productId) {
            throw new Error("Product ID is required");
        }
        if (warehouseId) {
            // Get stock for specific warehouse
            return this.getStockForWarehouse(productId, warehouseId);
        }
        // Get stock for all warehouses
        return this.getAllStockForProduct(productId);
    }
    async updateStock(productId, warehouseId, quantity) {
        if (!productId || !warehouseId) {
            throw new Error("Product ID and warehouse ID are required");
        }
        if (quantity < 0) {
            throw new Error("Quantity cannot be negative");
        }
        return {
            product_id: productId,
            warehouse_id: warehouseId,
            quantity,
            updated_at: new Date(),
        };
    }
    async transferStock(productId, fromWarehouse, toWarehouse, quantity) {
        if (!productId || !fromWarehouse || !toWarehouse) {
            throw new Error("Product ID, source warehouse, and destination warehouse are required");
        }
        if (quantity <= 0) {
            throw new Error("Transfer quantity must be greater than 0");
        }
        if (fromWarehouse === toWarehouse) {
            throw new Error("Source and destination warehouses must be different");
        }
        // Check if source warehouse has enough stock
        const sourceStock = await this.getStockForWarehouse(productId, fromWarehouse);
        if (sourceStock.available < quantity) {
            throw new Error(`Insufficient stock in warehouse ${fromWarehouse}. ` +
                `Available: ${sourceStock.available}, Requested: ${quantity}`);
        }
        // Perform transfer (in transaction)
        // 1. Decrease stock in source warehouse
        await this.updateStock(productId, fromWarehouse, sourceStock.quantity - quantity);
        // 2. Increase stock in destination warehouse
        const destStock = await this.getStockForWarehouse(productId, toWarehouse);
        await this.updateStock(productId, toWarehouse, destStock.quantity + quantity);
        return {
            product_id: productId,
            from_warehouse: fromWarehouse,
            to_warehouse: toWarehouse,
            quantity,
            transferred_at: new Date(),
        };
    }
    async reserveStock(productId, quantity, warehouseId) {
        if (!productId || quantity <= 0) {
            throw new Error("Product ID and positive quantity are required");
        }
        // Find warehouse with available stock
        const warehouse = warehouseId || await this.findWarehouseWithStock(productId, quantity);
        if (!warehouse) {
            throw new Error(`No warehouse has ${quantity} units of product ${productId} available`);
        }
        const stock = await this.getStockForWarehouse(productId, warehouse);
        if (stock.available < quantity) {
            throw new Error(`Insufficient stock in warehouse ${warehouse}. ` +
                `Available: ${stock.available}, Requested: ${quantity}`);
        }
        // Create reservation
        const reservation = {
            id: `res_${Date.now()}`,
            product_id: productId,
            warehouse_id: warehouse,
            quantity,
            created_at: new Date(),
        };
        // Update reserved quantity
        // In real implementation, update inventory table: reserved += quantity
        return reservation;
    }
    async releaseReservation(reservationId) {
        if (!reservationId) {
            throw new Error("Reservation ID is required");
        }
        // In real implementation:
        // 1. Fetch reservation
        // 2. Update inventory: reserved -= reservation.quantity
        // 3. Delete reservation
        return { released: true, id: reservationId };
    }
    async getLowStockAlerts(threshold) {
        const alertThreshold = threshold || this.LOW_STOCK_THRESHOLD;
        // In real implementation, query inventory table:
        // WHERE quantity < threshold
        // ORDER BY quantity ASC
        return [];
    }
    async getTotalStock(productId) {
        if (!productId) {
            throw new Error("Product ID is required");
        }
        const allStock = await this.getAllStockForProduct(productId);
        return allStock.reduce((total, stock) => total + stock.available, 0);
    }
    async getStockForWarehouse(productId, warehouseId) {
        // In real implementation, fetch from inventory table
        // WHERE product_id = productId AND warehouse_id = warehouseId
        return {
            product_id: productId,
            warehouse_id: warehouseId,
            quantity: 0,
            reserved: 0,
            available: 0,
        };
    }
    async getAllStockForProduct(productId) {
        // In real implementation, fetch from inventory table
        // WHERE product_id = productId
        return [];
    }
    async findWarehouseWithStock(productId, quantity) {
        const allStock = await this.getAllStockForProduct(productId);
        for (const stock of allStock) {
            if (stock.available >= quantity) {
                return stock.warehouse_id;
            }
        }
        return null;
    }
}
exports.default = OmexInventoryService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL29tZXgtaW52ZW50b3J5L3NlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBeUQ7QUF5QnpELE1BQU0sb0JBQXFCLFNBQVEsSUFBQSxxQkFBYSxFQUFDLEVBQUUsQ0FBQztJQUFwRDs7UUFDbUIsd0JBQW1CLEdBQUcsRUFBRSxDQUFBO0lBa0wzQyxDQUFDO0lBaExDLEtBQUssQ0FBQyxRQUFRLENBQUMsU0FBaUIsRUFBRSxXQUFvQjtRQUNwRCxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDZixNQUFNLElBQUksS0FBSyxDQUFDLHdCQUF3QixDQUFDLENBQUE7UUFDM0MsQ0FBQztRQUVELElBQUksV0FBVyxFQUFFLENBQUM7WUFDaEIsbUNBQW1DO1lBQ25DLE9BQU8sSUFBSSxDQUFDLG9CQUFvQixDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsQ0FBQTtRQUMxRCxDQUFDO1FBRUQsK0JBQStCO1FBQy9CLE9BQU8sSUFBSSxDQUFDLHFCQUFxQixDQUFDLFNBQVMsQ0FBQyxDQUFBO0lBQzlDLENBQUM7SUFFRCxLQUFLLENBQUMsV0FBVyxDQUFDLFNBQWlCLEVBQUUsV0FBbUIsRUFBRSxRQUFnQjtRQUN4RSxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDL0IsTUFBTSxJQUFJLEtBQUssQ0FBQywwQ0FBMEMsQ0FBQyxDQUFBO1FBQzdELENBQUM7UUFFRCxJQUFJLFFBQVEsR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNqQixNQUFNLElBQUksS0FBSyxDQUFDLDZCQUE2QixDQUFDLENBQUE7UUFDaEQsQ0FBQztRQUVELE9BQU87WUFDTCxVQUFVLEVBQUUsU0FBUztZQUNyQixZQUFZLEVBQUUsV0FBVztZQUN6QixRQUFRO1lBQ1IsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFO1NBQ3ZCLENBQUE7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLGFBQWEsQ0FDakIsU0FBaUIsRUFDakIsYUFBcUIsRUFDckIsV0FBbUIsRUFDbkIsUUFBZ0I7UUFFaEIsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLGFBQWEsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ2pELE1BQU0sSUFBSSxLQUFLLENBQUMsc0VBQXNFLENBQUMsQ0FBQTtRQUN6RixDQUFDO1FBRUQsSUFBSSxRQUFRLElBQUksQ0FBQyxFQUFFLENBQUM7WUFDbEIsTUFBTSxJQUFJLEtBQUssQ0FBQywwQ0FBMEMsQ0FBQyxDQUFBO1FBQzdELENBQUM7UUFFRCxJQUFJLGFBQWEsS0FBSyxXQUFXLEVBQUUsQ0FBQztZQUNsQyxNQUFNLElBQUksS0FBSyxDQUFDLHFEQUFxRCxDQUFDLENBQUE7UUFDeEUsQ0FBQztRQUVELDZDQUE2QztRQUM3QyxNQUFNLFdBQVcsR0FBRyxNQUFNLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxTQUFTLEVBQUUsYUFBYSxDQUFDLENBQUE7UUFFN0UsSUFBSSxXQUFXLENBQUMsU0FBUyxHQUFHLFFBQVEsRUFBRSxDQUFDO1lBQ3JDLE1BQU0sSUFBSSxLQUFLLENBQ2IsbUNBQW1DLGFBQWEsSUFBSTtnQkFDcEQsY0FBYyxXQUFXLENBQUMsU0FBUyxnQkFBZ0IsUUFBUSxFQUFFLENBQzlELENBQUE7UUFDSCxDQUFDO1FBRUQsb0NBQW9DO1FBQ3BDLHdDQUF3QztRQUN4QyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxFQUFFLGFBQWEsRUFBRSxXQUFXLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxDQUFBO1FBRWpGLDZDQUE2QztRQUM3QyxNQUFNLFNBQVMsR0FBRyxNQUFNLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxTQUFTLEVBQUUsV0FBVyxDQUFDLENBQUE7UUFDekUsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxXQUFXLEVBQUUsU0FBUyxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUMsQ0FBQTtRQUU3RSxPQUFPO1lBQ0wsVUFBVSxFQUFFLFNBQVM7WUFDckIsY0FBYyxFQUFFLGFBQWE7WUFDN0IsWUFBWSxFQUFFLFdBQVc7WUFDekIsUUFBUTtZQUNSLGNBQWMsRUFBRSxJQUFJLElBQUksRUFBRTtTQUMzQixDQUFBO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxZQUFZLENBQUMsU0FBaUIsRUFBRSxRQUFnQixFQUFFLFdBQW9CO1FBQzFFLElBQUksQ0FBQyxTQUFTLElBQUksUUFBUSxJQUFJLENBQUMsRUFBRSxDQUFDO1lBQ2hDLE1BQU0sSUFBSSxLQUFLLENBQUMsK0NBQStDLENBQUMsQ0FBQTtRQUNsRSxDQUFDO1FBRUQsc0NBQXNDO1FBQ3RDLE1BQU0sU0FBUyxHQUFHLFdBQVcsSUFBSSxNQUFNLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxTQUFTLEVBQUUsUUFBUSxDQUFDLENBQUE7UUFFdkYsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ2YsTUFBTSxJQUFJLEtBQUssQ0FBQyxvQkFBb0IsUUFBUSxxQkFBcUIsU0FBUyxZQUFZLENBQUMsQ0FBQTtRQUN6RixDQUFDO1FBRUQsTUFBTSxLQUFLLEdBQUcsTUFBTSxJQUFJLENBQUMsb0JBQW9CLENBQUMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFBO1FBRW5FLElBQUksS0FBSyxDQUFDLFNBQVMsR0FBRyxRQUFRLEVBQUUsQ0FBQztZQUMvQixNQUFNLElBQUksS0FBSyxDQUNiLG1DQUFtQyxTQUFTLElBQUk7Z0JBQ2hELGNBQWMsS0FBSyxDQUFDLFNBQVMsZ0JBQWdCLFFBQVEsRUFBRSxDQUN4RCxDQUFBO1FBQ0gsQ0FBQztRQUVELHFCQUFxQjtRQUNyQixNQUFNLFdBQVcsR0FBZ0I7WUFDL0IsRUFBRSxFQUFFLE9BQU8sSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO1lBQ3ZCLFVBQVUsRUFBRSxTQUFTO1lBQ3JCLFlBQVksRUFBRSxTQUFTO1lBQ3ZCLFFBQVE7WUFDUixVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUU7U0FDdkIsQ0FBQTtRQUVELDJCQUEyQjtRQUMzQix1RUFBdUU7UUFFdkUsT0FBTyxXQUFXLENBQUE7SUFDcEIsQ0FBQztJQUVELEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxhQUFxQjtRQUM1QyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDbkIsTUFBTSxJQUFJLEtBQUssQ0FBQyw0QkFBNEIsQ0FBQyxDQUFBO1FBQy9DLENBQUM7UUFFRCwwQkFBMEI7UUFDMUIsdUJBQXVCO1FBQ3ZCLHdEQUF3RDtRQUN4RCx3QkFBd0I7UUFFeEIsT0FBTyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLGFBQWEsRUFBRSxDQUFBO0lBQzlDLENBQUM7SUFFRCxLQUFLLENBQUMsaUJBQWlCLENBQUMsU0FBa0I7UUFDeEMsTUFBTSxjQUFjLEdBQUcsU0FBUyxJQUFJLElBQUksQ0FBQyxtQkFBbUIsQ0FBQTtRQUU1RCxpREFBaUQ7UUFDakQsNkJBQTZCO1FBQzdCLHdCQUF3QjtRQUV4QixPQUFPLEVBQUUsQ0FBQTtJQUNYLENBQUM7SUFFRCxLQUFLLENBQUMsYUFBYSxDQUFDLFNBQWlCO1FBQ25DLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUNmLE1BQU0sSUFBSSxLQUFLLENBQUMsd0JBQXdCLENBQUMsQ0FBQTtRQUMzQyxDQUFDO1FBRUQsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMscUJBQXFCLENBQUMsU0FBUyxDQUFDLENBQUE7UUFFNUQsT0FBTyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUE7SUFDdEUsQ0FBQztJQUVPLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxTQUFpQixFQUFFLFdBQW1CO1FBQ3ZFLHFEQUFxRDtRQUNyRCw4REFBOEQ7UUFFOUQsT0FBTztZQUNMLFVBQVUsRUFBRSxTQUFTO1lBQ3JCLFlBQVksRUFBRSxXQUFXO1lBQ3pCLFFBQVEsRUFBRSxDQUFDO1lBQ1gsUUFBUSxFQUFFLENBQUM7WUFDWCxTQUFTLEVBQUUsQ0FBQztTQUNiLENBQUE7SUFDSCxDQUFDO0lBRU8sS0FBSyxDQUFDLHFCQUFxQixDQUFDLFNBQWlCO1FBQ25ELHFEQUFxRDtRQUNyRCwrQkFBK0I7UUFFL0IsT0FBTyxFQUFFLENBQUE7SUFDWCxDQUFDO0lBRU8sS0FBSyxDQUFDLHNCQUFzQixDQUFDLFNBQWlCLEVBQUUsUUFBZ0I7UUFDdEUsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMscUJBQXFCLENBQUMsU0FBUyxDQUFDLENBQUE7UUFFNUQsS0FBSyxNQUFNLEtBQUssSUFBSSxRQUFRLEVBQUUsQ0FBQztZQUM3QixJQUFJLEtBQUssQ0FBQyxTQUFTLElBQUksUUFBUSxFQUFFLENBQUM7Z0JBQ2hDLE9BQU8sS0FBSyxDQUFDLFlBQVksQ0FBQTtZQUMzQixDQUFDO1FBQ0gsQ0FBQztRQUVELE9BQU8sSUFBSSxDQUFBO0lBQ2IsQ0FBQztDQUNGO0FBRUQsa0JBQWUsb0JBQW9CLENBQUEifQ==