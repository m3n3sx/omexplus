"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = cleanupAbandonedCarts;
async function cleanupAbandonedCarts(container) {
    console.log("Cleaning up abandoned carts...");
    // Usuwanie starych koszyków
    // Wysyłanie przypomnień o porzuconych koszykach
}
exports.config = {
    name: "cleanup-abandoned-carts",
    schedule: "0 2 * * *", // Codziennie o 2:00
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xlYW51cC1hYmFuZG9uZWQtY2FydHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvam9icy9jbGVhbnVwLWFiYW5kb25lZC1jYXJ0cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFFQSx3Q0FLQztBQUxjLEtBQUssVUFBVSxxQkFBcUIsQ0FBQyxTQUEwQjtJQUM1RSxPQUFPLENBQUMsR0FBRyxDQUFDLGdDQUFnQyxDQUFDLENBQUE7SUFFN0MsNEJBQTRCO0lBQzVCLGdEQUFnRDtBQUNsRCxDQUFDO0FBRVksUUFBQSxNQUFNLEdBQUc7SUFDcEIsSUFBSSxFQUFFLHlCQUF5QjtJQUMvQixRQUFRLEVBQUUsV0FBVyxFQUFFLG9CQUFvQjtDQUM1QyxDQUFBIn0=