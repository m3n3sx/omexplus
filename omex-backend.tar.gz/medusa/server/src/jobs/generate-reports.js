"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = generateReports;
async function generateReports(container) {
    console.log("Generating daily reports...");
    // Generowanie raportów sprzedaży
    // Analiza produktów
    // Statystyki klientów
}
exports.config = {
    name: "generate-reports",
    schedule: "0 0 * * *", // Codziennie o północy
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2VuZXJhdGUtcmVwb3J0cy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9qb2JzL2dlbmVyYXRlLXJlcG9ydHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBRUEsa0NBTUM7QUFOYyxLQUFLLFVBQVUsZUFBZSxDQUFDLFNBQTBCO0lBQ3RFLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLENBQUMsQ0FBQTtJQUUxQyxpQ0FBaUM7SUFDakMsb0JBQW9CO0lBQ3BCLHNCQUFzQjtBQUN4QixDQUFDO0FBRVksUUFBQSxNQUFNLEdBQUc7SUFDcEIsSUFBSSxFQUFFLGtCQUFrQjtJQUN4QixRQUFRLEVBQUUsV0FBVyxFQUFFLHVCQUF1QjtDQUMvQyxDQUFBIn0=