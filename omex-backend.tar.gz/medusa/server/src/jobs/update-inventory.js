"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = updateInventory;
async function updateInventory(container) {
    console.log("Updating inventory...");
    // Synchronizacja stanów magazynowych
    // Powiadomienia o niskich stanach
}
exports.config = {
    name: "update-inventory",
    schedule: "*/30 * * * *", // Co 30 minut
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXBkYXRlLWludmVudG9yeS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9qb2JzL3VwZGF0ZS1pbnZlbnRvcnkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBRUEsa0NBS0M7QUFMYyxLQUFLLFVBQVUsZUFBZSxDQUFDLFNBQTBCO0lBQ3RFLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQTtJQUVwQyxxQ0FBcUM7SUFDckMsa0NBQWtDO0FBQ3BDLENBQUM7QUFFWSxRQUFBLE1BQU0sR0FBRztJQUNwQixJQUFJLEVBQUUsa0JBQWtCO0lBQ3hCLFFBQVEsRUFBRSxjQUFjLEVBQUUsY0FBYztDQUN6QyxDQUFBIn0=