"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = generateSitemap;
async function generateSitemap(container) {
    console.log("Generating sitemap...");
    // Pobierz wszystkie strony, produkty, posty
    // Wygeneruj sitemap.xml
    // Zapisz w public/sitemap.xml
}
exports.config = {
    name: "generate-sitemap",
    schedule: "0 3 * * *", // Codziennie o 3:00
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2VuZXJhdGUtc2l0ZW1hcC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9qb2JzL2dlbmVyYXRlLXNpdGVtYXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBRUEsa0NBTUM7QUFOYyxLQUFLLFVBQVUsZUFBZSxDQUFDLFNBQTBCO0lBQ3RFLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQTtJQUVwQyw0Q0FBNEM7SUFDNUMsd0JBQXdCO0lBQ3hCLDhCQUE4QjtBQUNoQyxDQUFDO0FBRVksUUFBQSxNQUFNLEdBQUc7SUFDcEIsSUFBSSxFQUFFLGtCQUFrQjtJQUN4QixRQUFRLEVBQUUsV0FBVyxFQUFFLG9CQUFvQjtDQUM1QyxDQUFBIn0=