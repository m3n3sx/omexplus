"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.default = sendPromotionalEmails;
async function sendPromotionalEmails(container) {
    console.log("Sending promotional emails...");
    // Wysyłanie emaili promocyjnych
    // Segmentacja klientów
    // Personalizacja ofert
}
exports.config = {
    name: "send-promotional-emails",
    schedule: "0 10 * * 1", // Każdy poniedziałek o 10:00
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VuZC1wcm9tb3Rpb25hbC1lbWFpbHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvam9icy9zZW5kLXByb21vdGlvbmFsLWVtYWlscy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFFQSx3Q0FNQztBQU5jLEtBQUssVUFBVSxxQkFBcUIsQ0FBQyxTQUEwQjtJQUM1RSxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixDQUFDLENBQUE7SUFFNUMsZ0NBQWdDO0lBQ2hDLHVCQUF1QjtJQUN2Qix1QkFBdUI7QUFDekIsQ0FBQztBQUVZLFFBQUEsTUFBTSxHQUFHO0lBQ3BCLElBQUksRUFBRSx5QkFBeUI7SUFDL0IsUUFBUSxFQUFFLFlBQVksRUFBRSw2QkFBNkI7Q0FDdEQsQ0FBQSJ9