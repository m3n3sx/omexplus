"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = stripePlugin;
const stripe_1 = __importDefault(require("stripe"));
async function stripePlugin(container, options) {
    const logger = container.resolve('logger');
    try {
        // Initialize Stripe SDK
        const stripe = new stripe_1.default(options.apiKey, {
            apiVersion: options.apiVersion || '2023-10-16',
            typescript: true,
        });
        // Register Stripe instance in container
        container.register({
            stripe: {
                resolve: () => stripe,
            },
            stripeWebhookSecret: {
                resolve: () => options.webhookSecret,
            },
        });
        logger.info('Stripe plugin initialized successfully');
    }
    catch (error) {
        logger.error('Failed to initialize Stripe plugin:', error);
        throw error;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvcGx1Z2lucy9zdHJpcGUvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFTQSwrQkE0QkM7QUFyQ0Qsb0RBQTRCO0FBU2IsS0FBSyxVQUFVLFlBQVksQ0FDeEMsU0FBYyxFQUNkLE9BQTRCO0lBRTVCLE1BQU0sTUFBTSxHQUFXLFNBQVMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7SUFFbkQsSUFBSSxDQUFDO1FBQ0gsd0JBQXdCO1FBQ3hCLE1BQU0sTUFBTSxHQUFHLElBQUksZ0JBQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFO1lBQ3hDLFVBQVUsRUFBRyxPQUFPLENBQUMsVUFBa0IsSUFBSSxZQUFZO1lBQ3ZELFVBQVUsRUFBRSxJQUFJO1NBQ2pCLENBQUMsQ0FBQztRQUVILHdDQUF3QztRQUN4QyxTQUFTLENBQUMsUUFBUSxDQUFDO1lBQ2pCLE1BQU0sRUFBRTtnQkFDTixPQUFPLEVBQUUsR0FBRyxFQUFFLENBQUMsTUFBTTthQUN0QjtZQUNELG1CQUFtQixFQUFFO2dCQUNuQixPQUFPLEVBQUUsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLGFBQWE7YUFDckM7U0FDRixDQUFDLENBQUM7UUFFSCxNQUFNLENBQUMsSUFBSSxDQUFDLHdDQUF3QyxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixNQUFNLENBQUMsS0FBSyxDQUFDLHFDQUFxQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzNELE1BQU0sS0FBSyxDQUFDO0lBQ2QsQ0FBQztBQUNILENBQUMifQ==