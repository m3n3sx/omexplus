"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LanguageSwitcher = LanguageSwitcher;
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
function LanguageSwitcher() {
    const [languages, setLanguages] = (0, react_1.useState)({});
    const [currentLocale, setCurrentLocale] = (0, react_1.useState)('pl');
    (0, react_1.useEffect)(() => {
        // Pobierz dostępne języki
        fetch('/store/i18n/languages')
            .then(res => res.json())
            .then(data => {
            setLanguages(data.languages);
            // Pobierz aktualny język z cookie lub localStorage
            const savedLocale = localStorage.getItem('locale') || 'pl';
            setCurrentLocale(savedLocale);
        });
    }, []);
    const changeLanguage = async (locale) => {
        try {
            await fetch('/store/i18n/locale', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ locale })
            });
            localStorage.setItem('locale', locale);
            setCurrentLocale(locale);
            window.location.reload();
        }
        catch (error) {
            console.error('Failed to change language:', error);
        }
    };
    return ((0, jsx_runtime_1.jsx)("select", { value: currentLocale, onChange: (e) => changeLanguage(e.target.value), className: "border rounded px-3 py-2", children: Object.entries(languages).map(([code, lang]) => ((0, jsx_runtime_1.jsxs)("option", { value: code, children: [lang.flag, " ", lang.nativeName] }, code))) }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTGFuZ3VhZ2VTd2l0Y2hlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9pMThuL2NvbXBvbmVudHMvTGFuZ3VhZ2VTd2l0Y2hlci50c3giXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFRQSw0Q0E2Q0M7O0FBckRELGlDQUEyQztBQVEzQyxTQUFnQixnQkFBZ0I7SUFDOUIsTUFBTSxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsR0FBRyxJQUFBLGdCQUFRLEVBQTJCLEVBQUUsQ0FBQyxDQUFBO0lBQ3hFLE1BQU0sQ0FBQyxhQUFhLEVBQUUsZ0JBQWdCLENBQUMsR0FBRyxJQUFBLGdCQUFRLEVBQUMsSUFBSSxDQUFDLENBQUE7SUFFeEQsSUFBQSxpQkFBUyxFQUFDLEdBQUcsRUFBRTtRQUNiLDBCQUEwQjtRQUMxQixLQUFLLENBQUMsdUJBQXVCLENBQUM7YUFDM0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ3ZCLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNYLFlBQVksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUE7WUFDNUIsbURBQW1EO1lBQ25ELE1BQU0sV0FBVyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxDQUFBO1lBQzFELGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFBO1FBQy9CLENBQUMsQ0FBQyxDQUFBO0lBQ04sQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFBO0lBRU4sTUFBTSxjQUFjLEdBQUcsS0FBSyxFQUFFLE1BQWMsRUFBRSxFQUFFO1FBQzlDLElBQUksQ0FBQztZQUNILE1BQU0sS0FBSyxDQUFDLG9CQUFvQixFQUFFO2dCQUNoQyxNQUFNLEVBQUUsTUFBTTtnQkFDZCxPQUFPLEVBQUUsRUFBRSxjQUFjLEVBQUUsa0JBQWtCLEVBQUU7Z0JBQy9DLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsTUFBTSxFQUFFLENBQUM7YUFDakMsQ0FBQyxDQUFBO1lBRUYsWUFBWSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUE7WUFDdEMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUE7WUFDeEIsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQTtRQUMxQixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDcEQsQ0FBQztJQUNILENBQUMsQ0FBQTtJQUVELE9BQU8sQ0FDTCxtQ0FDRSxLQUFLLEVBQUUsYUFBYSxFQUNwQixRQUFRLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUMvQyxTQUFTLEVBQUMsMEJBQTBCLFlBRW5DLE1BQU0sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQy9DLG9DQUFtQixLQUFLLEVBQUUsSUFBSSxhQUMzQixJQUFJLENBQUMsSUFBSSxPQUFHLElBQUksQ0FBQyxVQUFVLEtBRGpCLElBQUksQ0FFUixDQUNWLENBQUMsR0FDSyxDQUNWLENBQUE7QUFDSCxDQUFDIn0=