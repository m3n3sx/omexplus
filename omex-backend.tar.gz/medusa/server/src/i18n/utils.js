"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTranslation = getTranslation;
exports.detectLocale = detectLocale;
exports.formatCurrency = formatCurrency;
exports.formatDate = formatDate;
const config_1 = require("./config");
function getTranslation(translations, key, params) {
    const keys = key.split(".");
    let value = translations;
    for (const k of keys) {
        if (value && typeof value === "object" && k in value) {
            value = value[k];
        }
        else {
            return key;
        }
    }
    if (typeof value !== "string") {
        return key;
    }
    if (params) {
        return Object.entries(params).reduce((str, [paramKey, paramValue]) => str.replace(new RegExp(`{{${paramKey}}}`, "g"), String(paramValue)), value);
    }
    return value;
}
function detectLocale(acceptLanguage) {
    if (!acceptLanguage)
        return config_1.i18nConfig.defaultLocale;
    const languages = acceptLanguage.split(",").map((lang) => {
        const [code] = lang.trim().split(";");
        return code.split("-")[0];
    });
    for (const lang of languages) {
        if (config_1.i18nConfig.locales.includes(lang)) {
            return lang;
        }
    }
    return config_1.i18nConfig.defaultLocale;
}
function formatCurrency(amount, locale, currency = "PLN") {
    const currencyMap = {
        pl: "PLN",
        en: "USD",
        de: "EUR",
        uk: "UAH",
    };
    return new Intl.NumberFormat(locale, {
        style: "currency",
        currency: currency || currencyMap[locale],
    }).format(amount);
}
function formatDate(date, locale) {
    return new Intl.DateTimeFormat(locale, {
        year: "numeric",
        month: "long",
        day: "numeric",
    }).format(date);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXRpbHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvaTE4bi91dGlscy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUVBLHdDQTZCQztBQUVELG9DQWVDO0FBRUQsd0NBZ0JDO0FBRUQsZ0NBTUM7QUExRUQscUNBQTZDO0FBRTdDLFNBQWdCLGNBQWMsQ0FDNUIsWUFBaUMsRUFDakMsR0FBVyxFQUNYLE1BQXdDO0lBRXhDLE1BQU0sSUFBSSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUE7SUFDM0IsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFBO0lBRXhCLEtBQUssTUFBTSxDQUFDLElBQUksSUFBSSxFQUFFLENBQUM7UUFDckIsSUFBSSxLQUFLLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxJQUFJLENBQUMsSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUNyRCxLQUFLLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBQ2xCLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxHQUFHLENBQUE7UUFDWixDQUFDO0lBQ0gsQ0FBQztJQUVELElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxFQUFFLENBQUM7UUFDOUIsT0FBTyxHQUFHLENBQUE7SUFDWixDQUFDO0lBRUQsSUFBSSxNQUFNLEVBQUUsQ0FBQztRQUNYLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQ2xDLENBQUMsR0FBRyxFQUFFLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQyxFQUFFLEVBQUUsQ0FDOUIsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxLQUFLLFFBQVEsSUFBSSxFQUFFLEdBQUcsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUNyRSxLQUFLLENBQ04sQ0FBQTtJQUNILENBQUM7SUFFRCxPQUFPLEtBQUssQ0FBQTtBQUNkLENBQUM7QUFFRCxTQUFnQixZQUFZLENBQUMsY0FBdUI7SUFDbEQsSUFBSSxDQUFDLGNBQWM7UUFBRSxPQUFPLG1CQUFVLENBQUMsYUFBdUIsQ0FBQTtJQUU5RCxNQUFNLFNBQVMsR0FBRyxjQUFjLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFO1FBQ3ZELE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFBO1FBQ3JDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUMzQixDQUFDLENBQUMsQ0FBQTtJQUVGLEtBQUssTUFBTSxJQUFJLElBQUksU0FBUyxFQUFFLENBQUM7UUFDN0IsSUFBSSxtQkFBVSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUN0QyxPQUFPLElBQWMsQ0FBQTtRQUN2QixDQUFDO0lBQ0gsQ0FBQztJQUVELE9BQU8sbUJBQVUsQ0FBQyxhQUF1QixDQUFBO0FBQzNDLENBQUM7QUFFRCxTQUFnQixjQUFjLENBQzVCLE1BQWMsRUFDZCxNQUFjLEVBQ2QsV0FBbUIsS0FBSztJQUV4QixNQUFNLFdBQVcsR0FBMkI7UUFDMUMsRUFBRSxFQUFFLEtBQUs7UUFDVCxFQUFFLEVBQUUsS0FBSztRQUNULEVBQUUsRUFBRSxLQUFLO1FBQ1QsRUFBRSxFQUFFLEtBQUs7S0FDVixDQUFBO0lBRUQsT0FBTyxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFO1FBQ25DLEtBQUssRUFBRSxVQUFVO1FBQ2pCLFFBQVEsRUFBRSxRQUFRLElBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQztLQUMxQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0FBQ25CLENBQUM7QUFFRCxTQUFnQixVQUFVLENBQUMsSUFBVSxFQUFFLE1BQWM7SUFDbkQsT0FBTyxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxFQUFFO1FBQ3JDLElBQUksRUFBRSxTQUFTO1FBQ2YsS0FBSyxFQUFFLE1BQU07UUFDYixHQUFHLEVBQUUsU0FBUztLQUNmLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUE7QUFDakIsQ0FBQyJ9