"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.i18nConfig = void 0;
exports.i18nConfig = {
    defaultLocale: "pl",
    locales: ["pl", "en", "de", "uk"],
    localeNames: {
        pl: "Polski",
        en: "English",
        de: "Deutsch",
        uk: "Українська",
    },
    localeFlags: {
        pl: "🇵🇱",
        en: "🇬🇧",
        de: "🇩🇪",
        uk: "🇺🇦",
    },
    fallbackLocale: "en",
    namespaces: [
        "common",
        "navigation",
        "products",
        "cart",
        "checkout",
        "account",
        "footer",
        "validation",
        "messages",
    ],
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL2kxOG4vY29uZmlnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFhLFFBQUEsVUFBVSxHQUFHO0lBQ3hCLGFBQWEsRUFBRSxJQUFJO0lBQ25CLE9BQU8sRUFBRSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQztJQUNqQyxXQUFXLEVBQUU7UUFDWCxFQUFFLEVBQUUsUUFBUTtRQUNaLEVBQUUsRUFBRSxTQUFTO1FBQ2IsRUFBRSxFQUFFLFNBQVM7UUFDYixFQUFFLEVBQUUsWUFBWTtLQUNqQjtJQUNELFdBQVcsRUFBRTtRQUNYLEVBQUUsRUFBRSxNQUFNO1FBQ1YsRUFBRSxFQUFFLE1BQU07UUFDVixFQUFFLEVBQUUsTUFBTTtRQUNWLEVBQUUsRUFBRSxNQUFNO0tBQ1g7SUFDRCxjQUFjLEVBQUUsSUFBSTtJQUNwQixVQUFVLEVBQUU7UUFDVixRQUFRO1FBQ1IsWUFBWTtRQUNaLFVBQVU7UUFDVixNQUFNO1FBQ04sVUFBVTtRQUNWLFNBQVM7UUFDVCxRQUFRO1FBQ1IsWUFBWTtRQUNaLFVBQVU7S0FDWDtDQUNGLENBQUEifQ==