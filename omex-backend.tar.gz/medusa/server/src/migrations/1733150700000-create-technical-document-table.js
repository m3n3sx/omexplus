"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateTechnicalDocumentTable1733150700000 = void 0;
const typeorm_1 = require("typeorm");
class CreateTechnicalDocumentTable1733150700000 {
    async up(queryRunner) {
        await queryRunner.createTable(new typeorm_1.Table({
            name: "technical_document",
            columns: [
                {
                    name: "id",
                    type: "uuid",
                    isPrimary: true,
                    generationStrategy: "uuid",
                    default: "uuid_generate_v4()",
                },
                {
                    name: "manufacturer_id",
                    type: "uuid",
                    isNullable: true,
                },
                {
                    name: "title",
                    type: "varchar",
                    length: "255",
                    isNullable: false,
                },
                {
                    name: "document_type",
                    type: "varchar",
                    length: "50",
                    isNullable: false,
                },
                {
                    name: "file_url",
                    type: "varchar",
                    length: "500",
                    isNullable: false,
                },
                {
                    name: "file_size",
                    type: "int",
                    isNullable: true,
                },
                {
                    name: "mime_type",
                    type: "varchar",
                    length: "100",
                    isNullable: true,
                },
                {
                    name: "products",
                    type: "jsonb",
                    isNullable: true,
                    default: "'[]'",
                },
                {
                    name: "created_at",
                    type: "timestamp",
                    default: "now()",
                },
                {
                    name: "updated_at",
                    type: "timestamp",
                    default: "now()",
                },
            ],
        }), true);
        // Add foreign key
        await queryRunner.createForeignKey("technical_document", new typeorm_1.TableForeignKey({
            columnNames: ["manufacturer_id"],
            referencedColumnNames: ["id"],
            referencedTableName: "manufacturer",
            onDelete: "CASCADE",
        }));
        // Create indexes
        await queryRunner.createIndex("technical_document", new typeorm_1.TableIndex({
            name: "IDX_technical_document_manufacturer_id",
            columnNames: ["manufacturer_id"],
        }));
        await queryRunner.createIndex("technical_document", new typeorm_1.TableIndex({
            name: "IDX_technical_document_type",
            columnNames: ["document_type"],
        }));
        // Create GIN index on products array for fast lookups
        await queryRunner.query(`CREATE INDEX "IDX_technical_document_products" ON "technical_document" USING GIN (products)`);
    }
    async down(queryRunner) {
        await queryRunner.dropTable("technical_document");
    }
}
exports.CreateTechnicalDocumentTable1733150700000 = CreateTechnicalDocumentTable1733150700000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTczMzE1MDcwMDAwMC1jcmVhdGUtdGVjaG5pY2FsLWRvY3VtZW50LXRhYmxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL21pZ3JhdGlvbnMvMTczMzE1MDcwMDAwMC1jcmVhdGUtdGVjaG5pY2FsLWRvY3VtZW50LXRhYmxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFDQUE2RjtBQUU3RixNQUFhLHlDQUF5QztJQUM3QyxLQUFLLENBQUMsRUFBRSxDQUFDLFdBQXdCO1FBQ3RDLE1BQU0sV0FBVyxDQUFDLFdBQVcsQ0FDM0IsSUFBSSxlQUFLLENBQUM7WUFDUixJQUFJLEVBQUUsb0JBQW9CO1lBQzFCLE9BQU8sRUFBRTtnQkFDUDtvQkFDRSxJQUFJLEVBQUUsSUFBSTtvQkFDVixJQUFJLEVBQUUsTUFBTTtvQkFDWixTQUFTLEVBQUUsSUFBSTtvQkFDZixrQkFBa0IsRUFBRSxNQUFNO29CQUMxQixPQUFPLEVBQUUsb0JBQW9CO2lCQUM5QjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsaUJBQWlCO29CQUN2QixJQUFJLEVBQUUsTUFBTTtvQkFDWixVQUFVLEVBQUUsSUFBSTtpQkFDakI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsTUFBTSxFQUFFLEtBQUs7b0JBQ2IsVUFBVSxFQUFFLEtBQUs7aUJBQ2xCO2dCQUNEO29CQUNFLElBQUksRUFBRSxlQUFlO29CQUNyQixJQUFJLEVBQUUsU0FBUztvQkFDZixNQUFNLEVBQUUsSUFBSTtvQkFDWixVQUFVLEVBQUUsS0FBSztpQkFDbEI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLFVBQVU7b0JBQ2hCLElBQUksRUFBRSxTQUFTO29CQUNmLE1BQU0sRUFBRSxLQUFLO29CQUNiLFVBQVUsRUFBRSxLQUFLO2lCQUNsQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsV0FBVztvQkFDakIsSUFBSSxFQUFFLEtBQUs7b0JBQ1gsVUFBVSxFQUFFLElBQUk7aUJBQ2pCO2dCQUNEO29CQUNFLElBQUksRUFBRSxXQUFXO29CQUNqQixJQUFJLEVBQUUsU0FBUztvQkFDZixNQUFNLEVBQUUsS0FBSztvQkFDYixVQUFVLEVBQUUsSUFBSTtpQkFDakI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLFVBQVU7b0JBQ2hCLElBQUksRUFBRSxPQUFPO29CQUNiLFVBQVUsRUFBRSxJQUFJO29CQUNoQixPQUFPLEVBQUUsTUFBTTtpQkFDaEI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLFlBQVk7b0JBQ2xCLElBQUksRUFBRSxXQUFXO29CQUNqQixPQUFPLEVBQUUsT0FBTztpQkFDakI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLFlBQVk7b0JBQ2xCLElBQUksRUFBRSxXQUFXO29CQUNqQixPQUFPLEVBQUUsT0FBTztpQkFDakI7YUFDRjtTQUNGLENBQUMsRUFDRixJQUFJLENBQ0wsQ0FBQTtRQUVELGtCQUFrQjtRQUNsQixNQUFNLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FDaEMsb0JBQW9CLEVBQ3BCLElBQUkseUJBQWUsQ0FBQztZQUNsQixXQUFXLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQztZQUNoQyxxQkFBcUIsRUFBRSxDQUFDLElBQUksQ0FBQztZQUM3QixtQkFBbUIsRUFBRSxjQUFjO1lBQ25DLFFBQVEsRUFBRSxTQUFTO1NBQ3BCLENBQUMsQ0FDSCxDQUFBO1FBRUQsaUJBQWlCO1FBQ2pCLE1BQU0sV0FBVyxDQUFDLFdBQVcsQ0FDM0Isb0JBQW9CLEVBQ3BCLElBQUksb0JBQVUsQ0FBQztZQUNiLElBQUksRUFBRSx3Q0FBd0M7WUFDOUMsV0FBVyxFQUFFLENBQUMsaUJBQWlCLENBQUM7U0FDakMsQ0FBQyxDQUNILENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxXQUFXLENBQzNCLG9CQUFvQixFQUNwQixJQUFJLG9CQUFVLENBQUM7WUFDYixJQUFJLEVBQUUsNkJBQTZCO1lBQ25DLFdBQVcsRUFBRSxDQUFDLGVBQWUsQ0FBQztTQUMvQixDQUFDLENBQ0gsQ0FBQTtRQUVELHNEQUFzRDtRQUN0RCxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQ3JCLDZGQUE2RixDQUM5RixDQUFBO0lBQ0gsQ0FBQztJQUVNLEtBQUssQ0FBQyxJQUFJLENBQUMsV0FBd0I7UUFDeEMsTUFBTSxXQUFXLENBQUMsU0FBUyxDQUFDLG9CQUFvQixDQUFDLENBQUE7SUFDbkQsQ0FBQztDQUNGO0FBekdELDhGQXlHQyJ9