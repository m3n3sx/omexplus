"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddB2bProductFields1733150500000 = void 0;
const typeorm_1 = require("typeorm");
class AddB2bProductFields1733150500000 {
    async up(queryRunner) {
        // Add B2B specific fields
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "b2b_min_quantity",
            type: "int",
            isNullable: true,
            default: 1,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "b2b_pricing_tiers",
            type: "jsonb",
            isNullable: true,
            default: "'[]'",
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "b2b_discount_percentage",
            type: "decimal",
            precision: 5,
            scale: 2,
            isNullable: true,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "b2b_lead_time_days",
            type: "int",
            isNullable: true,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "b2b_bulk_discount_available",
            type: "boolean",
            default: false,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "requires_quote",
            type: "boolean",
            default: false,
        }));
        // Add supplier and stock fields
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "supplier_ids",
            type: "jsonb",
            isNullable: true,
            default: "'[]'",
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "stock_level",
            type: "int",
            default: 0,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "stock_reserved",
            type: "int",
            default: 0,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "stock_available",
            type: "int",
            default: 0,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "stock_warehouse_locations",
            type: "jsonb",
            isNullable: true,
            default: "'[]'",
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "reorder_point",
            type: "int",
            isNullable: true,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "supplier_lead_time",
            type: "int",
            isNullable: true,
        }));
        // Create indexes
        await queryRunner.query(`CREATE INDEX "IDX_product_requires_quote" ON "product" ("requires_quote") WHERE requires_quote = true`);
        await queryRunner.query(`CREATE INDEX "IDX_product_stock_level" ON "product" ("stock_level")`);
        await queryRunner.query(`CREATE INDEX "IDX_product_stock_available" ON "product" ("stock_available")`);
    }
    async down(queryRunner) {
        await queryRunner.query(`DROP INDEX "IDX_product_stock_available"`);
        await queryRunner.query(`DROP INDEX "IDX_product_stock_level"`);
        await queryRunner.query(`DROP INDEX "IDX_product_requires_quote"`);
        await queryRunner.dropColumn("product", "supplier_lead_time");
        await queryRunner.dropColumn("product", "reorder_point");
        await queryRunner.dropColumn("product", "stock_warehouse_locations");
        await queryRunner.dropColumn("product", "stock_available");
        await queryRunner.dropColumn("product", "stock_reserved");
        await queryRunner.dropColumn("product", "stock_level");
        await queryRunner.dropColumn("product", "supplier_ids");
        await queryRunner.dropColumn("product", "requires_quote");
        await queryRunner.dropColumn("product", "b2b_bulk_discount_available");
        await queryRunner.dropColumn("product", "b2b_lead_time_days");
        await queryRunner.dropColumn("product", "b2b_discount_percentage");
        await queryRunner.dropColumn("product", "b2b_pricing_tiers");
        await queryRunner.dropColumn("product", "b2b_min_quantity");
    }
}
exports.AddB2bProductFields1733150500000 = AddB2bProductFields1733150500000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTczMzE1MDUwMDAwMC1hZGQtYjJiLXByb2R1Y3QtZmllbGRzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL21pZ3JhdGlvbnMvMTczMzE1MDUwMDAwMC1hZGQtYjJiLXByb2R1Y3QtZmllbGRzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFDQUFzRTtBQUV0RSxNQUFhLGdDQUFnQztJQUNwQyxLQUFLLENBQUMsRUFBRSxDQUFDLFdBQXdCO1FBQ3RDLDBCQUEwQjtRQUMxQixNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsa0JBQWtCO1lBQ3hCLElBQUksRUFBRSxLQUFLO1lBQ1gsVUFBVSxFQUFFLElBQUk7WUFDaEIsT0FBTyxFQUFFLENBQUM7U0FDWCxDQUFDLENBQ0gsQ0FBQTtRQUVELE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FDekIsU0FBUyxFQUNULElBQUkscUJBQVcsQ0FBQztZQUNkLElBQUksRUFBRSxtQkFBbUI7WUFDekIsSUFBSSxFQUFFLE9BQU87WUFDYixVQUFVLEVBQUUsSUFBSTtZQUNoQixPQUFPLEVBQUUsTUFBTTtTQUNoQixDQUFDLENBQ0gsQ0FBQTtRQUVELE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FDekIsU0FBUyxFQUNULElBQUkscUJBQVcsQ0FBQztZQUNkLElBQUksRUFBRSx5QkFBeUI7WUFDL0IsSUFBSSxFQUFFLFNBQVM7WUFDZixTQUFTLEVBQUUsQ0FBQztZQUNaLEtBQUssRUFBRSxDQUFDO1lBQ1IsVUFBVSxFQUFFLElBQUk7U0FDakIsQ0FBQyxDQUNILENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsb0JBQW9CO1lBQzFCLElBQUksRUFBRSxLQUFLO1lBQ1gsVUFBVSxFQUFFLElBQUk7U0FDakIsQ0FBQyxDQUNILENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsNkJBQTZCO1lBQ25DLElBQUksRUFBRSxTQUFTO1lBQ2YsT0FBTyxFQUFFLEtBQUs7U0FDZixDQUFDLENBQ0gsQ0FBQTtRQUVELE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FDekIsU0FBUyxFQUNULElBQUkscUJBQVcsQ0FBQztZQUNkLElBQUksRUFBRSxnQkFBZ0I7WUFDdEIsSUFBSSxFQUFFLFNBQVM7WUFDZixPQUFPLEVBQUUsS0FBSztTQUNmLENBQUMsQ0FDSCxDQUFBO1FBRUQsZ0NBQWdDO1FBQ2hDLE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FDekIsU0FBUyxFQUNULElBQUkscUJBQVcsQ0FBQztZQUNkLElBQUksRUFBRSxjQUFjO1lBQ3BCLElBQUksRUFBRSxPQUFPO1lBQ2IsVUFBVSxFQUFFLElBQUk7WUFDaEIsT0FBTyxFQUFFLE1BQU07U0FDaEIsQ0FBQyxDQUNILENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsYUFBYTtZQUNuQixJQUFJLEVBQUUsS0FBSztZQUNYLE9BQU8sRUFBRSxDQUFDO1NBQ1gsQ0FBQyxDQUNILENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsZ0JBQWdCO1lBQ3RCLElBQUksRUFBRSxLQUFLO1lBQ1gsT0FBTyxFQUFFLENBQUM7U0FDWCxDQUFDLENBQ0gsQ0FBQTtRQUVELE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FDekIsU0FBUyxFQUNULElBQUkscUJBQVcsQ0FBQztZQUNkLElBQUksRUFBRSxpQkFBaUI7WUFDdkIsSUFBSSxFQUFFLEtBQUs7WUFDWCxPQUFPLEVBQUUsQ0FBQztTQUNYLENBQUMsQ0FDSCxDQUFBO1FBRUQsTUFBTSxXQUFXLENBQUMsU0FBUyxDQUN6QixTQUFTLEVBQ1QsSUFBSSxxQkFBVyxDQUFDO1lBQ2QsSUFBSSxFQUFFLDJCQUEyQjtZQUNqQyxJQUFJLEVBQUUsT0FBTztZQUNiLFVBQVUsRUFBRSxJQUFJO1lBQ2hCLE9BQU8sRUFBRSxNQUFNO1NBQ2hCLENBQUMsQ0FDSCxDQUFBO1FBRUQsTUFBTSxXQUFXLENBQUMsU0FBUyxDQUN6QixTQUFTLEVBQ1QsSUFBSSxxQkFBVyxDQUFDO1lBQ2QsSUFBSSxFQUFFLGVBQWU7WUFDckIsSUFBSSxFQUFFLEtBQUs7WUFDWCxVQUFVLEVBQUUsSUFBSTtTQUNqQixDQUFDLENBQ0gsQ0FBQTtRQUVELE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FDekIsU0FBUyxFQUNULElBQUkscUJBQVcsQ0FBQztZQUNkLElBQUksRUFBRSxvQkFBb0I7WUFDMUIsSUFBSSxFQUFFLEtBQUs7WUFDWCxVQUFVLEVBQUUsSUFBSTtTQUNqQixDQUFDLENBQ0gsQ0FBQTtRQUVELGlCQUFpQjtRQUNqQixNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQ3JCLHVHQUF1RyxDQUN4RyxDQUFBO1FBRUQsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUNyQixxRUFBcUUsQ0FDdEUsQ0FBQTtRQUVELE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FDckIsNkVBQTZFLENBQzlFLENBQUE7SUFDSCxDQUFDO0lBRU0sS0FBSyxDQUFDLElBQUksQ0FBQyxXQUF3QjtRQUN4QyxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsMENBQTBDLENBQUMsQ0FBQTtRQUNuRSxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsc0NBQXNDLENBQUMsQ0FBQTtRQUMvRCxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMseUNBQXlDLENBQUMsQ0FBQTtRQUVsRSxNQUFNLFdBQVcsQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLG9CQUFvQixDQUFDLENBQUE7UUFDN0QsTUFBTSxXQUFXLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxlQUFlLENBQUMsQ0FBQTtRQUN4RCxNQUFNLFdBQVcsQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLDJCQUEyQixDQUFDLENBQUE7UUFDcEUsTUFBTSxXQUFXLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxpQkFBaUIsQ0FBQyxDQUFBO1FBQzFELE1BQU0sV0FBVyxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQTtRQUN6RCxNQUFNLFdBQVcsQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLGFBQWEsQ0FBQyxDQUFBO1FBQ3RELE1BQU0sV0FBVyxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsY0FBYyxDQUFDLENBQUE7UUFDdkQsTUFBTSxXQUFXLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFBO1FBQ3pELE1BQU0sV0FBVyxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsNkJBQTZCLENBQUMsQ0FBQTtRQUN0RSxNQUFNLFdBQVcsQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLG9CQUFvQixDQUFDLENBQUE7UUFDN0QsTUFBTSxXQUFXLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSx5QkFBeUIsQ0FBQyxDQUFBO1FBQ2xFLE1BQU0sV0FBVyxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsbUJBQW1CLENBQUMsQ0FBQTtRQUM1RCxNQUFNLFdBQVcsQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLGtCQUFrQixDQUFDLENBQUE7SUFDN0QsQ0FBQztDQUNGO0FBaEtELDRFQWdLQyJ9