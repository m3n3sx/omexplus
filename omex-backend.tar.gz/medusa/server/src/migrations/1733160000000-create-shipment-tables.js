"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateShipmentTables1733160000000 = void 0;
const typeorm_1 = require("typeorm");
class CreateShipmentTables1733160000000 {
    async up(queryRunner) {
        // Create shipment table
        await queryRunner.createTable(new typeorm_1.Table({
            name: "shipment",
            columns: [
                {
                    name: "id",
                    type: "uuid",
                    isPrimary: true,
                    generationStrategy: "uuid",
                    default: "uuid_generate_v4()",
                },
                {
                    name: "order_id",
                    type: "uuid",
                    isNullable: false,
                },
                {
                    name: "provider",
                    type: "varchar",
                    length: "50",
                    isNullable: false,
                },
                {
                    name: "shipping_method",
                    type: "varchar",
                    length: "100",
                    isNullable: true,
                },
                {
                    name: "tracking_number",
                    type: "varchar",
                    length: "255",
                    isNullable: true,
                    isUnique: true,
                },
                {
                    name: "label_url",
                    type: "varchar",
                    length: "500",
                    isNullable: true,
                },
                {
                    name: "price",
                    type: "decimal",
                    precision: 10,
                    scale: 2,
                    isNullable: true,
                },
                {
                    name: "status",
                    type: "varchar",
                    length: "50",
                    default: "'pending'",
                },
                {
                    name: "metadata",
                    type: "jsonb",
                    isNullable: true,
                },
                {
                    name: "created_at",
                    type: "timestamp",
                    default: "now()",
                },
                {
                    name: "updated_at",
                    type: "timestamp",
                    default: "now()",
                },
            ],
        }), true);
        // Create tracking_event table
        await queryRunner.createTable(new typeorm_1.Table({
            name: "tracking_event",
            columns: [
                {
                    name: "id",
                    type: "uuid",
                    isPrimary: true,
                    generationStrategy: "uuid",
                    default: "uuid_generate_v4()",
                },
                {
                    name: "shipment_id",
                    type: "uuid",
                    isNullable: false,
                },
                {
                    name: "status",
                    type: "varchar",
                    length: "50",
                    isNullable: false,
                },
                {
                    name: "location",
                    type: "varchar",
                    length: "255",
                    isNullable: true,
                },
                {
                    name: "timestamp",
                    type: "timestamp",
                    isNullable: false,
                },
                {
                    name: "description",
                    type: "text",
                    isNullable: true,
                },
                {
                    name: "created_at",
                    type: "timestamp",
                    default: "now()",
                },
            ],
        }), true);
        // Add foreign key for shipment.order_id
        await queryRunner.createForeignKey("shipment", new typeorm_1.TableForeignKey({
            columnNames: ["order_id"],
            referencedColumnNames: ["id"],
            referencedTableName: "order",
            onDelete: "CASCADE",
        }));
        // Add foreign key for tracking_event.shipment_id
        await queryRunner.createForeignKey("tracking_event", new typeorm_1.TableForeignKey({
            columnNames: ["shipment_id"],
            referencedColumnNames: ["id"],
            referencedTableName: "shipment",
            onDelete: "CASCADE",
        }));
        // Create indexes
        await queryRunner.query(`CREATE INDEX idx_shipment_order_id ON shipment(order_id)`);
        await queryRunner.query(`CREATE INDEX idx_shipment_tracking_number ON shipment(tracking_number)`);
        await queryRunner.query(`CREATE INDEX idx_shipment_status ON shipment(status)`);
        await queryRunner.query(`CREATE INDEX idx_tracking_event_shipment_id ON tracking_event(shipment_id)`);
    }
    async down(queryRunner) {
        // Drop foreign keys
        const shipmentTable = await queryRunner.getTable("shipment");
        const trackingEventTable = await queryRunner.getTable("tracking_event");
        if (trackingEventTable) {
            const foreignKey = trackingEventTable.foreignKeys.find((fk) => fk.columnNames.indexOf("shipment_id") !== -1);
            if (foreignKey) {
                await queryRunner.dropForeignKey("tracking_event", foreignKey);
            }
        }
        if (shipmentTable) {
            const foreignKey = shipmentTable.foreignKeys.find((fk) => fk.columnNames.indexOf("order_id") !== -1);
            if (foreignKey) {
                await queryRunner.dropForeignKey("shipment", foreignKey);
            }
        }
        // Drop tables
        await queryRunner.dropTable("tracking_event", true);
        await queryRunner.dropTable("shipment", true);
    }
}
exports.CreateShipmentTables1733160000000 = CreateShipmentTables1733160000000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTczMzE2MDAwMDAwMC1jcmVhdGUtc2hpcG1lbnQtdGFibGVzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL21pZ3JhdGlvbnMvMTczMzE2MDAwMDAwMC1jcmVhdGUtc2hpcG1lbnQtdGFibGVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFDQUFrRjtBQUVsRixNQUFhLGlDQUFpQztJQUNyQyxLQUFLLENBQUMsRUFBRSxDQUFDLFdBQXdCO1FBQ3RDLHdCQUF3QjtRQUN4QixNQUFNLFdBQVcsQ0FBQyxXQUFXLENBQzNCLElBQUksZUFBSyxDQUFDO1lBQ1IsSUFBSSxFQUFFLFVBQVU7WUFDaEIsT0FBTyxFQUFFO2dCQUNQO29CQUNFLElBQUksRUFBRSxJQUFJO29CQUNWLElBQUksRUFBRSxNQUFNO29CQUNaLFNBQVMsRUFBRSxJQUFJO29CQUNmLGtCQUFrQixFQUFFLE1BQU07b0JBQzFCLE9BQU8sRUFBRSxvQkFBb0I7aUJBQzlCO2dCQUNEO29CQUNFLElBQUksRUFBRSxVQUFVO29CQUNoQixJQUFJLEVBQUUsTUFBTTtvQkFDWixVQUFVLEVBQUUsS0FBSztpQkFDbEI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLFVBQVU7b0JBQ2hCLElBQUksRUFBRSxTQUFTO29CQUNmLE1BQU0sRUFBRSxJQUFJO29CQUNaLFVBQVUsRUFBRSxLQUFLO2lCQUNsQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsaUJBQWlCO29CQUN2QixJQUFJLEVBQUUsU0FBUztvQkFDZixNQUFNLEVBQUUsS0FBSztvQkFDYixVQUFVLEVBQUUsSUFBSTtpQkFDakI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLGlCQUFpQjtvQkFDdkIsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsTUFBTSxFQUFFLEtBQUs7b0JBQ2IsVUFBVSxFQUFFLElBQUk7b0JBQ2hCLFFBQVEsRUFBRSxJQUFJO2lCQUNmO2dCQUNEO29CQUNFLElBQUksRUFBRSxXQUFXO29CQUNqQixJQUFJLEVBQUUsU0FBUztvQkFDZixNQUFNLEVBQUUsS0FBSztvQkFDYixVQUFVLEVBQUUsSUFBSTtpQkFDakI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsU0FBUyxFQUFFLEVBQUU7b0JBQ2IsS0FBSyxFQUFFLENBQUM7b0JBQ1IsVUFBVSxFQUFFLElBQUk7aUJBQ2pCO2dCQUNEO29CQUNFLElBQUksRUFBRSxRQUFRO29CQUNkLElBQUksRUFBRSxTQUFTO29CQUNmLE1BQU0sRUFBRSxJQUFJO29CQUNaLE9BQU8sRUFBRSxXQUFXO2lCQUNyQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsVUFBVTtvQkFDaEIsSUFBSSxFQUFFLE9BQU87b0JBQ2IsVUFBVSxFQUFFLElBQUk7aUJBQ2pCO2dCQUNEO29CQUNFLElBQUksRUFBRSxZQUFZO29CQUNsQixJQUFJLEVBQUUsV0FBVztvQkFDakIsT0FBTyxFQUFFLE9BQU87aUJBQ2pCO2dCQUNEO29CQUNFLElBQUksRUFBRSxZQUFZO29CQUNsQixJQUFJLEVBQUUsV0FBVztvQkFDakIsT0FBTyxFQUFFLE9BQU87aUJBQ2pCO2FBQ0Y7U0FDRixDQUFDLEVBQ0YsSUFBSSxDQUNMLENBQUM7UUFFRiw4QkFBOEI7UUFDOUIsTUFBTSxXQUFXLENBQUMsV0FBVyxDQUMzQixJQUFJLGVBQUssQ0FBQztZQUNSLElBQUksRUFBRSxnQkFBZ0I7WUFDdEIsT0FBTyxFQUFFO2dCQUNQO29CQUNFLElBQUksRUFBRSxJQUFJO29CQUNWLElBQUksRUFBRSxNQUFNO29CQUNaLFNBQVMsRUFBRSxJQUFJO29CQUNmLGtCQUFrQixFQUFFLE1BQU07b0JBQzFCLE9BQU8sRUFBRSxvQkFBb0I7aUJBQzlCO2dCQUNEO29CQUNFLElBQUksRUFBRSxhQUFhO29CQUNuQixJQUFJLEVBQUUsTUFBTTtvQkFDWixVQUFVLEVBQUUsS0FBSztpQkFDbEI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLFFBQVE7b0JBQ2QsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsTUFBTSxFQUFFLElBQUk7b0JBQ1osVUFBVSxFQUFFLEtBQUs7aUJBQ2xCO2dCQUNEO29CQUNFLElBQUksRUFBRSxVQUFVO29CQUNoQixJQUFJLEVBQUUsU0FBUztvQkFDZixNQUFNLEVBQUUsS0FBSztvQkFDYixVQUFVLEVBQUUsSUFBSTtpQkFDakI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLFdBQVc7b0JBQ2pCLElBQUksRUFBRSxXQUFXO29CQUNqQixVQUFVLEVBQUUsS0FBSztpQkFDbEI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLGFBQWE7b0JBQ25CLElBQUksRUFBRSxNQUFNO29CQUNaLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsWUFBWTtvQkFDbEIsSUFBSSxFQUFFLFdBQVc7b0JBQ2pCLE9BQU8sRUFBRSxPQUFPO2lCQUNqQjthQUNGO1NBQ0YsQ0FBQyxFQUNGLElBQUksQ0FDTCxDQUFDO1FBRUYsd0NBQXdDO1FBQ3hDLE1BQU0sV0FBVyxDQUFDLGdCQUFnQixDQUNoQyxVQUFVLEVBQ1YsSUFBSSx5QkFBZSxDQUFDO1lBQ2xCLFdBQVcsRUFBRSxDQUFDLFVBQVUsQ0FBQztZQUN6QixxQkFBcUIsRUFBRSxDQUFDLElBQUksQ0FBQztZQUM3QixtQkFBbUIsRUFBRSxPQUFPO1lBQzVCLFFBQVEsRUFBRSxTQUFTO1NBQ3BCLENBQUMsQ0FDSCxDQUFDO1FBRUYsaURBQWlEO1FBQ2pELE1BQU0sV0FBVyxDQUFDLGdCQUFnQixDQUNoQyxnQkFBZ0IsRUFDaEIsSUFBSSx5QkFBZSxDQUFDO1lBQ2xCLFdBQVcsRUFBRSxDQUFDLGFBQWEsQ0FBQztZQUM1QixxQkFBcUIsRUFBRSxDQUFDLElBQUksQ0FBQztZQUM3QixtQkFBbUIsRUFBRSxVQUFVO1lBQy9CLFFBQVEsRUFBRSxTQUFTO1NBQ3BCLENBQUMsQ0FDSCxDQUFDO1FBRUYsaUJBQWlCO1FBQ2pCLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQywwREFBMEQsQ0FBQyxDQUFDO1FBQ3BGLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQyx3RUFBd0UsQ0FBQyxDQUFDO1FBQ2xHLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQyxzREFBc0QsQ0FBQyxDQUFDO1FBQ2hGLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQyw0RUFBNEUsQ0FBQyxDQUFDO0lBQ3hHLENBQUM7SUFFTSxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQXdCO1FBQ3hDLG9CQUFvQjtRQUNwQixNQUFNLGFBQWEsR0FBRyxNQUFNLFdBQVcsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDN0QsTUFBTSxrQkFBa0IsR0FBRyxNQUFNLFdBQVcsQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUV4RSxJQUFJLGtCQUFrQixFQUFFLENBQUM7WUFDdkIsTUFBTSxVQUFVLEdBQUcsa0JBQWtCLENBQUMsV0FBVyxDQUFDLElBQUksQ0FDcEQsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUNyRCxDQUFDO1lBQ0YsSUFBSSxVQUFVLEVBQUUsQ0FBQztnQkFDZixNQUFNLFdBQVcsQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLEVBQUUsVUFBVSxDQUFDLENBQUM7WUFDakUsQ0FBQztRQUNILENBQUM7UUFFRCxJQUFJLGFBQWEsRUFBRSxDQUFDO1lBQ2xCLE1BQU0sVUFBVSxHQUFHLGFBQWEsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUMvQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQ2xELENBQUM7WUFDRixJQUFJLFVBQVUsRUFBRSxDQUFDO2dCQUNmLE1BQU0sV0FBVyxDQUFDLGNBQWMsQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUM7WUFDM0QsQ0FBQztRQUNILENBQUM7UUFFRCxjQUFjO1FBQ2QsTUFBTSxXQUFXLENBQUMsU0FBUyxDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3BELE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDaEQsQ0FBQztDQUNGO0FBdExELDhFQXNMQyJ9