"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateImportHistoryTable1733150900000 = void 0;
class CreateImportHistoryTable1733150900000 {
    constructor() {
        this.name = 'CreateImportHistoryTable1733150900000';
    }
    async up(queryRunner) {
        // Create import_history table
        await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS "import_history" (
        "id" VARCHAR PRIMARY KEY,
        "filename" VARCHAR NOT NULL,
        "user_id" VARCHAR,
        "status" VARCHAR NOT NULL CHECK (status IN ('processing', 'completed', 'failed')),
        "total_rows" INTEGER NOT NULL DEFAULT 0,
        "successful_rows" INTEGER NOT NULL DEFAULT 0,
        "failed_rows" INTEGER NOT NULL DEFAULT 0,
        "error_report" TEXT,
        "duration_ms" INTEGER,
        "started_at" TIMESTAMP NOT NULL DEFAULT NOW(),
        "completed_at" TIMESTAMP,
        "created_at" TIMESTAMP NOT NULL DEFAULT NOW(),
        "updated_at" TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `);
        // Create indexes
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_import_history_user_id" 
      ON "import_history" ("user_id")
    `);
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_import_history_status" 
      ON "import_history" ("status")
    `);
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_import_history_created_at" 
      ON "import_history" ("created_at" DESC)
    `);
        // Create import_errors table for detailed error tracking
        await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS "import_error" (
        "id" VARCHAR PRIMARY KEY,
        "import_history_id" VARCHAR NOT NULL,
        "line_number" INTEGER NOT NULL,
        "field_name" VARCHAR NOT NULL,
        "error_reason" TEXT NOT NULL,
        "field_value" TEXT,
        "created_at" TIMESTAMP NOT NULL DEFAULT NOW(),
        FOREIGN KEY ("import_history_id") REFERENCES "import_history" ("id") ON DELETE CASCADE
      )
    `);
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_import_error_history_id" 
      ON "import_error" ("import_history_id")
    `);
    }
    async down(queryRunner) {
        await queryRunner.query(`DROP INDEX IF EXISTS "idx_import_error_history_id"`);
        await queryRunner.query(`DROP TABLE IF EXISTS "import_error"`);
        await queryRunner.query(`DROP INDEX IF EXISTS "idx_import_history_created_at"`);
        await queryRunner.query(`DROP INDEX IF EXISTS "idx_import_history_status"`);
        await queryRunner.query(`DROP INDEX IF EXISTS "idx_import_history_user_id"`);
        await queryRunner.query(`DROP TABLE IF EXISTS "import_history"`);
    }
}
exports.CreateImportHistoryTable1733150900000 = CreateImportHistoryTable1733150900000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTczMzE1MDkwMDAwMC1jcmVhdGUtaW1wb3J0LWhpc3RvcnktdGFibGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvbWlncmF0aW9ucy8xNzMzMTUwOTAwMDAwLWNyZWF0ZS1pbXBvcnQtaGlzdG9yeS10YWJsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFFQSxNQUFhLHFDQUFxQztJQUFsRDtRQUNFLFNBQUksR0FBRyx1Q0FBdUMsQ0FBQTtJQW1FaEQsQ0FBQztJQWpFUSxLQUFLLENBQUMsRUFBRSxDQUFDLFdBQXdCO1FBQ3RDLDhCQUE4QjtRQUM5QixNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7S0FnQnZCLENBQUMsQ0FBQTtRQUVGLGlCQUFpQjtRQUNqQixNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUM7OztLQUd2QixDQUFDLENBQUE7UUFFRixNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUM7OztLQUd2QixDQUFDLENBQUE7UUFFRixNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUM7OztLQUd2QixDQUFDLENBQUE7UUFFRix5REFBeUQ7UUFDekQsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDOzs7Ozs7Ozs7OztLQVd2QixDQUFDLENBQUE7UUFFRixNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUM7OztLQUd2QixDQUFDLENBQUE7SUFDSixDQUFDO0lBRU0sS0FBSyxDQUFDLElBQUksQ0FBQyxXQUF3QjtRQUN4QyxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsb0RBQW9ELENBQUMsQ0FBQTtRQUM3RSxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMscUNBQXFDLENBQUMsQ0FBQTtRQUU5RCxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsc0RBQXNELENBQUMsQ0FBQTtRQUMvRSxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsa0RBQWtELENBQUMsQ0FBQTtRQUMzRSxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsbURBQW1ELENBQUMsQ0FBQTtRQUM1RSxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsdUNBQXVDLENBQUMsQ0FBQTtJQUNsRSxDQUFDO0NBQ0Y7QUFwRUQsc0ZBb0VDIn0=