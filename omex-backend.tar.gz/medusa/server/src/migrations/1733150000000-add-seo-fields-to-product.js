"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddSeoFieldsToProduct1733150000000 = void 0;
const typeorm_1 = require("typeorm");
class AddSeoFieldsToProduct1733150000000 {
    async up(queryRunner) {
        // Add SEO fields to product table
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "meta_title",
            type: "varchar",
            length: "60",
            isNullable: true,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "meta_description",
            type: "varchar",
            length: "160",
            isNullable: true,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "meta_keywords",
            type: "jsonb",
            isNullable: true,
            default: "'[]'",
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "slug",
            type: "varchar",
            length: "255",
            isNullable: true,
            isUnique: true,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "canonical_url",
            type: "varchar",
            length: "500",
            isNullable: true,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "og_title",
            type: "varchar",
            length: "60",
            isNullable: true,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "og_description",
            type: "varchar",
            length: "160",
            isNullable: true,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "og_image",
            type: "varchar",
            length: "500",
            isNullable: true,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "schema_type",
            type: "varchar",
            length: "50",
            isNullable: true,
            default: "'Product'",
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "structured_data",
            type: "jsonb",
            isNullable: true,
        }));
        // Create index on slug for fast lookups
        await queryRunner.query(`CREATE INDEX "IDX_product_slug" ON "product" ("slug")`);
    }
    async down(queryRunner) {
        await queryRunner.query(`DROP INDEX "IDX_product_slug"`);
        await queryRunner.dropColumn("product", "structured_data");
        await queryRunner.dropColumn("product", "schema_type");
        await queryRunner.dropColumn("product", "og_image");
        await queryRunner.dropColumn("product", "og_description");
        await queryRunner.dropColumn("product", "og_title");
        await queryRunner.dropColumn("product", "canonical_url");
        await queryRunner.dropColumn("product", "slug");
        await queryRunner.dropColumn("product", "meta_keywords");
        await queryRunner.dropColumn("product", "meta_description");
        await queryRunner.dropColumn("product", "meta_title");
    }
}
exports.AddSeoFieldsToProduct1733150000000 = AddSeoFieldsToProduct1733150000000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTczMzE1MDAwMDAwMC1hZGQtc2VvLWZpZWxkcy10by1wcm9kdWN0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL21pZ3JhdGlvbnMvMTczMzE1MDAwMDAwMC1hZGQtc2VvLWZpZWxkcy10by1wcm9kdWN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFDQUFzRTtBQUV0RSxNQUFhLGtDQUFrQztJQUN0QyxLQUFLLENBQUMsRUFBRSxDQUFDLFdBQXdCO1FBQ3RDLGtDQUFrQztRQUNsQyxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsWUFBWTtZQUNsQixJQUFJLEVBQUUsU0FBUztZQUNmLE1BQU0sRUFBRSxJQUFJO1lBQ1osVUFBVSxFQUFFLElBQUk7U0FDakIsQ0FBQyxDQUNILENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsa0JBQWtCO1lBQ3hCLElBQUksRUFBRSxTQUFTO1lBQ2YsTUFBTSxFQUFFLEtBQUs7WUFDYixVQUFVLEVBQUUsSUFBSTtTQUNqQixDQUFDLENBQ0gsQ0FBQTtRQUVELE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FDekIsU0FBUyxFQUNULElBQUkscUJBQVcsQ0FBQztZQUNkLElBQUksRUFBRSxlQUFlO1lBQ3JCLElBQUksRUFBRSxPQUFPO1lBQ2IsVUFBVSxFQUFFLElBQUk7WUFDaEIsT0FBTyxFQUFFLE1BQU07U0FDaEIsQ0FBQyxDQUNILENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsTUFBTTtZQUNaLElBQUksRUFBRSxTQUFTO1lBQ2YsTUFBTSxFQUFFLEtBQUs7WUFDYixVQUFVLEVBQUUsSUFBSTtZQUNoQixRQUFRLEVBQUUsSUFBSTtTQUNmLENBQUMsQ0FDSCxDQUFBO1FBRUQsTUFBTSxXQUFXLENBQUMsU0FBUyxDQUN6QixTQUFTLEVBQ1QsSUFBSSxxQkFBVyxDQUFDO1lBQ2QsSUFBSSxFQUFFLGVBQWU7WUFDckIsSUFBSSxFQUFFLFNBQVM7WUFDZixNQUFNLEVBQUUsS0FBSztZQUNiLFVBQVUsRUFBRSxJQUFJO1NBQ2pCLENBQUMsQ0FDSCxDQUFBO1FBRUQsTUFBTSxXQUFXLENBQUMsU0FBUyxDQUN6QixTQUFTLEVBQ1QsSUFBSSxxQkFBVyxDQUFDO1lBQ2QsSUFBSSxFQUFFLFVBQVU7WUFDaEIsSUFBSSxFQUFFLFNBQVM7WUFDZixNQUFNLEVBQUUsSUFBSTtZQUNaLFVBQVUsRUFBRSxJQUFJO1NBQ2pCLENBQUMsQ0FDSCxDQUFBO1FBRUQsTUFBTSxXQUFXLENBQUMsU0FBUyxDQUN6QixTQUFTLEVBQ1QsSUFBSSxxQkFBVyxDQUFDO1lBQ2QsSUFBSSxFQUFFLGdCQUFnQjtZQUN0QixJQUFJLEVBQUUsU0FBUztZQUNmLE1BQU0sRUFBRSxLQUFLO1lBQ2IsVUFBVSxFQUFFLElBQUk7U0FDakIsQ0FBQyxDQUNILENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsVUFBVTtZQUNoQixJQUFJLEVBQUUsU0FBUztZQUNmLE1BQU0sRUFBRSxLQUFLO1lBQ2IsVUFBVSxFQUFFLElBQUk7U0FDakIsQ0FBQyxDQUNILENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsYUFBYTtZQUNuQixJQUFJLEVBQUUsU0FBUztZQUNmLE1BQU0sRUFBRSxJQUFJO1lBQ1osVUFBVSxFQUFFLElBQUk7WUFDaEIsT0FBTyxFQUFFLFdBQVc7U0FDckIsQ0FBQyxDQUNILENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsaUJBQWlCO1lBQ3ZCLElBQUksRUFBRSxPQUFPO1lBQ2IsVUFBVSxFQUFFLElBQUk7U0FDakIsQ0FBQyxDQUNILENBQUE7UUFFRCx3Q0FBd0M7UUFDeEMsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUNyQix1REFBdUQsQ0FDeEQsQ0FBQTtJQUNILENBQUM7SUFFTSxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQXdCO1FBQ3hDLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQywrQkFBK0IsQ0FBQyxDQUFBO1FBQ3hELE1BQU0sV0FBVyxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsaUJBQWlCLENBQUMsQ0FBQTtRQUMxRCxNQUFNLFdBQVcsQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLGFBQWEsQ0FBQyxDQUFBO1FBQ3RELE1BQU0sV0FBVyxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsVUFBVSxDQUFDLENBQUE7UUFDbkQsTUFBTSxXQUFXLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFBO1FBQ3pELE1BQU0sV0FBVyxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsVUFBVSxDQUFDLENBQUE7UUFDbkQsTUFBTSxXQUFXLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxlQUFlLENBQUMsQ0FBQTtRQUN4RCxNQUFNLFdBQVcsQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxDQUFBO1FBQy9DLE1BQU0sV0FBVyxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsZUFBZSxDQUFDLENBQUE7UUFDeEQsTUFBTSxXQUFXLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxrQkFBa0IsQ0FBQyxDQUFBO1FBQzNELE1BQU0sV0FBVyxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUE7SUFDdkQsQ0FBQztDQUNGO0FBM0hELGdGQTJIQyJ9