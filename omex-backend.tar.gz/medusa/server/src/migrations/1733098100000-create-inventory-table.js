"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateInventoryTable1733098100000 = void 0;
class CreateInventoryTable1733098100000 {
    constructor() {
        this.name = 'CreateInventoryTable1733098100000';
    }
    async up(queryRunner) {
        // Create inventory table for multi-warehouse management
        await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS "inventory" (
        "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        "product_id" UUID NOT NULL,
        "warehouse_id" VARCHAR(50) NOT NULL,
        "quantity" INTEGER NOT NULL DEFAULT 0,
        "reserved" INTEGER NOT NULL DEFAULT 0,
        "updated_at" TIMESTAMP DEFAULT NOW(),
        CONSTRAINT "fk_inventory_product" 
          FOREIGN KEY ("product_id") 
          REFERENCES "product"("id") 
          ON DELETE CASCADE,
        CONSTRAINT "uq_inventory_product_warehouse" 
          UNIQUE ("product_id", "warehouse_id")
      )
    `);
        // Create indexes
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_inventory_product_id" 
      ON "inventory" ("product_id")
    `);
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_inventory_warehouse_id" 
      ON "inventory" ("warehouse_id")
    `);
        // Create index for low stock queries
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_inventory_quantity" 
      ON "inventory" ("quantity")
    `);
    }
    async down(queryRunner) {
        await queryRunner.query(`DROP TABLE IF EXISTS "inventory" CASCADE`);
    }
}
exports.CreateInventoryTable1733098100000 = CreateInventoryTable1733098100000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTczMzA5ODEwMDAwMC1jcmVhdGUtaW52ZW50b3J5LXRhYmxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL21pZ3JhdGlvbnMvMTczMzA5ODEwMDAwMC1jcmVhdGUtaW52ZW50b3J5LXRhYmxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUVBLE1BQWEsaUNBQWlDO0lBQTlDO1FBQ0UsU0FBSSxHQUFHLG1DQUFtQyxDQUFBO0lBMEM1QyxDQUFDO0lBeENRLEtBQUssQ0FBQyxFQUFFLENBQUMsV0FBd0I7UUFDdEMsd0RBQXdEO1FBQ3hELE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQzs7Ozs7Ozs7Ozs7Ozs7O0tBZXZCLENBQUMsQ0FBQTtRQUVGLGlCQUFpQjtRQUNqQixNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUM7OztLQUd2QixDQUFDLENBQUE7UUFFRixNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUM7OztLQUd2QixDQUFDLENBQUE7UUFFRixxQ0FBcUM7UUFDckMsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDOzs7S0FHdkIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVNLEtBQUssQ0FBQyxJQUFJLENBQUMsV0FBd0I7UUFDeEMsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDLDBDQUEwQyxDQUFDLENBQUE7SUFDckUsQ0FBQztDQUNGO0FBM0NELDhFQTJDQyJ9