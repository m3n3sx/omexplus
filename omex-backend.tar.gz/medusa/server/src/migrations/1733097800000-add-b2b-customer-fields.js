"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddB2bCustomerFields1733097800000 = void 0;
class AddB2bCustomerFields1733097800000 {
    constructor() {
        this.name = 'AddB2bCustomerFields1733097800000';
    }
    async up(queryRunner) {
        // Add B2B customer fields
        await queryRunner.query(`
      ALTER TABLE "customer" 
      ADD COLUMN IF NOT EXISTS "company_name" VARCHAR(255),
      ADD COLUMN IF NOT EXISTS "tax_id" VARCHAR(20),
      ADD COLUMN IF NOT EXISTS "customer_type" VARCHAR(20) DEFAULT 'retail'
    `);
        // Create index for customer type filtering
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_customer_type" 
      ON "customer" ("customer_type")
    `);
        // Create index for tax_id lookups
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_customer_tax_id" 
      ON "customer" ("tax_id")
    `);
    }
    async down(queryRunner) {
        await queryRunner.query(`DROP INDEX IF EXISTS "idx_customer_type"`);
        await queryRunner.query(`DROP INDEX IF EXISTS "idx_customer_tax_id"`);
        await queryRunner.query(`
      ALTER TABLE "customer" 
      DROP COLUMN IF EXISTS "company_name",
      DROP COLUMN IF EXISTS "tax_id",
      DROP COLUMN IF EXISTS "customer_type"
    `);
    }
}
exports.AddB2bCustomerFields1733097800000 = AddB2bCustomerFields1733097800000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTczMzA5NzgwMDAwMC1hZGQtYjJiLWN1c3RvbWVyLWZpZWxkcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9taWdyYXRpb25zLzE3MzMwOTc4MDAwMDAtYWRkLWIyYi1jdXN0b21lci1maWVsZHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBRUEsTUFBYSxpQ0FBaUM7SUFBOUM7UUFDRSxTQUFJLEdBQUcsbUNBQW1DLENBQUE7SUFrQzVDLENBQUM7SUFoQ1EsS0FBSyxDQUFDLEVBQUUsQ0FBQyxXQUF3QjtRQUN0QywwQkFBMEI7UUFDMUIsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDOzs7OztLQUt2QixDQUFDLENBQUE7UUFFRiwyQ0FBMkM7UUFDM0MsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDOzs7S0FHdkIsQ0FBQyxDQUFBO1FBRUYsa0NBQWtDO1FBQ2xDLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQzs7O0tBR3ZCLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFTSxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQXdCO1FBQ3hDLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQywwQ0FBMEMsQ0FBQyxDQUFBO1FBQ25FLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFBO1FBQ3JFLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQzs7Ozs7S0FLdkIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztDQUNGO0FBbkNELDhFQW1DQyJ9