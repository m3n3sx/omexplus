"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateManufacturerPartTable1733150200000 = void 0;
const typeorm_1 = require("typeorm");
class CreateManufacturerPartTable1733150200000 {
    async up(queryRunner) {
        await queryRunner.createTable(new typeorm_1.Table({
            name: "manufacturer_part",
            columns: [
                {
                    name: "id",
                    type: "uuid",
                    isPrimary: true,
                    generationStrategy: "uuid",
                    default: "uuid_generate_v4()",
                },
                {
                    name: "manufacturer_id",
                    type: "uuid",
                    isNullable: false,
                },
                {
                    name: "product_id",
                    type: "uuid",
                    isNullable: false,
                },
                {
                    name: "manufacturer_sku",
                    type: "varchar",
                    length: "255",
                    isNullable: false,
                },
                {
                    name: "manufacturer_name",
                    type: "varchar",
                    length: "255",
                    isNullable: true,
                },
                {
                    name: "part_number",
                    type: "varchar",
                    length: "255",
                    isNullable: true,
                },
                {
                    name: "alternative_names",
                    type: "jsonb",
                    isNullable: true,
                    default: "'[]'",
                },
                {
                    name: "catalog_page",
                    type: "int",
                    isNullable: true,
                },
                {
                    name: "catalog_url",
                    type: "varchar",
                    length: "500",
                    isNullable: true,
                },
                {
                    name: "technical_doc_url",
                    type: "varchar",
                    length: "500",
                    isNullable: true,
                },
                {
                    name: "datasheet_json",
                    type: "jsonb",
                    isNullable: true,
                },
                {
                    name: "created_at",
                    type: "timestamp",
                    default: "now()",
                },
                {
                    name: "updated_at",
                    type: "timestamp",
                    default: "now()",
                },
            ],
        }), true);
        // Add foreign keys
        await queryRunner.createForeignKey("manufacturer_part", new typeorm_1.TableForeignKey({
            columnNames: ["manufacturer_id"],
            referencedColumnNames: ["id"],
            referencedTableName: "manufacturer",
            onDelete: "CASCADE",
        }));
        await queryRunner.createForeignKey("manufacturer_part", new typeorm_1.TableForeignKey({
            columnNames: ["product_id"],
            referencedColumnNames: ["id"],
            referencedTableName: "product",
            onDelete: "CASCADE",
        }));
        // Create indexes
        await queryRunner.createIndex("manufacturer_part", new typeorm_1.TableIndex({
            name: "IDX_manufacturer_part_sku",
            columnNames: ["manufacturer_sku"],
        }));
        await queryRunner.createIndex("manufacturer_part", new typeorm_1.TableIndex({
            name: "IDX_manufacturer_part_number",
            columnNames: ["part_number"],
        }));
        await queryRunner.createIndex("manufacturer_part", new typeorm_1.TableIndex({
            name: "IDX_manufacturer_part_catalog_page",
            columnNames: ["manufacturer_id", "catalog_page"],
        }));
        // Create unique constraint
        await queryRunner.query(`CREATE UNIQUE INDEX "IDX_manufacturer_part_unique" ON "manufacturer_part" ("manufacturer_id", "manufacturer_sku")`);
    }
    async down(queryRunner) {
        await queryRunner.dropTable("manufacturer_part");
    }
}
exports.CreateManufacturerPartTable1733150200000 = CreateManufacturerPartTable1733150200000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTczMzE1MDIwMDAwMC1jcmVhdGUtbWFudWZhY3R1cmVyLXBhcnQtdGFibGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvbWlncmF0aW9ucy8xNzMzMTUwMjAwMDAwLWNyZWF0ZS1tYW51ZmFjdHVyZXItcGFydC10YWJsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxQ0FBNkY7QUFFN0YsTUFBYSx3Q0FBd0M7SUFDNUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxXQUF3QjtRQUN0QyxNQUFNLFdBQVcsQ0FBQyxXQUFXLENBQzNCLElBQUksZUFBSyxDQUFDO1lBQ1IsSUFBSSxFQUFFLG1CQUFtQjtZQUN6QixPQUFPLEVBQUU7Z0JBQ1A7b0JBQ0UsSUFBSSxFQUFFLElBQUk7b0JBQ1YsSUFBSSxFQUFFLE1BQU07b0JBQ1osU0FBUyxFQUFFLElBQUk7b0JBQ2Ysa0JBQWtCLEVBQUUsTUFBTTtvQkFDMUIsT0FBTyxFQUFFLG9CQUFvQjtpQkFDOUI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLGlCQUFpQjtvQkFDdkIsSUFBSSxFQUFFLE1BQU07b0JBQ1osVUFBVSxFQUFFLEtBQUs7aUJBQ2xCO2dCQUNEO29CQUNFLElBQUksRUFBRSxZQUFZO29CQUNsQixJQUFJLEVBQUUsTUFBTTtvQkFDWixVQUFVLEVBQUUsS0FBSztpQkFDbEI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLGtCQUFrQjtvQkFDeEIsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsTUFBTSxFQUFFLEtBQUs7b0JBQ2IsVUFBVSxFQUFFLEtBQUs7aUJBQ2xCO2dCQUNEO29CQUNFLElBQUksRUFBRSxtQkFBbUI7b0JBQ3pCLElBQUksRUFBRSxTQUFTO29CQUNmLE1BQU0sRUFBRSxLQUFLO29CQUNiLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsYUFBYTtvQkFDbkIsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsTUFBTSxFQUFFLEtBQUs7b0JBQ2IsVUFBVSxFQUFFLElBQUk7aUJBQ2pCO2dCQUNEO29CQUNFLElBQUksRUFBRSxtQkFBbUI7b0JBQ3pCLElBQUksRUFBRSxPQUFPO29CQUNiLFVBQVUsRUFBRSxJQUFJO29CQUNoQixPQUFPLEVBQUUsTUFBTTtpQkFDaEI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLGNBQWM7b0JBQ3BCLElBQUksRUFBRSxLQUFLO29CQUNYLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsYUFBYTtvQkFDbkIsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsTUFBTSxFQUFFLEtBQUs7b0JBQ2IsVUFBVSxFQUFFLElBQUk7aUJBQ2pCO2dCQUNEO29CQUNFLElBQUksRUFBRSxtQkFBbUI7b0JBQ3pCLElBQUksRUFBRSxTQUFTO29CQUNmLE1BQU0sRUFBRSxLQUFLO29CQUNiLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsZ0JBQWdCO29CQUN0QixJQUFJLEVBQUUsT0FBTztvQkFDYixVQUFVLEVBQUUsSUFBSTtpQkFDakI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLFlBQVk7b0JBQ2xCLElBQUksRUFBRSxXQUFXO29CQUNqQixPQUFPLEVBQUUsT0FBTztpQkFDakI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLFlBQVk7b0JBQ2xCLElBQUksRUFBRSxXQUFXO29CQUNqQixPQUFPLEVBQUUsT0FBTztpQkFDakI7YUFDRjtTQUNGLENBQUMsRUFDRixJQUFJLENBQ0wsQ0FBQTtRQUVELG1CQUFtQjtRQUNuQixNQUFNLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FDaEMsbUJBQW1CLEVBQ25CLElBQUkseUJBQWUsQ0FBQztZQUNsQixXQUFXLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQztZQUNoQyxxQkFBcUIsRUFBRSxDQUFDLElBQUksQ0FBQztZQUM3QixtQkFBbUIsRUFBRSxjQUFjO1lBQ25DLFFBQVEsRUFBRSxTQUFTO1NBQ3BCLENBQUMsQ0FDSCxDQUFBO1FBRUQsTUFBTSxXQUFXLENBQUMsZ0JBQWdCLENBQ2hDLG1CQUFtQixFQUNuQixJQUFJLHlCQUFlLENBQUM7WUFDbEIsV0FBVyxFQUFFLENBQUMsWUFBWSxDQUFDO1lBQzNCLHFCQUFxQixFQUFFLENBQUMsSUFBSSxDQUFDO1lBQzdCLG1CQUFtQixFQUFFLFNBQVM7WUFDOUIsUUFBUSxFQUFFLFNBQVM7U0FDcEIsQ0FBQyxDQUNILENBQUE7UUFFRCxpQkFBaUI7UUFDakIsTUFBTSxXQUFXLENBQUMsV0FBVyxDQUMzQixtQkFBbUIsRUFDbkIsSUFBSSxvQkFBVSxDQUFDO1lBQ2IsSUFBSSxFQUFFLDJCQUEyQjtZQUNqQyxXQUFXLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQztTQUNsQyxDQUFDLENBQ0gsQ0FBQTtRQUVELE1BQU0sV0FBVyxDQUFDLFdBQVcsQ0FDM0IsbUJBQW1CLEVBQ25CLElBQUksb0JBQVUsQ0FBQztZQUNiLElBQUksRUFBRSw4QkFBOEI7WUFDcEMsV0FBVyxFQUFFLENBQUMsYUFBYSxDQUFDO1NBQzdCLENBQUMsQ0FDSCxDQUFBO1FBRUQsTUFBTSxXQUFXLENBQUMsV0FBVyxDQUMzQixtQkFBbUIsRUFDbkIsSUFBSSxvQkFBVSxDQUFDO1lBQ2IsSUFBSSxFQUFFLG9DQUFvQztZQUMxQyxXQUFXLEVBQUUsQ0FBQyxpQkFBaUIsRUFBRSxjQUFjLENBQUM7U0FDakQsQ0FBQyxDQUNILENBQUE7UUFFRCwyQkFBMkI7UUFDM0IsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUNyQixtSEFBbUgsQ0FDcEgsQ0FBQTtJQUNILENBQUM7SUFFTSxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQXdCO1FBQ3hDLE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFBO0lBQ2xELENBQUM7Q0FDRjtBQTNJRCw0RkEySUMifQ==