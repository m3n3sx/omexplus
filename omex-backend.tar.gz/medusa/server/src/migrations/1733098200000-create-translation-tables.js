"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateTranslationTables1733098200000 = void 0;
class CreateTranslationTables1733098200000 {
    constructor() {
        this.name = 'CreateTranslationTables1733098200000';
    }
    async up(queryRunner) {
        // Create product_translation table
        await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS "product_translation" (
        "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        "product_id" UUID NOT NULL,
        "locale" VARCHAR(5) NOT NULL,
        "title" VARCHAR(255) NOT NULL,
        "description" TEXT,
        "created_at" TIMESTAMP DEFAULT NOW(),
        "updated_at" TIMESTAMP DEFAULT NOW(),
        CONSTRAINT "fk_product_translation_product" 
          FOREIGN KEY ("product_id") 
          REFERENCES "product"("id") 
          ON DELETE CASCADE,
        CONSTRAINT "uq_product_translation_product_locale" 
          UNIQUE ("product_id", "locale")
      )
    `);
        // Create category_translation table
        await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS "category_translation" (
        "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        "category_id" UUID NOT NULL,
        "locale" VARCHAR(5) NOT NULL,
        "name" VARCHAR(255) NOT NULL,
        "description" TEXT,
        "created_at" TIMESTAMP DEFAULT NOW(),
        "updated_at" TIMESTAMP DEFAULT NOW(),
        CONSTRAINT "fk_category_translation_category" 
          FOREIGN KEY ("category_id") 
          REFERENCES "product_category"("id") 
          ON DELETE CASCADE,
        CONSTRAINT "uq_category_translation_category_locale" 
          UNIQUE ("category_id", "locale")
      )
    `);
        // Create indexes
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_product_translation_product_id" 
      ON "product_translation" ("product_id")
    `);
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_product_translation_locale" 
      ON "product_translation" ("locale")
    `);
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_category_translation_category_id" 
      ON "category_translation" ("category_id")
    `);
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_category_translation_locale" 
      ON "category_translation" ("locale")
    `);
    }
    async down(queryRunner) {
        await queryRunner.query(`DROP TABLE IF EXISTS "product_translation" CASCADE`);
        await queryRunner.query(`DROP TABLE IF EXISTS "category_translation" CASCADE`);
    }
}
exports.CreateTranslationTables1733098200000 = CreateTranslationTables1733098200000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTczMzA5ODIwMDAwMC1jcmVhdGUtdHJhbnNsYXRpb24tdGFibGVzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL21pZ3JhdGlvbnMvMTczMzA5ODIwMDAwMC1jcmVhdGUtdHJhbnNsYXRpb24tdGFibGVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUVBLE1BQWEsb0NBQW9DO0lBQWpEO1FBQ0UsU0FBSSxHQUFHLHNDQUFzQyxDQUFBO0lBbUUvQyxDQUFDO0lBakVRLEtBQUssQ0FBQyxFQUFFLENBQUMsV0FBd0I7UUFDdEMsbUNBQW1DO1FBQ25DLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQzs7Ozs7Ozs7Ozs7Ozs7OztLQWdCdkIsQ0FBQyxDQUFBO1FBRUYsb0NBQW9DO1FBQ3BDLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQzs7Ozs7Ozs7Ozs7Ozs7OztLQWdCdkIsQ0FBQyxDQUFBO1FBRUYsaUJBQWlCO1FBQ2pCLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQzs7O0tBR3ZCLENBQUMsQ0FBQTtRQUVGLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQzs7O0tBR3ZCLENBQUMsQ0FBQTtRQUVGLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQzs7O0tBR3ZCLENBQUMsQ0FBQTtRQUVGLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQzs7O0tBR3ZCLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFTSxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQXdCO1FBQ3hDLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQyxvREFBb0QsQ0FBQyxDQUFBO1FBQzdFLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQyxxREFBcUQsQ0FBQyxDQUFBO0lBQ2hGLENBQUM7Q0FDRjtBQXBFRCxvRkFvRUMifQ==