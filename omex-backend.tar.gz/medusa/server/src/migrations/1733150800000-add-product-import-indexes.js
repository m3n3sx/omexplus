"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddProductImportIndexes1733150800000 = void 0;
class AddProductImportIndexes1733150800000 {
    constructor() {
        this.name = 'AddProductImportIndexes1733150800000';
    }
    async up(queryRunner) {
        // Add unique index on SKU for fast duplicate checking
        await queryRunner.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS "idx_product_sku_unique" 
      ON "product" ("sku") 
      WHERE "deleted_at" IS NULL
    `);
        // Add index on category_id for validation
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_product_category_id" 
      ON "product" ("category_id")
    `);
        // Add index on created_at for sorting recent imports
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_product_created_at" 
      ON "product" ("created_at" DESC)
    `);
        // Add index on equipment_type for filtering
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_product_equipment_type" 
      ON "product" ("equipment_type")
    `);
        // Add composite index for common queries
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_product_category_equipment" 
      ON "product" ("category_id", "equipment_type")
    `);
    }
    async down(queryRunner) {
        await queryRunner.query(`DROP INDEX IF EXISTS "idx_product_sku_unique"`);
        await queryRunner.query(`DROP INDEX IF EXISTS "idx_product_category_id"`);
        await queryRunner.query(`DROP INDEX IF EXISTS "idx_product_created_at"`);
        await queryRunner.query(`DROP INDEX IF EXISTS "idx_product_equipment_type"`);
        await queryRunner.query(`DROP INDEX IF EXISTS "idx_product_category_equipment"`);
    }
}
exports.AddProductImportIndexes1733150800000 = AddProductImportIndexes1733150800000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTczMzE1MDgwMDAwMC1hZGQtcHJvZHVjdC1pbXBvcnQtaW5kZXhlcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9taWdyYXRpb25zLzE3MzMxNTA4MDAwMDAtYWRkLXByb2R1Y3QtaW1wb3J0LWluZGV4ZXMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBRUEsTUFBYSxvQ0FBb0M7SUFBakQ7UUFDRSxTQUFJLEdBQUcsc0NBQXNDLENBQUE7SUEwQy9DLENBQUM7SUF4Q1EsS0FBSyxDQUFDLEVBQUUsQ0FBQyxXQUF3QjtRQUN0QyxzREFBc0Q7UUFDdEQsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDOzs7O0tBSXZCLENBQUMsQ0FBQTtRQUVGLDBDQUEwQztRQUMxQyxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUM7OztLQUd2QixDQUFDLENBQUE7UUFFRixxREFBcUQ7UUFDckQsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDOzs7S0FHdkIsQ0FBQyxDQUFBO1FBRUYsNENBQTRDO1FBQzVDLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQzs7O0tBR3ZCLENBQUMsQ0FBQTtRQUVGLHlDQUF5QztRQUN6QyxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUM7OztLQUd2QixDQUFDLENBQUE7SUFDSixDQUFDO0lBRU0sS0FBSyxDQUFDLElBQUksQ0FBQyxXQUF3QjtRQUN4QyxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsK0NBQStDLENBQUMsQ0FBQTtRQUN4RSxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsZ0RBQWdELENBQUMsQ0FBQTtRQUN6RSxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsK0NBQStDLENBQUMsQ0FBQTtRQUN4RSxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsbURBQW1ELENBQUMsQ0FBQTtRQUM1RSxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsdURBQXVELENBQUMsQ0FBQTtJQUNsRixDQUFDO0NBQ0Y7QUEzQ0Qsb0ZBMkNDIn0=