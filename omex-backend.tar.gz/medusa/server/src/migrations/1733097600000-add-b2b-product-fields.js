"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddB2bProductFields1733097600000 = void 0;
class AddB2bProductFields1733097600000 {
    constructor() {
        this.name = 'AddB2bProductFields1733097600000';
    }
    async up(queryRunner) {
        // Add B2B fields to product table
        await queryRunner.query(`
      ALTER TABLE "product" 
      ADD COLUMN IF NOT EXISTS "part_number" VARCHAR(255),
      ADD COLUMN IF NOT EXISTS "equipment_type" VARCHAR(255),
      ADD COLUMN IF NOT EXISTS "technical_specs" JSONB,
      ADD COLUMN IF NOT EXISTS "min_order_qty" INTEGER DEFAULT 1
    `);
        // Create indexes for better query performance
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_product_part_number" ON "product" ("part_number")
    `);
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_product_equipment_type" ON "product" ("equipment_type")
    `);
    }
    async down(queryRunner) {
        // Remove indexes
        await queryRunner.query(`DROP INDEX IF EXISTS "idx_product_part_number"`);
        await queryRunner.query(`DROP INDEX IF EXISTS "idx_product_equipment_type"`);
        // Remove columns
        await queryRunner.query(`
      ALTER TABLE "product" 
      DROP COLUMN IF EXISTS "part_number",
      DROP COLUMN IF EXISTS "equipment_type",
      DROP COLUMN IF EXISTS "technical_specs",
      DROP COLUMN IF EXISTS "min_order_qty"
    `);
    }
}
exports.AddB2bProductFields1733097600000 = AddB2bProductFields1733097600000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTczMzA5NzYwMDAwMC1hZGQtYjJiLXByb2R1Y3QtZmllbGRzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL21pZ3JhdGlvbnMvMTczMzA5NzYwMDAwMC1hZGQtYjJiLXByb2R1Y3QtZmllbGRzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUVBLE1BQWEsZ0NBQWdDO0lBQTdDO1FBQ0UsU0FBSSxHQUFHLGtDQUFrQyxDQUFBO0lBb0MzQyxDQUFDO0lBbENRLEtBQUssQ0FBQyxFQUFFLENBQUMsV0FBd0I7UUFDdEMsa0NBQWtDO1FBQ2xDLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQzs7Ozs7O0tBTXZCLENBQUMsQ0FBQTtRQUVGLDhDQUE4QztRQUM5QyxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUM7O0tBRXZCLENBQUMsQ0FBQTtRQUVGLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQzs7S0FFdkIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVNLEtBQUssQ0FBQyxJQUFJLENBQUMsV0FBd0I7UUFDeEMsaUJBQWlCO1FBQ2pCLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQyxnREFBZ0QsQ0FBQyxDQUFBO1FBQ3pFLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQyxtREFBbUQsQ0FBQyxDQUFBO1FBRTVFLGlCQUFpQjtRQUNqQixNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUM7Ozs7OztLQU12QixDQUFDLENBQUE7SUFDSixDQUFDO0NBQ0Y7QUFyQ0QsNEVBcUNDIn0=