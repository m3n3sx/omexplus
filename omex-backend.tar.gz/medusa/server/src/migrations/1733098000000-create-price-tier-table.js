"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreatePriceTierTable1733098000000 = void 0;
class CreatePriceTierTable1733098000000 {
    constructor() {
        this.name = 'CreatePriceTierTable1733098000000';
    }
    async up(queryRunner) {
        // Create price_tier table for tiered pricing
        await queryRunner.query(`
      CREATE TABLE IF NOT EXISTS "price_tier" (
        "id" UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        "product_id" UUID NOT NULL,
        "customer_type" VARCHAR(20) NOT NULL,
        "quantity_min" INTEGER NOT NULL,
        "quantity_max" INTEGER,
        "price" DECIMAL(10,2) NOT NULL,
        "created_at" TIMESTAMP DEFAULT NOW(),
        "updated_at" TIMESTAMP DEFAULT NOW(),
        CONSTRAINT "fk_price_tier_product" 
          FOREIGN KEY ("product_id") 
          REFERENCES "product"("id") 
          ON DELETE CASCADE
      )
    `);
        // Create indexes
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_price_tier_product_id" 
      ON "price_tier" ("product_id")
    `);
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_price_tier_customer_type" 
      ON "price_tier" ("customer_type")
    `);
    }
    async down(queryRunner) {
        await queryRunner.query(`DROP TABLE IF EXISTS "price_tier" CASCADE`);
    }
}
exports.CreatePriceTierTable1733098000000 = CreatePriceTierTable1733098000000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTczMzA5ODAwMDAwMC1jcmVhdGUtcHJpY2UtdGllci10YWJsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9taWdyYXRpb25zLzE3MzMwOTgwMDAwMDAtY3JlYXRlLXByaWNlLXRpZXItdGFibGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBRUEsTUFBYSxpQ0FBaUM7SUFBOUM7UUFDRSxTQUFJLEdBQUcsbUNBQW1DLENBQUE7SUFvQzVDLENBQUM7SUFsQ1EsS0FBSyxDQUFDLEVBQUUsQ0FBQyxXQUF3QjtRQUN0Qyw2Q0FBNkM7UUFDN0MsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7S0FldkIsQ0FBQyxDQUFBO1FBRUYsaUJBQWlCO1FBQ2pCLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQzs7O0tBR3ZCLENBQUMsQ0FBQTtRQUVGLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQzs7O0tBR3ZCLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFTSxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQXdCO1FBQ3hDLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQywyQ0FBMkMsQ0FBQyxDQUFBO0lBQ3RFLENBQUM7Q0FDRjtBQXJDRCw4RUFxQ0MifQ==