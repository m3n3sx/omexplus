"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddSearchFieldsToProduct1733150400000 = void 0;
const typeorm_1 = require("typeorm");
class AddSearchFieldsToProduct1733150400000 {
    async up(queryRunner) {
        // Add search and filter fields
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "searchable_text",
            type: "text",
            isNullable: true,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "filter_attributes",
            type: "jsonb",
            isNullable: true,
            default: "'{}'",
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "is_featured",
            type: "boolean",
            default: false,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "is_bestseller",
            type: "boolean",
            default: false,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "is_new",
            type: "boolean",
            default: false,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "comparable_products",
            type: "jsonb",
            isNullable: true,
            default: "'[]'",
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "breadcrumb",
            type: "varchar",
            length: "500",
            isNullable: true,
        }));
        // Create full-text search index
        await queryRunner.query(`CREATE INDEX "IDX_product_searchable_text" ON "product" USING GIN (to_tsvector('simple', COALESCE(searchable_text, '')))`);
        // Create GIN index on filter_attributes for fast JSONB queries
        await queryRunner.query(`CREATE INDEX "IDX_product_filter_attributes" ON "product" USING GIN (filter_attributes)`);
        // Create indexes on boolean flags
        await queryRunner.query(`CREATE INDEX "IDX_product_is_featured" ON "product" ("is_featured") WHERE is_featured = true`);
        await queryRunner.query(`CREATE INDEX "IDX_product_is_bestseller" ON "product" ("is_bestseller") WHERE is_bestseller = true`);
        await queryRunner.query(`CREATE INDEX "IDX_product_is_new" ON "product" ("is_new") WHERE is_new = true`);
    }
    async down(queryRunner) {
        await queryRunner.query(`DROP INDEX "IDX_product_is_new"`);
        await queryRunner.query(`DROP INDEX "IDX_product_is_bestseller"`);
        await queryRunner.query(`DROP INDEX "IDX_product_is_featured"`);
        await queryRunner.query(`DROP INDEX "IDX_product_filter_attributes"`);
        await queryRunner.query(`DROP INDEX "IDX_product_searchable_text"`);
        await queryRunner.dropColumn("product", "breadcrumb");
        await queryRunner.dropColumn("product", "comparable_products");
        await queryRunner.dropColumn("product", "is_new");
        await queryRunner.dropColumn("product", "is_bestseller");
        await queryRunner.dropColumn("product", "is_featured");
        await queryRunner.dropColumn("product", "filter_attributes");
        await queryRunner.dropColumn("product", "searchable_text");
    }
}
exports.AddSearchFieldsToProduct1733150400000 = AddSearchFieldsToProduct1733150400000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTczMzE1MDQwMDAwMC1hZGQtc2VhcmNoLWZpZWxkcy10by1wcm9kdWN0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL21pZ3JhdGlvbnMvMTczMzE1MDQwMDAwMC1hZGQtc2VhcmNoLWZpZWxkcy10by1wcm9kdWN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFDQUFzRTtBQUV0RSxNQUFhLHFDQUFxQztJQUN6QyxLQUFLLENBQUMsRUFBRSxDQUFDLFdBQXdCO1FBQ3RDLCtCQUErQjtRQUMvQixNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsaUJBQWlCO1lBQ3ZCLElBQUksRUFBRSxNQUFNO1lBQ1osVUFBVSxFQUFFLElBQUk7U0FDakIsQ0FBQyxDQUNILENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsbUJBQW1CO1lBQ3pCLElBQUksRUFBRSxPQUFPO1lBQ2IsVUFBVSxFQUFFLElBQUk7WUFDaEIsT0FBTyxFQUFFLE1BQU07U0FDaEIsQ0FBQyxDQUNILENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsYUFBYTtZQUNuQixJQUFJLEVBQUUsU0FBUztZQUNmLE9BQU8sRUFBRSxLQUFLO1NBQ2YsQ0FBQyxDQUNILENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsZUFBZTtZQUNyQixJQUFJLEVBQUUsU0FBUztZQUNmLE9BQU8sRUFBRSxLQUFLO1NBQ2YsQ0FBQyxDQUNILENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsUUFBUTtZQUNkLElBQUksRUFBRSxTQUFTO1lBQ2YsT0FBTyxFQUFFLEtBQUs7U0FDZixDQUFDLENBQ0gsQ0FBQTtRQUVELE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FDekIsU0FBUyxFQUNULElBQUkscUJBQVcsQ0FBQztZQUNkLElBQUksRUFBRSxxQkFBcUI7WUFDM0IsSUFBSSxFQUFFLE9BQU87WUFDYixVQUFVLEVBQUUsSUFBSTtZQUNoQixPQUFPLEVBQUUsTUFBTTtTQUNoQixDQUFDLENBQ0gsQ0FBQTtRQUVELE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FDekIsU0FBUyxFQUNULElBQUkscUJBQVcsQ0FBQztZQUNkLElBQUksRUFBRSxZQUFZO1lBQ2xCLElBQUksRUFBRSxTQUFTO1lBQ2YsTUFBTSxFQUFFLEtBQUs7WUFDYixVQUFVLEVBQUUsSUFBSTtTQUNqQixDQUFDLENBQ0gsQ0FBQTtRQUVELGdDQUFnQztRQUNoQyxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQ3JCLDBIQUEwSCxDQUMzSCxDQUFBO1FBRUQsK0RBQStEO1FBQy9ELE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FDckIseUZBQXlGLENBQzFGLENBQUE7UUFFRCxrQ0FBa0M7UUFDbEMsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUNyQiw4RkFBOEYsQ0FDL0YsQ0FBQTtRQUVELE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FDckIsb0dBQW9HLENBQ3JHLENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQ3JCLCtFQUErRSxDQUNoRixDQUFBO0lBQ0gsQ0FBQztJQUVNLEtBQUssQ0FBQyxJQUFJLENBQUMsV0FBd0I7UUFDeEMsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDLGlDQUFpQyxDQUFDLENBQUE7UUFDMUQsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDLHdDQUF3QyxDQUFDLENBQUE7UUFDakUsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDLHNDQUFzQyxDQUFDLENBQUE7UUFDL0QsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDLDRDQUE0QyxDQUFDLENBQUE7UUFDckUsTUFBTSxXQUFXLENBQUMsS0FBSyxDQUFDLDBDQUEwQyxDQUFDLENBQUE7UUFFbkUsTUFBTSxXQUFXLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQTtRQUNyRCxNQUFNLFdBQVcsQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLHFCQUFxQixDQUFDLENBQUE7UUFDOUQsTUFBTSxXQUFXLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxRQUFRLENBQUMsQ0FBQTtRQUNqRCxNQUFNLFdBQVcsQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLGVBQWUsQ0FBQyxDQUFBO1FBQ3hELE1BQU0sV0FBVyxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsYUFBYSxDQUFDLENBQUE7UUFDdEQsTUFBTSxXQUFXLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxtQkFBbUIsQ0FBQyxDQUFBO1FBQzVELE1BQU0sV0FBVyxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsaUJBQWlCLENBQUMsQ0FBQTtJQUM1RCxDQUFDO0NBQ0Y7QUE1R0Qsc0ZBNEdDIn0=