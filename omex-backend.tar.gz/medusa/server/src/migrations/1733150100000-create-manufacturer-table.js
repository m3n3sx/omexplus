"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateManufacturerTable1733150100000 = void 0;
const typeorm_1 = require("typeorm");
class CreateManufacturerTable1733150100000 {
    async up(queryRunner) {
        await queryRunner.createTable(new typeorm_1.Table({
            name: "manufacturer",
            columns: [
                {
                    name: "id",
                    type: "uuid",
                    isPrimary: true,
                    generationStrategy: "uuid",
                    default: "uuid_generate_v4()",
                },
                {
                    name: "name",
                    type: "varchar",
                    length: "255",
                    isNullable: false,
                },
                {
                    name: "name_en",
                    type: "varchar",
                    length: "255",
                    isNullable: true,
                },
                {
                    name: "name_de",
                    type: "varchar",
                    length: "255",
                    isNullable: true,
                },
                {
                    name: "slug",
                    type: "varchar",
                    length: "255",
                    isUnique: true,
                    isNullable: false,
                },
                {
                    name: "logo_url",
                    type: "varchar",
                    length: "500",
                    isNullable: true,
                },
                {
                    name: "website_url",
                    type: "varchar",
                    length: "500",
                    isNullable: true,
                },
                {
                    name: "description",
                    type: "text",
                    isNullable: true,
                },
                {
                    name: "country",
                    type: "varchar",
                    length: "100",
                    isNullable: true,
                },
                {
                    name: "contact_email",
                    type: "varchar",
                    length: "255",
                    isNullable: true,
                },
                {
                    name: "contact_phone",
                    type: "varchar",
                    length: "20",
                    isNullable: true,
                },
                {
                    name: "catalog_pdf_url",
                    type: "varchar",
                    length: "500",
                    isNullable: true,
                },
                {
                    name: "catalog_updated_at",
                    type: "timestamp",
                    isNullable: true,
                },
                {
                    name: "api_endpoint",
                    type: "varchar",
                    length: "500",
                    isNullable: true,
                },
                {
                    name: "api_key",
                    type: "varchar",
                    length: "500",
                    isNullable: true,
                },
                {
                    name: "is_active",
                    type: "boolean",
                    default: true,
                },
                {
                    name: "sync_frequency",
                    type: "varchar",
                    length: "50",
                    isNullable: true,
                },
                {
                    name: "last_sync_at",
                    type: "timestamp",
                    isNullable: true,
                },
                {
                    name: "products_count",
                    type: "int",
                    default: 0,
                },
                {
                    name: "created_at",
                    type: "timestamp",
                    default: "now()",
                },
                {
                    name: "updated_at",
                    type: "timestamp",
                    default: "now()",
                },
            ],
        }), true);
        // Create indexes
        await queryRunner.createIndex("manufacturer", new typeorm_1.TableIndex({
            name: "IDX_manufacturer_slug",
            columnNames: ["slug"],
        }));
        await queryRunner.createIndex("manufacturer", new typeorm_1.TableIndex({
            name: "IDX_manufacturer_is_active",
            columnNames: ["is_active"],
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropTable("manufacturer");
    }
}
exports.CreateManufacturerTable1733150100000 = CreateManufacturerTable1733150100000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTczMzE1MDEwMDAwMC1jcmVhdGUtbWFudWZhY3R1cmVyLXRhYmxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL21pZ3JhdGlvbnMvMTczMzE1MDEwMDAwMC1jcmVhdGUtbWFudWZhY3R1cmVyLXRhYmxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFDQUE0RTtBQUU1RSxNQUFhLG9DQUFvQztJQUN4QyxLQUFLLENBQUMsRUFBRSxDQUFDLFdBQXdCO1FBQ3RDLE1BQU0sV0FBVyxDQUFDLFdBQVcsQ0FDM0IsSUFBSSxlQUFLLENBQUM7WUFDUixJQUFJLEVBQUUsY0FBYztZQUNwQixPQUFPLEVBQUU7Z0JBQ1A7b0JBQ0UsSUFBSSxFQUFFLElBQUk7b0JBQ1YsSUFBSSxFQUFFLE1BQU07b0JBQ1osU0FBUyxFQUFFLElBQUk7b0JBQ2Ysa0JBQWtCLEVBQUUsTUFBTTtvQkFDMUIsT0FBTyxFQUFFLG9CQUFvQjtpQkFDOUI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLE1BQU07b0JBQ1osSUFBSSxFQUFFLFNBQVM7b0JBQ2YsTUFBTSxFQUFFLEtBQUs7b0JBQ2IsVUFBVSxFQUFFLEtBQUs7aUJBQ2xCO2dCQUNEO29CQUNFLElBQUksRUFBRSxTQUFTO29CQUNmLElBQUksRUFBRSxTQUFTO29CQUNmLE1BQU0sRUFBRSxLQUFLO29CQUNiLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsU0FBUztvQkFDZixJQUFJLEVBQUUsU0FBUztvQkFDZixNQUFNLEVBQUUsS0FBSztvQkFDYixVQUFVLEVBQUUsSUFBSTtpQkFDakI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLE1BQU07b0JBQ1osSUFBSSxFQUFFLFNBQVM7b0JBQ2YsTUFBTSxFQUFFLEtBQUs7b0JBQ2IsUUFBUSxFQUFFLElBQUk7b0JBQ2QsVUFBVSxFQUFFLEtBQUs7aUJBQ2xCO2dCQUNEO29CQUNFLElBQUksRUFBRSxVQUFVO29CQUNoQixJQUFJLEVBQUUsU0FBUztvQkFDZixNQUFNLEVBQUUsS0FBSztvQkFDYixVQUFVLEVBQUUsSUFBSTtpQkFDakI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLGFBQWE7b0JBQ25CLElBQUksRUFBRSxTQUFTO29CQUNmLE1BQU0sRUFBRSxLQUFLO29CQUNiLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsYUFBYTtvQkFDbkIsSUFBSSxFQUFFLE1BQU07b0JBQ1osVUFBVSxFQUFFLElBQUk7aUJBQ2pCO2dCQUNEO29CQUNFLElBQUksRUFBRSxTQUFTO29CQUNmLElBQUksRUFBRSxTQUFTO29CQUNmLE1BQU0sRUFBRSxLQUFLO29CQUNiLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsZUFBZTtvQkFDckIsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsTUFBTSxFQUFFLEtBQUs7b0JBQ2IsVUFBVSxFQUFFLElBQUk7aUJBQ2pCO2dCQUNEO29CQUNFLElBQUksRUFBRSxlQUFlO29CQUNyQixJQUFJLEVBQUUsU0FBUztvQkFDZixNQUFNLEVBQUUsSUFBSTtvQkFDWixVQUFVLEVBQUUsSUFBSTtpQkFDakI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLGlCQUFpQjtvQkFDdkIsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsTUFBTSxFQUFFLEtBQUs7b0JBQ2IsVUFBVSxFQUFFLElBQUk7aUJBQ2pCO2dCQUNEO29CQUNFLElBQUksRUFBRSxvQkFBb0I7b0JBQzFCLElBQUksRUFBRSxXQUFXO29CQUNqQixVQUFVLEVBQUUsSUFBSTtpQkFDakI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLGNBQWM7b0JBQ3BCLElBQUksRUFBRSxTQUFTO29CQUNmLE1BQU0sRUFBRSxLQUFLO29CQUNiLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsU0FBUztvQkFDZixJQUFJLEVBQUUsU0FBUztvQkFDZixNQUFNLEVBQUUsS0FBSztvQkFDYixVQUFVLEVBQUUsSUFBSTtpQkFDakI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLFdBQVc7b0JBQ2pCLElBQUksRUFBRSxTQUFTO29CQUNmLE9BQU8sRUFBRSxJQUFJO2lCQUNkO2dCQUNEO29CQUNFLElBQUksRUFBRSxnQkFBZ0I7b0JBQ3RCLElBQUksRUFBRSxTQUFTO29CQUNmLE1BQU0sRUFBRSxJQUFJO29CQUNaLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsY0FBYztvQkFDcEIsSUFBSSxFQUFFLFdBQVc7b0JBQ2pCLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsZ0JBQWdCO29CQUN0QixJQUFJLEVBQUUsS0FBSztvQkFDWCxPQUFPLEVBQUUsQ0FBQztpQkFDWDtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsWUFBWTtvQkFDbEIsSUFBSSxFQUFFLFdBQVc7b0JBQ2pCLE9BQU8sRUFBRSxPQUFPO2lCQUNqQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsWUFBWTtvQkFDbEIsSUFBSSxFQUFFLFdBQVc7b0JBQ2pCLE9BQU8sRUFBRSxPQUFPO2lCQUNqQjthQUNGO1NBQ0YsQ0FBQyxFQUNGLElBQUksQ0FDTCxDQUFBO1FBRUQsaUJBQWlCO1FBQ2pCLE1BQU0sV0FBVyxDQUFDLFdBQVcsQ0FDM0IsY0FBYyxFQUNkLElBQUksb0JBQVUsQ0FBQztZQUNiLElBQUksRUFBRSx1QkFBdUI7WUFDN0IsV0FBVyxFQUFFLENBQUMsTUFBTSxDQUFDO1NBQ3RCLENBQUMsQ0FDSCxDQUFBO1FBRUQsTUFBTSxXQUFXLENBQUMsV0FBVyxDQUMzQixjQUFjLEVBQ2QsSUFBSSxvQkFBVSxDQUFDO1lBQ2IsSUFBSSxFQUFFLDRCQUE0QjtZQUNsQyxXQUFXLEVBQUUsQ0FBQyxXQUFXLENBQUM7U0FDM0IsQ0FBQyxDQUNILENBQUE7SUFDSCxDQUFDO0lBRU0sS0FBSyxDQUFDLElBQUksQ0FBQyxXQUF3QjtRQUN4QyxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUE7SUFDN0MsQ0FBQztDQUNGO0FBekpELG9GQXlKQyJ9