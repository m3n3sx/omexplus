"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddHierarchicalCategories1733097700000 = void 0;
class AddHierarchicalCategories1733097700000 {
    constructor() {
        this.name = 'AddHierarchicalCategories1733097700000';
    }
    async up(queryRunner) {
        // Add parent_id for hierarchical structure
        await queryRunner.query(`
      ALTER TABLE "product_category" 
      ADD COLUMN IF NOT EXISTS "parent_id" UUID,
      ADD CONSTRAINT "fk_product_category_parent" 
        FOREIGN KEY ("parent_id") 
        REFERENCES "product_category"("id") 
        ON DELETE CASCADE
    `);
        // Add icon field for category display
        await queryRunner.query(`
      ALTER TABLE "product_category" 
      ADD COLUMN IF NOT EXISTS "icon" VARCHAR(255)
    `);
        // Create index for parent_id lookups
        await queryRunner.query(`
      CREATE INDEX IF NOT EXISTS "idx_product_category_parent_id" 
      ON "product_category" ("parent_id")
    `);
    }
    async down(queryRunner) {
        await queryRunner.query(`DROP INDEX IF EXISTS "idx_product_category_parent_id"`);
        await queryRunner.query(`ALTER TABLE "product_category" DROP CONSTRAINT IF EXISTS "fk_product_category_parent"`);
        await queryRunner.query(`
      ALTER TABLE "product_category" 
      DROP COLUMN IF EXISTS "parent_id",
      DROP COLUMN IF EXISTS "icon"
    `);
    }
}
exports.AddHierarchicalCategories1733097700000 = AddHierarchicalCategories1733097700000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTczMzA5NzcwMDAwMC1hZGQtaGllcmFyY2hpY2FsLWNhdGVnb3JpZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvbWlncmF0aW9ucy8xNzMzMDk3NzAwMDAwLWFkZC1oaWVyYXJjaGljYWwtY2F0ZWdvcmllcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFFQSxNQUFhLHNDQUFzQztJQUFuRDtRQUNFLFNBQUksR0FBRyx3Q0FBd0MsQ0FBQTtJQW1DakQsQ0FBQztJQWpDUSxLQUFLLENBQUMsRUFBRSxDQUFDLFdBQXdCO1FBQ3RDLDJDQUEyQztRQUMzQyxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUM7Ozs7Ozs7S0FPdkIsQ0FBQyxDQUFBO1FBRUYsc0NBQXNDO1FBQ3RDLE1BQU0sV0FBVyxDQUFDLEtBQUssQ0FBQzs7O0tBR3ZCLENBQUMsQ0FBQTtRQUVGLHFDQUFxQztRQUNyQyxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUM7OztLQUd2QixDQUFDLENBQUE7SUFDSixDQUFDO0lBRU0sS0FBSyxDQUFDLElBQUksQ0FBQyxXQUF3QjtRQUN4QyxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsdURBQXVELENBQUMsQ0FBQTtRQUNoRixNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsdUZBQXVGLENBQUMsQ0FBQTtRQUNoSCxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUM7Ozs7S0FJdkIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztDQUNGO0FBcENELHdGQW9DQyJ9