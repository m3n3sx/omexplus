"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateB2bTables1733150600000 = void 0;
const typeorm_1 = require("typeorm");
class CreateB2bTables1733150600000 {
    async up(queryRunner) {
        // Create B2B Customer Group table
        await queryRunner.createTable(new typeorm_1.Table({
            name: "b2b_customer_group",
            columns: [
                {
                    name: "id",
                    type: "uuid",
                    isPrimary: true,
                    generationStrategy: "uuid",
                    default: "uuid_generate_v4()",
                },
                {
                    name: "name",
                    type: "varchar",
                    length: "255",
                    isNullable: false,
                },
                {
                    name: "discount_percentage",
                    type: "decimal",
                    precision: 5,
                    scale: 2,
                    isNullable: true,
                },
                {
                    name: "min_order_value",
                    type: "decimal",
                    precision: 10,
                    scale: 2,
                    isNullable: true,
                },
                {
                    name: "payment_terms",
                    type: "varchar",
                    length: "50",
                    isNullable: true,
                },
                {
                    name: "custom_catalog_ids",
                    type: "jsonb",
                    isNullable: true,
                    default: "'[]'",
                },
                {
                    name: "created_at",
                    type: "timestamp",
                    default: "now()",
                },
                {
                    name: "updated_at",
                    type: "timestamp",
                    default: "now()",
                },
            ],
        }), true);
        // Create Quote table
        await queryRunner.createTable(new typeorm_1.Table({
            name: "quote",
            columns: [
                {
                    name: "id",
                    type: "uuid",
                    isPrimary: true,
                    generationStrategy: "uuid",
                    default: "uuid_generate_v4()",
                },
                {
                    name: "customer_id",
                    type: "uuid",
                    isNullable: false,
                },
                {
                    name: "items",
                    type: "jsonb",
                    isNullable: false,
                },
                {
                    name: "total_amount",
                    type: "decimal",
                    precision: 10,
                    scale: 2,
                    isNullable: false,
                },
                {
                    name: "valid_until",
                    type: "timestamp",
                    isNullable: true,
                },
                {
                    name: "status",
                    type: "varchar",
                    length: "50",
                    default: "'draft'",
                },
                {
                    name: "notes",
                    type: "text",
                    isNullable: true,
                },
                {
                    name: "created_at",
                    type: "timestamp",
                    default: "now()",
                },
                {
                    name: "updated_at",
                    type: "timestamp",
                    default: "now()",
                },
            ],
        }), true);
        // Create Purchase Order table
        await queryRunner.createTable(new typeorm_1.Table({
            name: "purchase_order",
            columns: [
                {
                    name: "id",
                    type: "uuid",
                    isPrimary: true,
                    generationStrategy: "uuid",
                    default: "uuid_generate_v4()",
                },
                {
                    name: "customer_id",
                    type: "uuid",
                    isNullable: false,
                },
                {
                    name: "po_number",
                    type: "varchar",
                    length: "255",
                    isNullable: false,
                    isUnique: true,
                },
                {
                    name: "items",
                    type: "jsonb",
                    isNullable: false,
                },
                {
                    name: "total_amount",
                    type: "decimal",
                    precision: 10,
                    scale: 2,
                    isNullable: false,
                },
                {
                    name: "payment_terms",
                    type: "varchar",
                    length: "50",
                    isNullable: true,
                },
                {
                    name: "delivery_date",
                    type: "date",
                    isNullable: true,
                },
                {
                    name: "status",
                    type: "varchar",
                    length: "50",
                    default: "'pending'",
                },
                {
                    name: "notes",
                    type: "text",
                    isNullable: true,
                },
                {
                    name: "created_at",
                    type: "timestamp",
                    default: "now()",
                },
                {
                    name: "updated_at",
                    type: "timestamp",
                    default: "now()",
                },
            ],
        }), true);
        // Create indexes
        await queryRunner.createIndex("quote", new typeorm_1.TableIndex({
            name: "IDX_quote_customer_id",
            columnNames: ["customer_id"],
        }));
        await queryRunner.createIndex("quote", new typeorm_1.TableIndex({
            name: "IDX_quote_status",
            columnNames: ["status"],
        }));
        await queryRunner.createIndex("purchase_order", new typeorm_1.TableIndex({
            name: "IDX_purchase_order_customer_id",
            columnNames: ["customer_id"],
        }));
        await queryRunner.createIndex("purchase_order", new typeorm_1.TableIndex({
            name: "IDX_purchase_order_po_number",
            columnNames: ["po_number"],
        }));
        await queryRunner.createIndex("purchase_order", new typeorm_1.TableIndex({
            name: "IDX_purchase_order_status",
            columnNames: ["status"],
        }));
    }
    async down(queryRunner) {
        await queryRunner.dropTable("purchase_order");
        await queryRunner.dropTable("quote");
        await queryRunner.dropTable("b2b_customer_group");
    }
}
exports.CreateB2bTables1733150600000 = CreateB2bTables1733150600000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTczMzE1MDYwMDAwMC1jcmVhdGUtYjJiLXRhYmxlcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9taWdyYXRpb25zLzE3MzMxNTA2MDAwMDAtY3JlYXRlLWIyYi10YWJsZXMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscUNBQTZGO0FBRTdGLE1BQWEsNEJBQTRCO0lBQ2hDLEtBQUssQ0FBQyxFQUFFLENBQUMsV0FBd0I7UUFDdEMsa0NBQWtDO1FBQ2xDLE1BQU0sV0FBVyxDQUFDLFdBQVcsQ0FDM0IsSUFBSSxlQUFLLENBQUM7WUFDUixJQUFJLEVBQUUsb0JBQW9CO1lBQzFCLE9BQU8sRUFBRTtnQkFDUDtvQkFDRSxJQUFJLEVBQUUsSUFBSTtvQkFDVixJQUFJLEVBQUUsTUFBTTtvQkFDWixTQUFTLEVBQUUsSUFBSTtvQkFDZixrQkFBa0IsRUFBRSxNQUFNO29CQUMxQixPQUFPLEVBQUUsb0JBQW9CO2lCQUM5QjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsTUFBTTtvQkFDWixJQUFJLEVBQUUsU0FBUztvQkFDZixNQUFNLEVBQUUsS0FBSztvQkFDYixVQUFVLEVBQUUsS0FBSztpQkFDbEI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLHFCQUFxQjtvQkFDM0IsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsU0FBUyxFQUFFLENBQUM7b0JBQ1osS0FBSyxFQUFFLENBQUM7b0JBQ1IsVUFBVSxFQUFFLElBQUk7aUJBQ2pCO2dCQUNEO29CQUNFLElBQUksRUFBRSxpQkFBaUI7b0JBQ3ZCLElBQUksRUFBRSxTQUFTO29CQUNmLFNBQVMsRUFBRSxFQUFFO29CQUNiLEtBQUssRUFBRSxDQUFDO29CQUNSLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsZUFBZTtvQkFDckIsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsTUFBTSxFQUFFLElBQUk7b0JBQ1osVUFBVSxFQUFFLElBQUk7aUJBQ2pCO2dCQUNEO29CQUNFLElBQUksRUFBRSxvQkFBb0I7b0JBQzFCLElBQUksRUFBRSxPQUFPO29CQUNiLFVBQVUsRUFBRSxJQUFJO29CQUNoQixPQUFPLEVBQUUsTUFBTTtpQkFDaEI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLFlBQVk7b0JBQ2xCLElBQUksRUFBRSxXQUFXO29CQUNqQixPQUFPLEVBQUUsT0FBTztpQkFDakI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLFlBQVk7b0JBQ2xCLElBQUksRUFBRSxXQUFXO29CQUNqQixPQUFPLEVBQUUsT0FBTztpQkFDakI7YUFDRjtTQUNGLENBQUMsRUFDRixJQUFJLENBQ0wsQ0FBQTtRQUVELHFCQUFxQjtRQUNyQixNQUFNLFdBQVcsQ0FBQyxXQUFXLENBQzNCLElBQUksZUFBSyxDQUFDO1lBQ1IsSUFBSSxFQUFFLE9BQU87WUFDYixPQUFPLEVBQUU7Z0JBQ1A7b0JBQ0UsSUFBSSxFQUFFLElBQUk7b0JBQ1YsSUFBSSxFQUFFLE1BQU07b0JBQ1osU0FBUyxFQUFFLElBQUk7b0JBQ2Ysa0JBQWtCLEVBQUUsTUFBTTtvQkFDMUIsT0FBTyxFQUFFLG9CQUFvQjtpQkFDOUI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLGFBQWE7b0JBQ25CLElBQUksRUFBRSxNQUFNO29CQUNaLFVBQVUsRUFBRSxLQUFLO2lCQUNsQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsT0FBTztvQkFDYixVQUFVLEVBQUUsS0FBSztpQkFDbEI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLGNBQWM7b0JBQ3BCLElBQUksRUFBRSxTQUFTO29CQUNmLFNBQVMsRUFBRSxFQUFFO29CQUNiLEtBQUssRUFBRSxDQUFDO29CQUNSLFVBQVUsRUFBRSxLQUFLO2lCQUNsQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsYUFBYTtvQkFDbkIsSUFBSSxFQUFFLFdBQVc7b0JBQ2pCLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsUUFBUTtvQkFDZCxJQUFJLEVBQUUsU0FBUztvQkFDZixNQUFNLEVBQUUsSUFBSTtvQkFDWixPQUFPLEVBQUUsU0FBUztpQkFDbkI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLE1BQU07b0JBQ1osVUFBVSxFQUFFLElBQUk7aUJBQ2pCO2dCQUNEO29CQUNFLElBQUksRUFBRSxZQUFZO29CQUNsQixJQUFJLEVBQUUsV0FBVztvQkFDakIsT0FBTyxFQUFFLE9BQU87aUJBQ2pCO2dCQUNEO29CQUNFLElBQUksRUFBRSxZQUFZO29CQUNsQixJQUFJLEVBQUUsV0FBVztvQkFDakIsT0FBTyxFQUFFLE9BQU87aUJBQ2pCO2FBQ0Y7U0FDRixDQUFDLEVBQ0YsSUFBSSxDQUNMLENBQUE7UUFFRCw4QkFBOEI7UUFDOUIsTUFBTSxXQUFXLENBQUMsV0FBVyxDQUMzQixJQUFJLGVBQUssQ0FBQztZQUNSLElBQUksRUFBRSxnQkFBZ0I7WUFDdEIsT0FBTyxFQUFFO2dCQUNQO29CQUNFLElBQUksRUFBRSxJQUFJO29CQUNWLElBQUksRUFBRSxNQUFNO29CQUNaLFNBQVMsRUFBRSxJQUFJO29CQUNmLGtCQUFrQixFQUFFLE1BQU07b0JBQzFCLE9BQU8sRUFBRSxvQkFBb0I7aUJBQzlCO2dCQUNEO29CQUNFLElBQUksRUFBRSxhQUFhO29CQUNuQixJQUFJLEVBQUUsTUFBTTtvQkFDWixVQUFVLEVBQUUsS0FBSztpQkFDbEI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLFdBQVc7b0JBQ2pCLElBQUksRUFBRSxTQUFTO29CQUNmLE1BQU0sRUFBRSxLQUFLO29CQUNiLFVBQVUsRUFBRSxLQUFLO29CQUNqQixRQUFRLEVBQUUsSUFBSTtpQkFDZjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsT0FBTztvQkFDYixJQUFJLEVBQUUsT0FBTztvQkFDYixVQUFVLEVBQUUsS0FBSztpQkFDbEI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLGNBQWM7b0JBQ3BCLElBQUksRUFBRSxTQUFTO29CQUNmLFNBQVMsRUFBRSxFQUFFO29CQUNiLEtBQUssRUFBRSxDQUFDO29CQUNSLFVBQVUsRUFBRSxLQUFLO2lCQUNsQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsZUFBZTtvQkFDckIsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsTUFBTSxFQUFFLElBQUk7b0JBQ1osVUFBVSxFQUFFLElBQUk7aUJBQ2pCO2dCQUNEO29CQUNFLElBQUksRUFBRSxlQUFlO29CQUNyQixJQUFJLEVBQUUsTUFBTTtvQkFDWixVQUFVLEVBQUUsSUFBSTtpQkFDakI7Z0JBQ0Q7b0JBQ0UsSUFBSSxFQUFFLFFBQVE7b0JBQ2QsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsTUFBTSxFQUFFLElBQUk7b0JBQ1osT0FBTyxFQUFFLFdBQVc7aUJBQ3JCO2dCQUNEO29CQUNFLElBQUksRUFBRSxPQUFPO29CQUNiLElBQUksRUFBRSxNQUFNO29CQUNaLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsWUFBWTtvQkFDbEIsSUFBSSxFQUFFLFdBQVc7b0JBQ2pCLE9BQU8sRUFBRSxPQUFPO2lCQUNqQjtnQkFDRDtvQkFDRSxJQUFJLEVBQUUsWUFBWTtvQkFDbEIsSUFBSSxFQUFFLFdBQVc7b0JBQ2pCLE9BQU8sRUFBRSxPQUFPO2lCQUNqQjthQUNGO1NBQ0YsQ0FBQyxFQUNGLElBQUksQ0FDTCxDQUFBO1FBRUQsaUJBQWlCO1FBQ2pCLE1BQU0sV0FBVyxDQUFDLFdBQVcsQ0FDM0IsT0FBTyxFQUNQLElBQUksb0JBQVUsQ0FBQztZQUNiLElBQUksRUFBRSx1QkFBdUI7WUFDN0IsV0FBVyxFQUFFLENBQUMsYUFBYSxDQUFDO1NBQzdCLENBQUMsQ0FDSCxDQUFBO1FBRUQsTUFBTSxXQUFXLENBQUMsV0FBVyxDQUMzQixPQUFPLEVBQ1AsSUFBSSxvQkFBVSxDQUFDO1lBQ2IsSUFBSSxFQUFFLGtCQUFrQjtZQUN4QixXQUFXLEVBQUUsQ0FBQyxRQUFRLENBQUM7U0FDeEIsQ0FBQyxDQUNILENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxXQUFXLENBQzNCLGdCQUFnQixFQUNoQixJQUFJLG9CQUFVLENBQUM7WUFDYixJQUFJLEVBQUUsZ0NBQWdDO1lBQ3RDLFdBQVcsRUFBRSxDQUFDLGFBQWEsQ0FBQztTQUM3QixDQUFDLENBQ0gsQ0FBQTtRQUVELE1BQU0sV0FBVyxDQUFDLFdBQVcsQ0FDM0IsZ0JBQWdCLEVBQ2hCLElBQUksb0JBQVUsQ0FBQztZQUNiLElBQUksRUFBRSw4QkFBOEI7WUFDcEMsV0FBVyxFQUFFLENBQUMsV0FBVyxDQUFDO1NBQzNCLENBQUMsQ0FDSCxDQUFBO1FBRUQsTUFBTSxXQUFXLENBQUMsV0FBVyxDQUMzQixnQkFBZ0IsRUFDaEIsSUFBSSxvQkFBVSxDQUFDO1lBQ2IsSUFBSSxFQUFFLDJCQUEyQjtZQUNqQyxXQUFXLEVBQUUsQ0FBQyxRQUFRLENBQUM7U0FDeEIsQ0FBQyxDQUNILENBQUE7SUFDSCxDQUFDO0lBRU0sS0FBSyxDQUFDLElBQUksQ0FBQyxXQUF3QjtRQUN4QyxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsQ0FBQTtRQUM3QyxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUE7UUFDcEMsTUFBTSxXQUFXLENBQUMsU0FBUyxDQUFDLG9CQUFvQixDQUFDLENBQUE7SUFDbkQsQ0FBQztDQUNGO0FBalBELG9FQWlQQyJ9