"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddManufacturerFieldsToProduct1733150300000 = void 0;
const typeorm_1 = require("typeorm");
class AddManufacturerFieldsToProduct1733150300000 {
    async up(queryRunner) {
        // Add manufacturer fields
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "manufacturer_id",
            type: "uuid",
            isNullable: true,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "manufacturer_sku",
            type: "varchar",
            length: "255",
            isNullable: true,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "manufacturer_part_number",
            type: "varchar",
            length: "255",
            isNullable: true,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "manufacturer_catalog_page",
            type: "int",
            isNullable: true,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "manufacturer_catalog_pdf_url",
            type: "varchar",
            length: "500",
            isNullable: true,
        }));
        await queryRunner.addColumn("product", new typeorm_1.TableColumn({
            name: "manufacturer_technical_docs",
            type: "jsonb",
            isNullable: true,
            default: "'[]'",
        }));
        // Add foreign key
        await queryRunner.createForeignKey("product", new typeorm_1.TableForeignKey({
            columnNames: ["manufacturer_id"],
            referencedColumnNames: ["id"],
            referencedTableName: "manufacturer",
            onDelete: "SET NULL",
        }));
        // Create indexes
        await queryRunner.createIndex("product", new typeorm_1.TableIndex({
            name: "IDX_product_manufacturer_id",
            columnNames: ["manufacturer_id"],
        }));
        await queryRunner.createIndex("product", new typeorm_1.TableIndex({
            name: "IDX_product_manufacturer_sku",
            columnNames: ["manufacturer_sku"],
        }));
        await queryRunner.createIndex("product", new typeorm_1.TableIndex({
            name: "IDX_product_manufacturer_part_number",
            columnNames: ["manufacturer_part_number"],
        }));
    }
    async down(queryRunner) {
        const table = await queryRunner.getTable("product");
        const foreignKey = table?.foreignKeys.find(fk => fk.columnNames.indexOf("manufacturer_id") !== -1);
        if (foreignKey) {
            await queryRunner.dropForeignKey("product", foreignKey);
        }
        await queryRunner.query(`DROP INDEX "IDX_product_manufacturer_part_number"`);
        await queryRunner.query(`DROP INDEX "IDX_product_manufacturer_sku"`);
        await queryRunner.query(`DROP INDEX "IDX_product_manufacturer_id"`);
        await queryRunner.dropColumn("product", "manufacturer_technical_docs");
        await queryRunner.dropColumn("product", "manufacturer_catalog_pdf_url");
        await queryRunner.dropColumn("product", "manufacturer_catalog_page");
        await queryRunner.dropColumn("product", "manufacturer_part_number");
        await queryRunner.dropColumn("product", "manufacturer_sku");
        await queryRunner.dropColumn("product", "manufacturer_id");
    }
}
exports.AddManufacturerFieldsToProduct1733150300000 = AddManufacturerFieldsToProduct1733150300000;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMTczMzE1MDMwMDAwMC1hZGQtbWFudWZhY3R1cmVyLWZpZWxkcy10by1wcm9kdWN0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL21pZ3JhdGlvbnMvMTczMzE1MDMwMDAwMC1hZGQtbWFudWZhY3R1cmVyLWZpZWxkcy10by1wcm9kdWN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFDQUFtRztBQUVuRyxNQUFhLDJDQUEyQztJQUMvQyxLQUFLLENBQUMsRUFBRSxDQUFDLFdBQXdCO1FBQ3RDLDBCQUEwQjtRQUMxQixNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsaUJBQWlCO1lBQ3ZCLElBQUksRUFBRSxNQUFNO1lBQ1osVUFBVSxFQUFFLElBQUk7U0FDakIsQ0FBQyxDQUNILENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsa0JBQWtCO1lBQ3hCLElBQUksRUFBRSxTQUFTO1lBQ2YsTUFBTSxFQUFFLEtBQUs7WUFDYixVQUFVLEVBQUUsSUFBSTtTQUNqQixDQUFDLENBQ0gsQ0FBQTtRQUVELE1BQU0sV0FBVyxDQUFDLFNBQVMsQ0FDekIsU0FBUyxFQUNULElBQUkscUJBQVcsQ0FBQztZQUNkLElBQUksRUFBRSwwQkFBMEI7WUFDaEMsSUFBSSxFQUFFLFNBQVM7WUFDZixNQUFNLEVBQUUsS0FBSztZQUNiLFVBQVUsRUFBRSxJQUFJO1NBQ2pCLENBQUMsQ0FDSCxDQUFBO1FBRUQsTUFBTSxXQUFXLENBQUMsU0FBUyxDQUN6QixTQUFTLEVBQ1QsSUFBSSxxQkFBVyxDQUFDO1lBQ2QsSUFBSSxFQUFFLDJCQUEyQjtZQUNqQyxJQUFJLEVBQUUsS0FBSztZQUNYLFVBQVUsRUFBRSxJQUFJO1NBQ2pCLENBQUMsQ0FDSCxDQUFBO1FBRUQsTUFBTSxXQUFXLENBQUMsU0FBUyxDQUN6QixTQUFTLEVBQ1QsSUFBSSxxQkFBVyxDQUFDO1lBQ2QsSUFBSSxFQUFFLDhCQUE4QjtZQUNwQyxJQUFJLEVBQUUsU0FBUztZQUNmLE1BQU0sRUFBRSxLQUFLO1lBQ2IsVUFBVSxFQUFFLElBQUk7U0FDakIsQ0FBQyxDQUNILENBQUE7UUFFRCxNQUFNLFdBQVcsQ0FBQyxTQUFTLENBQ3pCLFNBQVMsRUFDVCxJQUFJLHFCQUFXLENBQUM7WUFDZCxJQUFJLEVBQUUsNkJBQTZCO1lBQ25DLElBQUksRUFBRSxPQUFPO1lBQ2IsVUFBVSxFQUFFLElBQUk7WUFDaEIsT0FBTyxFQUFFLE1BQU07U0FDaEIsQ0FBQyxDQUNILENBQUE7UUFFRCxrQkFBa0I7UUFDbEIsTUFBTSxXQUFXLENBQUMsZ0JBQWdCLENBQ2hDLFNBQVMsRUFDVCxJQUFJLHlCQUFlLENBQUM7WUFDbEIsV0FBVyxFQUFFLENBQUMsaUJBQWlCLENBQUM7WUFDaEMscUJBQXFCLEVBQUUsQ0FBQyxJQUFJLENBQUM7WUFDN0IsbUJBQW1CLEVBQUUsY0FBYztZQUNuQyxRQUFRLEVBQUUsVUFBVTtTQUNyQixDQUFDLENBQ0gsQ0FBQTtRQUVELGlCQUFpQjtRQUNqQixNQUFNLFdBQVcsQ0FBQyxXQUFXLENBQzNCLFNBQVMsRUFDVCxJQUFJLG9CQUFVLENBQUM7WUFDYixJQUFJLEVBQUUsNkJBQTZCO1lBQ25DLFdBQVcsRUFBRSxDQUFDLGlCQUFpQixDQUFDO1NBQ2pDLENBQUMsQ0FDSCxDQUFBO1FBRUQsTUFBTSxXQUFXLENBQUMsV0FBVyxDQUMzQixTQUFTLEVBQ1QsSUFBSSxvQkFBVSxDQUFDO1lBQ2IsSUFBSSxFQUFFLDhCQUE4QjtZQUNwQyxXQUFXLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQztTQUNsQyxDQUFDLENBQ0gsQ0FBQTtRQUVELE1BQU0sV0FBVyxDQUFDLFdBQVcsQ0FDM0IsU0FBUyxFQUNULElBQUksb0JBQVUsQ0FBQztZQUNiLElBQUksRUFBRSxzQ0FBc0M7WUFDNUMsV0FBVyxFQUFFLENBQUMsMEJBQTBCLENBQUM7U0FDMUMsQ0FBQyxDQUNILENBQUE7SUFDSCxDQUFDO0lBRU0sS0FBSyxDQUFDLElBQUksQ0FBQyxXQUF3QjtRQUN4QyxNQUFNLEtBQUssR0FBRyxNQUFNLFdBQVcsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUE7UUFDbkQsTUFBTSxVQUFVLEdBQUcsS0FBSyxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQ3hDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FDdkQsQ0FBQTtRQUNELElBQUksVUFBVSxFQUFFLENBQUM7WUFDZixNQUFNLFdBQVcsQ0FBQyxjQUFjLENBQUMsU0FBUyxFQUFFLFVBQVUsQ0FBQyxDQUFBO1FBQ3pELENBQUM7UUFFRCxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsbURBQW1ELENBQUMsQ0FBQTtRQUM1RSxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsMkNBQTJDLENBQUMsQ0FBQTtRQUNwRSxNQUFNLFdBQVcsQ0FBQyxLQUFLLENBQUMsMENBQTBDLENBQUMsQ0FBQTtRQUVuRSxNQUFNLFdBQVcsQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLDZCQUE2QixDQUFDLENBQUE7UUFDdEUsTUFBTSxXQUFXLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSw4QkFBOEIsQ0FBQyxDQUFBO1FBQ3ZFLE1BQU0sV0FBVyxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsMkJBQTJCLENBQUMsQ0FBQTtRQUNwRSxNQUFNLFdBQVcsQ0FBQyxVQUFVLENBQUMsU0FBUyxFQUFFLDBCQUEwQixDQUFDLENBQUE7UUFDbkUsTUFBTSxXQUFXLENBQUMsVUFBVSxDQUFDLFNBQVMsRUFBRSxrQkFBa0IsQ0FBQyxDQUFBO1FBQzNELE1BQU0sV0FBVyxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsaUJBQWlCLENBQUMsQ0FBQTtJQUM1RCxDQUFDO0NBQ0Y7QUF0SEQsa0dBc0hDIn0=