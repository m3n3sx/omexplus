"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InPostShippingProvider = void 0;
const shipping_base_1 = require("./shipping-base");
class InPostShippingProvider extends shipping_base_1.ShippingProviderBase {
    constructor(config) {
        super({
            apiKey: config.apiKey,
            apiSecret: config.apiSecret,
            baseUrl: config.baseUrl || "https://api-shipx-pl.easypack24.net/v1",
            providerName: "InPost",
        });
        this.orgId = config.orgId;
    }
    async getOrganizations() {
        try {
            const response = await this.makeRequest("/organizations");
            return response.items || [];
        }
        catch (error) {
            console.error("Failed to fetch InPost organizations:", error);
            return [];
        }
    }
    async calculateRate(origin, destination, parcel, serviceType) {
        const rates = [];
        const weightSurcharge = this.calculateWeightSurcharge(parcel.weight);
        // InPost Paczkomat 24/7
        if (!serviceType || serviceType === "paczkomat_24_7") {
            rates.push({
                provider: "inpost",
                method: "paczkomat_24_7",
                price: 4.99 + weightSurcharge,
                delivery_days: 2,
                currency: "USD",
            });
        }
        // InPost Courier
        if (!serviceType || serviceType === "courier") {
            rates.push({
                provider: "inpost",
                method: "courier",
                price: 7.99 + weightSurcharge,
                delivery_days: 2,
                currency: "USD",
            });
        }
        // InPost Standard Locker
        if (!serviceType || serviceType === "parcel_locker") {
            rates.push({
                provider: "inpost",
                method: "parcel_locker",
                price: 3.99 + weightSurcharge,
                delivery_days: 2,
                currency: "USD",
            });
        }
        return rates;
    }
    async createShipment(order, shippingMethod, parcel) {
        const shippingAddress = order.shipping_address;
        if (!shippingAddress) {
            throw new Error("Order missing shipping address");
        }
        const shipmentRequest = {
            receiver: {
                name: `${shippingAddress.first_name} ${shippingAddress.last_name}`,
                email: order.email || "",
                phone: shippingAddress.phone || "",
                address: {
                    street: shippingAddress.address_1 || "",
                    building_number: shippingAddress.address_2 || "1",
                    city: shippingAddress.city || "",
                    post_code: shippingAddress.postal_code || "",
                    country_code: shippingAddress.country_code || "PL",
                },
            },
            parcels: [
                {
                    dimensions: {
                        length: parcel.length.toString(),
                        width: parcel.width.toString(),
                        height: parcel.height.toString(),
                        unit: "cm",
                    },
                    weight: {
                        amount: (parcel.weight / 1000).toString(),
                        unit: "kg",
                    },
                },
            ],
            service: shippingMethod,
            reference: order.id,
            sender: {
                name: "OMEX B2B",
                email: "shipping@omex.com",
                phone: "+48123456789",
                address: {
                    street: "Warehouse Street",
                    building_number: "1",
                    city: "Warsaw",
                    post_code: "00-001",
                    country_code: "PL",
                },
            },
        };
        try {
            const response = await this.makeRequest("/organizations/" + this.orgId + "/shipments", "POST", shipmentRequest);
            return {
                shipment_id: response.id,
                tracking_number: response.tracking_number,
                label_url: response.label_url || "",
                provider: "inpost",
                status: "pending",
            };
        }
        catch (error) {
            console.error("InPost shipment creation failed:", error);
            throw new Error(`Failed to create InPost shipment: ${error.message}`);
        }
    }
    async generateLabel(shipmentId) {
        try {
            const response = await this.makeRequest(`/shipments/${shipmentId}/label`, "GET");
            return response.label_url || response.url || "";
        }
        catch (error) {
            console.error("InPost label generation failed:", error);
            throw new Error(`Failed to generate InPost label: ${error.message}`);
        }
    }
    async trackShipment(trackingNumber) {
        try {
            const response = await this.makeRequest(`/tracking/${trackingNumber}`);
            const events = (response.tracking_details || []).map((detail) => ({
                timestamp: new Date(detail.datetime),
                status: detail.status,
                location: detail.location || "",
                description: detail.description || "",
            }));
            return {
                tracking_number: trackingNumber,
                status: response.status || "unknown",
                events,
            };
        }
        catch (error) {
            console.error("InPost tracking failed:", error);
            throw new Error(`Failed to track InPost shipment: ${error.message}`);
        }
    }
    async cancelShipment(shipmentId) {
        try {
            await this.makeRequest(`/shipments/${shipmentId}`, "DELETE");
            return true;
        }
        catch (error) {
            console.error("InPost shipment cancellation failed:", error);
            return false;
        }
    }
}
exports.InPostShippingProvider = InPostShippingProvider;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2hpcHBpbmctaW5wb3N0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3NlcnZpY2VzL3NoaXBwaW5nLWlucG9zdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxtREFReUI7QUF3RHpCLE1BQWEsc0JBQXVCLFNBQVEsb0NBQW9CO0lBRzlELFlBQVksTUFBb0I7UUFDOUIsS0FBSyxDQUFDO1lBQ0osTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO1lBQ3JCLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztZQUMzQixPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sSUFBSSx3Q0FBd0M7WUFDbkUsWUFBWSxFQUFFLFFBQVE7U0FDdkIsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDO0lBQzVCLENBQUM7SUFFRCxLQUFLLENBQUMsZ0JBQWdCO1FBQ3BCLElBQUksQ0FBQztZQUNILE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQzFELE9BQU8sUUFBUSxDQUFDLEtBQUssSUFBSSxFQUFFLENBQUM7UUFDOUIsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLHVDQUF1QyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzlELE9BQU8sRUFBRSxDQUFDO1FBQ1osQ0FBQztJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsYUFBYSxDQUNqQixNQUF1QixFQUN2QixXQUE0QixFQUM1QixNQUF3QixFQUN4QixXQUFvQjtRQUVwQixNQUFNLEtBQUssR0FBbUIsRUFBRSxDQUFDO1FBQ2pDLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFckUsd0JBQXdCO1FBQ3hCLElBQUksQ0FBQyxXQUFXLElBQUksV0FBVyxLQUFLLGdCQUFnQixFQUFFLENBQUM7WUFDckQsS0FBSyxDQUFDLElBQUksQ0FBQztnQkFDVCxRQUFRLEVBQUUsUUFBUTtnQkFDbEIsTUFBTSxFQUFFLGdCQUFnQjtnQkFDeEIsS0FBSyxFQUFFLElBQUksR0FBRyxlQUFlO2dCQUM3QixhQUFhLEVBQUUsQ0FBQztnQkFDaEIsUUFBUSxFQUFFLEtBQUs7YUFDaEIsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVELGlCQUFpQjtRQUNqQixJQUFJLENBQUMsV0FBVyxJQUFJLFdBQVcsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUM5QyxLQUFLLENBQUMsSUFBSSxDQUFDO2dCQUNULFFBQVEsRUFBRSxRQUFRO2dCQUNsQixNQUFNLEVBQUUsU0FBUztnQkFDakIsS0FBSyxFQUFFLElBQUksR0FBRyxlQUFlO2dCQUM3QixhQUFhLEVBQUUsQ0FBQztnQkFDaEIsUUFBUSxFQUFFLEtBQUs7YUFDaEIsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVELHlCQUF5QjtRQUN6QixJQUFJLENBQUMsV0FBVyxJQUFJLFdBQVcsS0FBSyxlQUFlLEVBQUUsQ0FBQztZQUNwRCxLQUFLLENBQUMsSUFBSSxDQUFDO2dCQUNULFFBQVEsRUFBRSxRQUFRO2dCQUNsQixNQUFNLEVBQUUsZUFBZTtnQkFDdkIsS0FBSyxFQUFFLElBQUksR0FBRyxlQUFlO2dCQUM3QixhQUFhLEVBQUUsQ0FBQztnQkFDaEIsUUFBUSxFQUFFLEtBQUs7YUFDaEIsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVELEtBQUssQ0FBQyxjQUFjLENBQ2xCLEtBQWUsRUFDZixjQUFzQixFQUN0QixNQUF3QjtRQUV4QixNQUFNLGVBQWUsR0FBRyxLQUFLLENBQUMsZ0JBQWdCLENBQUM7UUFDL0MsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQ3JCLE1BQU0sSUFBSSxLQUFLLENBQUMsZ0NBQWdDLENBQUMsQ0FBQztRQUNwRCxDQUFDO1FBRUQsTUFBTSxlQUFlLEdBQTBCO1lBQzdDLFFBQVEsRUFBRTtnQkFDUixJQUFJLEVBQUUsR0FBRyxlQUFlLENBQUMsVUFBVSxJQUFJLGVBQWUsQ0FBQyxTQUFTLEVBQUU7Z0JBQ2xFLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSyxJQUFJLEVBQUU7Z0JBQ3hCLEtBQUssRUFBRSxlQUFlLENBQUMsS0FBSyxJQUFJLEVBQUU7Z0JBQ2xDLE9BQU8sRUFBRTtvQkFDUCxNQUFNLEVBQUUsZUFBZSxDQUFDLFNBQVMsSUFBSSxFQUFFO29CQUN2QyxlQUFlLEVBQUUsZUFBZSxDQUFDLFNBQVMsSUFBSSxHQUFHO29CQUNqRCxJQUFJLEVBQUUsZUFBZSxDQUFDLElBQUksSUFBSSxFQUFFO29CQUNoQyxTQUFTLEVBQUUsZUFBZSxDQUFDLFdBQVcsSUFBSSxFQUFFO29CQUM1QyxZQUFZLEVBQUUsZUFBZSxDQUFDLFlBQVksSUFBSSxJQUFJO2lCQUNuRDthQUNGO1lBQ0QsT0FBTyxFQUFFO2dCQUNQO29CQUNFLFVBQVUsRUFBRTt3QkFDVixNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUU7d0JBQ2hDLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRTt3QkFDOUIsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFO3dCQUNoQyxJQUFJLEVBQUUsSUFBSTtxQkFDWDtvQkFDRCxNQUFNLEVBQUU7d0JBQ04sTUFBTSxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUU7d0JBQ3pDLElBQUksRUFBRSxJQUFJO3FCQUNYO2lCQUNGO2FBQ0Y7WUFDRCxPQUFPLEVBQUUsY0FBYztZQUN2QixTQUFTLEVBQUUsS0FBSyxDQUFDLEVBQUU7WUFDbkIsTUFBTSxFQUFFO2dCQUNOLElBQUksRUFBRSxVQUFVO2dCQUNoQixLQUFLLEVBQUUsbUJBQW1CO2dCQUMxQixLQUFLLEVBQUUsY0FBYztnQkFDckIsT0FBTyxFQUFFO29CQUNQLE1BQU0sRUFBRSxrQkFBa0I7b0JBQzFCLGVBQWUsRUFBRSxHQUFHO29CQUNwQixJQUFJLEVBQUUsUUFBUTtvQkFDZCxTQUFTLEVBQUUsUUFBUTtvQkFDbkIsWUFBWSxFQUFFLElBQUk7aUJBQ25CO2FBQ0Y7U0FDRixDQUFDO1FBRUYsSUFBSSxDQUFDO1lBQ0gsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsWUFBWSxFQUFFLE1BQU0sRUFBRSxlQUFlLENBQUMsQ0FBQztZQUVoSCxPQUFPO2dCQUNMLFdBQVcsRUFBRSxRQUFRLENBQUMsRUFBRTtnQkFDeEIsZUFBZSxFQUFFLFFBQVEsQ0FBQyxlQUFlO2dCQUN6QyxTQUFTLEVBQUUsUUFBUSxDQUFDLFNBQVMsSUFBSSxFQUFFO2dCQUNuQyxRQUFRLEVBQUUsUUFBUTtnQkFDbEIsTUFBTSxFQUFFLFNBQVM7YUFDbEIsQ0FBQztRQUNKLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyxrQ0FBa0MsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN6RCxNQUFNLElBQUksS0FBSyxDQUFDLHFDQUFxQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUN4RSxDQUFDO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxhQUFhLENBQUMsVUFBa0I7UUFDcEMsSUFBSSxDQUFDO1lBQ0gsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsVUFBVSxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDakYsT0FBTyxRQUFRLENBQUMsU0FBUyxJQUFJLFFBQVEsQ0FBQyxHQUFHLElBQUksRUFBRSxDQUFDO1FBQ2xELENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN4RCxNQUFNLElBQUksS0FBSyxDQUFDLG9DQUFvQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUN2RSxDQUFDO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxhQUFhLENBQUMsY0FBc0I7UUFDeEMsSUFBSSxDQUFDO1lBQ0gsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsY0FBYyxFQUFFLENBQUMsQ0FBQztZQUV2RSxNQUFNLE1BQU0sR0FBb0IsQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLElBQUksRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBVyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUN0RixTQUFTLEVBQUUsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztnQkFDcEMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO2dCQUNyQixRQUFRLEVBQUUsTUFBTSxDQUFDLFFBQVEsSUFBSSxFQUFFO2dCQUMvQixXQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVcsSUFBSSxFQUFFO2FBQ3RDLENBQUMsQ0FBQyxDQUFDO1lBRUosT0FBTztnQkFDTCxlQUFlLEVBQUUsY0FBYztnQkFDL0IsTUFBTSxFQUFFLFFBQVEsQ0FBQyxNQUFNLElBQUksU0FBUztnQkFDcEMsTUFBTTthQUNQLENBQUM7UUFDSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMseUJBQXlCLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDaEQsTUFBTSxJQUFJLEtBQUssQ0FBQyxvQ0FBb0MsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDdkUsQ0FBQztJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsY0FBYyxDQUFDLFVBQWtCO1FBQ3JDLElBQUksQ0FBQztZQUNILE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLFVBQVUsRUFBRSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1lBQzdELE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLHNDQUFzQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzdELE9BQU8sS0FBSyxDQUFDO1FBQ2YsQ0FBQztJQUNILENBQUM7Q0FDRjtBQWxMRCx3REFrTEMifQ==