"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const medusa_1 = require("@medusajs/medusa");
class PaymentService extends medusa_1.TransactionBaseService {
    constructor(container) {
        super(container);
        this.stripe_ = container.stripe;
        this.logger_ = container.logger;
    }
    /**
     * Create a Stripe PaymentIntent
     */
    async createPaymentIntent(params) {
        try {
            const { amount, currency, metadata, customer_email } = params;
            // Validate amount
            if (amount <= 0) {
                throw new Error('Payment amount must be greater than 0');
            }
            const paymentIntent = await this.stripe_.paymentIntents.create({
                amount: Math.round(amount * 100), // Convert to cents
                currency: currency.toLowerCase(),
                metadata: metadata || {},
                receipt_email: customer_email,
                automatic_payment_methods: {
                    enabled: true,
                },
            });
            this.logger_.info(`PaymentIntent created: ${paymentIntent.id}`);
            return {
                clientSecret: paymentIntent.client_secret,
                paymentIntentId: paymentIntent.id,
            };
        }
        catch (error) {
            this.logger_.error('Failed to create PaymentIntent:', error);
            throw new Error(`Payment intent creation failed: ${error.message}`);
        }
    }
    /**
     * Confirm a PaymentIntent (charge the card)
     */
    async confirmPaymentIntent(paymentIntentId, paymentMethodId) {
        try {
            const confirmParams = {};
            if (paymentMethodId) {
                confirmParams.payment_method = paymentMethodId;
            }
            const paymentIntent = await this.stripe_.paymentIntents.confirm(paymentIntentId, confirmParams);
            this.logger_.info(`PaymentIntent confirmed: ${paymentIntent.id}, status: ${paymentIntent.status}`);
            return {
                status: paymentIntent.status,
                chargeId: paymentIntent.latest_charge,
            };
        }
        catch (error) {
            this.logger_.error('Failed to confirm PaymentIntent:', error);
            // Handle specific Stripe errors
            if (error.type === 'StripeCardError') {
                throw new Error(`Card declined: ${error.message}`);
            }
            else if (error.type === 'StripeAuthenticationError') {
                throw new Error('3D Secure authentication required');
            }
            throw new Error(`Payment confirmation failed: ${error.message}`);
        }
    }
    /**
     * Capture a payment (for authorized payments)
     */
    async capturePayment(paymentIntentId, amount) {
        try {
            const captureParams = {};
            if (amount) {
                captureParams.amount_to_capture = Math.round(amount * 100);
            }
            const paymentIntent = await this.stripe_.paymentIntents.capture(paymentIntentId, captureParams);
            this.logger_.info(`Payment captured: ${paymentIntent.id}`);
            return {
                status: paymentIntent.status,
                capturedAmount: paymentIntent.amount_received / 100,
            };
        }
        catch (error) {
            this.logger_.error('Failed to capture payment:', error);
            throw new Error(`Payment capture failed: ${error.message}`);
        }
    }
    /**
     * Refund a payment
     */
    async refundPayment(paymentIntentId, amount, reason) {
        try {
            const refundParams = {
                payment_intent: paymentIntentId,
            };
            if (amount) {
                refundParams.amount = Math.round(amount * 100);
            }
            if (reason) {
                refundParams.reason = reason;
            }
            const refund = await this.stripe_.refunds.create(refundParams);
            this.logger_.info(`Refund created: ${refund.id}`);
            return {
                refundId: refund.id,
                status: refund.status,
                amount: refund.amount / 100,
            };
        }
        catch (error) {
            this.logger_.error('Failed to create refund:', error);
            throw new Error(`Refund failed: ${error.message}`);
        }
    }
    /**
     * Get payment status
     */
    async getPaymentStatus(paymentIntentId) {
        try {
            const paymentIntent = await this.stripe_.paymentIntents.retrieve(paymentIntentId);
            return {
                status: paymentIntent.status,
                amount: paymentIntent.amount / 100,
                currency: paymentIntent.currency,
                chargeId: paymentIntent.latest_charge,
            };
        }
        catch (error) {
            this.logger_.error('Failed to retrieve payment status:', error);
            throw new Error(`Failed to get payment status: ${error.message}`);
        }
    }
    /**
     * Cancel a PaymentIntent
     */
    async cancelPaymentIntent(paymentIntentId) {
        try {
            await this.stripe_.paymentIntents.cancel(paymentIntentId);
            this.logger_.info(`PaymentIntent cancelled: ${paymentIntentId}`);
        }
        catch (error) {
            this.logger_.error('Failed to cancel PaymentIntent:', error);
            throw new Error(`Payment cancellation failed: ${error.message}`);
        }
    }
}
exports.default = PaymentService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGF5bWVudC1zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3NlcnZpY2VzL3BheW1lbnQtc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLDZDQUEwRDtBQWtCMUQsTUFBTSxjQUFlLFNBQVEsK0JBQXNCO0lBSWpELFlBQVksU0FBYztRQUN4QixLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDakIsSUFBSSxDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUMsTUFBTSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQztJQUNsQyxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsbUJBQW1CLENBQUMsTUFBaUM7UUFJekQsSUFBSSxDQUFDO1lBQ0gsTUFBTSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLGNBQWMsRUFBRSxHQUFHLE1BQU0sQ0FBQztZQUU5RCxrQkFBa0I7WUFDbEIsSUFBSSxNQUFNLElBQUksQ0FBQyxFQUFFLENBQUM7Z0JBQ2hCLE1BQU0sSUFBSSxLQUFLLENBQUMsdUNBQXVDLENBQUMsQ0FBQztZQUMzRCxDQUFDO1lBRUQsTUFBTSxhQUFhLEdBQUcsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUM7Z0JBQzdELE1BQU0sRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUMsRUFBRSxtQkFBbUI7Z0JBQ3JELFFBQVEsRUFBRSxRQUFRLENBQUMsV0FBVyxFQUFFO2dCQUNoQyxRQUFRLEVBQUUsUUFBUSxJQUFJLEVBQUU7Z0JBQ3hCLGFBQWEsRUFBRSxjQUFjO2dCQUM3Qix5QkFBeUIsRUFBRTtvQkFDekIsT0FBTyxFQUFFLElBQUk7aUJBQ2Q7YUFDRixDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQywwQkFBMEIsYUFBYSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFFaEUsT0FBTztnQkFDTCxZQUFZLEVBQUUsYUFBYSxDQUFDLGFBQWM7Z0JBQzFDLGVBQWUsRUFBRSxhQUFhLENBQUMsRUFBRTthQUNsQyxDQUFDO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUM3RCxNQUFNLElBQUksS0FBSyxDQUFDLG1DQUFtQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUN0RSxDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLG9CQUFvQixDQUN4QixlQUF1QixFQUN2QixlQUF3QjtRQUt4QixJQUFJLENBQUM7WUFDSCxNQUFNLGFBQWEsR0FBUSxFQUFFLENBQUM7WUFDOUIsSUFBSSxlQUFlLEVBQUUsQ0FBQztnQkFDcEIsYUFBYSxDQUFDLGNBQWMsR0FBRyxlQUFlLENBQUM7WUFDakQsQ0FBQztZQUVELE1BQU0sYUFBYSxHQUFHLE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUM3RCxlQUFlLEVBQ2YsYUFBYSxDQUNkLENBQUM7WUFFRixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyw0QkFBNEIsYUFBYSxDQUFDLEVBQUUsYUFBYSxhQUFhLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUVuRyxPQUFPO2dCQUNMLE1BQU0sRUFBRSxhQUFhLENBQUMsTUFBTTtnQkFDNUIsUUFBUSxFQUFFLGFBQWEsQ0FBQyxhQUF1QjthQUNoRCxDQUFDO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxrQ0FBa0MsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUU5RCxnQ0FBZ0M7WUFDaEMsSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLGlCQUFpQixFQUFFLENBQUM7Z0JBQ3JDLE1BQU0sSUFBSSxLQUFLLENBQUMsa0JBQWtCLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQ3JELENBQUM7aUJBQU0sSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLDJCQUEyQixFQUFFLENBQUM7Z0JBQ3RELE1BQU0sSUFBSSxLQUFLLENBQUMsbUNBQW1DLENBQUMsQ0FBQztZQUN2RCxDQUFDO1lBRUQsTUFBTSxJQUFJLEtBQUssQ0FBQyxnQ0FBZ0MsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDbkUsQ0FBQztJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxjQUFjLENBQUMsZUFBdUIsRUFBRSxNQUFlO1FBSTNELElBQUksQ0FBQztZQUNILE1BQU0sYUFBYSxHQUFRLEVBQUUsQ0FBQztZQUM5QixJQUFJLE1BQU0sRUFBRSxDQUFDO2dCQUNYLGFBQWEsQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUMsQ0FBQztZQUM3RCxDQUFDO1lBRUQsTUFBTSxhQUFhLEdBQUcsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQzdELGVBQWUsRUFDZixhQUFhLENBQ2QsQ0FBQztZQUVGLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLHFCQUFxQixhQUFhLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUUzRCxPQUFPO2dCQUNMLE1BQU0sRUFBRSxhQUFhLENBQUMsTUFBTTtnQkFDNUIsY0FBYyxFQUFFLGFBQWEsQ0FBQyxlQUFlLEdBQUcsR0FBRzthQUNwRCxDQUFDO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyw0QkFBNEIsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN4RCxNQUFNLElBQUksS0FBSyxDQUFDLDJCQUEyQixLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUM5RCxDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGFBQWEsQ0FDakIsZUFBdUIsRUFDdkIsTUFBZSxFQUNmLE1BQWU7UUFNZixJQUFJLENBQUM7WUFDSCxNQUFNLFlBQVksR0FBUTtnQkFDeEIsY0FBYyxFQUFFLGVBQWU7YUFDaEMsQ0FBQztZQUVGLElBQUksTUFBTSxFQUFFLENBQUM7Z0JBQ1gsWUFBWSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUMsQ0FBQztZQUNqRCxDQUFDO1lBRUQsSUFBSSxNQUFNLEVBQUUsQ0FBQztnQkFDWCxZQUFZLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztZQUMvQixDQUFDO1lBRUQsTUFBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFL0QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLE1BQU0sQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBRWxELE9BQU87Z0JBQ0wsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO2dCQUNuQixNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07Z0JBQ3JCLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTSxHQUFHLEdBQUc7YUFDNUIsQ0FBQztRQUNKLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsMEJBQTBCLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDdEQsTUFBTSxJQUFJLEtBQUssQ0FBQyxrQkFBa0IsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDckQsQ0FBQztJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxlQUF1QjtRQU01QyxJQUFJLENBQUM7WUFDSCxNQUFNLGFBQWEsR0FBRyxNQUFNLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FDOUQsZUFBZSxDQUNoQixDQUFDO1lBRUYsT0FBTztnQkFDTCxNQUFNLEVBQUUsYUFBYSxDQUFDLE1BQU07Z0JBQzVCLE1BQU0sRUFBRSxhQUFhLENBQUMsTUFBTSxHQUFHLEdBQUc7Z0JBQ2xDLFFBQVEsRUFBRSxhQUFhLENBQUMsUUFBUTtnQkFDaEMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxhQUF1QjthQUNoRCxDQUFDO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxvQ0FBb0MsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNoRSxNQUFNLElBQUksS0FBSyxDQUFDLGlDQUFpQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUNwRSxDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLG1CQUFtQixDQUFDLGVBQXVCO1FBQy9DLElBQUksQ0FBQztZQUNILE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBQzFELElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLDRCQUE0QixlQUFlLEVBQUUsQ0FBQyxDQUFDO1FBQ25FLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsaUNBQWlDLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDN0QsTUFBTSxJQUFJLEtBQUssQ0FBQyxnQ0FBZ0MsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDbkUsQ0FBQztJQUNILENBQUM7Q0FDRjtBQUVELGtCQUFlLGNBQWMsQ0FBQyJ9