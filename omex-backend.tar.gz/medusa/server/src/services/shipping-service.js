"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShippingService = void 0;
const shipping_inpost_1 = require("./shipping-inpost");
const shipping_dpd_1 = require("./shipping-dpd");
const shipping_dhl_1 = require("./shipping-dhl");
class ShippingService {
    constructor(config) {
        this.providers = new Map();
        if (config.inpost) {
            this.providers.set("inpost", new shipping_inpost_1.InPostShippingProvider(config.inpost));
        }
        if (config.dpd) {
            this.providers.set("dpd", new shipping_dpd_1.DPDShippingProvider(config.dpd));
        }
        if (config.dhl) {
            this.providers.set("dhl", new shipping_dhl_1.DHLShippingProvider(config.dhl));
        }
    }
    selectProvider(destination, method) {
        const country = destination.country?.toUpperCase() || "";
        // InPost for Poland
        if (country === "PL" || country === "POL") {
            return "inpost";
        }
        // DPD for EU countries
        const euCountries = ["DE", "FR", "IT", "ES", "NL", "BE", "AT", "CZ", "SK", "HU", "RO", "BG"];
        if (euCountries.includes(country)) {
            return "dpd";
        }
        // DHL for global
        return "dhl";
    }
    async getRates(origin, destination, parcel) {
        const allRates = [];
        try {
            // Get rates from all available providers
            for (const [providerName, provider] of this.providers) {
                try {
                    const rates = await provider.calculateRate(origin, destination, parcel);
                    allRates.push(...rates);
                }
                catch (error) {
                    console.error(`Failed to get rates from ${providerName}:`, error);
                }
            }
            // Sort by price
            return allRates.sort((a, b) => a.price - b.price);
        }
        catch (error) {
            console.error("Failed to get shipping rates:", error);
            throw new Error("Unable to calculate shipping rates");
        }
    }
    async createShipment(order, shippingMethod, parcel, providerName) {
        try {
            // Auto-select provider if not specified
            if (!providerName && order.shipping_address) {
                providerName = this.selectProvider(order.shipping_address, shippingMethod);
            }
            if (!providerName) {
                throw new Error("Unable to determine shipping provider");
            }
            const provider = this.providers.get(providerName);
            if (!provider) {
                throw new Error(`Shipping provider ${providerName} not configured`);
            }
            return await provider.createShipment(order, shippingMethod, parcel);
        }
        catch (error) {
            console.error("Failed to create shipment:", error);
            throw error;
        }
    }
    async getLabel(shipmentId, providerName) {
        const provider = this.providers.get(providerName);
        if (!provider) {
            throw new Error(`Shipping provider ${providerName} not configured`);
        }
        return await provider.generateLabel(shipmentId);
    }
    async track(trackingNumber, providerName) {
        const provider = this.providers.get(providerName);
        if (!provider) {
            throw new Error(`Shipping provider ${providerName} not configured`);
        }
        return await provider.trackShipment(trackingNumber);
    }
    async cancelShipment(shipmentId, providerName) {
        const provider = this.providers.get(providerName);
        if (!provider) {
            throw new Error(`Shipping provider ${providerName} not configured`);
        }
        return await provider.cancelShipment(shipmentId);
    }
    getAvailableProviders() {
        return Array.from(this.providers.keys());
    }
}
exports.ShippingService = ShippingService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2hpcHBpbmctc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zZXJ2aWNlcy9zaGlwcGluZy1zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUNBLHVEQUEyRDtBQUMzRCxpREFBcUQ7QUFDckQsaURBQXFEO0FBMkJyRCxNQUFhLGVBQWU7SUFHMUIsWUFBWSxNQUE2QjtRQUZqQyxjQUFTLEdBQXNDLElBQUksR0FBRyxFQUFFLENBQUM7UUFHL0QsSUFBSSxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDbEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLElBQUksd0NBQXNCLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDMUUsQ0FBQztRQUNELElBQUksTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksa0NBQW1CLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDakUsQ0FBQztRQUNELElBQUksTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksa0NBQW1CLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDakUsQ0FBQztJQUNILENBQUM7SUFFTyxjQUFjLENBQUMsV0FBNEIsRUFBRSxNQUFlO1FBQ2xFLE1BQU0sT0FBTyxHQUFHLFdBQVcsQ0FBQyxPQUFPLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxDQUFDO1FBRXpELG9CQUFvQjtRQUNwQixJQUFJLE9BQU8sS0FBSyxJQUFJLElBQUksT0FBTyxLQUFLLEtBQUssRUFBRSxDQUFDO1lBQzFDLE9BQU8sUUFBUSxDQUFDO1FBQ2xCLENBQUM7UUFFRCx1QkFBdUI7UUFDdkIsTUFBTSxXQUFXLEdBQUcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzdGLElBQUksV0FBVyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1lBQ2xDLE9BQU8sS0FBSyxDQUFDO1FBQ2YsQ0FBQztRQUVELGlCQUFpQjtRQUNqQixPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFFRCxLQUFLLENBQUMsUUFBUSxDQUNaLE1BQXVCLEVBQ3ZCLFdBQTRCLEVBQzVCLE1BQXdCO1FBRXhCLE1BQU0sUUFBUSxHQUFtQixFQUFFLENBQUM7UUFFcEMsSUFBSSxDQUFDO1lBQ0gseUNBQXlDO1lBQ3pDLEtBQUssTUFBTSxDQUFDLFlBQVksRUFBRSxRQUFRLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQ3RELElBQUksQ0FBQztvQkFDSCxNQUFNLEtBQUssR0FBRyxNQUFNLFFBQVEsQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLFdBQVcsRUFBRSxNQUFNLENBQUMsQ0FBQztvQkFDeEUsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDO2dCQUMxQixDQUFDO2dCQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7b0JBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyw0QkFBNEIsWUFBWSxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQ3BFLENBQUM7WUFDSCxDQUFDO1lBRUQsZ0JBQWdCO1lBQ2hCLE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3BELENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQywrQkFBK0IsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN0RCxNQUFNLElBQUksS0FBSyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7UUFDeEQsQ0FBQztJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsY0FBYyxDQUNsQixLQUFlLEVBQ2YsY0FBc0IsRUFDdEIsTUFBd0IsRUFDeEIsWUFBcUI7UUFFckIsSUFBSSxDQUFDO1lBQ0gsd0NBQXdDO1lBQ3hDLElBQUksQ0FBQyxZQUFZLElBQUksS0FBSyxDQUFDLGdCQUFnQixFQUFFLENBQUM7Z0JBQzVDLFlBQVksR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsRUFBRSxjQUFjLENBQUMsQ0FBQztZQUM3RSxDQUFDO1lBRUQsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUNsQixNQUFNLElBQUksS0FBSyxDQUFDLHVDQUF1QyxDQUFDLENBQUM7WUFDM0QsQ0FBQztZQUVELE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ2xELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQkFDZCxNQUFNLElBQUksS0FBSyxDQUFDLHFCQUFxQixZQUFZLGlCQUFpQixDQUFDLENBQUM7WUFDdEUsQ0FBQztZQUVELE9BQU8sTUFBTSxRQUFRLENBQUMsY0FBYyxDQUFDLEtBQUssRUFBRSxjQUFjLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDdEUsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLDRCQUE0QixFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ25ELE1BQU0sS0FBSyxDQUFDO1FBQ2QsQ0FBQztJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQWtCLEVBQUUsWUFBb0I7UUFDckQsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDbEQsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ2QsTUFBTSxJQUFJLEtBQUssQ0FBQyxxQkFBcUIsWUFBWSxpQkFBaUIsQ0FBQyxDQUFDO1FBQ3RFLENBQUM7UUFFRCxPQUFPLE1BQU0sUUFBUSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBRUQsS0FBSyxDQUFDLEtBQUssQ0FBQyxjQUFzQixFQUFFLFlBQW9CO1FBQ3RELE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ2xELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNkLE1BQU0sSUFBSSxLQUFLLENBQUMscUJBQXFCLFlBQVksaUJBQWlCLENBQUMsQ0FBQztRQUN0RSxDQUFDO1FBRUQsT0FBTyxNQUFNLFFBQVEsQ0FBQyxhQUFhLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDdEQsQ0FBQztJQUVELEtBQUssQ0FBQyxjQUFjLENBQUMsVUFBa0IsRUFBRSxZQUFvQjtRQUMzRCxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUNsRCxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDZCxNQUFNLElBQUksS0FBSyxDQUFDLHFCQUFxQixZQUFZLGlCQUFpQixDQUFDLENBQUM7UUFDdEUsQ0FBQztRQUVELE9BQU8sTUFBTSxRQUFRLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFRCxxQkFBcUI7UUFDbkIsT0FBTyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztJQUMzQyxDQUFDO0NBQ0Y7QUFySEQsMENBcUhDIn0=