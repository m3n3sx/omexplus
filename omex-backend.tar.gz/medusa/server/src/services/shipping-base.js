"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShippingProviderBase = void 0;
class ShippingProviderBase {
    constructor(config) {
        this.apiKey = config.apiKey;
        this.apiSecret = config.apiSecret;
        this.baseUrl = config.baseUrl;
        this.providerName = config.providerName;
    }
    async makeRequest(endpoint, method = "GET", data, headers) {
        const url = `${this.baseUrl}${endpoint}`;
        const defaultHeaders = {
            "Content-Type": "application/json",
            Authorization: `Bearer ${this.apiKey}`,
            ...headers,
        };
        try {
            const response = await fetch(url, {
                method,
                headers: defaultHeaders,
                body: data ? JSON.stringify(data) : undefined,
            });
            if (!response.ok) {
                const error = await response.text();
                throw new Error(`${this.providerName} API Error: ${response.status} - ${error}`);
            }
            return await response.json();
        }
        catch (error) {
            console.error(`${this.providerName} API Request Failed:`, error);
            throw error;
        }
    }
    calculateWeightSurcharge(weight) {
        const baseWeight = 5000; // 5kg in grams
        if (weight > baseWeight) {
            const extraKg = Math.ceil((weight - baseWeight) / 1000);
            return extraKg * 1.0;
        }
        return 0;
    }
    calculateInsurance(value) {
        return Math.ceil(value / 100) * 0.5;
    }
}
exports.ShippingProviderBase = ShippingProviderBase;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2hpcHBpbmctYmFzZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zZXJ2aWNlcy9zaGlwcGluZy1iYXNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQThDQSxNQUFzQixvQkFBb0I7SUFNeEMsWUFBWSxNQUFxRjtRQUMvRixJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFDNUIsSUFBSSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQztRQUM5QixJQUFJLENBQUMsWUFBWSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUM7SUFDMUMsQ0FBQztJQXFCUyxLQUFLLENBQUMsV0FBVyxDQUN6QixRQUFnQixFQUNoQixTQUFpQixLQUFLLEVBQ3RCLElBQVUsRUFDVixPQUFnQztRQUVoQyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLEdBQUcsUUFBUSxFQUFFLENBQUM7UUFDekMsTUFBTSxjQUFjLEdBQUc7WUFDckIsY0FBYyxFQUFFLGtCQUFrQjtZQUNsQyxhQUFhLEVBQUUsVUFBVSxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ3RDLEdBQUcsT0FBTztTQUNYLENBQUM7UUFFRixJQUFJLENBQUM7WUFDSCxNQUFNLFFBQVEsR0FBRyxNQUFNLEtBQUssQ0FBQyxHQUFHLEVBQUU7Z0JBQ2hDLE1BQU07Z0JBQ04sT0FBTyxFQUFFLGNBQWM7Z0JBQ3ZCLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7YUFDOUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQztnQkFDakIsTUFBTSxLQUFLLEdBQUcsTUFBTSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ3BDLE1BQU0sSUFBSSxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxlQUFlLFFBQVEsQ0FBQyxNQUFNLE1BQU0sS0FBSyxFQUFFLENBQUMsQ0FBQztZQUNuRixDQUFDO1lBRUQsT0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUMvQixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxzQkFBc0IsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNqRSxNQUFNLEtBQUssQ0FBQztRQUNkLENBQUM7SUFDSCxDQUFDO0lBRVMsd0JBQXdCLENBQUMsTUFBYztRQUMvQyxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsQ0FBQyxlQUFlO1FBQ3hDLElBQUksTUFBTSxHQUFHLFVBQVUsRUFBRSxDQUFDO1lBQ3hCLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEdBQUcsVUFBVSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7WUFDeEQsT0FBTyxPQUFPLEdBQUcsR0FBRyxDQUFDO1FBQ3ZCLENBQUM7UUFDRCxPQUFPLENBQUMsQ0FBQztJQUNYLENBQUM7SUFFUyxrQkFBa0IsQ0FBQyxLQUFhO1FBQ3hDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDO0lBQ3RDLENBQUM7Q0FDRjtBQTVFRCxvREE0RUMifQ==