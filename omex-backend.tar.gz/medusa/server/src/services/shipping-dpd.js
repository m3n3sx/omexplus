"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DPDShippingProvider = void 0;
const shipping_base_1 = require("./shipping-base");
class DPDShippingProvider extends shipping_base_1.ShippingProviderBase {
    constructor(config) {
        super({
            apiKey: config.apiKey,
            baseUrl: config.baseUrl || "https://www.dpd.com.pl/api",
            providerName: "DPD",
        });
        this.login = config.login;
        this.password = config.password;
    }
    async calculateRate(origin, destination, parcel, serviceType) {
        const rates = [];
        const weightSurcharge = this.calculateWeightSurcharge(parcel.weight);
        // DPD Economy
        if (!serviceType || serviceType === "economy") {
            rates.push({
                provider: "dpd",
                method: "economy",
                price: 6.99 + weightSurcharge,
                delivery_days: 3,
                currency: "USD",
            });
        }
        // DPD Express
        if (!serviceType || serviceType === "express") {
            rates.push({
                provider: "dpd",
                method: "express",
                price: 12.99 + weightSurcharge,
                delivery_days: 1,
                currency: "USD",
            });
        }
        return rates;
    }
    async createShipment(order, shippingMethod, parcel) {
        const shippingAddress = order.shipping_address;
        if (!shippingAddress) {
            throw new Error("Order missing shipping address");
        }
        const shipmentRequest = {
            receiver: {
                name: `${shippingAddress.first_name} ${shippingAddress.last_name}`,
                phone: shippingAddress.phone || "",
                email: order.email || "",
                address: {
                    street: shippingAddress.address_1 || "",
                    city: shippingAddress.city || "",
                    postal_code: shippingAddress.postal_code || "",
                    country: shippingAddress.country_code || "",
                },
            },
            parcels: [
                {
                    weight: parcel.weight / 1000, // kg
                    length: parcel.length,
                    width: parcel.width,
                    height: parcel.height,
                },
            ],
            service: shippingMethod,
            reference: order.id,
            sender: {
                name: "OMEX B2B",
                phone: "+48123456789",
                email: "shipping@omex.com",
                address: {
                    street: "Warehouse Street 1",
                    city: "Warsaw",
                    postal_code: "00-001",
                    country: "PL",
                },
            },
        };
        try {
            const response = await this.makeRequest("/shipments", "POST", shipmentRequest, {
                "X-DPD-Login": this.login,
                "X-DPD-Password": this.password,
            });
            return {
                shipment_id: response.shipment_id || response.id,
                tracking_number: response.tracking_number || response.parcel_number,
                label_url: response.label_url || "",
                provider: "dpd",
                status: "pending",
            };
        }
        catch (error) {
            console.error("DPD shipment creation failed:", error);
            throw new Error(`Failed to create DPD shipment: ${error.message}`);
        }
    }
    async generateLabel(shipmentId) {
        try {
            const response = await this.makeRequest(`/shipments/${shipmentId}/label`, "GET", undefined, {
                "X-DPD-Login": this.login,
                "X-DPD-Password": this.password,
            });
            return response.label_url || response.pdf_url || "";
        }
        catch (error) {
            console.error("DPD label generation failed:", error);
            throw new Error(`Failed to generate DPD label: ${error.message}`);
        }
    }
    async trackShipment(trackingNumber) {
        try {
            const response = await this.makeRequest(`/tracking/${trackingNumber}`, "GET", undefined, {
                "X-DPD-Login": this.login,
                "X-DPD-Password": this.password,
            });
            const events = (response.events || []).map((event) => ({
                timestamp: new Date(event.timestamp),
                status: event.status,
                location: event.location || "",
                description: event.description || "",
            }));
            return {
                tracking_number: trackingNumber,
                status: response.status || "unknown",
                events,
            };
        }
        catch (error) {
            console.error("DPD tracking failed:", error);
            throw new Error(`Failed to track DPD shipment: ${error.message}`);
        }
    }
    async cancelShipment(shipmentId) {
        try {
            await this.makeRequest(`/shipments/${shipmentId}/cancel`, "POST", {}, {
                "X-DPD-Login": this.login,
                "X-DPD-Password": this.password,
            });
            return true;
        }
        catch (error) {
            console.error("DPD shipment cancellation failed:", error);
            return false;
        }
    }
}
exports.DPDShippingProvider = DPDShippingProvider;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2hpcHBpbmctZHBkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3NlcnZpY2VzL3NoaXBwaW5nLWRwZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxtREFReUI7QUFTekIsTUFBYSxtQkFBb0IsU0FBUSxvQ0FBb0I7SUFJM0QsWUFBWSxNQUFpQjtRQUMzQixLQUFLLENBQUM7WUFDSixNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07WUFDckIsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPLElBQUksNEJBQTRCO1lBQ3ZELFlBQVksRUFBRSxLQUFLO1NBQ3BCLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQztRQUMxQixJQUFJLENBQUMsUUFBUSxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQUM7SUFDbEMsQ0FBQztJQUVELEtBQUssQ0FBQyxhQUFhLENBQ2pCLE1BQXVCLEVBQ3ZCLFdBQTRCLEVBQzVCLE1BQXdCLEVBQ3hCLFdBQW9CO1FBRXBCLE1BQU0sS0FBSyxHQUFtQixFQUFFLENBQUM7UUFDakMsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLHdCQUF3QixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVyRSxjQUFjO1FBQ2QsSUFBSSxDQUFDLFdBQVcsSUFBSSxXQUFXLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDOUMsS0FBSyxDQUFDLElBQUksQ0FBQztnQkFDVCxRQUFRLEVBQUUsS0FBSztnQkFDZixNQUFNLEVBQUUsU0FBUztnQkFDakIsS0FBSyxFQUFFLElBQUksR0FBRyxlQUFlO2dCQUM3QixhQUFhLEVBQUUsQ0FBQztnQkFDaEIsUUFBUSxFQUFFLEtBQUs7YUFDaEIsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVELGNBQWM7UUFDZCxJQUFJLENBQUMsV0FBVyxJQUFJLFdBQVcsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUM5QyxLQUFLLENBQUMsSUFBSSxDQUFDO2dCQUNULFFBQVEsRUFBRSxLQUFLO2dCQUNmLE1BQU0sRUFBRSxTQUFTO2dCQUNqQixLQUFLLEVBQUUsS0FBSyxHQUFHLGVBQWU7Z0JBQzlCLGFBQWEsRUFBRSxDQUFDO2dCQUNoQixRQUFRLEVBQUUsS0FBSzthQUNoQixDQUFDLENBQUM7UUFDTCxDQUFDO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBRUQsS0FBSyxDQUFDLGNBQWMsQ0FDbEIsS0FBZSxFQUNmLGNBQXNCLEVBQ3RCLE1BQXdCO1FBRXhCLE1BQU0sZUFBZSxHQUFHLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQztRQUMvQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDckIsTUFBTSxJQUFJLEtBQUssQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO1FBQ3BELENBQUM7UUFFRCxNQUFNLGVBQWUsR0FBRztZQUN0QixRQUFRLEVBQUU7Z0JBQ1IsSUFBSSxFQUFFLEdBQUcsZUFBZSxDQUFDLFVBQVUsSUFBSSxlQUFlLENBQUMsU0FBUyxFQUFFO2dCQUNsRSxLQUFLLEVBQUUsZUFBZSxDQUFDLEtBQUssSUFBSSxFQUFFO2dCQUNsQyxLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUssSUFBSSxFQUFFO2dCQUN4QixPQUFPLEVBQUU7b0JBQ1AsTUFBTSxFQUFFLGVBQWUsQ0FBQyxTQUFTLElBQUksRUFBRTtvQkFDdkMsSUFBSSxFQUFFLGVBQWUsQ0FBQyxJQUFJLElBQUksRUFBRTtvQkFDaEMsV0FBVyxFQUFFLGVBQWUsQ0FBQyxXQUFXLElBQUksRUFBRTtvQkFDOUMsT0FBTyxFQUFFLGVBQWUsQ0FBQyxZQUFZLElBQUksRUFBRTtpQkFDNUM7YUFDRjtZQUNELE9BQU8sRUFBRTtnQkFDUDtvQkFDRSxNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxJQUFJLEVBQUUsS0FBSztvQkFDbkMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO29CQUNyQixLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7b0JBQ25CLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtpQkFDdEI7YUFDRjtZQUNELE9BQU8sRUFBRSxjQUFjO1lBQ3ZCLFNBQVMsRUFBRSxLQUFLLENBQUMsRUFBRTtZQUNuQixNQUFNLEVBQUU7Z0JBQ04sSUFBSSxFQUFFLFVBQVU7Z0JBQ2hCLEtBQUssRUFBRSxjQUFjO2dCQUNyQixLQUFLLEVBQUUsbUJBQW1CO2dCQUMxQixPQUFPLEVBQUU7b0JBQ1AsTUFBTSxFQUFFLG9CQUFvQjtvQkFDNUIsSUFBSSxFQUFFLFFBQVE7b0JBQ2QsV0FBVyxFQUFFLFFBQVE7b0JBQ3JCLE9BQU8sRUFBRSxJQUFJO2lCQUNkO2FBQ0Y7U0FDRixDQUFDO1FBRUYsSUFBSSxDQUFDO1lBQ0gsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUNyQyxZQUFZLEVBQ1osTUFBTSxFQUNOLGVBQWUsRUFDZjtnQkFDRSxhQUFhLEVBQUUsSUFBSSxDQUFDLEtBQUs7Z0JBQ3pCLGdCQUFnQixFQUFFLElBQUksQ0FBQyxRQUFRO2FBQ2hDLENBQ0YsQ0FBQztZQUVGLE9BQU87Z0JBQ0wsV0FBVyxFQUFFLFFBQVEsQ0FBQyxXQUFXLElBQUksUUFBUSxDQUFDLEVBQUU7Z0JBQ2hELGVBQWUsRUFBRSxRQUFRLENBQUMsZUFBZSxJQUFJLFFBQVEsQ0FBQyxhQUFhO2dCQUNuRSxTQUFTLEVBQUUsUUFBUSxDQUFDLFNBQVMsSUFBSSxFQUFFO2dCQUNuQyxRQUFRLEVBQUUsS0FBSztnQkFDZixNQUFNLEVBQUUsU0FBUzthQUNsQixDQUFDO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLCtCQUErQixFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3RELE1BQU0sSUFBSSxLQUFLLENBQUMsa0NBQWtDLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQ3JFLENBQUM7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLGFBQWEsQ0FBQyxVQUFrQjtRQUNwQyxJQUFJLENBQUM7WUFDSCxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQ3JDLGNBQWMsVUFBVSxRQUFRLEVBQ2hDLEtBQUssRUFDTCxTQUFTLEVBQ1Q7Z0JBQ0UsYUFBYSxFQUFFLElBQUksQ0FBQyxLQUFLO2dCQUN6QixnQkFBZ0IsRUFBRSxJQUFJLENBQUMsUUFBUTthQUNoQyxDQUNGLENBQUM7WUFDRixPQUFPLFFBQVEsQ0FBQyxTQUFTLElBQUksUUFBUSxDQUFDLE9BQU8sSUFBSSxFQUFFLENBQUM7UUFDdEQsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLDhCQUE4QixFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3JELE1BQU0sSUFBSSxLQUFLLENBQUMsaUNBQWlDLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQ3BFLENBQUM7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLGFBQWEsQ0FBQyxjQUFzQjtRQUN4QyxJQUFJLENBQUM7WUFDSCxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQ3JDLGFBQWEsY0FBYyxFQUFFLEVBQzdCLEtBQUssRUFDTCxTQUFTLEVBQ1Q7Z0JBQ0UsYUFBYSxFQUFFLElBQUksQ0FBQyxLQUFLO2dCQUN6QixnQkFBZ0IsRUFBRSxJQUFJLENBQUMsUUFBUTthQUNoQyxDQUNGLENBQUM7WUFFRixNQUFNLE1BQU0sR0FBb0IsQ0FBQyxRQUFRLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDM0UsU0FBUyxFQUFFLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7Z0JBQ3BDLE1BQU0sRUFBRSxLQUFLLENBQUMsTUFBTTtnQkFDcEIsUUFBUSxFQUFFLEtBQUssQ0FBQyxRQUFRLElBQUksRUFBRTtnQkFDOUIsV0FBVyxFQUFFLEtBQUssQ0FBQyxXQUFXLElBQUksRUFBRTthQUNyQyxDQUFDLENBQUMsQ0FBQztZQUVKLE9BQU87Z0JBQ0wsZUFBZSxFQUFFLGNBQWM7Z0JBQy9CLE1BQU0sRUFBRSxRQUFRLENBQUMsTUFBTSxJQUFJLFNBQVM7Z0JBQ3BDLE1BQU07YUFDUCxDQUFDO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLHNCQUFzQixFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzdDLE1BQU0sSUFBSSxLQUFLLENBQUMsaUNBQWlDLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQ3BFLENBQUM7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLGNBQWMsQ0FBQyxVQUFrQjtRQUNyQyxJQUFJLENBQUM7WUFDSCxNQUFNLElBQUksQ0FBQyxXQUFXLENBQ3BCLGNBQWMsVUFBVSxTQUFTLEVBQ2pDLE1BQU0sRUFDTixFQUFFLEVBQ0Y7Z0JBQ0UsYUFBYSxFQUFFLElBQUksQ0FBQyxLQUFLO2dCQUN6QixnQkFBZ0IsRUFBRSxJQUFJLENBQUMsUUFBUTthQUNoQyxDQUNGLENBQUM7WUFDRixPQUFPLElBQUksQ0FBQztRQUNkLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyxtQ0FBbUMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUMxRCxPQUFPLEtBQUssQ0FBQztRQUNmLENBQUM7SUFDSCxDQUFDO0NBQ0Y7QUF0TEQsa0RBc0xDIn0=