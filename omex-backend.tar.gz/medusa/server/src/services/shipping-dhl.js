"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DHLShippingProvider = void 0;
const shipping_base_1 = require("./shipping-base");
class DHLShippingProvider extends shipping_base_1.ShippingProviderBase {
    constructor(config) {
        super({
            apiKey: config.apiKey,
            baseUrl: config.baseUrl || "https://api.dhl.com/v1",
            providerName: "DHL",
        });
        this.accountNumber = config.accountNumber;
    }
    async calculateRate(origin, destination, parcel, serviceType) {
        const rates = [];
        const weightSurcharge = this.calculateWeightSurcharge(parcel.weight);
        // DHL Parcel
        if (!serviceType || serviceType === "parcel") {
            rates.push({
                provider: "dhl",
                method: "parcel",
                price: 8.99 + weightSurcharge,
                delivery_days: 3,
                currency: "USD",
            });
        }
        // DHL Express
        if (!serviceType || serviceType === "express") {
            rates.push({
                provider: "dhl",
                method: "express",
                price: 14.99 + weightSurcharge,
                delivery_days: 1,
                currency: "USD",
            });
        }
        return rates;
    }
    async createShipment(order, shippingMethod, parcel) {
        const shippingAddress = order.shipping_address;
        if (!shippingAddress) {
            throw new Error("Order missing shipping address");
        }
        const shipmentRequest = {
            plannedShippingDateAndTime: new Date().toISOString(),
            pickup: {
                isRequested: false,
            },
            productCode: shippingMethod === "express" ? "P" : "N",
            accounts: [
                {
                    typeCode: "shipper",
                    number: this.accountNumber,
                },
            ],
            customerDetails: {
                shipperDetails: {
                    postalAddress: {
                        postalCode: "00-001",
                        cityName: "Warsaw",
                        countryCode: "PL",
                        addressLine1: "Warehouse Street 1",
                    },
                    contactInformation: {
                        email: "shipping@omex.com",
                        phone: "+48123456789",
                        companyName: "OMEX B2B",
                        fullName: "OMEX Shipping",
                    },
                },
                receiverDetails: {
                    postalAddress: {
                        postalCode: shippingAddress.postal_code || "",
                        cityName: shippingAddress.city || "",
                        countryCode: shippingAddress.country_code || "",
                        addressLine1: shippingAddress.address_1 || "",
                        addressLine2: shippingAddress.address_2 || "",
                    },
                    contactInformation: {
                        email: order.email || "",
                        phone: shippingAddress.phone || "",
                        fullName: `${shippingAddress.first_name} ${shippingAddress.last_name}`,
                    },
                },
            },
            content: {
                packages: [
                    {
                        weight: parcel.weight / 1000,
                        dimensions: {
                            length: parcel.length,
                            width: parcel.width,
                            height: parcel.height,
                        },
                    },
                ],
                isCustomsDeclarable: false,
                description: "E-commerce order",
                incoterm: "DAP",
            },
            outputImageProperties: {
                imageOptions: [
                    {
                        typeCode: "label",
                        templateName: "ECOM26_A4_001",
                    },
                ],
            },
        };
        try {
            const response = await this.makeRequest("/shipments", "POST", shipmentRequest, {
                "DHL-API-Key": this.apiKey,
            });
            const shipmentId = response.shipmentTrackingNumber || response.dispatchConfirmationNumber;
            const labelUrl = response.documents?.[0]?.content || "";
            return {
                shipment_id: shipmentId,
                tracking_number: shipmentId,
                label_url: labelUrl,
                provider: "dhl",
                status: "pending",
            };
        }
        catch (error) {
            console.error("DHL shipment creation failed:", error);
            throw new Error(`Failed to create DHL shipment: ${error.message}`);
        }
    }
    async generateLabel(shipmentId) {
        try {
            const response = await this.makeRequest(`/shipments/${shipmentId}/label`, "GET", undefined, {
                "DHL-API-Key": this.apiKey,
            });
            return response.label_url || response.documents?.[0]?.content || "";
        }
        catch (error) {
            console.error("DHL label generation failed:", error);
            throw new Error(`Failed to generate DHL label: ${error.message}`);
        }
    }
    async trackShipment(trackingNumber) {
        try {
            const response = await this.makeRequest(`/track/shipments?trackingNumber=${trackingNumber}`, "GET", undefined, {
                "DHL-API-Key": this.apiKey,
            });
            const shipment = response.shipments?.[0];
            if (!shipment) {
                throw new Error("Shipment not found");
            }
            const events = (shipment.events || []).map((event) => ({
                timestamp: new Date(event.timestamp),
                status: event.statusCode,
                location: event.location?.address?.addressLocality || "",
                description: event.description || "",
            }));
            return {
                tracking_number: trackingNumber,
                status: shipment.status?.statusCode || "unknown",
                events,
            };
        }
        catch (error) {
            console.error("DHL tracking failed:", error);
            throw new Error(`Failed to track DHL shipment: ${error.message}`);
        }
    }
    async cancelShipment(shipmentId) {
        try {
            await this.makeRequest(`/shipments/${shipmentId}`, "DELETE", undefined, {
                "DHL-API-Key": this.apiKey,
            });
            return true;
        }
        catch (error) {
            console.error("DHL shipment cancellation failed:", error);
            return false;
        }
    }
}
exports.DHLShippingProvider = DHLShippingProvider;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2hpcHBpbmctZGhsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3NlcnZpY2VzL3NoaXBwaW5nLWRobC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxtREFReUI7QUFRekIsTUFBYSxtQkFBb0IsU0FBUSxvQ0FBb0I7SUFHM0QsWUFBWSxNQUFpQjtRQUMzQixLQUFLLENBQUM7WUFDSixNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07WUFDckIsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPLElBQUksd0JBQXdCO1lBQ25ELFlBQVksRUFBRSxLQUFLO1NBQ3BCLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQztJQUM1QyxDQUFDO0lBRUQsS0FBSyxDQUFDLGFBQWEsQ0FDakIsTUFBdUIsRUFDdkIsV0FBNEIsRUFDNUIsTUFBd0IsRUFDeEIsV0FBb0I7UUFFcEIsTUFBTSxLQUFLLEdBQW1CLEVBQUUsQ0FBQztRQUNqQyxNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsd0JBQXdCLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRXJFLGFBQWE7UUFDYixJQUFJLENBQUMsV0FBVyxJQUFJLFdBQVcsS0FBSyxRQUFRLEVBQUUsQ0FBQztZQUM3QyxLQUFLLENBQUMsSUFBSSxDQUFDO2dCQUNULFFBQVEsRUFBRSxLQUFLO2dCQUNmLE1BQU0sRUFBRSxRQUFRO2dCQUNoQixLQUFLLEVBQUUsSUFBSSxHQUFHLGVBQWU7Z0JBQzdCLGFBQWEsRUFBRSxDQUFDO2dCQUNoQixRQUFRLEVBQUUsS0FBSzthQUNoQixDQUFDLENBQUM7UUFDTCxDQUFDO1FBRUQsY0FBYztRQUNkLElBQUksQ0FBQyxXQUFXLElBQUksV0FBVyxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQzlDLEtBQUssQ0FBQyxJQUFJLENBQUM7Z0JBQ1QsUUFBUSxFQUFFLEtBQUs7Z0JBQ2YsTUFBTSxFQUFFLFNBQVM7Z0JBQ2pCLEtBQUssRUFBRSxLQUFLLEdBQUcsZUFBZTtnQkFDOUIsYUFBYSxFQUFFLENBQUM7Z0JBQ2hCLFFBQVEsRUFBRSxLQUFLO2FBQ2hCLENBQUMsQ0FBQztRQUNMLENBQUM7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFFRCxLQUFLLENBQUMsY0FBYyxDQUNsQixLQUFlLEVBQ2YsY0FBc0IsRUFDdEIsTUFBd0I7UUFFeEIsTUFBTSxlQUFlLEdBQUcsS0FBSyxDQUFDLGdCQUFnQixDQUFDO1FBQy9DLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUNyQixNQUFNLElBQUksS0FBSyxDQUFDLGdDQUFnQyxDQUFDLENBQUM7UUFDcEQsQ0FBQztRQUVELE1BQU0sZUFBZSxHQUFHO1lBQ3RCLDBCQUEwQixFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO1lBQ3BELE1BQU0sRUFBRTtnQkFDTixXQUFXLEVBQUUsS0FBSzthQUNuQjtZQUNELFdBQVcsRUFBRSxjQUFjLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUc7WUFDckQsUUFBUSxFQUFFO2dCQUNSO29CQUNFLFFBQVEsRUFBRSxTQUFTO29CQUNuQixNQUFNLEVBQUUsSUFBSSxDQUFDLGFBQWE7aUJBQzNCO2FBQ0Y7WUFDRCxlQUFlLEVBQUU7Z0JBQ2YsY0FBYyxFQUFFO29CQUNkLGFBQWEsRUFBRTt3QkFDYixVQUFVLEVBQUUsUUFBUTt3QkFDcEIsUUFBUSxFQUFFLFFBQVE7d0JBQ2xCLFdBQVcsRUFBRSxJQUFJO3dCQUNqQixZQUFZLEVBQUUsb0JBQW9CO3FCQUNuQztvQkFDRCxrQkFBa0IsRUFBRTt3QkFDbEIsS0FBSyxFQUFFLG1CQUFtQjt3QkFDMUIsS0FBSyxFQUFFLGNBQWM7d0JBQ3JCLFdBQVcsRUFBRSxVQUFVO3dCQUN2QixRQUFRLEVBQUUsZUFBZTtxQkFDMUI7aUJBQ0Y7Z0JBQ0QsZUFBZSxFQUFFO29CQUNmLGFBQWEsRUFBRTt3QkFDYixVQUFVLEVBQUUsZUFBZSxDQUFDLFdBQVcsSUFBSSxFQUFFO3dCQUM3QyxRQUFRLEVBQUUsZUFBZSxDQUFDLElBQUksSUFBSSxFQUFFO3dCQUNwQyxXQUFXLEVBQUUsZUFBZSxDQUFDLFlBQVksSUFBSSxFQUFFO3dCQUMvQyxZQUFZLEVBQUUsZUFBZSxDQUFDLFNBQVMsSUFBSSxFQUFFO3dCQUM3QyxZQUFZLEVBQUUsZUFBZSxDQUFDLFNBQVMsSUFBSSxFQUFFO3FCQUM5QztvQkFDRCxrQkFBa0IsRUFBRTt3QkFDbEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLLElBQUksRUFBRTt3QkFDeEIsS0FBSyxFQUFFLGVBQWUsQ0FBQyxLQUFLLElBQUksRUFBRTt3QkFDbEMsUUFBUSxFQUFFLEdBQUcsZUFBZSxDQUFDLFVBQVUsSUFBSSxlQUFlLENBQUMsU0FBUyxFQUFFO3FCQUN2RTtpQkFDRjthQUNGO1lBQ0QsT0FBTyxFQUFFO2dCQUNQLFFBQVEsRUFBRTtvQkFDUjt3QkFDRSxNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxJQUFJO3dCQUM1QixVQUFVLEVBQUU7NEJBQ1YsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNOzRCQUNyQixLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7NEJBQ25CLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTTt5QkFDdEI7cUJBQ0Y7aUJBQ0Y7Z0JBQ0QsbUJBQW1CLEVBQUUsS0FBSztnQkFDMUIsV0FBVyxFQUFFLGtCQUFrQjtnQkFDL0IsUUFBUSxFQUFFLEtBQUs7YUFDaEI7WUFDRCxxQkFBcUIsRUFBRTtnQkFDckIsWUFBWSxFQUFFO29CQUNaO3dCQUNFLFFBQVEsRUFBRSxPQUFPO3dCQUNqQixZQUFZLEVBQUUsZUFBZTtxQkFDOUI7aUJBQ0Y7YUFDRjtTQUNGLENBQUM7UUFFRixJQUFJLENBQUM7WUFDSCxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxFQUFFLE1BQU0sRUFBRSxlQUFlLEVBQUU7Z0JBQzdFLGFBQWEsRUFBRSxJQUFJLENBQUMsTUFBTTthQUMzQixDQUFDLENBQUM7WUFFSCxNQUFNLFVBQVUsR0FBRyxRQUFRLENBQUMsc0JBQXNCLElBQUksUUFBUSxDQUFDLDBCQUEwQixDQUFDO1lBQzFGLE1BQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLElBQUksRUFBRSxDQUFDO1lBRXhELE9BQU87Z0JBQ0wsV0FBVyxFQUFFLFVBQVU7Z0JBQ3ZCLGVBQWUsRUFBRSxVQUFVO2dCQUMzQixTQUFTLEVBQUUsUUFBUTtnQkFDbkIsUUFBUSxFQUFFLEtBQUs7Z0JBQ2YsTUFBTSxFQUFFLFNBQVM7YUFDbEIsQ0FBQztRQUNKLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQywrQkFBK0IsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN0RCxNQUFNLElBQUksS0FBSyxDQUFDLGtDQUFrQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUNyRSxDQUFDO0lBQ0gsQ0FBQztJQUVELEtBQUssQ0FBQyxhQUFhLENBQUMsVUFBa0I7UUFDcEMsSUFBSSxDQUFDO1lBQ0gsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsVUFBVSxRQUFRLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRTtnQkFDMUYsYUFBYSxFQUFFLElBQUksQ0FBQyxNQUFNO2FBQzNCLENBQUMsQ0FBQztZQUNILE9BQU8sUUFBUSxDQUFDLFNBQVMsSUFBSSxRQUFRLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxJQUFJLEVBQUUsQ0FBQztRQUN0RSxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsOEJBQThCLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDckQsTUFBTSxJQUFJLEtBQUssQ0FBQyxpQ0FBaUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDcEUsQ0FBQztJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsYUFBYSxDQUFDLGNBQXNCO1FBQ3hDLElBQUksQ0FBQztZQUNILE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxtQ0FBbUMsY0FBYyxFQUFFLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRTtnQkFDN0csYUFBYSxFQUFFLElBQUksQ0FBQyxNQUFNO2FBQzNCLENBQUMsQ0FBQztZQUVILE1BQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN6QyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7Z0JBQ2QsTUFBTSxJQUFJLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1lBQ3hDLENBQUM7WUFFRCxNQUFNLE1BQU0sR0FBb0IsQ0FBQyxRQUFRLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDM0UsU0FBUyxFQUFFLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7Z0JBQ3BDLE1BQU0sRUFBRSxLQUFLLENBQUMsVUFBVTtnQkFDeEIsUUFBUSxFQUFFLEtBQUssQ0FBQyxRQUFRLEVBQUUsT0FBTyxFQUFFLGVBQWUsSUFBSSxFQUFFO2dCQUN4RCxXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVcsSUFBSSxFQUFFO2FBQ3JDLENBQUMsQ0FBQyxDQUFDO1lBRUosT0FBTztnQkFDTCxlQUFlLEVBQUUsY0FBYztnQkFDL0IsTUFBTSxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsVUFBVSxJQUFJLFNBQVM7Z0JBQ2hELE1BQU07YUFDUCxDQUFDO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLHNCQUFzQixFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzdDLE1BQU0sSUFBSSxLQUFLLENBQUMsaUNBQWlDLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQ3BFLENBQUM7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLGNBQWMsQ0FBQyxVQUFrQjtRQUNyQyxJQUFJLENBQUM7WUFDSCxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsY0FBYyxVQUFVLEVBQUUsRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFO2dCQUN0RSxhQUFhLEVBQUUsSUFBSSxDQUFDLE1BQU07YUFDM0IsQ0FBQyxDQUFDO1lBQ0gsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsbUNBQW1DLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDMUQsT0FBTyxLQUFLLENBQUM7UUFDZixDQUFDO0lBQ0gsQ0FBQztDQUNGO0FBcE1ELGtEQW9NQyJ9