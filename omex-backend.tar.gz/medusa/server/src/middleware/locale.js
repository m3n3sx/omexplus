"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.localeMiddleware = localeMiddleware;
function localeMiddleware(req, res, next) {
    // Pobierz język z nagłówka, query lub cookie
    const locale = req.query.locale ||
        req.headers["accept-language"]?.split(",")[0]?.split("-")[0] ||
        req.cookies?.locale ||
        "pl";
    // Sprawdź czy język jest wspierany
    const supportedLocales = ["pl", "en", "de", "uk"];
    req.locale = supportedLocales.includes(locale) ? locale : "pl";
    next();
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9jYWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL21pZGRsZXdhcmUvbG9jYWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBRUEsNENBaUJDO0FBakJELFNBQWdCLGdCQUFnQixDQUM5QixHQUFrQixFQUNsQixHQUFtQixFQUNuQixJQUF3QjtJQUV4Qiw2Q0FBNkM7SUFDN0MsTUFBTSxNQUFNLEdBQ1YsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFnQjtRQUMxQixHQUFHLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLEVBQUUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDNUQsR0FBRyxDQUFDLE9BQU8sRUFBRSxNQUFNO1FBQ25CLElBQUksQ0FBQTtJQUVOLG1DQUFtQztJQUNuQyxNQUFNLGdCQUFnQixHQUFHLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUE7SUFDakQsR0FBRyxDQUFDLE1BQU0sR0FBRyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFBO0lBRTlELElBQUksRUFBRSxDQUFBO0FBQ1IsQ0FBQyJ9