"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Inventory = void 0;
const utils_1 = require("@medusajs/framework/utils");
exports.Inventory = utils_1.model.define("inventory", {
    id: utils_1.model.id().primaryKey(),
    product_id: utils_1.model.text(),
    warehouse_id: utils_1.model.text(),
    quantity: utils_1.model.number().default(0),
    reserved: utils_1.model.number().default(0),
    updated_at: utils_1.model.dateTime().default("now"),
});
exports.default = exports.Inventory;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW52ZW50b3J5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL21vZGVscy9pbnZlbnRvcnkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEscURBQWlEO0FBRXBDLFFBQUEsU0FBUyxHQUFHLGFBQUssQ0FBQyxNQUFNLENBQUMsV0FBVyxFQUFFO0lBQ2pELEVBQUUsRUFBRSxhQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsVUFBVSxFQUFFO0lBQzNCLFVBQVUsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBQ3hCLFlBQVksRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBQzFCLFFBQVEsRUFBRSxhQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUNuQyxRQUFRLEVBQUUsYUFBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDbkMsVUFBVSxFQUFFLGFBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO0NBQzVDLENBQUMsQ0FBQTtBQUVGLGtCQUFlLGlCQUFTLENBQUEifQ==