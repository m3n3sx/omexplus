"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const B2BCustomerGroup = utils_1.model.define("b2b_customer_group", {
    id: utils_1.model.id().primaryKey(),
    name: utils_1.model.text(),
    discount_percentage: utils_1.model.bigNumber().nullable(),
    min_order_value: utils_1.model.bigNumber().nullable(),
    payment_terms: utils_1.model.text().nullable(),
    custom_catalog_ids: utils_1.model.json().nullable(),
});
exports.default = B2BCustomerGroup;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYjJiLWN1c3RvbWVyLWdyb3VwLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL21vZGVscy9iMmItY3VzdG9tZXItZ3JvdXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBaUQ7QUFFakQsTUFBTSxnQkFBZ0IsR0FBRyxhQUFLLENBQUMsTUFBTSxDQUFDLG9CQUFvQixFQUFFO0lBQzFELEVBQUUsRUFBRSxhQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsVUFBVSxFQUFFO0lBQzNCLElBQUksRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBQ2xCLG1CQUFtQixFQUFFLGFBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDakQsZUFBZSxFQUFFLGFBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDN0MsYUFBYSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDdEMsa0JBQWtCLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtDQUM1QyxDQUFDLENBQUE7QUFFRixrQkFBZSxnQkFBZ0IsQ0FBQSJ9