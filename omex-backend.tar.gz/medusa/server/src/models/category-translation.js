"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CategoryTranslation = void 0;
const utils_1 = require("@medusajs/framework/utils");
exports.CategoryTranslation = utils_1.model.define("category_translation", {
    id: utils_1.model.id().primaryKey(),
    category_id: utils_1.model.text(),
    locale: utils_1.model.enum(["pl", "en", "de"]),
    name: utils_1.model.text(),
    description: utils_1.model.text().nullable(),
    created_at: utils_1.model.dateTime().default("now"),
    updated_at: utils_1.model.dateTime().default("now"),
});
exports.default = exports.CategoryTranslation;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2F0ZWdvcnktdHJhbnNsYXRpb24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvbW9kZWxzL2NhdGVnb3J5LXRyYW5zbGF0aW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFEQUFpRDtBQUVwQyxRQUFBLG1CQUFtQixHQUFHLGFBQUssQ0FBQyxNQUFNLENBQUMsc0JBQXNCLEVBQUU7SUFDdEUsRUFBRSxFQUFFLGFBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxVQUFVLEVBQUU7SUFDM0IsV0FBVyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDekIsTUFBTSxFQUFFLGFBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3RDLElBQUksRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFO0lBQ2xCLFdBQVcsRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ3BDLFVBQVUsRUFBRSxhQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztJQUMzQyxVQUFVLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7Q0FDNUMsQ0FBQyxDQUFBO0FBRUYsa0JBQWUsMkJBQW1CLENBQUEifQ==