"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PriceTier = void 0;
const utils_1 = require("@medusajs/framework/utils");
exports.PriceTier = utils_1.model.define("price_tier", {
    id: utils_1.model.id().primaryKey(),
    product_id: utils_1.model.text(),
    customer_type: utils_1.model.enum(["retail", "b2b", "wholesale"]),
    quantity_min: utils_1.model.number(),
    quantity_max: utils_1.model.number().nullable(),
    price: utils_1.model.bigNumber(),
    created_at: utils_1.model.dateTime().default("now"),
    updated_at: utils_1.model.dateTime().default("now"),
});
exports.default = exports.PriceTier;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJpY2UtdGllci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9tb2RlbHMvcHJpY2UtdGllci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxREFBaUQ7QUFFcEMsUUFBQSxTQUFTLEdBQUcsYUFBSyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUU7SUFDbEQsRUFBRSxFQUFFLGFBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxVQUFVLEVBQUU7SUFDM0IsVUFBVSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDeEIsYUFBYSxFQUFFLGFBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQ3pELFlBQVksRUFBRSxhQUFLLENBQUMsTUFBTSxFQUFFO0lBQzVCLFlBQVksRUFBRSxhQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsUUFBUSxFQUFFO0lBQ3ZDLEtBQUssRUFBRSxhQUFLLENBQUMsU0FBUyxFQUFFO0lBQ3hCLFVBQVUsRUFBRSxhQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztJQUMzQyxVQUFVLEVBQUUsYUFBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7Q0FDNUMsQ0FBQyxDQUFBO0FBRUYsa0JBQWUsaUJBQVMsQ0FBQSJ9