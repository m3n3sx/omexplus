"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
/**
 * GET /store/manufacturers/:id/catalog
 * Get products from manufacturer catalog by page number
 */
async function GET(req, res) {
    const { id } = req.params;
    const { page } = req.query;
    if (!id) {
        return res.status(400).json({
            error: "Manufacturer ID is required",
        });
    }
    if (!page) {
        return res.status(400).json({
            error: "Catalog page number is required",
        });
    }
    try {
        const searchService = req.scope.resolve("omexSearch");
        const products = await searchService.searchByCatalogPage(id, Number(page));
        return res.json({
            products,
            count: products.length,
            manufacturer_id: id,
            catalog_page: Number(page),
        });
    }
    catch (error) {
        return res.status(500).json({
            error: error.message || "Failed to get catalog products",
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL21hbnVmYWN0dXJlcnMvW2lkXS9jYXRhbG9nL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBTUEsa0JBZ0NDO0FBcENEOzs7R0FHRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUMvRCxNQUFNLEVBQUUsRUFBRSxFQUFFLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQTtJQUN6QixNQUFNLEVBQUUsSUFBSSxFQUFFLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtJQUUxQixJQUFJLENBQUMsRUFBRSxFQUFFLENBQUM7UUFDUixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLEtBQUssRUFBRSw2QkFBNkI7U0FDckMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNWLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsS0FBSyxFQUFFLGlDQUFpQztTQUN6QyxDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsSUFBSSxDQUFDO1FBQ0gsTUFBTSxhQUFhLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUE7UUFFckQsTUFBTSxRQUFRLEdBQUcsTUFBTSxhQUFhLENBQUMsbUJBQW1CLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFBO1FBRTFFLE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQztZQUNkLFFBQVE7WUFDUixLQUFLLEVBQUUsUUFBUSxDQUFDLE1BQU07WUFDdEIsZUFBZSxFQUFFLEVBQUU7WUFDbkIsWUFBWSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUM7U0FDM0IsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU8sSUFBSSxnQ0FBZ0M7U0FDekQsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==