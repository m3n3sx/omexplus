"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
async function GET(req, res) {
    // Pobieranie aktywnych promocji
    const promotions = {
        active: [],
        upcoming: [],
    };
    res.json({ promotions });
}
async function POST(req, res) {
    const { code } = req.body;
    // Walidacja kodu promocyjnego
    const discount = {
        valid: true,
        code,
        amount: 0,
    };
    res.json({ discount });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3Byb21vdGlvbnMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFFQSxrQkFRQztBQUVELG9CQVdDO0FBckJNLEtBQUssVUFBVSxHQUFHLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUMvRCxnQ0FBZ0M7SUFDaEMsTUFBTSxVQUFVLEdBQUc7UUFDakIsTUFBTSxFQUFFLEVBQUU7UUFDVixRQUFRLEVBQUUsRUFBRTtLQUNiLENBQUE7SUFFRCxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsVUFBVSxFQUFFLENBQUMsQ0FBQTtBQUMxQixDQUFDO0FBRU0sS0FBSyxVQUFVLElBQUksQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQ2hFLE1BQU0sRUFBRSxJQUFJLEVBQUUsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBRXpCLDhCQUE4QjtJQUM5QixNQUFNLFFBQVEsR0FBRztRQUNmLEtBQUssRUFBRSxJQUFJO1FBQ1gsSUFBSTtRQUNKLE1BQU0sRUFBRSxDQUFDO0tBQ1YsQ0FBQTtJQUVELEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFBO0FBQ3hCLENBQUMifQ==