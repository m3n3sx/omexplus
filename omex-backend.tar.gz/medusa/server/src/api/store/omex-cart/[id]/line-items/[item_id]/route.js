"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PUT = PUT;
exports.DELETE = DELETE;
const omex_pricing_1 = require("../../../../../../modules/omex-pricing");
async function PUT(req, res) {
    const pricingService = req.scope.resolve(omex_pricing_1.OMEX_PRICING_MODULE);
    const { id, item_id } = req.params;
    const { quantity } = req.body;
    if (!quantity || quantity < 1) {
        return res.status(400).json({
            error: {
                code: 'INVALID_QUANTITY',
                message: 'Quantity must be at least 1',
            },
        });
    }
    try {
        // In real implementation:
        // 1. Fetch line item
        // 2. Check min_order_qty
        // 3. Check stock
        // 4. Recalculate price based on new quantity
        // 5. Update line item
        const customerType = 'retail';
        // const price = await pricingService.getPrice(product_id, customerType, quantity)
        res.json({
            line_item: {
                id: item_id,
                quantity,
                updated_at: new Date(),
            },
        });
    }
    catch (error) {
        res.status(400).json({
            error: {
                code: 'UPDATE_ITEM_ERROR',
                message: error.message,
            },
        });
    }
}
async function DELETE(req, res) {
    const { id, item_id } = req.params;
    try {
        // Remove item from cart
        res.json({
            deleted: true,
            id: item_id,
        });
    }
    catch (error) {
        res.status(400).json({
            error: {
                code: 'DELETE_ITEM_ERROR',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL29tZXgtY2FydC9baWRdL2xpbmUtaXRlbXMvW2l0ZW1faWRdL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBR0Esa0JBeUNDO0FBRUQsd0JBaUJDO0FBOURELHlFQUE0RTtBQUVyRSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxjQUFjLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsa0NBQW1CLENBQUMsQ0FBQTtJQUU3RCxNQUFNLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUE7SUFDbEMsTUFBTSxFQUFFLFFBQVEsRUFBRSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUE7SUFFN0IsSUFBSSxDQUFDLFFBQVEsSUFBSSxRQUFRLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDOUIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixLQUFLLEVBQUU7Z0JBQ0wsSUFBSSxFQUFFLGtCQUFrQjtnQkFDeEIsT0FBTyxFQUFFLDZCQUE2QjthQUN2QztTQUNGLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCwwQkFBMEI7UUFDMUIscUJBQXFCO1FBQ3JCLHlCQUF5QjtRQUN6QixpQkFBaUI7UUFDakIsNkNBQTZDO1FBQzdDLHNCQUFzQjtRQUV0QixNQUFNLFlBQVksR0FBRyxRQUFRLENBQUE7UUFDN0Isa0ZBQWtGO1FBRWxGLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDUCxTQUFTLEVBQUU7Z0JBQ1QsRUFBRSxFQUFFLE9BQU87Z0JBQ1gsUUFBUTtnQkFDUixVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUU7YUFDdkI7U0FDRixDQUFDLENBQUE7SUFDSixDQUFDO0lBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztRQUNwQixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUU7Z0JBQ0wsSUFBSSxFQUFFLG1CQUFtQjtnQkFDekIsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO2FBQ3ZCO1NBQ0YsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUM7QUFFTSxLQUFLLFVBQVUsTUFBTSxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDbEUsTUFBTSxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFBO0lBRWxDLElBQUksQ0FBQztRQUNILHdCQUF3QjtRQUN4QixHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ1AsT0FBTyxFQUFFLElBQUk7WUFDYixFQUFFLEVBQUUsT0FBTztTQUNaLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1FBQ3BCLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLEtBQUssRUFBRTtnQkFDTCxJQUFJLEVBQUUsbUJBQW1CO2dCQUN6QixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87YUFDdkI7U0FDRixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9