"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const omex_order_1 = require("../../../../../modules/omex-order");
const omex_inventory_1 = require("../../../../../modules/omex-inventory");
async function POST(req, res) {
    const orderService = req.scope.resolve(omex_order_1.OMEX_ORDER_MODULE);
    const inventoryService = req.scope.resolve(omex_inventory_1.OMEX_INVENTORY_MODULE);
    const { id } = req.params;
    const { shipping_address, billing_address, shipping_method, payment_method, purchase_order_number, delivery_date, payment_terms, } = req.body;
    // Validate required fields
    if (!shipping_address || !shipping_method || !payment_method) {
        return res.status(400).json({
            error: {
                code: 'MISSING_REQUIRED_FIELDS',
                message: 'Shipping address, shipping method, and payment method are required',
            },
        });
    }
    try {
        // In real implementation:
        // 1. Fetch cart with items
        // 2. Validate all items still in stock
        // 3. Reserve stock
        // 4. Create order
        // 5. Process payment
        // 6. Send confirmation email
        // 7. Clear cart
        const customer_id = req.auth_context?.actor_id || 'guest';
        const order = await orderService.createOrderFromCart({
            customer_id,
            cart_id: id,
            purchase_order_number,
            delivery_date: delivery_date ? new Date(delivery_date) : undefined,
            payment_terms,
        });
        res.json({
            order,
            message: 'Order placed successfully',
        });
    }
    catch (error) {
        res.status(400).json({
            error: {
                code: 'CHECKOUT_ERROR',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL29tZXgtY2FydC9baWRdL2NvbXBsZXRlL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBSUEsb0JBeURDO0FBNURELGtFQUFxRTtBQUNyRSwwRUFBNkU7QUFFdEUsS0FBSyxVQUFVLElBQUksQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQ2hFLE1BQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLDhCQUFpQixDQUFDLENBQUE7SUFDekQsTUFBTSxnQkFBZ0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxzQ0FBcUIsQ0FBQyxDQUFBO0lBRWpFLE1BQU0sRUFBRSxFQUFFLEVBQUUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFBO0lBQ3pCLE1BQU0sRUFDSixnQkFBZ0IsRUFDaEIsZUFBZSxFQUNmLGVBQWUsRUFDZixjQUFjLEVBQ2QscUJBQXFCLEVBQ3JCLGFBQWEsRUFDYixhQUFhLEdBQ2QsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBRVosMkJBQTJCO0lBQzNCLElBQUksQ0FBQyxnQkFBZ0IsSUFBSSxDQUFDLGVBQWUsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQzdELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSx5QkFBeUI7Z0JBQy9CLE9BQU8sRUFBRSxvRUFBb0U7YUFDOUU7U0FDRixDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsSUFBSSxDQUFDO1FBQ0gsMEJBQTBCO1FBQzFCLDJCQUEyQjtRQUMzQix1Q0FBdUM7UUFDdkMsbUJBQW1CO1FBQ25CLGtCQUFrQjtRQUNsQixxQkFBcUI7UUFDckIsNkJBQTZCO1FBQzdCLGdCQUFnQjtRQUVoQixNQUFNLFdBQVcsR0FBRyxHQUFHLENBQUMsWUFBWSxFQUFFLFFBQVEsSUFBSSxPQUFPLENBQUE7UUFFekQsTUFBTSxLQUFLLEdBQUcsTUFBTSxZQUFZLENBQUMsbUJBQW1CLENBQUM7WUFDbkQsV0FBVztZQUNYLE9BQU8sRUFBRSxFQUFFO1lBQ1gscUJBQXFCO1lBQ3JCLGFBQWEsRUFBRSxhQUFhLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTO1lBQ2xFLGFBQWE7U0FDZCxDQUFDLENBQUE7UUFFRixHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ1AsS0FBSztZQUNMLE9BQU8sRUFBRSwyQkFBMkI7U0FDckMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSxnQkFBZ0I7Z0JBQ3RCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTzthQUN2QjtTQUNGLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=