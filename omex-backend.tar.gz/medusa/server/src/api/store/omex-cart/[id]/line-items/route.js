"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const omex_product_1 = require("../../../../../modules/omex-product");
const omex_pricing_1 = require("../../../../../modules/omex-pricing");
const omex_inventory_1 = require("../../../../../modules/omex-inventory");
async function POST(req, res) {
    const productService = req.scope.resolve(omex_product_1.OMEX_PRODUCT_MODULE);
    const pricingService = req.scope.resolve(omex_pricing_1.OMEX_PRICING_MODULE);
    const inventoryService = req.scope.resolve(omex_inventory_1.OMEX_INVENTORY_MODULE);
    const { id } = req.params;
    const { product_id, quantity } = req.body;
    if (!product_id || !quantity) {
        return res.status(400).json({
            error: {
                code: 'MISSING_FIELDS',
                message: 'Product ID and quantity are required',
            },
        });
    }
    try {
        // Get product
        const product = await productService.retrieveProduct(product_id);
        if (!product) {
            return res.status(404).json({
                error: {
                    code: 'PRODUCT_NOT_FOUND',
                    message: `Product ${product_id} not found`,
                },
            });
        }
        // Check minimum order quantity
        if (product.min_order_qty && quantity < product.min_order_qty) {
            return res.status(400).json({
                error: {
                    code: 'MIN_ORDER_QTY_NOT_MET',
                    message: `Minimum order quantity is ${product.min_order_qty}`,
                },
            });
        }
        // Check stock availability
        const stock = await inventoryService.getTotalStock(product_id);
        if (stock < quantity) {
            return res.status(400).json({
                error: {
                    code: 'INSUFFICIENT_STOCK',
                    message: `Only ${stock} units available`,
                },
            });
        }
        // Get price (customer type from session)
        const customerType = 'retail'; // Default
        const price = await pricingService.getPrice(product_id, customerType, quantity);
        // Add item to cart
        const lineItem = {
            id: `item_${Date.now()}`,
            cart_id: id,
            product_id,
            quantity,
            unit_price: price.amount,
            total: price.amount * quantity,
            created_at: new Date(),
        };
        res.json({ line_item: lineItem });
    }
    catch (error) {
        res.status(400).json({
            error: {
                code: 'ADD_TO_CART_ERROR',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL29tZXgtY2FydC9baWRdL2xpbmUtaXRlbXMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFLQSxvQkEyRUM7QUEvRUQsc0VBQXlFO0FBQ3pFLHNFQUF5RTtBQUN6RSwwRUFBNkU7QUFFdEUsS0FBSyxVQUFVLElBQUksQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQ2hFLE1BQU0sY0FBYyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGtDQUFtQixDQUFDLENBQUE7SUFDN0QsTUFBTSxjQUFjLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsa0NBQW1CLENBQUMsQ0FBQTtJQUM3RCxNQUFNLGdCQUFnQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHNDQUFxQixDQUFDLENBQUE7SUFFakUsTUFBTSxFQUFFLEVBQUUsRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUE7SUFDekIsTUFBTSxFQUFFLFVBQVUsRUFBRSxRQUFRLEVBQUUsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBRXpDLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUM3QixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLEtBQUssRUFBRTtnQkFDTCxJQUFJLEVBQUUsZ0JBQWdCO2dCQUN0QixPQUFPLEVBQUUsc0NBQXNDO2FBQ2hEO1NBQ0YsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELElBQUksQ0FBQztRQUNILGNBQWM7UUFDZCxNQUFNLE9BQU8sR0FBRyxNQUFNLGNBQWMsQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDLENBQUE7UUFFaEUsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2IsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDMUIsS0FBSyxFQUFFO29CQUNMLElBQUksRUFBRSxtQkFBbUI7b0JBQ3pCLE9BQU8sRUFBRSxXQUFXLFVBQVUsWUFBWTtpQkFDM0M7YUFDRixDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsK0JBQStCO1FBQy9CLElBQUksT0FBTyxDQUFDLGFBQWEsSUFBSSxRQUFRLEdBQUcsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQzlELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzFCLEtBQUssRUFBRTtvQkFDTCxJQUFJLEVBQUUsdUJBQXVCO29CQUM3QixPQUFPLEVBQUUsNkJBQTZCLE9BQU8sQ0FBQyxhQUFhLEVBQUU7aUJBQzlEO2FBQ0YsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUVELDJCQUEyQjtRQUMzQixNQUFNLEtBQUssR0FBRyxNQUFNLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQTtRQUM5RCxJQUFJLEtBQUssR0FBRyxRQUFRLEVBQUUsQ0FBQztZQUNyQixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUMxQixLQUFLLEVBQUU7b0JBQ0wsSUFBSSxFQUFFLG9CQUFvQjtvQkFDMUIsT0FBTyxFQUFFLFFBQVEsS0FBSyxrQkFBa0I7aUJBQ3pDO2FBQ0YsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUVELHlDQUF5QztRQUN6QyxNQUFNLFlBQVksR0FBRyxRQUFRLENBQUEsQ0FBQyxVQUFVO1FBQ3hDLE1BQU0sS0FBSyxHQUFHLE1BQU0sY0FBYyxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUUsWUFBWSxFQUFFLFFBQVEsQ0FBQyxDQUFBO1FBRS9FLG1CQUFtQjtRQUNuQixNQUFNLFFBQVEsR0FBRztZQUNmLEVBQUUsRUFBRSxRQUFRLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtZQUN4QixPQUFPLEVBQUUsRUFBRTtZQUNYLFVBQVU7WUFDVixRQUFRO1lBQ1IsVUFBVSxFQUFFLEtBQUssQ0FBQyxNQUFNO1lBQ3hCLEtBQUssRUFBRSxLQUFLLENBQUMsTUFBTSxHQUFHLFFBQVE7WUFDOUIsVUFBVSxFQUFFLElBQUksSUFBSSxFQUFFO1NBQ3ZCLENBQUE7UUFFRCxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUE7SUFDbkMsQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSxtQkFBbUI7Z0JBQ3pCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTzthQUN2QjtTQUNGLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=