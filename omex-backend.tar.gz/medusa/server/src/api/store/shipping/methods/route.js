"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const shipping_service_1 = require("../../../../services/shipping-service");
async function GET(req, res) {
    try {
        const shippingService = new shipping_service_1.ShippingService({
            inpost: {
                apiKey: process.env.INPOST_API_KEY || "",
                apiSecret: process.env.INPOST_API_SECRET || "",
                orgId: process.env.INPOST_ORG_ID || "",
            },
            dpd: {
                apiKey: process.env.DPD_API_KEY || "",
                login: process.env.DPD_LOGIN || "",
                password: process.env.DPD_PASSWORD || "",
            },
            dhl: {
                apiKey: process.env.DHL_API_KEY || "",
                accountNumber: process.env.DHL_ACCOUNT_NUMBER || "",
            },
        });
        const providers = shippingService.getAvailableProviders();
        const methods = [
            // InPost methods
            {
                id: "inpost_paczkomat_24_7",
                name: "InPost Paczkomat 24/7",
                provider: "inpost",
                price: 4.99,
                delivery_days: 2,
                currency: "USD",
            },
            {
                id: "inpost_courier",
                name: "InPost Courier",
                provider: "inpost",
                price: 7.99,
                delivery_days: 2,
                currency: "USD",
            },
            {
                id: "inpost_parcel_locker",
                name: "InPost Standard Locker",
                provider: "inpost",
                price: 3.99,
                delivery_days: 2,
                currency: "USD",
            },
            // DPD methods
            {
                id: "dpd_economy",
                name: "DPD Economy",
                provider: "dpd",
                price: 6.99,
                delivery_days: 3,
                currency: "USD",
            },
            {
                id: "dpd_express",
                name: "DPD Express",
                provider: "dpd",
                price: 12.99,
                delivery_days: 1,
                currency: "USD",
            },
            // DHL methods
            {
                id: "dhl_parcel",
                name: "DHL Parcel",
                provider: "dhl",
                price: 8.99,
                delivery_days: 3,
                currency: "USD",
            },
            {
                id: "dhl_express",
                name: "DHL Express",
                provider: "dhl",
                price: 14.99,
                delivery_days: 1,
                currency: "USD",
            },
        ].filter((method) => providers.includes(method.provider));
        res.json({ methods });
    }
    catch (error) {
        console.error("Failed to fetch shipping methods:", error);
        res.status(500).json({
            error: "Failed to fetch shipping methods",
            message: error.message,
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3NoaXBwaW5nL21ldGhvZHMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFHQSxrQkEyRkM7QUE3RkQsNEVBQXdFO0FBRWpFLEtBQUssVUFBVSxHQUFHLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUMvRCxJQUFJLENBQUM7UUFDSCxNQUFNLGVBQWUsR0FBRyxJQUFJLGtDQUFlLENBQUM7WUFDMUMsTUFBTSxFQUFFO2dCQUNOLE1BQU0sRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsSUFBSSxFQUFFO2dCQUN4QyxTQUFTLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsSUFBSSxFQUFFO2dCQUM5QyxLQUFLLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLElBQUksRUFBRTthQUN2QztZQUNELEdBQUcsRUFBRTtnQkFDSCxNQUFNLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLElBQUksRUFBRTtnQkFDckMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxJQUFJLEVBQUU7Z0JBQ2xDLFFBQVEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksSUFBSSxFQUFFO2FBQ3pDO1lBQ0QsR0FBRyxFQUFFO2dCQUNILE1BQU0sRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsSUFBSSxFQUFFO2dCQUNyQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsSUFBSSxFQUFFO2FBQ3BEO1NBQ0YsQ0FBQyxDQUFDO1FBRUgsTUFBTSxTQUFTLEdBQUcsZUFBZSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFFMUQsTUFBTSxPQUFPLEdBQUc7WUFDZCxpQkFBaUI7WUFDakI7Z0JBQ0UsRUFBRSxFQUFFLHVCQUF1QjtnQkFDM0IsSUFBSSxFQUFFLHVCQUF1QjtnQkFDN0IsUUFBUSxFQUFFLFFBQVE7Z0JBQ2xCLEtBQUssRUFBRSxJQUFJO2dCQUNYLGFBQWEsRUFBRSxDQUFDO2dCQUNoQixRQUFRLEVBQUUsS0FBSzthQUNoQjtZQUNEO2dCQUNFLEVBQUUsRUFBRSxnQkFBZ0I7Z0JBQ3BCLElBQUksRUFBRSxnQkFBZ0I7Z0JBQ3RCLFFBQVEsRUFBRSxRQUFRO2dCQUNsQixLQUFLLEVBQUUsSUFBSTtnQkFDWCxhQUFhLEVBQUUsQ0FBQztnQkFDaEIsUUFBUSxFQUFFLEtBQUs7YUFDaEI7WUFDRDtnQkFDRSxFQUFFLEVBQUUsc0JBQXNCO2dCQUMxQixJQUFJLEVBQUUsd0JBQXdCO2dCQUM5QixRQUFRLEVBQUUsUUFBUTtnQkFDbEIsS0FBSyxFQUFFLElBQUk7Z0JBQ1gsYUFBYSxFQUFFLENBQUM7Z0JBQ2hCLFFBQVEsRUFBRSxLQUFLO2FBQ2hCO1lBQ0QsY0FBYztZQUNkO2dCQUNFLEVBQUUsRUFBRSxhQUFhO2dCQUNqQixJQUFJLEVBQUUsYUFBYTtnQkFDbkIsUUFBUSxFQUFFLEtBQUs7Z0JBQ2YsS0FBSyxFQUFFLElBQUk7Z0JBQ1gsYUFBYSxFQUFFLENBQUM7Z0JBQ2hCLFFBQVEsRUFBRSxLQUFLO2FBQ2hCO1lBQ0Q7Z0JBQ0UsRUFBRSxFQUFFLGFBQWE7Z0JBQ2pCLElBQUksRUFBRSxhQUFhO2dCQUNuQixRQUFRLEVBQUUsS0FBSztnQkFDZixLQUFLLEVBQUUsS0FBSztnQkFDWixhQUFhLEVBQUUsQ0FBQztnQkFDaEIsUUFBUSxFQUFFLEtBQUs7YUFDaEI7WUFDRCxjQUFjO1lBQ2Q7Z0JBQ0UsRUFBRSxFQUFFLFlBQVk7Z0JBQ2hCLElBQUksRUFBRSxZQUFZO2dCQUNsQixRQUFRLEVBQUUsS0FBSztnQkFDZixLQUFLLEVBQUUsSUFBSTtnQkFDWCxhQUFhLEVBQUUsQ0FBQztnQkFDaEIsUUFBUSxFQUFFLEtBQUs7YUFDaEI7WUFDRDtnQkFDRSxFQUFFLEVBQUUsYUFBYTtnQkFDakIsSUFBSSxFQUFFLGFBQWE7Z0JBQ25CLFFBQVEsRUFBRSxLQUFLO2dCQUNmLEtBQUssRUFBRSxLQUFLO2dCQUNaLGFBQWEsRUFBRSxDQUFDO2dCQUNoQixRQUFRLEVBQUUsS0FBSzthQUNoQjtTQUNGLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBRTFELEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDO0lBQ3hCLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyxtQ0FBbUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUMxRCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUUsa0NBQWtDO1lBQ3pDLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztTQUN2QixDQUFDLENBQUM7SUFDTCxDQUFDO0FBQ0gsQ0FBQyJ9