"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const shipping_service_1 = require("../../../../services/shipping-service");
async function POST(req, res) {
    try {
        const { postal_code, country, weight, dimensions } = req.body;
        if (!postal_code || !country || !weight) {
            return res.status(400).json({
                error: "Missing required fields: postal_code, country, weight",
            });
        }
        const shippingService = new shipping_service_1.ShippingService({
            inpost: {
                apiKey: process.env.INPOST_API_KEY || "",
                apiSecret: process.env.INPOST_API_SECRET || "",
                orgId: process.env.INPOST_ORG_ID || "",
            },
            dpd: {
                apiKey: process.env.DPD_API_KEY || "",
                login: process.env.DPD_LOGIN || "",
                password: process.env.DPD_PASSWORD || "",
            },
            dhl: {
                apiKey: process.env.DHL_API_KEY || "",
                accountNumber: process.env.DHL_ACCOUNT_NUMBER || "",
            },
        });
        const origin = {
            street: "Warehouse Street 1",
            city: "Warsaw",
            postal_code: "00-001",
            country: "PL",
        };
        const destination = {
            street: "",
            city: "",
            postal_code,
            country,
        };
        const parcel = {
            weight: weight || 1000,
            length: dimensions?.length || 30,
            width: dimensions?.width || 20,
            height: dimensions?.height || 10,
        };
        const rates = await shippingService.getRates(origin, destination, parcel);
        res.json({ rates });
    }
    catch (error) {
        console.error("Failed to calculate shipping rates:", error);
        res.status(500).json({
            error: "Failed to calculate shipping rates",
            message: error.message,
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3NoaXBwaW5nL3JhdGVzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBR0Esb0JBMERDO0FBNURELDRFQUF3RTtBQUVqRSxLQUFLLFVBQVUsSUFBSSxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDaEUsSUFBSSxDQUFDO1FBQ0gsTUFBTSxFQUFFLFdBQVcsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFFOUQsSUFBSSxDQUFDLFdBQVcsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3hDLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzFCLEtBQUssRUFBRSx1REFBdUQ7YUFDL0QsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVELE1BQU0sZUFBZSxHQUFHLElBQUksa0NBQWUsQ0FBQztZQUMxQyxNQUFNLEVBQUU7Z0JBQ04sTUFBTSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxJQUFJLEVBQUU7Z0JBQ3hDLFNBQVMsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixJQUFJLEVBQUU7Z0JBQzlDLEtBQUssRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLGFBQWEsSUFBSSxFQUFFO2FBQ3ZDO1lBQ0QsR0FBRyxFQUFFO2dCQUNILE1BQU0sRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsSUFBSSxFQUFFO2dCQUNyQyxLQUFLLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLElBQUksRUFBRTtnQkFDbEMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxJQUFJLEVBQUU7YUFDekM7WUFDRCxHQUFHLEVBQUU7Z0JBQ0gsTUFBTSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxJQUFJLEVBQUU7Z0JBQ3JDLGFBQWEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixJQUFJLEVBQUU7YUFDcEQ7U0FDRixDQUFDLENBQUM7UUFFSCxNQUFNLE1BQU0sR0FBRztZQUNiLE1BQU0sRUFBRSxvQkFBb0I7WUFDNUIsSUFBSSxFQUFFLFFBQVE7WUFDZCxXQUFXLEVBQUUsUUFBUTtZQUNyQixPQUFPLEVBQUUsSUFBSTtTQUNkLENBQUM7UUFFRixNQUFNLFdBQVcsR0FBRztZQUNsQixNQUFNLEVBQUUsRUFBRTtZQUNWLElBQUksRUFBRSxFQUFFO1lBQ1IsV0FBVztZQUNYLE9BQU87U0FDUixDQUFDO1FBRUYsTUFBTSxNQUFNLEdBQUc7WUFDYixNQUFNLEVBQUUsTUFBTSxJQUFJLElBQUk7WUFDdEIsTUFBTSxFQUFFLFVBQVUsRUFBRSxNQUFNLElBQUksRUFBRTtZQUNoQyxLQUFLLEVBQUUsVUFBVSxFQUFFLEtBQUssSUFBSSxFQUFFO1lBQzlCLE1BQU0sRUFBRSxVQUFVLEVBQUUsTUFBTSxJQUFJLEVBQUU7U0FDakMsQ0FBQztRQUVGLE1BQU0sS0FBSyxHQUFHLE1BQU0sZUFBZSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBRTFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO0lBQ3RCLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyxxQ0FBcUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUM1RCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUUsb0NBQW9DO1lBQzNDLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztTQUN2QixDQUFDLENBQUM7SUFDTCxDQUFDO0FBQ0gsQ0FBQyJ9