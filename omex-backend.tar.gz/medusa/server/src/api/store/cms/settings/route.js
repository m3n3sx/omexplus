"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const cms_1 = require("../../../../modules/cms");
async function GET(req, res) {
    const cmsService = req.scope.resolve(cms_1.CMS_MODULE);
    const settings = await cmsService.getSettings();
    // Zwróć tylko publiczne ustawienia
    const publicSettings = {
        siteName: settings.siteName,
        siteDescription: settings.siteDescription,
        logo: settings.logo,
        socialMedia: settings.socialMedia,
        contactInfo: settings.contactInfo,
    };
    res.json({ settings: publicSettings });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2Ntcy9zZXR0aW5ncy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUdBLGtCQWNDO0FBaEJELGlEQUFvRDtBQUU3QyxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZ0JBQVUsQ0FBQyxDQUFBO0lBQ2hELE1BQU0sUUFBUSxHQUFHLE1BQU0sVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFBO0lBRS9DLG1DQUFtQztJQUNuQyxNQUFNLGNBQWMsR0FBRztRQUNyQixRQUFRLEVBQUUsUUFBUSxDQUFDLFFBQVE7UUFDM0IsZUFBZSxFQUFFLFFBQVEsQ0FBQyxlQUFlO1FBQ3pDLElBQUksRUFBRSxRQUFRLENBQUMsSUFBSTtRQUNuQixXQUFXLEVBQUUsUUFBUSxDQUFDLFdBQVc7UUFDakMsV0FBVyxFQUFFLFFBQVEsQ0FBQyxXQUFXO0tBQ2xDLENBQUE7SUFFRCxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsUUFBUSxFQUFFLGNBQWMsRUFBRSxDQUFDLENBQUE7QUFDeEMsQ0FBQyJ9