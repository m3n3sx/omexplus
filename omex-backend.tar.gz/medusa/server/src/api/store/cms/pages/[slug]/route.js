"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const cms_1 = require("../../../../../modules/cms");
async function GET(req, res) {
    const cmsService = req.scope.resolve(cms_1.CMS_MODULE);
    const page = await cmsService.getPage(req.params.slug);
    res.json({ page });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2Ntcy9wYWdlcy9bc2x1Z10vcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFHQSxrQkFLQztBQVBELG9EQUF1RDtBQUVoRCxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZ0JBQVUsQ0FBQyxDQUFBO0lBQ2hELE1BQU0sSUFBSSxHQUFHLE1BQU0sVUFBVSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFBO0lBRXRELEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO0FBQ3BCLENBQUMifQ==