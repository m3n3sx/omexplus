"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
/**
 * POST /store/checkout/payment/intent
 * Create a Stripe PaymentIntent for checkout
 */
async function POST(req, res) {
    try {
        const { cart_id, email, amount, currency, metadata } = req.body;
        // Validate required fields
        if (!cart_id || !amount || !currency) {
            return res.status(400).json({
                error: 'Missing required fields: cart_id, amount, currency',
            });
        }
        const paymentService = req.scope.resolve('paymentService');
        const result = await paymentService.createPaymentIntent({
            amount,
            currency,
            customer_email: email,
            metadata: {
                cart_id,
                ...metadata,
            },
        });
        return res.status(200).json({
            clientSecret: result.clientSecret,
            paymentIntentId: result.paymentIntentId,
        });
    }
    catch (error) {
        console.error('Payment intent creation error:', error);
        return res.status(500).json({
            error: error.message || 'Failed to create payment intent',
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2NoZWNrb3V0L3BheW1lbnQvaW50ZW50L3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBT0Esb0JBaUNDO0FBckNEOzs7R0FHRztBQUNJLEtBQUssVUFBVSxJQUFJLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUNoRSxJQUFJLENBQUM7UUFDSCxNQUFNLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFFaEUsMkJBQTJCO1FBQzNCLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNyQyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUMxQixLQUFLLEVBQUUsb0RBQW9EO2FBQzVELENBQUMsQ0FBQztRQUNMLENBQUM7UUFFRCxNQUFNLGNBQWMsR0FBbUIsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUUzRSxNQUFNLE1BQU0sR0FBRyxNQUFNLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBQztZQUN0RCxNQUFNO1lBQ04sUUFBUTtZQUNSLGNBQWMsRUFBRSxLQUFLO1lBQ3JCLFFBQVEsRUFBRTtnQkFDUixPQUFPO2dCQUNQLEdBQUcsUUFBUTthQUNaO1NBQ0YsQ0FBQyxDQUFDO1FBRUgsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7WUFDakMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxlQUFlO1NBQ3hDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyxnQ0FBZ0MsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUN2RCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTyxJQUFJLGlDQUFpQztTQUMxRCxDQUFDLENBQUM7SUFDTCxDQUFDO0FBQ0gsQ0FBQyJ9