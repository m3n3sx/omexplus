"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
/**
 * GET /store/products/search/manufacturer
 * Search by manufacturer SKU
 */
async function GET(req, res) {
    const { sku, manufacturer_id } = req.query;
    if (!sku || typeof sku !== "string") {
        return res.status(400).json({
            error: "Manufacturer SKU is required",
        });
    }
    try {
        const searchService = req.scope.resolve("omexSearch");
        const results = await searchService.searchByManufacturerSKU(sku, manufacturer_id);
        return res.json({
            products: results,
            count: results.length,
        });
    }
    catch (error) {
        return res.status(500).json({
            error: error.message || "Search failed",
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3Byb2R1Y3RzL3NlYXJjaC9tYW51ZmFjdHVyZXIvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFNQSxrQkEwQkM7QUE5QkQ7OztHQUdHO0FBQ0ksS0FBSyxVQUFVLEdBQUcsQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQy9ELE1BQU0sRUFBRSxHQUFHLEVBQUUsZUFBZSxFQUFFLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtJQUUxQyxJQUFJLENBQUMsR0FBRyxJQUFJLE9BQU8sR0FBRyxLQUFLLFFBQVEsRUFBRSxDQUFDO1FBQ3BDLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsS0FBSyxFQUFFLDhCQUE4QjtTQUN0QyxDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsSUFBSSxDQUFDO1FBQ0gsTUFBTSxhQUFhLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUE7UUFFckQsTUFBTSxPQUFPLEdBQUcsTUFBTSxhQUFhLENBQUMsdUJBQXVCLENBQ3pELEdBQUcsRUFDSCxlQUFxQyxDQUN0QyxDQUFBO1FBRUQsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ2QsUUFBUSxFQUFFLE9BQU87WUFDakIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxNQUFNO1NBQ3RCLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1FBQ3BCLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxPQUFPLElBQUksZUFBZTtTQUN4QyxDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9