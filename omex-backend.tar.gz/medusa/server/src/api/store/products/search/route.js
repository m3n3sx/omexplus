"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
/**
 * GET /store/products/search
 * Basic product search with filters
 */
async function GET(req, res) {
    const { query, category, price_min, price_max, sort, limit = 20, offset = 0 } = req.query;
    if (!query || typeof query !== "string" || query.trim().length === 0) {
        return res.status(400).json({
            error: "Search query is required",
        });
    }
    try {
        // Get search service
        const searchService = req.scope.resolve("omexSearch");
        // Build filters
        const filters = {};
        if (category)
            filters.category_id = category;
        if (price_min)
            filters.min_price = parseFloat(price_min);
        if (price_max)
            filters.max_price = parseFloat(price_max);
        // Build sort options
        const sortOptions = {
            field: "popularity",
            order: "desc",
        };
        if (sort === "price_asc") {
            sortOptions.field = "price";
            sortOptions.order = "asc";
        }
        else if (sort === "price_desc") {
            sortOptions.field = "price";
            sortOptions.order = "desc";
        }
        else if (sort === "newest") {
            sortOptions.field = "created_at";
            sortOptions.order = "desc";
        }
        // Perform search
        const result = await searchService.search(query, filters, sortOptions, {
            page: Math.floor(Number(offset) / Number(limit)) + 1,
            limit: Number(limit),
        });
        return res.json(result);
    }
    catch (error) {
        return res.status(500).json({
            error: error.message || "Search failed",
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3Byb2R1Y3RzL3NlYXJjaC9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQU1BLGtCQXFEQztBQXpERDs7O0dBR0c7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsS0FBSyxHQUFHLEVBQUUsRUFBRSxNQUFNLEdBQUcsQ0FBQyxFQUFFLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtJQUV6RixJQUFJLENBQUMsS0FBSyxJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsSUFBSSxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1FBQ3JFLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsS0FBSyxFQUFFLDBCQUEwQjtTQUNsQyxDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsSUFBSSxDQUFDO1FBQ0gscUJBQXFCO1FBQ3JCLE1BQU0sYUFBYSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFBO1FBRXJELGdCQUFnQjtRQUNoQixNQUFNLE9BQU8sR0FBUSxFQUFFLENBQUE7UUFDdkIsSUFBSSxRQUFRO1lBQUUsT0FBTyxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUE7UUFDNUMsSUFBSSxTQUFTO1lBQUUsT0FBTyxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUMsU0FBbUIsQ0FBQyxDQUFBO1FBQ2xFLElBQUksU0FBUztZQUFFLE9BQU8sQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLFNBQW1CLENBQUMsQ0FBQTtRQUVsRSxxQkFBcUI7UUFDckIsTUFBTSxXQUFXLEdBQUc7WUFDbEIsS0FBSyxFQUFFLFlBQXFCO1lBQzVCLEtBQUssRUFBRSxNQUFlO1NBQ3ZCLENBQUE7UUFFRCxJQUFJLElBQUksS0FBSyxXQUFXLEVBQUUsQ0FBQztZQUN6QixXQUFXLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQTtZQUMzQixXQUFXLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQTtRQUMzQixDQUFDO2FBQU0sSUFBSSxJQUFJLEtBQUssWUFBWSxFQUFFLENBQUM7WUFDakMsV0FBVyxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUE7WUFDM0IsV0FBVyxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUE7UUFDNUIsQ0FBQzthQUFNLElBQUksSUFBSSxLQUFLLFFBQVEsRUFBRSxDQUFDO1lBQzdCLFdBQVcsQ0FBQyxLQUFLLEdBQUcsWUFBWSxDQUFBO1lBQ2hDLFdBQVcsQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFBO1FBQzVCLENBQUM7UUFFRCxpQkFBaUI7UUFDakIsTUFBTSxNQUFNLEdBQUcsTUFBTSxhQUFhLENBQUMsTUFBTSxDQUN2QyxLQUFLLEVBQ0wsT0FBTyxFQUNQLFdBQVcsRUFDWDtZQUNFLElBQUksRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDO1lBQ3BELEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDO1NBQ3JCLENBQ0YsQ0FBQTtRQUVELE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUN6QixDQUFDO0lBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztRQUNwQixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTyxJQUFJLGVBQWU7U0FDeEMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==