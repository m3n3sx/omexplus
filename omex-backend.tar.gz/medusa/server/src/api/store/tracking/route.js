"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
async function GET(req, res) {
    const { orderId } = req.query;
    // Śledzenie przesyłki
    const tracking = {
        orderId,
        status: "in_transit",
        trackingNumber: "TRACK123456",
        carrier: "DHL",
        estimatedDelivery: new Date(),
        history: [],
    };
    res.json({ tracking });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3RyYWNraW5nL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBRUEsa0JBY0M7QUFkTSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxFQUFFLE9BQU8sRUFBRSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUE7SUFFN0Isc0JBQXNCO0lBQ3RCLE1BQU0sUUFBUSxHQUFHO1FBQ2YsT0FBTztRQUNQLE1BQU0sRUFBRSxZQUFZO1FBQ3BCLGNBQWMsRUFBRSxhQUFhO1FBQzdCLE9BQU8sRUFBRSxLQUFLO1FBQ2QsaUJBQWlCLEVBQUUsSUFBSSxJQUFJLEVBQUU7UUFDN0IsT0FBTyxFQUFFLEVBQUU7S0FDWixDQUFBO0lBRUQsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUE7QUFDeEIsQ0FBQyJ9