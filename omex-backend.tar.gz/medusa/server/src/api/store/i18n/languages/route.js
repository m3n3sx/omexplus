"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const i18n_1 = require("../../../../modules/i18n");
async function GET(req, res) {
    const i18nService = req.scope.resolve(i18n_1.I18N_MODULE);
    const languages = await i18nService.getSupportedLanguages();
    const defaultLanguage = await i18nService.getDefaultLanguage();
    res.json({
        languages,
        defaultLanguage
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2kxOG4vbGFuZ3VhZ2VzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBR0Esa0JBVUM7QUFaRCxtREFBc0Q7QUFFL0MsS0FBSyxVQUFVLEdBQUcsQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQy9ELE1BQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGtCQUFXLENBQUMsQ0FBQTtJQUVsRCxNQUFNLFNBQVMsR0FBRyxNQUFNLFdBQVcsQ0FBQyxxQkFBcUIsRUFBRSxDQUFBO0lBQzNELE1BQU0sZUFBZSxHQUFHLE1BQU0sV0FBVyxDQUFDLGtCQUFrQixFQUFFLENBQUE7SUFFOUQsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNQLFNBQVM7UUFDVCxlQUFlO0tBQ2hCLENBQUMsQ0FBQTtBQUNKLENBQUMifQ==