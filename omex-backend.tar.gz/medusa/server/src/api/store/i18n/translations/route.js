"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const i18n_1 = require("../../../../modules/i18n");
async function GET(req, res) {
    const i18nService = req.scope.resolve(i18n_1.I18N_MODULE);
    const { locale, namespace } = req.query;
    const translations = await i18nService.getTranslations(locale || "pl", namespace);
    res.json({ translations });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2kxOG4vdHJhbnNsYXRpb25zL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBR0Esa0JBVUM7QUFaRCxtREFBc0Q7QUFFL0MsS0FBSyxVQUFVLEdBQUcsQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQy9ELE1BQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGtCQUFXLENBQUMsQ0FBQTtJQUNsRCxNQUFNLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUE7SUFFdkMsTUFBTSxZQUFZLEdBQUcsTUFBTSxXQUFXLENBQUMsZUFBZSxDQUNwRCxNQUFnQixJQUFJLElBQUksRUFDeEIsU0FBbUIsQ0FDcEIsQ0FBQTtJQUVELEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxZQUFZLEVBQUUsQ0FBQyxDQUFBO0FBQzVCLENBQUMifQ==