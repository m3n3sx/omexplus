"use strict";
/**
 * METHOD 2: Part Number Search
 * GET /store/omex-search/part-number
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
async function GET(req, res) {
    const advancedSearchService = req.scope.resolve("advancedSearchService");
    try {
        const { partNumber, includeAlternatives = 'true', exactMatch = 'false' } = req.query;
        if (!partNumber) {
            return res.status(400).json({
                error: "Part number is required",
                example: "/store/omex-search/part-number?partNumber=320-8134",
            });
        }
        const result = await advancedSearchService.searchByPartNumber({
            partNumber: partNumber,
            includeAlternatives: includeAlternatives === 'true',
            exactMatch: exactMatch === 'true',
        });
        res.json(result);
    }
    catch (error) {
        res.status(500).json({
            error: "Part number search failed",
            message: error.message,
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL29tZXgtc2VhcmNoL3BhcnQtbnVtYmVyL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7O0dBR0c7O0FBSUgsa0JBaUNDO0FBakNNLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0scUJBQXFCLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQTtJQUV4RSxJQUFJLENBQUM7UUFDSCxNQUFNLEVBQ0osVUFBVSxFQUNWLG1CQUFtQixHQUFHLE1BQU0sRUFDNUIsVUFBVSxHQUFHLE9BQU8sRUFDckIsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFBO1FBRWIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2hCLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzFCLEtBQUssRUFBRSx5QkFBeUI7Z0JBQ2hDLE9BQU8sRUFBRSxvREFBb0Q7YUFDOUQsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUVELE1BQU0sTUFBTSxHQUFHLE1BQU0scUJBQXFCLENBQUMsa0JBQWtCLENBQUM7WUFDNUQsVUFBVSxFQUFFLFVBQW9CO1lBQ2hDLG1CQUFtQixFQUFFLG1CQUFtQixLQUFLLE1BQU07WUFDbkQsVUFBVSxFQUFFLFVBQVUsS0FBSyxNQUFNO1NBQ2xDLENBQUMsQ0FBQTtRQUVGLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUE7SUFDbEIsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUUsMkJBQTJCO1lBQ2xDLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztTQUN2QixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9