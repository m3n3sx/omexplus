"use strict";
/**
 * METHOD 3: Visual Search (Image Upload)
 * POST /store/omex-search/visual
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
async function POST(req, res) {
    const advancedSearchService = req.scope.resolve("advancedSearchService");
    try {
        const { image, imageUrl, detectOCR = true } = req.body;
        if (!image && !imageUrl) {
            return res.status(400).json({
                error: "Image data or URL is required",
                fields: {
                    image: "Base64 encoded image data",
                    imageUrl: "URL to image",
                    detectOCR: "Optional: Try to read part numbers (default: true)",
                },
            });
        }
        // Convert base64 to buffer if needed
        let imageBuffer;
        if (image) {
            imageBuffer = Buffer.from(image, 'base64');
        }
        else if (imageUrl) {
            // Fetch image from URL
            const response = await fetch(imageUrl);
            const arrayBuffer = await response.arrayBuffer();
            imageBuffer = Buffer.from(arrayBuffer);
        }
        const result = await advancedSearchService.searchByImage({
            image: imageBuffer,
            detectOCR,
        });
        res.json(result);
    }
    catch (error) {
        res.status(500).json({
            error: "Visual search failed",
            message: error.message,
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL29tZXgtc2VhcmNoL3Zpc3VhbC9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7OztHQUdHOztBQUlILG9CQTJDQztBQTNDTSxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixNQUFNLHFCQUFxQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUE7SUFFeEUsSUFBSSxDQUFDO1FBQ0gsTUFBTSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUyxHQUFHLElBQUksRUFBRSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUE7UUFFdEQsSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3hCLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzFCLEtBQUssRUFBRSwrQkFBK0I7Z0JBQ3RDLE1BQU0sRUFBRTtvQkFDTixLQUFLLEVBQUUsMkJBQTJCO29CQUNsQyxRQUFRLEVBQUUsY0FBYztvQkFDeEIsU0FBUyxFQUFFLG9EQUFvRDtpQkFDaEU7YUFDRixDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQscUNBQXFDO1FBQ3JDLElBQUksV0FBbUIsQ0FBQTtRQUN2QixJQUFJLEtBQUssRUFBRSxDQUFDO1lBQ1YsV0FBVyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxDQUFBO1FBQzVDLENBQUM7YUFBTSxJQUFJLFFBQVEsRUFBRSxDQUFDO1lBQ3BCLHVCQUF1QjtZQUN2QixNQUFNLFFBQVEsR0FBRyxNQUFNLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQTtZQUN0QyxNQUFNLFdBQVcsR0FBRyxNQUFNLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQTtZQUNoRCxXQUFXLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQTtRQUN4QyxDQUFDO1FBRUQsTUFBTSxNQUFNLEdBQUcsTUFBTSxxQkFBcUIsQ0FBQyxhQUFhLENBQUM7WUFDdkQsS0FBSyxFQUFFLFdBQVk7WUFDbkIsU0FBUztTQUNWLENBQUMsQ0FBQTtRQUVGLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUE7SUFDbEIsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUUsc0JBQXNCO1lBQzdCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztTQUN2QixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9