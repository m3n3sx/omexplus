"use strict";
/**
 * GET /store/omex-search/machine/types
 * Get available machine types (step 2)
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
async function GET(req, res) {
    const advancedSearchService = req.scope.resolve("advancedSearchService");
    try {
        const { brand } = req.query;
        const types = await advancedSearchService.getMachineTypes(brand);
        res.json({
            types,
            count: types.length,
        });
    }
    catch (error) {
        res.status(500).json({
            error: "Failed to fetch machine types",
            message: error.message,
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL29tZXgtc2VhcmNoL21hY2hpbmUvdHlwZXMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7R0FHRzs7QUFJSCxrQkFxQkM7QUFyQk0sS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxxQkFBcUIsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFBO0lBRXhFLElBQUksQ0FBQztRQUNILE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFBO1FBRTNCLE1BQU0sS0FBSyxHQUFHLE1BQU0scUJBQXFCLENBQUMsZUFBZSxDQUFDLEtBQWUsQ0FBQyxDQUFBO1FBRTFFLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDUCxLQUFLO1lBQ0wsS0FBSyxFQUFFLEtBQUssQ0FBQyxNQUFNO1NBQ3BCLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFLCtCQUErQjtZQUN0QyxPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDdkIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==