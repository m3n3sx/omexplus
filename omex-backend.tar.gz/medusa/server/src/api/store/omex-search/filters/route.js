"use strict";
/**
 * METHOD 5: Advanced Filters
 * POST /store/omex-search/filters
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
exports.GET = GET;
async function POST(req, res) {
    const advancedSearchService = req.scope.resolve("advancedSearchService");
    try {
        const filters = req.body;
        const result = await advancedSearchService.searchWithFilters(filters);
        res.json(result);
    }
    catch (error) {
        res.status(500).json({
            error: "Filter search failed",
            message: error.message,
        });
    }
}
/**
 * GET /store/omex-search/filters/options
 * Get available filter options
 */
async function GET(req, res) {
    try {
        // Return available filter options
        res.json({
            categories: {
                description: "Multi-select categories",
                endpoint: "/store/omex-categories/tree",
            },
            machineBrands: {
                description: "Machine brands",
                options: [
                    "CAT", "Komatsu", "Hitachi", "Volvo", "JCB",
                    "Kobelco", "Hyundai", "Bobcat", "Doosan"
                ],
            },
            availability: {
                description: "Stock availability",
                options: [
                    { value: "in-stock", label: "Na magazynie" },
                    { value: "order-2-5-days", label: "Zamówienie (2-5 dni)" },
                    { value: "order-2-4-weeks", label: "Zamówienie (2-4 tygodnie)" },
                    { value: "discontinued", label: "Wycofane" },
                ],
            },
            partTypes: {
                description: "OEM vs alternatives",
                options: [
                    { value: "OEM", label: "Oryginalne" },
                    { value: "Certified", label: "Certyfikowane" },
                    { value: "Premium", label: "Wysokiej jakości" },
                    { value: "Budget", label: "Ekonomiczne" },
                ],
            },
            manufacturers: {
                description: "Part manufacturers",
                options: [
                    "Parker", "Rexroth", "Vickers", "Perkins",
                    "Yanmar", "Mitsubishi", "Bosch"
                ],
            },
            sortBy: {
                description: "Sort options",
                options: [
                    { value: "newest", label: "Najnowsze" },
                    { value: "best-selling", label: "Najlepiej sprzedające się" },
                    { value: "price-asc", label: "Najtańsze" },
                    { value: "price-desc", label: "Najdroższe" },
                    { value: "rating", label: "Najwyżej oceniane" },
                ],
            },
        });
    }
    catch (error) {
        res.status(500).json({
            error: "Failed to fetch filter options",
            message: error.message,
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL29tZXgtc2VhcmNoL2ZpbHRlcnMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7R0FHRzs7QUFJSCxvQkFrQkM7QUFNRCxrQkE0REM7QUFwRk0sS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxxQkFBcUIsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFBO0lBRXhFLElBQUksQ0FBQztRQUNILE1BQU0sT0FBTyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUE7UUFFeEIsTUFBTSxNQUFNLEdBQUcsTUFBTSxxQkFBcUIsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQTtRQUVyRSxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQ2xCLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFLHNCQUFzQjtZQUM3QixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDdkIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUM7QUFFRDs7O0dBR0c7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUN2QixHQUFrQixFQUNsQixHQUFtQjtJQUVuQixJQUFJLENBQUM7UUFDSCxrQ0FBa0M7UUFDbEMsR0FBRyxDQUFDLElBQUksQ0FBQztZQUNQLFVBQVUsRUFBRTtnQkFDVixXQUFXLEVBQUUseUJBQXlCO2dCQUN0QyxRQUFRLEVBQUUsNkJBQTZCO2FBQ3hDO1lBQ0QsYUFBYSxFQUFFO2dCQUNiLFdBQVcsRUFBRSxnQkFBZ0I7Z0JBQzdCLE9BQU8sRUFBRTtvQkFDUCxLQUFLLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsS0FBSztvQkFDM0MsU0FBUyxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsUUFBUTtpQkFDekM7YUFDRjtZQUNELFlBQVksRUFBRTtnQkFDWixXQUFXLEVBQUUsb0JBQW9CO2dCQUNqQyxPQUFPLEVBQUU7b0JBQ1AsRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxjQUFjLEVBQUU7b0JBQzVDLEVBQUUsS0FBSyxFQUFFLGdCQUFnQixFQUFFLEtBQUssRUFBRSxzQkFBc0IsRUFBRTtvQkFDMUQsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLEVBQUUsS0FBSyxFQUFFLDJCQUEyQixFQUFFO29CQUNoRSxFQUFFLEtBQUssRUFBRSxjQUFjLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBRTtpQkFDN0M7YUFDRjtZQUNELFNBQVMsRUFBRTtnQkFDVCxXQUFXLEVBQUUscUJBQXFCO2dCQUNsQyxPQUFPLEVBQUU7b0JBQ1AsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUU7b0JBQ3JDLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsZUFBZSxFQUFFO29CQUM5QyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLGtCQUFrQixFQUFFO29CQUMvQyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLGFBQWEsRUFBRTtpQkFDMUM7YUFDRjtZQUNELGFBQWEsRUFBRTtnQkFDYixXQUFXLEVBQUUsb0JBQW9CO2dCQUNqQyxPQUFPLEVBQUU7b0JBQ1AsUUFBUSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsU0FBUztvQkFDekMsUUFBUSxFQUFFLFlBQVksRUFBRSxPQUFPO2lCQUNoQzthQUNGO1lBQ0QsTUFBTSxFQUFFO2dCQUNOLFdBQVcsRUFBRSxjQUFjO2dCQUMzQixPQUFPLEVBQUU7b0JBQ1AsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUU7b0JBQ3ZDLEVBQUUsS0FBSyxFQUFFLGNBQWMsRUFBRSxLQUFLLEVBQUUsMkJBQTJCLEVBQUU7b0JBQzdELEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFO29CQUMxQyxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRTtvQkFDNUMsRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxtQkFBbUIsRUFBRTtpQkFDaEQ7YUFDRjtTQUNGLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFLGdDQUFnQztZQUN2QyxPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87U0FDdkIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==