"use strict";
/**
 * GET /store/omex-search/suggestions
 * Autocomplete suggestions
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
async function GET(req, res) {
    const advancedSearchService = req.scope.resolve("advancedSearchService");
    try {
        const { q, query, limit = '10' } = req.query;
        const searchQuery = (q || query);
        if (!searchQuery || searchQuery.length < 2) {
            return res.json({
                suggestions: [],
                message: "Query must be at least 2 characters",
            });
        }
        const suggestions = await advancedSearchService.getSuggestions(searchQuery, parseInt(limit));
        res.json({
            suggestions,
            count: suggestions.length,
        });
    }
    catch (error) {
        res.status(500).json({
            error: "Failed to fetch suggestions",
            message: error.message,
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL29tZXgtc2VhcmNoL3N1Z2dlc3Rpb25zL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7O0dBR0c7O0FBSUgsa0JBaUNDO0FBakNNLEtBQUssVUFBVSxHQUFHLENBQ3ZCLEdBQWtCLEVBQ2xCLEdBQW1CO0lBRW5CLE1BQU0scUJBQXFCLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQTtJQUV4RSxJQUFJLENBQUM7UUFDSCxNQUFNLEVBQUUsQ0FBQyxFQUFFLEtBQUssRUFBRSxLQUFLLEdBQUcsSUFBSSxFQUFFLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtRQUU1QyxNQUFNLFdBQVcsR0FBRyxDQUFDLENBQUMsSUFBSSxLQUFLLENBQVcsQ0FBQTtRQUUxQyxJQUFJLENBQUMsV0FBVyxJQUFJLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDM0MsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDO2dCQUNkLFdBQVcsRUFBRSxFQUFFO2dCQUNmLE9BQU8sRUFBRSxxQ0FBcUM7YUFDL0MsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUVELE1BQU0sV0FBVyxHQUFHLE1BQU0scUJBQXFCLENBQUMsY0FBYyxDQUM1RCxXQUFXLEVBQ1gsUUFBUSxDQUFDLEtBQWUsQ0FBQyxDQUMxQixDQUFBO1FBRUQsR0FBRyxDQUFDLElBQUksQ0FBQztZQUNQLFdBQVc7WUFDWCxLQUFLLEVBQUUsV0FBVyxDQUFDLE1BQU07U0FDMUIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUUsNkJBQTZCO1lBQ3BDLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztTQUN2QixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9