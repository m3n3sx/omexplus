"use strict";
/**
 * METHOD 4: Text Search (Natural Language)
 * GET /store/omex-search/text
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
async function GET(req, res) {
    const advancedSearchService = req.scope.resolve("advancedSearchService");
    try {
        const { q, query, language = 'pl', fuzzy = 'true' } = req.query;
        const searchQuery = (q || query);
        if (!searchQuery) {
            return res.status(400).json({
                error: "Search query is required",
                example: "/store/omex-search/text?q=pompa hydrauliczna do komatsu pc200",
                examples: [
                    "pompa hydrauliczna do komatsu pc200",
                    "filtr oleju cat 320d",
                    "gąsienice do hitachi zx210",
                    "młot hydrauliczny 3 tony",
                    "320-8134",
                ],
            });
        }
        const result = await advancedSearchService.searchByText({
            query: searchQuery,
            language: language,
            fuzzy: fuzzy === 'true',
        });
        res.json(result);
    }
    catch (error) {
        res.status(500).json({
            error: "Text search failed",
            message: error.message,
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL29tZXgtc2VhcmNoL3RleHQvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOzs7R0FHRzs7QUFJSCxrQkEyQ0M7QUEzQ00sS0FBSyxVQUFVLEdBQUcsQ0FDdkIsR0FBa0IsRUFDbEIsR0FBbUI7SUFFbkIsTUFBTSxxQkFBcUIsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFBO0lBRXhFLElBQUksQ0FBQztRQUNILE1BQU0sRUFDSixDQUFDLEVBQ0QsS0FBSyxFQUNMLFFBQVEsR0FBRyxJQUFJLEVBQ2YsS0FBSyxHQUFHLE1BQU0sRUFDZixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUE7UUFFYixNQUFNLFdBQVcsR0FBRyxDQUFDLENBQUMsSUFBSSxLQUFLLENBQVcsQ0FBQTtRQUUxQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDakIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDMUIsS0FBSyxFQUFFLDBCQUEwQjtnQkFDakMsT0FBTyxFQUFFLCtEQUErRDtnQkFDeEUsUUFBUSxFQUFFO29CQUNSLHFDQUFxQztvQkFDckMsc0JBQXNCO29CQUN0Qiw0QkFBNEI7b0JBQzVCLDBCQUEwQjtvQkFDMUIsVUFBVTtpQkFDWDthQUNGLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxNQUFNLE1BQU0sR0FBRyxNQUFNLHFCQUFxQixDQUFDLFlBQVksQ0FBQztZQUN0RCxLQUFLLEVBQUUsV0FBVztZQUNsQixRQUFRLEVBQUUsUUFBcUM7WUFDL0MsS0FBSyxFQUFFLEtBQUssS0FBSyxNQUFNO1NBQ3hCLENBQUMsQ0FBQTtRQUVGLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUE7SUFDbEIsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUUsb0JBQW9CO1lBQzNCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztTQUN2QixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9