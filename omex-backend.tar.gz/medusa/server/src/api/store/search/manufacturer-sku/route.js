"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
async function GET(req, res) {
    const searchService = req.scope.resolve("omexSearchService");
    const { sku, manufacturer_id } = req.query;
    try {
        if (!sku || typeof sku !== "string") {
            return res.status(400).json({
                error: "Manufacturer SKU parameter 'sku' is required",
            });
        }
        const products = await searchService.searchByManufacturerSKU(sku, manufacturer_id);
        return res.json({
            manufacturer_sku: sku,
            manufacturer_id: manufacturer_id || null,
            products,
            count: products.length,
        });
    }
    catch (error) {
        console.error("Manufacturer SKU search error:", error);
        return res.status(500).json({
            error: "Search failed",
            message: error.message,
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3NlYXJjaC9tYW51ZmFjdHVyZXItc2t1L3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBR0Esa0JBOEJDO0FBOUJNLEtBQUssVUFBVSxHQUFHLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUMvRCxNQUFNLGFBQWEsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBc0IsQ0FBQTtJQUVqRixNQUFNLEVBQUUsR0FBRyxFQUFFLGVBQWUsRUFBRSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUE7SUFFMUMsSUFBSSxDQUFDO1FBQ0gsSUFBSSxDQUFDLEdBQUcsSUFBSSxPQUFPLEdBQUcsS0FBSyxRQUFRLEVBQUUsQ0FBQztZQUNwQyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUMxQixLQUFLLEVBQUUsOENBQThDO2FBQ3RELENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxNQUFNLFFBQVEsR0FBRyxNQUFNLGFBQWEsQ0FBQyx1QkFBdUIsQ0FDMUQsR0FBRyxFQUNILGVBQXlCLENBQzFCLENBQUE7UUFFRCxPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDZCxnQkFBZ0IsRUFBRSxHQUFHO1lBQ3JCLGVBQWUsRUFBRSxlQUFlLElBQUksSUFBSTtZQUN4QyxRQUFRO1lBQ1IsS0FBSyxFQUFFLFFBQVEsQ0FBQyxNQUFNO1NBQ3ZCLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyxnQ0FBZ0MsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUN0RCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLEtBQUssRUFBRSxlQUFlO1lBQ3RCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztTQUN2QixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9