"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
async function GET(req, res) {
    const searchService = req.scope.resolve("omexSearchService");
    const { q, category_id, min_price, max_price, brand, equipment_type, in_stock, sort_by = "popularity", sort_order = "desc", page = 1, limit = 12, } = req.query;
    try {
        if (!q || typeof q !== "string") {
            return res.status(400).json({
                error: "Search query 'q' is required",
            });
        }
        const filters = {
            category_id: category_id,
            min_price: min_price ? parseFloat(min_price) : undefined,
            max_price: max_price ? parseFloat(max_price) : undefined,
            brand: brand ? (Array.isArray(brand) ? brand : [brand]) : undefined,
            equipment_type: equipment_type ? (Array.isArray(equipment_type) ? equipment_type : [equipment_type]) : undefined,
            in_stock: in_stock === "true",
        };
        const sort = {
            field: sort_by,
            order: sort_order,
        };
        const pagination = {
            page: parseInt(page),
            limit: parseInt(limit),
        };
        const results = await searchService.search(q, filters, sort, pagination);
        return res.json(results);
    }
    catch (error) {
        console.error("Search error:", error);
        return res.status(500).json({
            error: "Search failed",
            message: error.message,
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL3NlYXJjaC9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUdBLGtCQXFEQztBQXJETSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxhQUFhLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsbUJBQW1CLENBQXNCLENBQUE7SUFFakYsTUFBTSxFQUNKLENBQUMsRUFDRCxXQUFXLEVBQ1gsU0FBUyxFQUNULFNBQVMsRUFDVCxLQUFLLEVBQ0wsY0FBYyxFQUNkLFFBQVEsRUFDUixPQUFPLEdBQUcsWUFBWSxFQUN0QixVQUFVLEdBQUcsTUFBTSxFQUNuQixJQUFJLEdBQUcsQ0FBQyxFQUNSLEtBQUssR0FBRyxFQUFFLEdBQ1gsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFBO0lBRWIsSUFBSSxDQUFDO1FBQ0gsSUFBSSxDQUFDLENBQUMsSUFBSSxPQUFPLENBQUMsS0FBSyxRQUFRLEVBQUUsQ0FBQztZQUNoQyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUMxQixLQUFLLEVBQUUsOEJBQThCO2FBQ3RDLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxNQUFNLE9BQU8sR0FBRztZQUNkLFdBQVcsRUFBRSxXQUFxQjtZQUNsQyxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsU0FBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTO1lBQ2xFLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxTQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7WUFDbEUsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQWEsQ0FBQyxDQUFDLENBQUMsU0FBUztZQUMvRSxjQUFjLEVBQUUsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBYSxDQUFDLENBQUMsQ0FBQyxTQUFTO1lBQzVILFFBQVEsRUFBRSxRQUFRLEtBQUssTUFBTTtTQUM5QixDQUFBO1FBRUQsTUFBTSxJQUFJLEdBQUc7WUFDWCxLQUFLLEVBQUUsT0FBeUQ7WUFDaEUsS0FBSyxFQUFFLFVBQTRCO1NBQ3BDLENBQUE7UUFFRCxNQUFNLFVBQVUsR0FBRztZQUNqQixJQUFJLEVBQUUsUUFBUSxDQUFDLElBQWMsQ0FBQztZQUM5QixLQUFLLEVBQUUsUUFBUSxDQUFDLEtBQWUsQ0FBQztTQUNqQyxDQUFBO1FBRUQsTUFBTSxPQUFPLEdBQUcsTUFBTSxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLFVBQVUsQ0FBQyxDQUFBO1FBRXhFLE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtJQUMxQixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsZUFBZSxFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQ3JDLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsS0FBSyxFQUFFLGVBQWU7WUFDdEIsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3ZCLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=