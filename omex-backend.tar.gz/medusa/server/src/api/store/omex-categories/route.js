"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const omex_category_1 = require("../../../modules/omex-category");
const omex_translation_1 = require("../../../modules/omex-translation");
async function GET(req, res) {
    const categoryService = req.scope.resolve(omex_category_1.OMEX_CATEGORY_MODULE);
    const translationService = req.scope.resolve(omex_translation_1.OMEX_TRANSLATION_MODULE);
    const { locale = 'pl' } = req.query;
    try {
        // Get category tree
        const tree = await categoryService.listTree();
        // Add translations for each category
        const translateCategory = async (category) => {
            const translation = await translationService.getCategoryTranslation(category.id, locale);
            const translatedCategory = {
                ...category,
                translated_name: translation?.name || category.name,
                translated_description: translation?.description || category.description,
            };
            if (category.children && category.children.length > 0) {
                translatedCategory.children = await Promise.all(category.children.map(translateCategory));
            }
            return translatedCategory;
        };
        const translatedTree = await Promise.all(tree.map(translateCategory));
        res.json({
            categories: translatedTree,
        });
    }
    catch (error) {
        res.status(400).json({
            error: {
                code: 'CATEGORY_LIST_ERROR',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL29tZXgtY2F0ZWdvcmllcy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUlBLGtCQTZDQztBQWhERCxrRUFBcUU7QUFDckUsd0VBQTJFO0FBRXBFLEtBQUssVUFBVSxHQUFHLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUMvRCxNQUFNLGVBQWUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxvQ0FBb0IsQ0FBQyxDQUFBO0lBQy9ELE1BQU0sa0JBQWtCLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsMENBQXVCLENBQUMsQ0FBQTtJQUVyRSxNQUFNLEVBQUUsTUFBTSxHQUFHLElBQUksRUFBRSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUE7SUFFbkMsSUFBSSxDQUFDO1FBQ0gsb0JBQW9CO1FBQ3BCLE1BQU0sSUFBSSxHQUFHLE1BQU0sZUFBZSxDQUFDLFFBQVEsRUFBRSxDQUFBO1FBRTdDLHFDQUFxQztRQUNyQyxNQUFNLGlCQUFpQixHQUFHLEtBQUssRUFBRSxRQUFhLEVBQWdCLEVBQUU7WUFDOUQsTUFBTSxXQUFXLEdBQUcsTUFBTSxrQkFBa0IsQ0FBQyxzQkFBc0IsQ0FDakUsUUFBUSxDQUFDLEVBQUUsRUFDWCxNQUFnQixDQUNqQixDQUFBO1lBRUQsTUFBTSxrQkFBa0IsR0FBRztnQkFDekIsR0FBRyxRQUFRO2dCQUNYLGVBQWUsRUFBRSxXQUFXLEVBQUUsSUFBSSxJQUFJLFFBQVEsQ0FBQyxJQUFJO2dCQUNuRCxzQkFBc0IsRUFBRSxXQUFXLEVBQUUsV0FBVyxJQUFJLFFBQVEsQ0FBQyxXQUFXO2FBQ3pFLENBQUE7WUFFRCxJQUFJLFFBQVEsQ0FBQyxRQUFRLElBQUksUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7Z0JBQ3RELGtCQUFrQixDQUFDLFFBQVEsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQzdDLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQ3pDLENBQUE7WUFDSCxDQUFDO1lBRUQsT0FBTyxrQkFBa0IsQ0FBQTtRQUMzQixDQUFDLENBQUE7UUFFRCxNQUFNLGNBQWMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUE7UUFFckUsR0FBRyxDQUFDLElBQUksQ0FBQztZQUNQLFVBQVUsRUFBRSxjQUFjO1NBQzNCLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1FBQ3BCLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLEtBQUssRUFBRTtnQkFDTCxJQUFJLEVBQUUscUJBQXFCO2dCQUMzQixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87YUFDdkI7U0FDRixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9