"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const omex_category_1 = require("../../../../../modules/omex-category");
async function GET(req, res) {
    const categoryService = req.scope.resolve(omex_category_1.OMEX_CATEGORY_MODULE);
    const { id } = req.params;
    const { include_subcategories = 'true' } = req.query;
    try {
        const products = await categoryService.getProductsByCategory(id, include_subcategories === 'true');
        res.json({
            products,
            category_id: id,
            includes_subcategories: include_subcategories === 'true',
        });
    }
    catch (error) {
        res.status(400).json({
            error: {
                code: 'CATEGORY_PRODUCTS_ERROR',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL29tZXgtY2F0ZWdvcmllcy9baWRdL3Byb2R1Y3RzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBR0Esa0JBeUJDO0FBM0JELHdFQUEyRTtBQUVwRSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxlQUFlLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsb0NBQW9CLENBQUMsQ0FBQTtJQUUvRCxNQUFNLEVBQUUsRUFBRSxFQUFFLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQTtJQUN6QixNQUFNLEVBQUUscUJBQXFCLEdBQUcsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtJQUVwRCxJQUFJLENBQUM7UUFDSCxNQUFNLFFBQVEsR0FBRyxNQUFNLGVBQWUsQ0FBQyxxQkFBcUIsQ0FDMUQsRUFBRSxFQUNGLHFCQUFxQixLQUFLLE1BQU0sQ0FDakMsQ0FBQTtRQUVELEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDUCxRQUFRO1lBQ1IsV0FBVyxFQUFFLEVBQUU7WUFDZixzQkFBc0IsRUFBRSxxQkFBcUIsS0FBSyxNQUFNO1NBQ3pELENBQUMsQ0FBQTtJQUNKLENBQUM7SUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1FBQ3BCLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLEtBQUssRUFBRTtnQkFDTCxJQUFJLEVBQUUseUJBQXlCO2dCQUMvQixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87YUFDdkI7U0FDRixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9