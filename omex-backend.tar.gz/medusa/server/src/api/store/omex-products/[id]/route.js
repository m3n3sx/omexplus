"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const omex_product_1 = require("../../../../modules/omex-product");
const omex_translation_1 = require("../../../../modules/omex-translation");
const omex_pricing_1 = require("../../../../modules/omex-pricing");
const omex_inventory_1 = require("../../../../modules/omex-inventory");
async function GET(req, res) {
    const productService = req.scope.resolve(omex_product_1.OMEX_PRODUCT_MODULE);
    const translationService = req.scope.resolve(omex_translation_1.OMEX_TRANSLATION_MODULE);
    const pricingService = req.scope.resolve(omex_pricing_1.OMEX_PRICING_MODULE);
    const inventoryService = req.scope.resolve(omex_inventory_1.OMEX_INVENTORY_MODULE);
    const { id } = req.params;
    const { locale = 'pl' } = req.query;
    try {
        // Get product
        const product = await productService.retrieveProduct(id, locale);
        if (!product) {
            return res.status(404).json({
                error: {
                    code: 'PRODUCT_NOT_FOUND',
                    message: `Product with ID ${id} not found`,
                },
            });
        }
        // Get translation
        const translation = await translationService.getProductTranslation(id, locale);
        // Get pricing tiers (for B2B customers)
        // In real implementation, get customer type from session
        const customerType = 'retail'; // Default to retail
        // Get stock levels
        const stock = await inventoryService.getTotalStock(id);
        res.json({
            product: {
                ...product,
                translated_title: translation?.title || product.title,
                translated_description: translation?.description || product.description,
                total_stock: stock,
                in_stock: stock > 0,
            },
        });
    }
    catch (error) {
        res.status(400).json({
            error: {
                code: 'PRODUCT_RETRIEVE_ERROR',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL29tZXgtcHJvZHVjdHMvW2lkXS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQU1BLGtCQW9EQztBQXpERCxtRUFBc0U7QUFDdEUsMkVBQThFO0FBQzlFLG1FQUFzRTtBQUN0RSx1RUFBMEU7QUFFbkUsS0FBSyxVQUFVLEdBQUcsQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQy9ELE1BQU0sY0FBYyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGtDQUFtQixDQUFDLENBQUE7SUFDN0QsTUFBTSxrQkFBa0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQywwQ0FBdUIsQ0FBQyxDQUFBO0lBQ3JFLE1BQU0sY0FBYyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGtDQUFtQixDQUFDLENBQUE7SUFDN0QsTUFBTSxnQkFBZ0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxzQ0FBcUIsQ0FBQyxDQUFBO0lBRWpFLE1BQU0sRUFBRSxFQUFFLEVBQUUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFBO0lBQ3pCLE1BQU0sRUFBRSxNQUFNLEdBQUcsSUFBSSxFQUFFLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtJQUVuQyxJQUFJLENBQUM7UUFDSCxjQUFjO1FBQ2QsTUFBTSxPQUFPLEdBQUcsTUFBTSxjQUFjLENBQUMsZUFBZSxDQUFDLEVBQUUsRUFBRSxNQUFnQixDQUFDLENBQUE7UUFFMUUsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2IsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDMUIsS0FBSyxFQUFFO29CQUNMLElBQUksRUFBRSxtQkFBbUI7b0JBQ3pCLE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxZQUFZO2lCQUMzQzthQUNGLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxrQkFBa0I7UUFDbEIsTUFBTSxXQUFXLEdBQUcsTUFBTSxrQkFBa0IsQ0FBQyxxQkFBcUIsQ0FDaEUsRUFBRSxFQUNGLE1BQWdCLENBQ2pCLENBQUE7UUFFRCx3Q0FBd0M7UUFDeEMseURBQXlEO1FBQ3pELE1BQU0sWUFBWSxHQUFHLFFBQVEsQ0FBQSxDQUFDLG9CQUFvQjtRQUVsRCxtQkFBbUI7UUFDbkIsTUFBTSxLQUFLLEdBQUcsTUFBTSxnQkFBZ0IsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUE7UUFFdEQsR0FBRyxDQUFDLElBQUksQ0FBQztZQUNQLE9BQU8sRUFBRTtnQkFDUCxHQUFHLE9BQU87Z0JBQ1YsZ0JBQWdCLEVBQUUsV0FBVyxFQUFFLEtBQUssSUFBSSxPQUFPLENBQUMsS0FBSztnQkFDckQsc0JBQXNCLEVBQUUsV0FBVyxFQUFFLFdBQVcsSUFBSSxPQUFPLENBQUMsV0FBVztnQkFDdkUsV0FBVyxFQUFFLEtBQUs7Z0JBQ2xCLFFBQVEsRUFBRSxLQUFLLEdBQUcsQ0FBQzthQUNwQjtTQUNGLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1FBQ3BCLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLEtBQUssRUFBRTtnQkFDTCxJQUFJLEVBQUUsd0JBQXdCO2dCQUM5QixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87YUFDdkI7U0FDRixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9