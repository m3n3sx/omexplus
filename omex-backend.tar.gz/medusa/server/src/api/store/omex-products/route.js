"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const omex_product_1 = require("../../../modules/omex-product");
const omex_translation_1 = require("../../../modules/omex-translation");
async function GET(req, res) {
    const productService = req.scope.resolve(omex_product_1.OMEX_PRODUCT_MODULE);
    const translationService = req.scope.resolve(omex_translation_1.OMEX_TRANSLATION_MODULE);
    const { category_id, equipment_type, min_price, max_price, in_stock, q, limit = 12, offset = 0, locale = 'pl', } = req.query;
    try {
        const filters = {
            category_id: category_id,
            equipment_type: equipment_type,
            min_price: min_price ? parseFloat(min_price) : undefined,
            max_price: max_price ? parseFloat(max_price) : undefined,
            in_stock: in_stock === 'true',
            q: q,
        };
        const pagination = {
            limit: parseInt(limit),
            offset: parseInt(offset),
        };
        const result = await productService.listProducts(filters, pagination);
        // Add translations for each product
        const productsWithTranslations = await Promise.all(result.products.map(async (product) => {
            const translation = await translationService.getProductTranslation(product.id, locale);
            return {
                ...product,
                translated_title: translation?.title || product.title,
                translated_description: translation?.description || product.description,
            };
        }));
        res.json({
            products: productsWithTranslations,
            count: result.count,
            limit: result.limit,
            offset: result.offset,
        });
    }
    catch (error) {
        res.status(400).json({
            error: {
                code: 'PRODUCT_LIST_ERROR',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL29tZXgtcHJvZHVjdHMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFJQSxrQkE4REM7QUFqRUQsZ0VBQW1FO0FBQ25FLHdFQUEyRTtBQUVwRSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxjQUFjLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsa0NBQW1CLENBQUMsQ0FBQTtJQUM3RCxNQUFNLGtCQUFrQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLDBDQUF1QixDQUFDLENBQUE7SUFFckUsTUFBTSxFQUNKLFdBQVcsRUFDWCxjQUFjLEVBQ2QsU0FBUyxFQUNULFNBQVMsRUFDVCxRQUFRLEVBQ1IsQ0FBQyxFQUNELEtBQUssR0FBRyxFQUFFLEVBQ1YsTUFBTSxHQUFHLENBQUMsRUFDVixNQUFNLEdBQUcsSUFBSSxHQUNkLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtJQUViLElBQUksQ0FBQztRQUNILE1BQU0sT0FBTyxHQUFHO1lBQ2QsV0FBVyxFQUFFLFdBQXFCO1lBQ2xDLGNBQWMsRUFBRSxjQUF3QjtZQUN4QyxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsU0FBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTO1lBQ2xFLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxTQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7WUFDbEUsUUFBUSxFQUFFLFFBQVEsS0FBSyxNQUFNO1lBQzdCLENBQUMsRUFBRSxDQUFXO1NBQ2YsQ0FBQTtRQUVELE1BQU0sVUFBVSxHQUFHO1lBQ2pCLEtBQUssRUFBRSxRQUFRLENBQUMsS0FBZSxDQUFDO1lBQ2hDLE1BQU0sRUFBRSxRQUFRLENBQUMsTUFBZ0IsQ0FBQztTQUNuQyxDQUFBO1FBRUQsTUFBTSxNQUFNLEdBQUcsTUFBTSxjQUFjLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsQ0FBQTtRQUVyRSxvQ0FBb0M7UUFDcEMsTUFBTSx3QkFBd0IsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQ2hELE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxPQUFZLEVBQUUsRUFBRTtZQUN6QyxNQUFNLFdBQVcsR0FBRyxNQUFNLGtCQUFrQixDQUFDLHFCQUFxQixDQUNoRSxPQUFPLENBQUMsRUFBRSxFQUNWLE1BQWdCLENBQ2pCLENBQUE7WUFDRCxPQUFPO2dCQUNMLEdBQUcsT0FBTztnQkFDVixnQkFBZ0IsRUFBRSxXQUFXLEVBQUUsS0FBSyxJQUFJLE9BQU8sQ0FBQyxLQUFLO2dCQUNyRCxzQkFBc0IsRUFBRSxXQUFXLEVBQUUsV0FBVyxJQUFJLE9BQU8sQ0FBQyxXQUFXO2FBQ3hFLENBQUE7UUFDSCxDQUFDLENBQUMsQ0FDSCxDQUFBO1FBRUQsR0FBRyxDQUFDLElBQUksQ0FBQztZQUNQLFFBQVEsRUFBRSx3QkFBd0I7WUFDbEMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO1lBQ25CLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSztZQUNuQixNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07U0FDdEIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSxvQkFBb0I7Z0JBQzFCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTzthQUN2QjtTQUNGLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=