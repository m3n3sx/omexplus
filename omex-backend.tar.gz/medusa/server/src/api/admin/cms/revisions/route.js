"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
async function GET(req, res) {
    const { entityType, entityId } = req.query;
    // Historia wersji dla danej treści
    const revisions = [
        {
            id: "rev_1",
            entityType,
            entityId,
            changes: {},
            author: "admin@example.com",
            createdAt: new Date(),
        }
    ];
    res.json({ revisions });
}
async function POST(req, res) {
    const { revisionId } = req.body;
    // Przywróć wersję
    res.json({ success: true, revisionId });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2Ntcy9yZXZpc2lvbnMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFFQSxrQkFnQkM7QUFFRCxvQkFLQztBQXZCTSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxFQUFFLFVBQVUsRUFBRSxRQUFRLEVBQUUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFBO0lBRTFDLG1DQUFtQztJQUNuQyxNQUFNLFNBQVMsR0FBRztRQUNoQjtZQUNFLEVBQUUsRUFBRSxPQUFPO1lBQ1gsVUFBVTtZQUNWLFFBQVE7WUFDUixPQUFPLEVBQUUsRUFBRTtZQUNYLE1BQU0sRUFBRSxtQkFBbUI7WUFDM0IsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFO1NBQ3RCO0tBQ0YsQ0FBQTtJQUVELEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFBO0FBQ3pCLENBQUM7QUFFTSxLQUFLLFVBQVUsSUFBSSxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDaEUsTUFBTSxFQUFFLFVBQVUsRUFBRSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUE7SUFFL0Isa0JBQWtCO0lBQ2xCLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxDQUFDLENBQUE7QUFDekMsQ0FBQyJ9