"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
exports.GET = GET;
async function POST(req, res) {
    // Upload plików multimedialnych
    const file = req.file;
    // Zapisz plik i zwróć URL
    const media = {
        id: `media_${Date.now()}`,
        url: `/uploads/${file?.filename}`,
        type: file?.mimetype,
        size: file?.size,
        createdAt: new Date(),
    };
    res.json({ media });
}
async function GET(req, res) {
    // Lista wszystkich mediów
    const media = [];
    res.json({ media });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2Ntcy9tZWRpYS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUVBLG9CQWNDO0FBRUQsa0JBS0M7QUFyQk0sS0FBSyxVQUFVLElBQUksQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQ2hFLGdDQUFnQztJQUNoQyxNQUFNLElBQUksR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBRXJCLDBCQUEwQjtJQUMxQixNQUFNLEtBQUssR0FBRztRQUNaLEVBQUUsRUFBRSxTQUFTLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRTtRQUN6QixHQUFHLEVBQUUsWUFBWSxJQUFJLEVBQUUsUUFBUSxFQUFFO1FBQ2pDLElBQUksRUFBRSxJQUFJLEVBQUUsUUFBUTtRQUNwQixJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUk7UUFDaEIsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFO0tBQ3RCLENBQUE7SUFFRCxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtBQUNyQixDQUFDO0FBRU0sS0FBSyxVQUFVLEdBQUcsQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQy9ELDBCQUEwQjtJQUMxQixNQUFNLEtBQUssR0FBRyxFQUFFLENBQUE7SUFFaEIsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7QUFDckIsQ0FBQyJ9