"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
async function GET(req, res) {
    // Szablony stron
    const templates = [
        {
            id: "landing-page",
            name: "Landing Page",
            description: "Strona docelowa z hero i sekcjami",
            preview: "/templates/landing.jpg",
            blocks: [
                { type: "hero", content: {} },
                { type: "features", content: {} },
                { type: "cta", content: {} },
            ]
        },
        {
            id: "about-us",
            name: "O nas",
            description: "Strona o firmie",
            preview: "/templates/about.jpg",
            blocks: [
                { type: "heading", content: {} },
                { type: "paragraph", content: {} },
                { type: "team", content: {} },
            ]
        },
        {
            id: "contact",
            name: "Kontakt",
            description: "Strona kontaktowa z formularzem",
            preview: "/templates/contact.jpg",
            blocks: [
                { type: "heading", content: {} },
                { type: "contact-form", content: {} },
                { type: "map", content: {} },
            ]
        }
    ];
    res.json({ templates });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2Ntcy90ZW1wbGF0ZXMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFFQSxrQkF1Q0M7QUF2Q00sS0FBSyxVQUFVLEdBQUcsQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQy9ELGlCQUFpQjtJQUNqQixNQUFNLFNBQVMsR0FBRztRQUNoQjtZQUNFLEVBQUUsRUFBRSxjQUFjO1lBQ2xCLElBQUksRUFBRSxjQUFjO1lBQ3BCLFdBQVcsRUFBRSxtQ0FBbUM7WUFDaEQsT0FBTyxFQUFFLHdCQUF3QjtZQUNqQyxNQUFNLEVBQUU7Z0JBQ04sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUU7Z0JBQzdCLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFO2dCQUNqQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRTthQUM3QjtTQUNGO1FBQ0Q7WUFDRSxFQUFFLEVBQUUsVUFBVTtZQUNkLElBQUksRUFBRSxPQUFPO1lBQ2IsV0FBVyxFQUFFLGlCQUFpQjtZQUM5QixPQUFPLEVBQUUsc0JBQXNCO1lBQy9CLE1BQU0sRUFBRTtnQkFDTixFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRTtnQkFDaEMsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUU7Z0JBQ2xDLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFO2FBQzlCO1NBQ0Y7UUFDRDtZQUNFLEVBQUUsRUFBRSxTQUFTO1lBQ2IsSUFBSSxFQUFFLFNBQVM7WUFDZixXQUFXLEVBQUUsaUNBQWlDO1lBQzlDLE9BQU8sRUFBRSx3QkFBd0I7WUFDakMsTUFBTSxFQUFFO2dCQUNOLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsRUFBRSxFQUFFO2dCQUNoQyxFQUFFLElBQUksRUFBRSxjQUFjLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRTtnQkFDckMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUU7YUFDN0I7U0FDRjtLQUNGLENBQUE7SUFFRCxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsU0FBUyxFQUFFLENBQUMsQ0FBQTtBQUN6QixDQUFDIn0=