"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
exports.PUT = PUT;
const omex_bulk_import_1 = require("../../../../modules/omex-bulk-import");
async function POST(req, res) {
    const bulkImportService = req.scope.resolve(omex_bulk_import_1.OMEX_BULK_IMPORT_MODULE);
    try {
        // Check if file is provided
        const file = req.file;
        if (!file) {
            return res.status(400).json({
                error: {
                    code: 'NO_FILE',
                    message: 'No file provided. Please upload a CSV file.',
                },
            });
        }
        // Validate file type
        if (!file.originalname.endsWith('.csv')) {
            return res.status(400).json({
                error: {
                    code: 'INVALID_FILE_TYPE',
                    message: 'Invalid file type. Only CSV files are allowed.',
                },
            });
        }
        // Validate file size (50MB max)
        const maxSize = 50 * 1024 * 1024;
        if (file.size > maxSize) {
            return res.status(400).json({
                error: {
                    code: 'FILE_TOO_LARGE',
                    message: `File size exceeds maximum allowed size of 50MB.`,
                },
            });
        }
        // Set up SSE headers
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');
        // Progress callback
        const onProgress = (progress) => {
            res.write(`data: ${JSON.stringify(progress)}\n\n`);
        };
        // Start import
        const result = await bulkImportService.importFromCSV(file.buffer, onProgress);
        // Send final result
        res.write(`data: ${JSON.stringify(result)}\n\n`);
        res.end();
    }
    catch (error) {
        console.error('Import error:', error);
        const errorResponse = {
            status: 'failed',
            total: 0,
            successful: 0,
            failed: 0,
            errors: [{
                    line: 0,
                    field: 'system',
                    reason: error.message,
                }],
        };
        res.write(`data: ${JSON.stringify(errorResponse)}\n\n`);
        res.end();
    }
}
// Alternative non-SSE endpoint for simpler clients
async function PUT(req, res) {
    const bulkImportService = req.scope.resolve(omex_bulk_import_1.OMEX_BULK_IMPORT_MODULE);
    try {
        const file = req.file;
        if (!file) {
            return res.status(400).json({
                error: {
                    code: 'NO_FILE',
                    message: 'No file provided. Please upload a CSV file.',
                },
            });
        }
        if (!file.originalname.endsWith('.csv')) {
            return res.status(400).json({
                error: {
                    code: 'INVALID_FILE_TYPE',
                    message: 'Invalid file type. Only CSV files are allowed.',
                },
            });
        }
        const result = await bulkImportService.importFromCSV(file.buffer);
        res.json(result);
    }
    catch (error) {
        console.error('Import error:', error);
        res.status(500).json({
            error: {
                code: 'IMPORT_FAILED',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3Byb2R1Y3RzL2ltcG9ydC9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUlBLG9CQTBFQztBQUdELGtCQW9DQztBQXBIRCwyRUFBOEU7QUFHdkUsS0FBSyxVQUFVLElBQUksQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQ2hFLE1BQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsMENBQXVCLENBQUMsQ0FBQTtJQUVwRSxJQUFJLENBQUM7UUFDSCw0QkFBNEI7UUFDNUIsTUFBTSxJQUFJLEdBQUksR0FBVyxDQUFDLElBQUksQ0FBQTtRQUM5QixJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDVixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUMxQixLQUFLLEVBQUU7b0JBQ0wsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsT0FBTyxFQUFFLDZDQUE2QztpQkFDdkQ7YUFDRixDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQscUJBQXFCO1FBQ3JCLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1lBQ3hDLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzFCLEtBQUssRUFBRTtvQkFDTCxJQUFJLEVBQUUsbUJBQW1CO29CQUN6QixPQUFPLEVBQUUsZ0RBQWdEO2lCQUMxRDthQUNGLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxnQ0FBZ0M7UUFDaEMsTUFBTSxPQUFPLEdBQUcsRUFBRSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUE7UUFDaEMsSUFBSSxJQUFJLENBQUMsSUFBSSxHQUFHLE9BQU8sRUFBRSxDQUFDO1lBQ3hCLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzFCLEtBQUssRUFBRTtvQkFDTCxJQUFJLEVBQUUsZ0JBQWdCO29CQUN0QixPQUFPLEVBQUUsaURBQWlEO2lCQUMzRDthQUNGLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxxQkFBcUI7UUFDckIsR0FBRyxDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQUUsbUJBQW1CLENBQUMsQ0FBQTtRQUNsRCxHQUFHLENBQUMsU0FBUyxDQUFDLGVBQWUsRUFBRSxVQUFVLENBQUMsQ0FBQTtRQUMxQyxHQUFHLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxZQUFZLENBQUMsQ0FBQTtRQUV6QyxvQkFBb0I7UUFDcEIsTUFBTSxVQUFVLEdBQUcsQ0FBQyxRQUF3QixFQUFFLEVBQUU7WUFDOUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxTQUFTLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFBO1FBQ3BELENBQUMsQ0FBQTtRQUVELGVBQWU7UUFDZixNQUFNLE1BQU0sR0FBRyxNQUFNLGlCQUFpQixDQUFDLGFBQWEsQ0FDbEQsSUFBSSxDQUFDLE1BQU0sRUFDWCxVQUFVLENBQ1gsQ0FBQTtRQUVELG9CQUFvQjtRQUNwQixHQUFHLENBQUMsS0FBSyxDQUFDLFNBQVMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUE7UUFDaEQsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFBO0lBRVgsQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsT0FBTyxDQUFDLEtBQUssQ0FBQyxlQUFlLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFFckMsTUFBTSxhQUFhLEdBQUc7WUFDcEIsTUFBTSxFQUFFLFFBQVE7WUFDaEIsS0FBSyxFQUFFLENBQUM7WUFDUixVQUFVLEVBQUUsQ0FBQztZQUNiLE1BQU0sRUFBRSxDQUFDO1lBQ1QsTUFBTSxFQUFFLENBQUM7b0JBQ1AsSUFBSSxFQUFFLENBQUM7b0JBQ1AsS0FBSyxFQUFFLFFBQVE7b0JBQ2YsTUFBTSxFQUFFLEtBQUssQ0FBQyxPQUFPO2lCQUN0QixDQUFDO1NBQ0gsQ0FBQTtRQUVELEdBQUcsQ0FBQyxLQUFLLENBQUMsU0FBUyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUN2RCxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUE7SUFDWCxDQUFDO0FBQ0gsQ0FBQztBQUVELG1EQUFtRDtBQUM1QyxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxpQkFBaUIsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQywwQ0FBdUIsQ0FBQyxDQUFBO0lBRXBFLElBQUksQ0FBQztRQUNILE1BQU0sSUFBSSxHQUFJLEdBQVcsQ0FBQyxJQUFJLENBQUE7UUFDOUIsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ1YsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDMUIsS0FBSyxFQUFFO29CQUNMLElBQUksRUFBRSxTQUFTO29CQUNmLE9BQU8sRUFBRSw2Q0FBNkM7aUJBQ3ZEO2FBQ0YsQ0FBQyxDQUFBO1FBQ0osQ0FBQztRQUVELElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1lBQ3hDLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzFCLEtBQUssRUFBRTtvQkFDTCxJQUFJLEVBQUUsbUJBQW1CO29CQUN6QixPQUFPLEVBQUUsZ0RBQWdEO2lCQUMxRDthQUNGLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxNQUFNLE1BQU0sR0FBRyxNQUFNLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUE7UUFFakUsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUVsQixDQUFDO0lBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztRQUNwQixPQUFPLENBQUMsS0FBSyxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUNyQyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUU7Z0JBQ0wsSUFBSSxFQUFFLGVBQWU7Z0JBQ3JCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTzthQUN2QjtTQUNGLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=