"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.DELETE = DELETE;
const omex_bulk_import_1 = require("../../../../../../modules/omex-bulk-import");
/**
 * GET /admin/products/import/history/:id
 * Get detailed import history including errors
 */
async function GET(req, res) {
    const bulkImportService = req.scope.resolve(omex_bulk_import_1.OMEX_BULK_IMPORT_MODULE);
    const { id } = req.params;
    try {
        // In production, query import_history and import_error tables
        const importRecord = {
            id,
            filename: 'sample-products-120.csv',
            status: 'completed',
            total_rows: 120,
            successful_rows: 118,
            failed_rows: 2,
            duration_ms: 5432,
            started_at: new Date(),
            completed_at: new Date(),
            errors: [],
        };
        res.json(importRecord);
    }
    catch (error) {
        console.error('Failed to fetch import details:', error);
        res.status(500).json({
            error: {
                code: 'IMPORT_DETAIL_ERROR',
                message: error.message,
            },
        });
    }
}
/**
 * DELETE /admin/products/import/history/:id
 * Delete import history record
 */
async function DELETE(req, res) {
    const { id } = req.params;
    try {
        // In production, delete from import_history table (cascade to import_error)
        res.json({
            id,
            deleted: true,
        });
    }
    catch (error) {
        console.error('Failed to delete import history:', error);
        res.status(500).json({
            error: {
                code: 'IMPORT_DELETE_ERROR',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3Byb2R1Y3RzL2ltcG9ydC9oaXN0b3J5L1tpZF0vcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFPQSxrQkE2QkM7QUFNRCx3QkFrQkM7QUEzREQsaUZBQW9GO0FBRXBGOzs7R0FHRztBQUNJLEtBQUssVUFBVSxHQUFHLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUMvRCxNQUFNLGlCQUFpQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLDBDQUF1QixDQUFDLENBQUE7SUFDcEUsTUFBTSxFQUFFLEVBQUUsRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUE7SUFFekIsSUFBSSxDQUFDO1FBQ0gsOERBQThEO1FBQzlELE1BQU0sWUFBWSxHQUFHO1lBQ25CLEVBQUU7WUFDRixRQUFRLEVBQUUseUJBQXlCO1lBQ25DLE1BQU0sRUFBRSxXQUFXO1lBQ25CLFVBQVUsRUFBRSxHQUFHO1lBQ2YsZUFBZSxFQUFFLEdBQUc7WUFDcEIsV0FBVyxFQUFFLENBQUM7WUFDZCxXQUFXLEVBQUUsSUFBSTtZQUNqQixVQUFVLEVBQUUsSUFBSSxJQUFJLEVBQUU7WUFDdEIsWUFBWSxFQUFFLElBQUksSUFBSSxFQUFFO1lBQ3hCLE1BQU0sRUFBRSxFQUFFO1NBQ1gsQ0FBQTtRQUVELEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUE7SUFDeEIsQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsT0FBTyxDQUFDLEtBQUssQ0FBQyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUN2RCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUU7Z0JBQ0wsSUFBSSxFQUFFLHFCQUFxQjtnQkFDM0IsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO2FBQ3ZCO1NBQ0YsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUM7QUFFRDs7O0dBR0c7QUFDSSxLQUFLLFVBQVUsTUFBTSxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDbEUsTUFBTSxFQUFFLEVBQUUsRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUE7SUFFekIsSUFBSSxDQUFDO1FBQ0gsNEVBQTRFO1FBQzVFLEdBQUcsQ0FBQyxJQUFJLENBQUM7WUFDUCxFQUFFO1lBQ0YsT0FBTyxFQUFFLElBQUk7U0FDZCxDQUFDLENBQUE7SUFDSixDQUFDO0lBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztRQUNwQixPQUFPLENBQUMsS0FBSyxDQUFDLGtDQUFrQyxFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQ3hELEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLEtBQUssRUFBRTtnQkFDTCxJQUFJLEVBQUUscUJBQXFCO2dCQUMzQixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87YUFDdkI7U0FDRixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9