"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const omex_bulk_import_1 = require("../../../../../../modules/omex-bulk-import");
/**
 * GET /admin/products/import/errors/:id
 * Download error report for a specific import
 */
async function GET(req, res) {
    const bulkImportService = req.scope.resolve(omex_bulk_import_1.OMEX_BULK_IMPORT_MODULE);
    const { id } = req.params;
    const { format = 'txt' } = req.query;
    try {
        // In production, fetch errors from import_error table
        const errors = [
            {
                line: 15,
                field: 'price',
                reason: 'Price must be a positive number',
                value: 'invalid',
            },
            {
                line: 42,
                field: 'sku',
                reason: 'SKU must match format XXX-000',
                value: 'INVALID-SKU',
            },
        ];
        if (format === 'csv') {
            // Generate CSV format
            let csv = 'Line,Field,Reason,Value\n';
            errors.forEach(error => {
                csv += `${error.line},"${error.field}","${error.reason}","${error.value || ''}"\n`;
            });
            res.setHeader('Content-Type', 'text/csv');
            res.setHeader('Content-Disposition', `attachment; filename="import-errors-${id}.csv"`);
            res.send(csv);
        }
        else {
            // Generate text format
            const report = bulkImportService.generateErrorReport(errors);
            res.setHeader('Content-Type', 'text/plain');
            res.setHeader('Content-Disposition', `attachment; filename="import-errors-${id}.txt"`);
            res.send(report);
        }
    }
    catch (error) {
        console.error('Failed to generate error report:', error);
        res.status(500).json({
            error: {
                code: 'ERROR_REPORT_FAILED',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3Byb2R1Y3RzL2ltcG9ydC9lcnJvcnMvW2lkXS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQU9BLGtCQWtEQztBQXhERCxpRkFBb0Y7QUFFcEY7OztHQUdHO0FBQ0ksS0FBSyxVQUFVLEdBQUcsQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQy9ELE1BQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsMENBQXVCLENBQUMsQ0FBQTtJQUNwRSxNQUFNLEVBQUUsRUFBRSxFQUFFLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQTtJQUN6QixNQUFNLEVBQUUsTUFBTSxHQUFHLEtBQUssRUFBRSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUE7SUFFcEMsSUFBSSxDQUFDO1FBQ0gsc0RBQXNEO1FBQ3RELE1BQU0sTUFBTSxHQUFHO1lBQ2I7Z0JBQ0UsSUFBSSxFQUFFLEVBQUU7Z0JBQ1IsS0FBSyxFQUFFLE9BQU87Z0JBQ2QsTUFBTSxFQUFFLGlDQUFpQztnQkFDekMsS0FBSyxFQUFFLFNBQVM7YUFDakI7WUFDRDtnQkFDRSxJQUFJLEVBQUUsRUFBRTtnQkFDUixLQUFLLEVBQUUsS0FBSztnQkFDWixNQUFNLEVBQUUsK0JBQStCO2dCQUN2QyxLQUFLLEVBQUUsYUFBYTthQUNyQjtTQUNGLENBQUE7UUFFRCxJQUFJLE1BQU0sS0FBSyxLQUFLLEVBQUUsQ0FBQztZQUNyQixzQkFBc0I7WUFDdEIsSUFBSSxHQUFHLEdBQUcsMkJBQTJCLENBQUE7WUFDckMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDckIsR0FBRyxJQUFJLEdBQUcsS0FBSyxDQUFDLElBQUksS0FBSyxLQUFLLENBQUMsS0FBSyxNQUFNLEtBQUssQ0FBQyxNQUFNLE1BQU0sS0FBSyxDQUFDLEtBQUssSUFBSSxFQUFFLEtBQUssQ0FBQTtZQUNwRixDQUFDLENBQUMsQ0FBQTtZQUVGLEdBQUcsQ0FBQyxTQUFTLENBQUMsY0FBYyxFQUFFLFVBQVUsQ0FBQyxDQUFBO1lBQ3pDLEdBQUcsQ0FBQyxTQUFTLENBQUMscUJBQXFCLEVBQUUsdUNBQXVDLEVBQUUsT0FBTyxDQUFDLENBQUE7WUFDdEYsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQTtRQUNmLENBQUM7YUFBTSxDQUFDO1lBQ04sdUJBQXVCO1lBQ3ZCLE1BQU0sTUFBTSxHQUFHLGlCQUFpQixDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFBO1lBRTVELEdBQUcsQ0FBQyxTQUFTLENBQUMsY0FBYyxFQUFFLFlBQVksQ0FBQyxDQUFBO1lBQzNDLEdBQUcsQ0FBQyxTQUFTLENBQUMscUJBQXFCLEVBQUUsdUNBQXVDLEVBQUUsT0FBTyxDQUFDLENBQUE7WUFDdEYsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUNsQixDQUFDO0lBRUgsQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsT0FBTyxDQUFDLEtBQUssQ0FBQyxrQ0FBa0MsRUFBRSxLQUFLLENBQUMsQ0FBQTtRQUN4RCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUU7Z0JBQ0wsSUFBSSxFQUFFLHFCQUFxQjtnQkFDM0IsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO2FBQ3ZCO1NBQ0YsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==