"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const omex_bulk_import_1 = require("../../../../../modules/omex-bulk-import");
/**
 * GET /admin/products/import/stats
 * Get import statistics and metrics
 */
async function GET(req, res) {
    const bulkImportService = req.scope.resolve(omex_bulk_import_1.OMEX_BULK_IMPORT_MODULE);
    try {
        const stats = await bulkImportService.getImportStatistics();
        // Add additional metrics
        const metrics = {
            ...stats,
            success_rate: stats.total_imports > 0
                ? ((stats.successful_products / (stats.successful_products + stats.failed_products)) * 100).toFixed(2)
                : 0,
            average_products_per_import: stats.total_imports > 0
                ? Math.round((stats.successful_products + stats.failed_products) / stats.total_imports)
                : 0,
        };
        res.json(metrics);
    }
    catch (error) {
        console.error('Failed to fetch import statistics:', error);
        res.status(500).json({
            error: {
                code: 'STATS_FETCH_ERROR',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3Byb2R1Y3RzL2ltcG9ydC9zdGF0cy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQU9BLGtCQTRCQztBQWxDRCw4RUFBaUY7QUFFakY7OztHQUdHO0FBQ0ksS0FBSyxVQUFVLEdBQUcsQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQy9ELE1BQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsMENBQXVCLENBQUMsQ0FBQTtJQUVwRSxJQUFJLENBQUM7UUFDSCxNQUFNLEtBQUssR0FBRyxNQUFNLGlCQUFpQixDQUFDLG1CQUFtQixFQUFFLENBQUE7UUFFM0QseUJBQXlCO1FBQ3pCLE1BQU0sT0FBTyxHQUFHO1lBQ2QsR0FBRyxLQUFLO1lBQ1IsWUFBWSxFQUFFLEtBQUssQ0FBQyxhQUFhLEdBQUcsQ0FBQztnQkFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsbUJBQW1CLEdBQUcsQ0FBQyxLQUFLLENBQUMsbUJBQW1CLEdBQUcsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztnQkFDdEcsQ0FBQyxDQUFDLENBQUM7WUFDTCwyQkFBMkIsRUFBRSxLQUFLLENBQUMsYUFBYSxHQUFHLENBQUM7Z0JBQ2xELENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLG1CQUFtQixHQUFHLEtBQUssQ0FBQyxlQUFlLENBQUMsR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDO2dCQUN2RixDQUFDLENBQUMsQ0FBQztTQUNOLENBQUE7UUFFRCxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO0lBRW5CLENBQUM7SUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1FBQ3BCLE9BQU8sQ0FBQyxLQUFLLENBQUMsb0NBQW9DLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDMUQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSxtQkFBbUI7Z0JBQ3pCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTzthQUN2QjtTQUNGLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=