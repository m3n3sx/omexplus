"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const omex_bulk_import_1 = require("../../../../../modules/omex-bulk-import");
/**
 * POST /admin/products/import/validate
 * Validate CSV without importing (dry-run mode)
 */
async function POST(req, res) {
    const bulkImportService = req.scope.resolve(omex_bulk_import_1.OMEX_BULK_IMPORT_MODULE);
    try {
        const file = req.file;
        if (!file) {
            return res.status(400).json({
                error: {
                    code: 'NO_FILE',
                    message: 'No file provided. Please upload a CSV file.',
                },
            });
        }
        if (!file.originalname.endsWith('.csv')) {
            return res.status(400).json({
                error: {
                    code: 'INVALID_FILE_TYPE',
                    message: 'Invalid file type. Only CSV files are allowed.',
                },
            });
        }
        // Validate without importing
        const result = await bulkImportService.validateCSV(file.buffer);
        res.json({
            valid: result.errors.length === 0,
            total_rows: result.total,
            validation_errors: result.errors,
            warnings: result.warnings || [],
            summary: {
                duplicate_skus: result.duplicate_skus || [],
                invalid_categories: result.invalid_categories || [],
                missing_translations: result.missing_translations || 0,
            },
        });
    }
    catch (error) {
        console.error('Validation error:', error);
        res.status(500).json({
            error: {
                code: 'VALIDATION_FAILED',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3Byb2R1Y3RzL2ltcG9ydC92YWxpZGF0ZS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQU9BLG9CQStDQztBQXJERCw4RUFBaUY7QUFFakY7OztHQUdHO0FBQ0ksS0FBSyxVQUFVLElBQUksQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQ2hFLE1BQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsMENBQXVCLENBQUMsQ0FBQTtJQUVwRSxJQUFJLENBQUM7UUFDSCxNQUFNLElBQUksR0FBSSxHQUFXLENBQUMsSUFBSSxDQUFBO1FBQzlCLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNWLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzFCLEtBQUssRUFBRTtvQkFDTCxJQUFJLEVBQUUsU0FBUztvQkFDZixPQUFPLEVBQUUsNkNBQTZDO2lCQUN2RDthQUNGLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztZQUN4QyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUMxQixLQUFLLEVBQUU7b0JBQ0wsSUFBSSxFQUFFLG1CQUFtQjtvQkFDekIsT0FBTyxFQUFFLGdEQUFnRDtpQkFDMUQ7YUFDRixDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsNkJBQTZCO1FBQzdCLE1BQU0sTUFBTSxHQUFHLE1BQU0saUJBQWlCLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUUvRCxHQUFHLENBQUMsSUFBSSxDQUFDO1lBQ1AsS0FBSyxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxLQUFLLENBQUM7WUFDakMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxLQUFLO1lBQ3hCLGlCQUFpQixFQUFFLE1BQU0sQ0FBQyxNQUFNO1lBQ2hDLFFBQVEsRUFBRSxNQUFNLENBQUMsUUFBUSxJQUFJLEVBQUU7WUFDL0IsT0FBTyxFQUFFO2dCQUNQLGNBQWMsRUFBRSxNQUFNLENBQUMsY0FBYyxJQUFJLEVBQUU7Z0JBQzNDLGtCQUFrQixFQUFFLE1BQU0sQ0FBQyxrQkFBa0IsSUFBSSxFQUFFO2dCQUNuRCxvQkFBb0IsRUFBRSxNQUFNLENBQUMsb0JBQW9CLElBQUksQ0FBQzthQUN2RDtTQUNGLENBQUMsQ0FBQTtJQUVKLENBQUM7SUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1FBQ3BCLE9BQU8sQ0FBQyxLQUFLLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDekMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSxtQkFBbUI7Z0JBQ3pCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTzthQUN2QjtTQUNGLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=