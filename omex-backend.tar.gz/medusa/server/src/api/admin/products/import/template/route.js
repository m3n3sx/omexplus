"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
/**
 * GET /admin/products/import/template
 * Download CSV template for product import
 */
async function GET(req, res) {
    const { type = 'basic' } = req.query;
    try {
        let csv = 'SKU,name_pl,name_en,name_de,desc_pl,desc_en,desc_de,price,cost,category_id,equipment_type,min_order_qty,technical_specs_json\n';
        if (type === 'sample') {
            // Include sample data
            csv += 'HYD-001,Pompa hydrauliczna,Hydraulic pump,Hydraulische Pumpe,Pompa tłokowa osiowa,Variable displacement pump,Axialkolbenpumpe,2499.99,1249.99,cat-hydraulika,Hydraulika,1,"{""displacement"": ""28cc"", ""pressure"": ""280bar""}"\n';
            csv += 'FLT-001,Filtr oleju,Oil filter,Ölfilter,Filtr oleju silnikowego,Engine oil filter,Motorölfilter,49.99,24.99,cat-filtry,Filtry,2,"{""filtration"": ""25μm"", ""flow"": ""150L/min""}"\n';
            csv += 'SPW-001,Przewód hydrauliczny,Hydraulic hose,Hydraulikschlauch,Przewód hydrauliczny dwuoplotowy,Two-wire braided hose,Zweifach geflochtener Schlauch,15.99,7.99,cat-osprzet,Osprzęt,5,"{""pressure"": ""400bar"", ""diameter"": ""12mm""}"\n';
        }
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="product-import-template.csv"`);
        res.send(csv);
    }
    catch (error) {
        console.error('Failed to generate template:', error);
        res.status(500).json({
            error: {
                code: 'TEMPLATE_GENERATION_FAILED',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3Byb2R1Y3RzL2ltcG9ydC90ZW1wbGF0ZS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQU1BLGtCQTBCQztBQTlCRDs7O0dBR0c7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxFQUFFLElBQUksR0FBRyxPQUFPLEVBQUUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFBO0lBRXBDLElBQUksQ0FBQztRQUNILElBQUksR0FBRyxHQUFHLGdJQUFnSSxDQUFBO1FBRTFJLElBQUksSUFBSSxLQUFLLFFBQVEsRUFBRSxDQUFDO1lBQ3RCLHNCQUFzQjtZQUN0QixHQUFHLElBQUksc09BQXNPLENBQUE7WUFDN08sR0FBRyxJQUFJLHdMQUF3TCxDQUFBO1lBQy9MLEdBQUcsSUFBSSw2T0FBNk8sQ0FBQTtRQUN0UCxDQUFDO1FBRUQsR0FBRyxDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQUUsVUFBVSxDQUFDLENBQUE7UUFDekMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsRUFBRSxvREFBb0QsQ0FBQyxDQUFBO1FBQzFGLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7SUFFZixDQUFDO0lBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztRQUNwQixPQUFPLENBQUMsS0FBSyxDQUFDLDhCQUE4QixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQ3BELEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLEtBQUssRUFBRTtnQkFDTCxJQUFJLEVBQUUsNEJBQTRCO2dCQUNsQyxPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87YUFDdkI7U0FDRixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9