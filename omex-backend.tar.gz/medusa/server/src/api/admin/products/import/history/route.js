"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const omex_bulk_import_1 = require("../../../../../modules/omex-bulk-import");
/**
 * GET /admin/products/import/history
 * List all import history records
 */
async function GET(req, res) {
    const bulkImportService = req.scope.resolve(omex_bulk_import_1.OMEX_BULK_IMPORT_MODULE);
    try {
        const { limit = 20, offset = 0, status } = req.query;
        // In production, query import_history table
        const history = {
            imports: [],
            count: 0,
            limit: parseInt(limit),
            offset: parseInt(offset),
        };
        res.json(history);
    }
    catch (error) {
        console.error('Failed to fetch import history:', error);
        res.status(500).json({
            error: {
                code: 'HISTORY_FETCH_ERROR',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3Byb2R1Y3RzL2ltcG9ydC9oaXN0b3J5L3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBT0Esa0JBd0JDO0FBOUJELDhFQUFpRjtBQUVqRjs7O0dBR0c7QUFDSSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxpQkFBaUIsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQywwQ0FBdUIsQ0FBQyxDQUFBO0lBRXBFLElBQUksQ0FBQztRQUNILE1BQU0sRUFBRSxLQUFLLEdBQUcsRUFBRSxFQUFFLE1BQU0sR0FBRyxDQUFDLEVBQUUsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtRQUVwRCw0Q0FBNEM7UUFDNUMsTUFBTSxPQUFPLEdBQUc7WUFDZCxPQUFPLEVBQUUsRUFBRTtZQUNYLEtBQUssRUFBRSxDQUFDO1lBQ1IsS0FBSyxFQUFFLFFBQVEsQ0FBQyxLQUFlLENBQUM7WUFDaEMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxNQUFnQixDQUFDO1NBQ25DLENBQUE7UUFFRCxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO0lBQ25CLENBQUM7SUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1FBQ3BCLE9BQU8sQ0FBQyxLQUFLLENBQUMsaUNBQWlDLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDdkQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSxxQkFBcUI7Z0JBQzNCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTzthQUN2QjtTQUNGLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=