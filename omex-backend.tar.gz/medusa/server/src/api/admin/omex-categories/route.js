"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const omex_category_1 = require("../../../modules/omex-category");
const omex_translation_1 = require("../../../modules/omex-translation");
async function GET(req, res) {
    const categoryService = req.scope.resolve(omex_category_1.OMEX_CATEGORY_MODULE);
    try {
        const tree = await categoryService.listTree();
        res.json({ categories: tree });
    }
    catch (error) {
        res.status(400).json({
            error: {
                code: 'CATEGORY_LIST_ERROR',
                message: error.message,
            },
        });
    }
}
async function POST(req, res) {
    const categoryService = req.scope.resolve(omex_category_1.OMEX_CATEGORY_MODULE);
    const translationService = req.scope.resolve(omex_translation_1.OMEX_TRANSLATION_MODULE);
    const { name, slug, parent_id, icon, description, translations } = req.body;
    try {
        const category = await categoryService.createCategory({
            name,
            slug,
            parent_id,
            icon,
            description,
        });
        // Add translations if provided
        if (translations) {
            await translationService.bulkAddTranslations(category.id, 'category', translations);
        }
        res.status(201).json({ category });
    }
    catch (error) {
        res.status(400).json({
            error: {
                code: 'CATEGORY_CREATE_ERROR',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL29tZXgtY2F0ZWdvcmllcy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUlBLGtCQWVDO0FBRUQsb0JBaUNDO0FBckRELGtFQUFxRTtBQUNyRSx3RUFBMkU7QUFFcEUsS0FBSyxVQUFVLEdBQUcsQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQy9ELE1BQU0sZUFBZSxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLG9DQUFvQixDQUFDLENBQUE7SUFFL0QsSUFBSSxDQUFDO1FBQ0gsTUFBTSxJQUFJLEdBQUcsTUFBTSxlQUFlLENBQUMsUUFBUSxFQUFFLENBQUE7UUFFN0MsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO0lBQ2hDLENBQUM7SUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1FBQ3BCLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLEtBQUssRUFBRTtnQkFDTCxJQUFJLEVBQUUscUJBQXFCO2dCQUMzQixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87YUFDdkI7U0FDRixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQztBQUVNLEtBQUssVUFBVSxJQUFJLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUNoRSxNQUFNLGVBQWUsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxvQ0FBb0IsQ0FBQyxDQUFBO0lBQy9ELE1BQU0sa0JBQWtCLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsMENBQXVCLENBQUMsQ0FBQTtJQUVyRSxNQUFNLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxZQUFZLEVBQUUsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBRTNFLElBQUksQ0FBQztRQUNILE1BQU0sUUFBUSxHQUFHLE1BQU0sZUFBZSxDQUFDLGNBQWMsQ0FBQztZQUNwRCxJQUFJO1lBQ0osSUFBSTtZQUNKLFNBQVM7WUFDVCxJQUFJO1lBQ0osV0FBVztTQUNaLENBQUMsQ0FBQTtRQUVGLCtCQUErQjtRQUMvQixJQUFJLFlBQVksRUFBRSxDQUFDO1lBQ2pCLE1BQU0sa0JBQWtCLENBQUMsbUJBQW1CLENBQzFDLFFBQVEsQ0FBQyxFQUFFLEVBQ1gsVUFBVSxFQUNWLFlBQVksQ0FDYixDQUFBO1FBQ0gsQ0FBQztRQUVELEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQTtJQUNwQyxDQUFDO0lBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztRQUNwQixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUU7Z0JBQ0wsSUFBSSxFQUFFLHVCQUF1QjtnQkFDN0IsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO2FBQ3ZCO1NBQ0YsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUMifQ==