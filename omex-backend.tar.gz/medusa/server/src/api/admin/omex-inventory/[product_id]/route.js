"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PUT = PUT;
const omex_inventory_1 = require("../../../../modules/omex-inventory");
async function PUT(req, res) {
    const inventoryService = req.scope.resolve(omex_inventory_1.OMEX_INVENTORY_MODULE);
    const { product_id } = req.params;
    const { warehouse_id, quantity } = req.body;
    if (!warehouse_id || quantity === undefined) {
        return res.status(400).json({
            error: {
                code: 'MISSING_FIELDS',
                message: 'Warehouse ID and quantity are required',
            },
        });
    }
    try {
        const result = await inventoryService.updateStock(product_id, warehouse_id, quantity);
        res.json(result);
    }
    catch (error) {
        res.status(400).json({
            error: {
                code: 'INVENTORY_UPDATE_ERROR',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL29tZXgtaW52ZW50b3J5L1twcm9kdWN0X2lkXS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUdBLGtCQThCQztBQWhDRCx1RUFBMEU7QUFFbkUsS0FBSyxVQUFVLEdBQUcsQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQy9ELE1BQU0sZ0JBQWdCLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsc0NBQXFCLENBQUMsQ0FBQTtJQUNqRSxNQUFNLEVBQUUsVUFBVSxFQUFFLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQTtJQUNqQyxNQUFNLEVBQUUsWUFBWSxFQUFFLFFBQVEsRUFBRSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUE7SUFFM0MsSUFBSSxDQUFDLFlBQVksSUFBSSxRQUFRLEtBQUssU0FBUyxFQUFFLENBQUM7UUFDNUMsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixLQUFLLEVBQUU7Z0JBQ0wsSUFBSSxFQUFFLGdCQUFnQjtnQkFDdEIsT0FBTyxFQUFFLHdDQUF3QzthQUNsRDtTQUNGLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxJQUFJLENBQUM7UUFDSCxNQUFNLE1BQU0sR0FBRyxNQUFNLGdCQUFnQixDQUFDLFdBQVcsQ0FDL0MsVUFBVSxFQUNWLFlBQVksRUFDWixRQUFRLENBQ1QsQ0FBQTtRQUVELEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUE7SUFDbEIsQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSx3QkFBd0I7Z0JBQzlCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTzthQUN2QjtTQUNGLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=