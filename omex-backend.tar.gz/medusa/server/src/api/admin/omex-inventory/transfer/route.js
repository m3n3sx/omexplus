"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const omex_inventory_1 = require("../../../../modules/omex-inventory");
async function POST(req, res) {
    const inventoryService = req.scope.resolve(omex_inventory_1.OMEX_INVENTORY_MODULE);
    const { product_id, from_warehouse, to_warehouse, quantity } = req.body;
    if (!product_id || !from_warehouse || !to_warehouse || !quantity) {
        return res.status(400).json({
            error: {
                code: 'MISSING_FIELDS',
                message: 'Product ID, source warehouse, destination warehouse, and quantity are required',
            },
        });
    }
    try {
        const result = await inventoryService.transferStock(product_id, from_warehouse, to_warehouse, quantity);
        res.json(result);
    }
    catch (error) {
        res.status(400).json({
            error: {
                code: 'TRANSFER_ERROR',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL29tZXgtaW52ZW50b3J5L3RyYW5zZmVyL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBR0Esb0JBK0JDO0FBakNELHVFQUEwRTtBQUVuRSxLQUFLLFVBQVUsSUFBSSxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDaEUsTUFBTSxnQkFBZ0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxzQ0FBcUIsQ0FBQyxDQUFBO0lBRWpFLE1BQU0sRUFBRSxVQUFVLEVBQUUsY0FBYyxFQUFFLFlBQVksRUFBRSxRQUFRLEVBQUUsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBRXZFLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxjQUFjLElBQUksQ0FBQyxZQUFZLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNqRSxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLEtBQUssRUFBRTtnQkFDTCxJQUFJLEVBQUUsZ0JBQWdCO2dCQUN0QixPQUFPLEVBQUUsZ0ZBQWdGO2FBQzFGO1NBQ0YsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELElBQUksQ0FBQztRQUNILE1BQU0sTUFBTSxHQUFHLE1BQU0sZ0JBQWdCLENBQUMsYUFBYSxDQUNqRCxVQUFVLEVBQ1YsY0FBYyxFQUNkLFlBQVksRUFDWixRQUFRLENBQ1QsQ0FBQTtRQUVELEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUE7SUFDbEIsQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSxnQkFBZ0I7Z0JBQ3RCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTzthQUN2QjtTQUNGLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=