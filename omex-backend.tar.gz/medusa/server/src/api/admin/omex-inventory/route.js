"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const omex_inventory_1 = require("../../../modules/omex-inventory");
async function GET(req, res) {
    const inventoryService = req.scope.resolve(omex_inventory_1.OMEX_INVENTORY_MODULE);
    const { product_id, warehouse_id, low_stock_threshold } = req.query;
    try {
        if (product_id) {
            // Get stock for specific product
            const stock = await inventoryService.getStock(product_id, warehouse_id);
            return res.json({ stock });
        }
        if (low_stock_threshold) {
            // Get low stock alerts
            const alerts = await inventoryService.getLowStockAlerts(parseInt(low_stock_threshold));
            return res.json({ alerts });
        }
        // Return all inventory (paginated in real implementation)
        res.json({ inventory: [] });
    }
    catch (error) {
        res.status(400).json({
            error: {
                code: 'INVENTORY_ERROR',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL29tZXgtaW52ZW50b3J5L3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBR0Esa0JBbUNDO0FBckNELG9FQUF1RTtBQUVoRSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxnQkFBZ0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxzQ0FBcUIsQ0FBQyxDQUFBO0lBRWpFLE1BQU0sRUFBRSxVQUFVLEVBQUUsWUFBWSxFQUFFLG1CQUFtQixFQUFFLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtJQUVuRSxJQUFJLENBQUM7UUFDSCxJQUFJLFVBQVUsRUFBRSxDQUFDO1lBQ2YsaUNBQWlDO1lBQ2pDLE1BQU0sS0FBSyxHQUFHLE1BQU0sZ0JBQWdCLENBQUMsUUFBUSxDQUMzQyxVQUFvQixFQUNwQixZQUFzQixDQUN2QixDQUFBO1lBRUQsT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQTtRQUM1QixDQUFDO1FBRUQsSUFBSSxtQkFBbUIsRUFBRSxDQUFDO1lBQ3hCLHVCQUF1QjtZQUN2QixNQUFNLE1BQU0sR0FBRyxNQUFNLGdCQUFnQixDQUFDLGlCQUFpQixDQUNyRCxRQUFRLENBQUMsbUJBQTZCLENBQUMsQ0FDeEMsQ0FBQTtZQUVELE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUE7UUFDN0IsQ0FBQztRQUVELDBEQUEwRDtRQUMxRCxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUE7SUFDN0IsQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDbkIsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSxpQkFBaUI7Z0JBQ3ZCLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTzthQUN2QjtTQUNGLENBQUMsQ0FBQTtJQUNKLENBQUM7QUFDSCxDQUFDIn0=