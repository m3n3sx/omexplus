"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const shipping_service_1 = require("../../../../../services/shipping-service");
async function GET(req, res) {
    try {
        const { id: shipmentId } = req.params;
        // Fetch shipment from database
        const query = req.scope.resolve("query");
        const result = await query(`
      SELECT * FROM shipment WHERE id = $1
    `, [shipmentId]);
        if (!result.rows || result.rows.length === 0) {
            return res.status(404).json({ error: "Shipment not found" });
        }
        const shipment = result.rows[0];
        // If label URL already exists, return it
        if (shipment.label_url) {
            return res.json({ label_url: shipment.label_url });
        }
        // Generate label
        const shippingService = new shipping_service_1.ShippingService({
            inpost: {
                apiKey: process.env.INPOST_API_KEY || "",
                apiSecret: process.env.INPOST_API_SECRET || "",
                orgId: process.env.INPOST_ORG_ID || "",
            },
            dpd: {
                apiKey: process.env.DPD_API_KEY || "",
                login: process.env.DPD_LOGIN || "",
                password: process.env.DPD_PASSWORD || "",
            },
            dhl: {
                apiKey: process.env.DHL_API_KEY || "",
                accountNumber: process.env.DHL_ACCOUNT_NUMBER || "",
            },
        });
        const metadata = shipment.metadata || {};
        const labelUrl = await shippingService.getLabel(metadata.shipment_id || shipmentId, shipment.provider);
        // Update shipment with label URL
        await query(`
      UPDATE shipment SET label_url = $1, updated_at = NOW() WHERE id = $2
    `, [labelUrl, shipmentId]);
        res.json({ label_url: labelUrl });
    }
    catch (error) {
        console.error("Failed to get shipping label:", error);
        res.status(500).json({
            error: "Failed to get shipping label",
            message: error.message,
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3NoaXBtZW50cy9baWRdL2xhYmVsL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBR0Esa0JBMERDO0FBNURELCtFQUEyRTtBQUVwRSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsSUFBSSxDQUFDO1FBQ0gsTUFBTSxFQUFFLEVBQUUsRUFBRSxVQUFVLEVBQUUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDO1FBRXRDLCtCQUErQjtRQUMvQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN6QyxNQUFNLE1BQU0sR0FBRyxNQUFNLEtBQUssQ0FBQzs7S0FFMUIsRUFBRSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7UUFFakIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDN0MsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSxvQkFBb0IsRUFBRSxDQUFDLENBQUM7UUFDL0QsQ0FBQztRQUVELE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFaEMseUNBQXlDO1FBQ3pDLElBQUksUUFBUSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ3ZCLE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLFNBQVMsRUFBRSxRQUFRLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQztRQUNyRCxDQUFDO1FBRUQsaUJBQWlCO1FBQ2pCLE1BQU0sZUFBZSxHQUFHLElBQUksa0NBQWUsQ0FBQztZQUMxQyxNQUFNLEVBQUU7Z0JBQ04sTUFBTSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxJQUFJLEVBQUU7Z0JBQ3hDLFNBQVMsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixJQUFJLEVBQUU7Z0JBQzlDLEtBQUssRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLGFBQWEsSUFBSSxFQUFFO2FBQ3ZDO1lBQ0QsR0FBRyxFQUFFO2dCQUNILE1BQU0sRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsSUFBSSxFQUFFO2dCQUNyQyxLQUFLLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLElBQUksRUFBRTtnQkFDbEMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxJQUFJLEVBQUU7YUFDekM7WUFDRCxHQUFHLEVBQUU7Z0JBQ0gsTUFBTSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxJQUFJLEVBQUU7Z0JBQ3JDLGFBQWEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixJQUFJLEVBQUU7YUFDcEQ7U0FDRixDQUFDLENBQUM7UUFFSCxNQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsUUFBUSxJQUFJLEVBQUUsQ0FBQztRQUN6QyxNQUFNLFFBQVEsR0FBRyxNQUFNLGVBQWUsQ0FBQyxRQUFRLENBQzdDLFFBQVEsQ0FBQyxXQUFXLElBQUksVUFBVSxFQUNsQyxRQUFRLENBQUMsUUFBUSxDQUNsQixDQUFDO1FBRUYsaUNBQWlDO1FBQ2pDLE1BQU0sS0FBSyxDQUFDOztLQUVYLEVBQUUsQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQztRQUUzQixHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLCtCQUErQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ3RELEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLEtBQUssRUFBRSw4QkFBOEI7WUFDckMsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO1NBQ3ZCLENBQUMsQ0FBQztJQUNMLENBQUM7QUFDSCxDQUFDIn0=