"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const i18n_1 = require("../../../../modules/i18n");
async function GET(req, res) {
    const i18nService = req.scope.resolve(i18n_1.I18N_MODULE);
    const { locale, format } = req.query;
    const translations = await i18nService.getTranslations(locale);
    if (format === "csv") {
        // Eksport do CSV
        res.setHeader("Content-Type", "text/csv");
        res.setHeader("Content-Disposition", `attachment; filename=translations-${locale}.csv`);
    }
    else {
        // Eksport do JSON
        res.setHeader("Content-Type", "application/json");
        res.setHeader("Content-Disposition", `attachment; filename=translations-${locale}.json`);
    }
    res.json(translations);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2kxOG4vZXhwb3J0L3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBR0Esa0JBaUJDO0FBbkJELG1EQUFzRDtBQUUvQyxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsa0JBQVcsQ0FBQyxDQUFBO0lBQ2xELE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtJQUVwQyxNQUFNLFlBQVksR0FBRyxNQUFNLFdBQVcsQ0FBQyxlQUFlLENBQUMsTUFBZ0IsQ0FBQyxDQUFBO0lBRXhFLElBQUksTUFBTSxLQUFLLEtBQUssRUFBRSxDQUFDO1FBQ3JCLGlCQUFpQjtRQUNqQixHQUFHLENBQUMsU0FBUyxDQUFDLGNBQWMsRUFBRSxVQUFVLENBQUMsQ0FBQTtRQUN6QyxHQUFHLENBQUMsU0FBUyxDQUFDLHFCQUFxQixFQUFFLHFDQUFxQyxNQUFNLE1BQU0sQ0FBQyxDQUFBO0lBQ3pGLENBQUM7U0FBTSxDQUFDO1FBQ04sa0JBQWtCO1FBQ2xCLEdBQUcsQ0FBQyxTQUFTLENBQUMsY0FBYyxFQUFFLGtCQUFrQixDQUFDLENBQUE7UUFDakQsR0FBRyxDQUFDLFNBQVMsQ0FBQyxxQkFBcUIsRUFBRSxxQ0FBcUMsTUFBTSxPQUFPLENBQUMsQ0FBQTtJQUMxRixDQUFDO0lBRUQsR0FBRyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQTtBQUN4QixDQUFDIn0=