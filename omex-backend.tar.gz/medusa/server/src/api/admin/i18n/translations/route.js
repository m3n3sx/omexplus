"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.PUT = PUT;
const i18n_1 = require("../../../../modules/i18n");
async function GET(req, res) {
    const i18nService = req.scope.resolve(i18n_1.I18N_MODULE);
    const { locale } = req.query;
    const translations = await i18nService.getTranslations(locale);
    res.json({ translations });
}
async function PUT(req, res) {
    const i18nService = req.scope.resolve(i18n_1.I18N_MODULE);
    const { locale, key, value } = req.body;
    const translation = await i18nService.setTranslation(locale, key, value);
    res.json({ translation });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2kxOG4vdHJhbnNsYXRpb25zL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBR0Esa0JBT0M7QUFFRCxrQkFPQztBQWxCRCxtREFBc0Q7QUFFL0MsS0FBSyxVQUFVLEdBQUcsQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQy9ELE1BQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGtCQUFXLENBQUMsQ0FBQTtJQUNsRCxNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtJQUU1QixNQUFNLFlBQVksR0FBRyxNQUFNLFdBQVcsQ0FBQyxlQUFlLENBQUMsTUFBZ0IsQ0FBQyxDQUFBO0lBRXhFLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxZQUFZLEVBQUUsQ0FBQyxDQUFBO0FBQzVCLENBQUM7QUFFTSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsa0JBQVcsQ0FBQyxDQUFBO0lBQ2xELE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBRSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUE7SUFFdkMsTUFBTSxXQUFXLEdBQUcsTUFBTSxXQUFXLENBQUMsY0FBYyxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUE7SUFFeEUsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLFdBQVcsRUFBRSxDQUFDLENBQUE7QUFDM0IsQ0FBQyJ9