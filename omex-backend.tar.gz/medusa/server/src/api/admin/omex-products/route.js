"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const omex_product_1 = require("../../../modules/omex-product");
const omex_translation_1 = require("../../../modules/omex-translation");
async function GET(req, res) {
    const productService = req.scope.resolve(omex_product_1.OMEX_PRODUCT_MODULE);
    const { category_id, equipment_type, q, limit = 20, offset = 0, } = req.query;
    try {
        const filters = {
            category_id: category_id,
            equipment_type: equipment_type,
            q: q,
        };
        const pagination = {
            limit: parseInt(limit),
            offset: parseInt(offset),
        };
        const result = await productService.listProducts(filters, pagination);
        res.json(result);
    }
    catch (error) {
        res.status(400).json({
            error: {
                code: 'PRODUCT_LIST_ERROR',
                message: error.message,
            },
        });
    }
}
async function POST(req, res) {
    const productService = req.scope.resolve(omex_product_1.OMEX_PRODUCT_MODULE);
    const translationService = req.scope.resolve(omex_translation_1.OMEX_TRANSLATION_MODULE);
    const { title, description, sku, part_number, equipment_type, price, cost, min_order_qty, technical_specs, categories, translations, } = req.body;
    try {
        // Create product
        const product = await productService.createProduct({
            title,
            description,
            sku,
            part_number,
            equipment_type,
            price,
            cost,
            min_order_qty,
            technical_specs,
            categories,
        });
        // Add translations if provided
        if (translations) {
            await translationService.bulkAddTranslations(product.id, 'product', translations);
        }
        res.status(201).json({ product });
    }
    catch (error) {
        res.status(400).json({
            error: {
                code: 'PRODUCT_CREATE_ERROR',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL29tZXgtcHJvZHVjdHMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFJQSxrQkFrQ0M7QUFFRCxvQkFtREM7QUExRkQsZ0VBQW1FO0FBQ25FLHdFQUEyRTtBQUVwRSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxjQUFjLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsa0NBQW1CLENBQUMsQ0FBQTtJQUU3RCxNQUFNLEVBQ0osV0FBVyxFQUNYLGNBQWMsRUFDZCxDQUFDLEVBQ0QsS0FBSyxHQUFHLEVBQUUsRUFDVixNQUFNLEdBQUcsQ0FBQyxHQUNYLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQTtJQUViLElBQUksQ0FBQztRQUNILE1BQU0sT0FBTyxHQUFHO1lBQ2QsV0FBVyxFQUFFLFdBQXFCO1lBQ2xDLGNBQWMsRUFBRSxjQUF3QjtZQUN4QyxDQUFDLEVBQUUsQ0FBVztTQUNmLENBQUE7UUFFRCxNQUFNLFVBQVUsR0FBRztZQUNqQixLQUFLLEVBQUUsUUFBUSxDQUFDLEtBQWUsQ0FBQztZQUNoQyxNQUFNLEVBQUUsUUFBUSxDQUFDLE1BQWdCLENBQUM7U0FDbkMsQ0FBQTtRQUVELE1BQU0sTUFBTSxHQUFHLE1BQU0sY0FBYyxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDLENBQUE7UUFFckUsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUNsQixDQUFDO0lBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztRQUNwQixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUU7Z0JBQ0wsSUFBSSxFQUFFLG9CQUFvQjtnQkFDMUIsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO2FBQ3ZCO1NBQ0YsQ0FBQyxDQUFBO0lBQ0osQ0FBQztBQUNILENBQUM7QUFFTSxLQUFLLFVBQVUsSUFBSSxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDaEUsTUFBTSxjQUFjLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsa0NBQW1CLENBQUMsQ0FBQTtJQUM3RCxNQUFNLGtCQUFrQixHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLDBDQUF1QixDQUFDLENBQUE7SUFFckUsTUFBTSxFQUNKLEtBQUssRUFDTCxXQUFXLEVBQ1gsR0FBRyxFQUNILFdBQVcsRUFDWCxjQUFjLEVBQ2QsS0FBSyxFQUNMLElBQUksRUFDSixhQUFhLEVBQ2IsZUFBZSxFQUNmLFVBQVUsRUFDVixZQUFZLEdBQ2IsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0lBRVosSUFBSSxDQUFDO1FBQ0gsaUJBQWlCO1FBQ2pCLE1BQU0sT0FBTyxHQUFHLE1BQU0sY0FBYyxDQUFDLGFBQWEsQ0FBQztZQUNqRCxLQUFLO1lBQ0wsV0FBVztZQUNYLEdBQUc7WUFDSCxXQUFXO1lBQ1gsY0FBYztZQUNkLEtBQUs7WUFDTCxJQUFJO1lBQ0osYUFBYTtZQUNiLGVBQWU7WUFDZixVQUFVO1NBQ1gsQ0FBQyxDQUFBO1FBRUYsK0JBQStCO1FBQy9CLElBQUksWUFBWSxFQUFFLENBQUM7WUFDakIsTUFBTSxrQkFBa0IsQ0FBQyxtQkFBbUIsQ0FDMUMsT0FBTyxDQUFDLEVBQUUsRUFDVixTQUFTLEVBQ1QsWUFBWSxDQUNiLENBQUE7UUFDSCxDQUFDO1FBRUQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFBO0lBQ25DLENBQUM7SUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1FBQ3BCLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLEtBQUssRUFBRTtnQkFDTCxJQUFJLEVBQUUsc0JBQXNCO2dCQUM1QixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87YUFDdkI7U0FDRixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9