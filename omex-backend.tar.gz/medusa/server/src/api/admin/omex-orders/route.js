"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const omex_order_1 = require("../../../modules/omex-order");
async function GET(req, res) {
    const orderService = req.scope.resolve(omex_order_1.OMEX_ORDER_MODULE);
    const { status, payment_status, customer_id, date_from, date_to, limit = 20, offset = 0, } = req.query;
    try {
        const filters = {
            status: status,
            payment_status: payment_status,
            customer_id: customer_id,
            date_from: date_from ? new Date(date_from) : undefined,
            date_to: date_to ? new Date(date_to) : undefined,
        };
        const pagination = {
            limit: parseInt(limit),
            offset: parseInt(offset),
        };
        const result = await orderService.listOrders(filters, pagination);
        res.json(result);
    }
    catch (error) {
        res.status(400).json({
            error: {
                code: 'ORDER_LIST_ERROR',
                message: error.message,
            },
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL29tZXgtb3JkZXJzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBR0Esa0JBc0NDO0FBeENELDREQUErRDtBQUV4RCxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsOEJBQWlCLENBQUMsQ0FBQTtJQUV6RCxNQUFNLEVBQ0osTUFBTSxFQUNOLGNBQWMsRUFDZCxXQUFXLEVBQ1gsU0FBUyxFQUNULE9BQU8sRUFDUCxLQUFLLEdBQUcsRUFBRSxFQUNWLE1BQU0sR0FBRyxDQUFDLEdBQ1gsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFBO0lBRWIsSUFBSSxDQUFDO1FBQ0gsTUFBTSxPQUFPLEdBQUc7WUFDZCxNQUFNLEVBQUUsTUFBYTtZQUNyQixjQUFjLEVBQUUsY0FBcUI7WUFDckMsV0FBVyxFQUFFLFdBQXFCO1lBQ2xDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUztZQUNoRSxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxPQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7U0FDM0QsQ0FBQTtRQUVELE1BQU0sVUFBVSxHQUFHO1lBQ2pCLEtBQUssRUFBRSxRQUFRLENBQUMsS0FBZSxDQUFDO1lBQ2hDLE1BQU0sRUFBRSxRQUFRLENBQUMsTUFBZ0IsQ0FBQztTQUNuQyxDQUFBO1FBRUQsTUFBTSxNQUFNLEdBQUcsTUFBTSxZQUFZLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsQ0FBQTtRQUVqRSxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQ2xCLENBQUM7SUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO1FBQ3BCLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ25CLEtBQUssRUFBRTtnQkFDTCxJQUFJLEVBQUUsa0JBQWtCO2dCQUN4QixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87YUFDdkI7U0FDRixDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9