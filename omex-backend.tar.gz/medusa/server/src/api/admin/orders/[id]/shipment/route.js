"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const shipping_service_1 = require("../../../../../services/shipping-service");
async function POST(req, res) {
    try {
        const { id: orderId } = req.params;
        const { shipping_method_id, weight, dimensions } = req.body;
        if (!shipping_method_id) {
            return res.status(400).json({
                error: "Missing required field: shipping_method_id",
            });
        }
        // Fetch order from database
        const orderModule = req.scope.resolve("orderModuleService");
        const order = await orderModule.retrieveOrder(orderId, {
            relations: ["shipping_address", "items"],
        });
        if (!order) {
            return res.status(404).json({ error: "Order not found" });
        }
        // Parse shipping method
        const [provider, method] = shipping_method_id.split("_", 2);
        const shippingService = new shipping_service_1.ShippingService({
            inpost: {
                apiKey: process.env.INPOST_API_KEY || "",
                apiSecret: process.env.INPOST_API_SECRET || "",
                orgId: process.env.INPOST_ORG_ID || "",
            },
            dpd: {
                apiKey: process.env.DPD_API_KEY || "",
                login: process.env.DPD_LOGIN || "",
                password: process.env.DPD_PASSWORD || "",
            },
            dhl: {
                apiKey: process.env.DHL_API_KEY || "",
                accountNumber: process.env.DHL_ACCOUNT_NUMBER || "",
            },
        });
        const parcel = {
            weight: weight || 1000,
            length: dimensions?.length || 30,
            width: dimensions?.width || 20,
            height: dimensions?.height || 10,
        };
        const shipment = await shippingService.createShipment(order, method || shipping_method_id, parcel, provider);
        // Save shipment to database
        const query = req.scope.resolve("query");
        await query(`
      INSERT INTO shipment (id, order_id, provider, shipping_method, tracking_number, label_url, status, metadata)
      VALUES (gen_random_uuid(), $1, $2, $3, $4, $5, $6, $7)
    `, [
            orderId,
            shipment.provider,
            shipping_method_id,
            shipment.tracking_number,
            shipment.label_url,
            shipment.status,
            JSON.stringify({ shipment_id: shipment.shipment_id }),
        ]);
        res.json({ shipment });
    }
    catch (error) {
        console.error("Failed to create shipment:", error);
        res.status(500).json({
            error: "Failed to create shipment",
            message: error.message,
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL29yZGVycy9baWRdL3NoaXBtZW50L3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBR0Esb0JBOEVDO0FBaEZELCtFQUEyRTtBQUVwRSxLQUFLLFVBQVUsSUFBSSxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDaEUsSUFBSSxDQUFDO1FBQ0gsTUFBTSxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDO1FBQ25DLE1BQU0sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQztRQUU1RCxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztZQUN4QixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUMxQixLQUFLLEVBQUUsNENBQTRDO2FBQ3BELENBQUMsQ0FBQztRQUNMLENBQUM7UUFFRCw0QkFBNEI7UUFDNUIsTUFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUM1RCxNQUFNLEtBQUssR0FBRyxNQUFNLFdBQVcsQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFO1lBQ3JELFNBQVMsRUFBRSxDQUFDLGtCQUFrQixFQUFFLE9BQU8sQ0FBQztTQUN6QyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDWCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixFQUFFLENBQUMsQ0FBQztRQUM1RCxDQUFDO1FBRUQsd0JBQXdCO1FBQ3hCLE1BQU0sQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLEdBQUcsa0JBQWtCLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUU1RCxNQUFNLGVBQWUsR0FBRyxJQUFJLGtDQUFlLENBQUM7WUFDMUMsTUFBTSxFQUFFO2dCQUNOLE1BQU0sRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsSUFBSSxFQUFFO2dCQUN4QyxTQUFTLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsSUFBSSxFQUFFO2dCQUM5QyxLQUFLLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLElBQUksRUFBRTthQUN2QztZQUNELEdBQUcsRUFBRTtnQkFDSCxNQUFNLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLElBQUksRUFBRTtnQkFDckMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxJQUFJLEVBQUU7Z0JBQ2xDLFFBQVEsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksSUFBSSxFQUFFO2FBQ3pDO1lBQ0QsR0FBRyxFQUFFO2dCQUNILE1BQU0sRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsSUFBSSxFQUFFO2dCQUNyQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsSUFBSSxFQUFFO2FBQ3BEO1NBQ0YsQ0FBQyxDQUFDO1FBRUgsTUFBTSxNQUFNLEdBQUc7WUFDYixNQUFNLEVBQUUsTUFBTSxJQUFJLElBQUk7WUFDdEIsTUFBTSxFQUFFLFVBQVUsRUFBRSxNQUFNLElBQUksRUFBRTtZQUNoQyxLQUFLLEVBQUUsVUFBVSxFQUFFLEtBQUssSUFBSSxFQUFFO1lBQzlCLE1BQU0sRUFBRSxVQUFVLEVBQUUsTUFBTSxJQUFJLEVBQUU7U0FDakMsQ0FBQztRQUVGLE1BQU0sUUFBUSxHQUFHLE1BQU0sZUFBZSxDQUFDLGNBQWMsQ0FDbkQsS0FBSyxFQUNMLE1BQU0sSUFBSSxrQkFBa0IsRUFDNUIsTUFBTSxFQUNOLFFBQVEsQ0FDVCxDQUFDO1FBRUYsNEJBQTRCO1FBQzVCLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3pDLE1BQU0sS0FBSyxDQUFDOzs7S0FHWCxFQUFFO1lBQ0QsT0FBTztZQUNQLFFBQVEsQ0FBQyxRQUFRO1lBQ2pCLGtCQUFrQjtZQUNsQixRQUFRLENBQUMsZUFBZTtZQUN4QixRQUFRLENBQUMsU0FBUztZQUNsQixRQUFRLENBQUMsTUFBTTtZQUNmLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxXQUFXLEVBQUUsUUFBUSxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQ3RELENBQUMsQ0FBQztRQUVILEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBQ3pCLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyw0QkFBNEIsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUNuRCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNuQixLQUFLLEVBQUUsMkJBQTJCO1lBQ2xDLE9BQU8sRUFBRSxLQUFLLENBQUMsT0FBTztTQUN2QixDQUFDLENBQUM7SUFDTCxDQUFDO0FBQ0gsQ0FBQyJ9