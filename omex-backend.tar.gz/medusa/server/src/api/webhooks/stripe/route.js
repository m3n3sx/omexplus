"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
exports.POST = POST;
/**
 * POST /webhooks/stripe
 * Handle Stripe webhook events
 */
async function POST(req, res) {
    const stripe = req.scope.resolve('stripe');
    const webhookSecret = req.scope.resolve('stripeWebhookSecret');
    const logger = req.scope.resolve('logger');
    const sig = req.headers['stripe-signature'];
    if (!sig) {
        logger.error('Missing Stripe signature header');
        return res.status(400).json({ error: 'Missing signature' });
    }
    let event;
    try {
        // Verify webhook signature
        event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
    }
    catch (error) {
        logger.error('Webhook signature verification failed:', error);
        return res.status(400).json({ error: 'Invalid signature' });
    }
    logger.info(`Received Stripe webhook: ${event.type}`);
    try {
        switch (event.type) {
            case 'payment_intent.succeeded': {
                const paymentIntent = event.data.object;
                logger.info(`Payment succeeded: ${paymentIntent.id}`);
                // TODO: Mark order as paid
                // const orderId = paymentIntent.metadata.order_id;
                // if (orderId) {
                //   const orderService = req.scope.resolve('orderService');
                //   await orderService.update(orderId, { payment_status: 'paid' });
                // }
                break;
            }
            case 'payment_intent.payment_failed': {
                const paymentIntent = event.data.object;
                logger.error(`Payment failed: ${paymentIntent.id}`);
                // TODO: Notify customer and mark order as failed
                // const orderId = paymentIntent.metadata.order_id;
                // if (orderId) {
                //   const orderService = req.scope.resolve('orderService');
                //   await orderService.update(orderId, { payment_status: 'failed' });
                // }
                break;
            }
            case 'charge.refunded': {
                const charge = event.data.object;
                logger.info(`Charge refunded: ${charge.id}`);
                // TODO: Process refund in system
                break;
            }
            case 'charge.dispute.created': {
                const dispute = event.data.object;
                logger.warn(`Dispute created: ${dispute.id}`);
                // TODO: Alert admin about dispute
                break;
            }
            case 'payment_intent.canceled': {
                const paymentIntent = event.data.object;
                logger.info(`Payment canceled: ${paymentIntent.id}`);
                break;
            }
            default:
                logger.info(`Unhandled event type: ${event.type}`);
        }
        return res.status(200).json({ received: true });
    }
    catch (error) {
        logger.error('Webhook processing error:', error);
        return res.status(500).json({ error: 'Webhook processing failed' });
    }
}
// Disable body parsing for webhooks (Stripe needs raw body)
exports.config = {
    api: {
        bodyParser: false,
    },
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3dlYmhvb2tzL3N0cmlwZS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFPQSxvQkF1RkM7QUEzRkQ7OztHQUdHO0FBQ0ksS0FBSyxVQUFVLElBQUksQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQ2hFLE1BQU0sTUFBTSxHQUFXLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ25ELE1BQU0sYUFBYSxHQUFXLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLHFCQUFxQixDQUFDLENBQUM7SUFDdkUsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7SUFFM0MsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0lBRTVDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNULE1BQU0sQ0FBQyxLQUFLLENBQUMsaUNBQWlDLENBQUMsQ0FBQztRQUNoRCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxFQUFFLG1CQUFtQixFQUFFLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBRUQsSUFBSSxLQUFtQixDQUFDO0lBRXhCLElBQUksQ0FBQztRQUNILDJCQUEyQjtRQUMzQixLQUFLLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQ3BDLEdBQUcsQ0FBQyxJQUFJLEVBQ1IsR0FBRyxFQUNILGFBQWEsQ0FDZCxDQUFDO0lBQ0osQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixNQUFNLENBQUMsS0FBSyxDQUFDLHdDQUF3QyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzlELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsbUJBQW1CLEVBQUUsQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFFRCxNQUFNLENBQUMsSUFBSSxDQUFDLDRCQUE0QixLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztJQUV0RCxJQUFJLENBQUM7UUFDSCxRQUFRLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNuQixLQUFLLDBCQUEwQixDQUFDLENBQUMsQ0FBQztnQkFDaEMsTUFBTSxhQUFhLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUE4QixDQUFDO2dCQUNoRSxNQUFNLENBQUMsSUFBSSxDQUFDLHNCQUFzQixhQUFhLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFFdEQsMkJBQTJCO2dCQUMzQixtREFBbUQ7Z0JBQ25ELGlCQUFpQjtnQkFDakIsNERBQTREO2dCQUM1RCxvRUFBb0U7Z0JBQ3BFLElBQUk7Z0JBQ0osTUFBTTtZQUNSLENBQUM7WUFFRCxLQUFLLCtCQUErQixDQUFDLENBQUMsQ0FBQztnQkFDckMsTUFBTSxhQUFhLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUE4QixDQUFDO2dCQUNoRSxNQUFNLENBQUMsS0FBSyxDQUFDLG1CQUFtQixhQUFhLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFFcEQsaURBQWlEO2dCQUNqRCxtREFBbUQ7Z0JBQ25ELGlCQUFpQjtnQkFDakIsNERBQTREO2dCQUM1RCxzRUFBc0U7Z0JBQ3RFLElBQUk7Z0JBQ0osTUFBTTtZQUNSLENBQUM7WUFFRCxLQUFLLGlCQUFpQixDQUFDLENBQUMsQ0FBQztnQkFDdkIsTUFBTSxNQUFNLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUF1QixDQUFDO2dCQUNsRCxNQUFNLENBQUMsSUFBSSxDQUFDLG9CQUFvQixNQUFNLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFFN0MsaUNBQWlDO2dCQUNqQyxNQUFNO1lBQ1IsQ0FBQztZQUVELEtBQUssd0JBQXdCLENBQUMsQ0FBQyxDQUFDO2dCQUM5QixNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQXdCLENBQUM7Z0JBQ3BELE1BQU0sQ0FBQyxJQUFJLENBQUMsb0JBQW9CLE9BQU8sQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUU5QyxrQ0FBa0M7Z0JBQ2xDLE1BQU07WUFDUixDQUFDO1lBRUQsS0FBSyx5QkFBeUIsQ0FBQyxDQUFDLENBQUM7Z0JBQy9CLE1BQU0sYUFBYSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBOEIsQ0FBQztnQkFDaEUsTUFBTSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsYUFBYSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQ3JELE1BQU07WUFDUixDQUFDO1lBRUQ7Z0JBQ0UsTUFBTSxDQUFDLElBQUksQ0FBQyx5QkFBeUIsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7UUFDdkQsQ0FBQztRQUVELE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE1BQU0sQ0FBQyxLQUFLLENBQUMsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDakQsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSwyQkFBMkIsRUFBRSxDQUFDLENBQUM7SUFDdEUsQ0FBQztBQUNILENBQUM7QUFFRCw0REFBNEQ7QUFDL0MsUUFBQSxNQUFNLEdBQUc7SUFDcEIsR0FBRyxFQUFFO1FBQ0gsVUFBVSxFQUFFLEtBQUs7S0FDbEI7Q0FDRixDQUFDIn0=