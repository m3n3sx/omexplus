"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
async function POST(req, res) {
    try {
        const { tracking_number, status, event_type, timestamp, location } = req.body;
        if (!tracking_number) {
            return res.status(400).json({ error: "Missing tracking_number" });
        }
        const query = req.scope.resolve("query");
        // Find shipment by tracking number
        const result = await query(`
      SELECT * FROM shipment WHERE tracking_number = $1
    `, [tracking_number]);
        if (!result.rows || result.rows.length === 0) {
            return res.status(404).json({ error: "Shipment not found" });
        }
        const shipment = result.rows[0];
        // Update shipment status
        if (status) {
            await query(`
        UPDATE shipment SET status = $1, updated_at = NOW() WHERE id = $2
      `, [status, shipment.id]);
        }
        // Create tracking event
        await query(`
      INSERT INTO tracking_event (id, shipment_id, status, location, timestamp, description)
      VALUES (gen_random_uuid(), $1, $2, $3, $4, $5)
    `, [
            shipment.id,
            status || event_type,
            location || "",
            timestamp ? new Date(timestamp) : new Date(),
            event_type || "",
        ]);
        res.json({ success: true });
    }
    catch (error) {
        console.error("DHL webhook error:", error);
        res.status(500).json({ error: "Webhook processing failed" });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3dlYmhvb2tzL2RobC9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUVBLG9CQTZDQztBQTdDTSxLQUFLLFVBQVUsSUFBSSxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDaEUsSUFBSSxDQUFDO1FBQ0gsTUFBTSxFQUFFLGVBQWUsRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDO1FBRTlFLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUNyQixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxFQUFFLHlCQUF5QixFQUFFLENBQUMsQ0FBQztRQUNwRSxDQUFDO1FBRUQsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFekMsbUNBQW1DO1FBQ25DLE1BQU0sTUFBTSxHQUFHLE1BQU0sS0FBSyxDQUFDOztLQUUxQixFQUFFLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQztRQUV0QixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUM3QyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxFQUFFLG9CQUFvQixFQUFFLENBQUMsQ0FBQztRQUMvRCxDQUFDO1FBRUQsTUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVoQyx5QkFBeUI7UUFDekIsSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUNYLE1BQU0sS0FBSyxDQUFDOztPQUVYLEVBQUUsQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDNUIsQ0FBQztRQUVELHdCQUF3QjtRQUN4QixNQUFNLEtBQUssQ0FBQzs7O0tBR1gsRUFBRTtZQUNELFFBQVEsQ0FBQyxFQUFFO1lBQ1gsTUFBTSxJQUFJLFVBQVU7WUFDcEIsUUFBUSxJQUFJLEVBQUU7WUFDZCxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRTtZQUM1QyxVQUFVLElBQUksRUFBRTtTQUNqQixDQUFDLENBQUM7UUFFSCxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7SUFDOUIsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzNDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxFQUFFLDJCQUEyQixFQUFFLENBQUMsQ0FBQztJQUMvRCxDQUFDO0FBQ0gsQ0FBQyJ9