"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = require("fs");
const sync_1 = require("csv-parse/sync");
/**
 * Test script to validate CSV format before import
 * Usage: npm run test-import
 */
const CSV_FILE = './sample-products-120.csv';
async function testImport() {
    console.log('🧪 Testing CSV Import...\n');
    try {
        // Read CSV file
        const fileContent = (0, fs_1.readFileSync)(CSV_FILE, 'utf-8');
        // Parse CSV
        const records = (0, sync_1.parse)(fileContent, {
            columns: true,
            skip_empty_lines: true,
            trim: true,
        });
        console.log(`📊 Total products: ${records.length}`);
        console.log('');
        // Validate each row
        let validCount = 0;
        let errorCount = 0;
        const errors = [];
        records.forEach((row, index) => {
            const lineNumber = index + 2; // +1 for header, +1 for 0-index
            let hasError = false;
            // Check required fields
            if (!row.sku || row.sku.trim() === '') {
                errors.push({ line: lineNumber, field: 'sku', reason: 'Missing SKU' });
                hasError = true;
            }
            if (!row.name_pl || row.name_pl.trim() === '') {
                errors.push({ line: lineNumber, field: 'name_pl', reason: 'Missing Polish name' });
                hasError = true;
            }
            if (!row.price || row.price.trim() === '') {
                errors.push({ line: lineNumber, field: 'price', reason: 'Missing price' });
                hasError = true;
            }
            if (!row.category_id || row.category_id.trim() === '') {
                errors.push({ line: lineNumber, field: 'category_id', reason: 'Missing category' });
                hasError = true;
            }
            // Validate SKU format
            if (row.sku && !/^[A-Z]{3}-\d{3}$/.test(row.sku)) {
                errors.push({
                    line: lineNumber,
                    field: 'sku',
                    reason: 'Invalid SKU format (should be XXX-000)',
                    value: row.sku
                });
                hasError = true;
            }
            // Validate price
            if (row.price) {
                const price = parseFloat(row.price);
                if (isNaN(price) || price < 0) {
                    errors.push({
                        line: lineNumber,
                        field: 'price',
                        reason: 'Invalid price',
                        value: row.price
                    });
                    hasError = true;
                }
            }
            // Validate technical specs JSON
            if (row.technical_specs_json && row.technical_specs_json.trim() !== '') {
                try {
                    JSON.parse(row.technical_specs_json);
                }
                catch {
                    errors.push({
                        line: lineNumber,
                        field: 'technical_specs_json',
                        reason: 'Invalid JSON',
                        value: row.technical_specs_json.substring(0, 50) + '...'
                    });
                    hasError = true;
                }
            }
            if (hasError) {
                errorCount++;
            }
            else {
                validCount++;
            }
        });
        // Print results
        console.log('📈 Validation Results:');
        console.log(`  ✅ Valid: ${validCount}`);
        console.log(`  ❌ Errors: ${errorCount}`);
        console.log('');
        if (errors.length > 0) {
            console.log('⚠️  Errors found:');
            errors.slice(0, 10).forEach(error => {
                console.log(`  Line ${error.line}: ${error.field} - ${error.reason}`);
                if (error.value) {
                    console.log(`    Value: ${error.value}`);
                }
            });
            if (errors.length > 10) {
                console.log(`  ... and ${errors.length - 10} more errors`);
            }
            console.log('');
        }
        // Category breakdown
        const categories = new Map();
        records.forEach(row => {
            const count = categories.get(row.category_id) || 0;
            categories.set(row.category_id, count + 1);
        });
        console.log('📦 Products by Category:');
        categories.forEach((count, category) => {
            console.log(`  ${category}: ${count} products`);
        });
        console.log('');
        // Sample products
        console.log('🔍 Sample Products:');
        records.slice(0, 3).forEach(row => {
            console.log(`  ${row.sku} - ${row.name_pl} (${row.price} PLN)`);
        });
        console.log('');
        if (errorCount === 0) {
            console.log('✅ CSV is valid and ready for import!');
        }
        else {
            console.log('❌ Please fix errors before importing');
            process.exit(1);
        }
    }
    catch (error) {
        console.error('❌ Error:', error.message);
        process.exit(1);
    }
}
testImport();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVzdC1pbXBvcnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvc2NyaXB0cy90ZXN0LWltcG9ydC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLDJCQUFpQztBQUNqQyx5Q0FBc0M7QUFFdEM7OztHQUdHO0FBRUgsTUFBTSxRQUFRLEdBQUcsMkJBQTJCLENBQUE7QUFrQjVDLEtBQUssVUFBVSxVQUFVO0lBQ3ZCLE9BQU8sQ0FBQyxHQUFHLENBQUMsNEJBQTRCLENBQUMsQ0FBQTtJQUV6QyxJQUFJLENBQUM7UUFDSCxnQkFBZ0I7UUFDaEIsTUFBTSxXQUFXLEdBQUcsSUFBQSxpQkFBWSxFQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQTtRQUVuRCxZQUFZO1FBQ1osTUFBTSxPQUFPLEdBQUcsSUFBQSxZQUFLLEVBQUMsV0FBVyxFQUFFO1lBQ2pDLE9BQU8sRUFBRSxJQUFJO1lBQ2IsZ0JBQWdCLEVBQUUsSUFBSTtZQUN0QixJQUFJLEVBQUUsSUFBSTtTQUNYLENBQWlCLENBQUE7UUFFbEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUE7UUFDbkQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUVmLG9CQUFvQjtRQUNwQixJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUE7UUFDbEIsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFBO1FBQ2xCLE1BQU0sTUFBTSxHQUFVLEVBQUUsQ0FBQTtRQUV4QixPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxFQUFFO1lBQzdCLE1BQU0sVUFBVSxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUEsQ0FBQyxnQ0FBZ0M7WUFDN0QsSUFBSSxRQUFRLEdBQUcsS0FBSyxDQUFBO1lBRXBCLHdCQUF3QjtZQUN4QixJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDO2dCQUN0QyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxhQUFhLEVBQUUsQ0FBQyxDQUFBO2dCQUN0RSxRQUFRLEdBQUcsSUFBSSxDQUFBO1lBQ2pCLENBQUM7WUFFRCxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sSUFBSSxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDO2dCQUM5QyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxxQkFBcUIsRUFBRSxDQUFDLENBQUE7Z0JBQ2xGLFFBQVEsR0FBRyxJQUFJLENBQUE7WUFDakIsQ0FBQztZQUVELElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxJQUFJLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUM7Z0JBQzFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLGVBQWUsRUFBRSxDQUFDLENBQUE7Z0JBQzFFLFFBQVEsR0FBRyxJQUFJLENBQUE7WUFDakIsQ0FBQztZQUVELElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxJQUFJLEdBQUcsQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUM7Z0JBQ3RELE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxhQUFhLEVBQUUsTUFBTSxFQUFFLGtCQUFrQixFQUFFLENBQUMsQ0FBQTtnQkFDbkYsUUFBUSxHQUFHLElBQUksQ0FBQTtZQUNqQixDQUFDO1lBRUQsc0JBQXNCO1lBQ3RCLElBQUksR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDakQsTUFBTSxDQUFDLElBQUksQ0FBQztvQkFDVixJQUFJLEVBQUUsVUFBVTtvQkFDaEIsS0FBSyxFQUFFLEtBQUs7b0JBQ1osTUFBTSxFQUFFLHdDQUF3QztvQkFDaEQsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO2lCQUNmLENBQUMsQ0FBQTtnQkFDRixRQUFRLEdBQUcsSUFBSSxDQUFBO1lBQ2pCLENBQUM7WUFFRCxpQkFBaUI7WUFDakIsSUFBSSxHQUFHLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBQ2QsTUFBTSxLQUFLLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQTtnQkFDbkMsSUFBSSxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxHQUFHLENBQUMsRUFBRSxDQUFDO29CQUM5QixNQUFNLENBQUMsSUFBSSxDQUFDO3dCQUNWLElBQUksRUFBRSxVQUFVO3dCQUNoQixLQUFLLEVBQUUsT0FBTzt3QkFDZCxNQUFNLEVBQUUsZUFBZTt3QkFDdkIsS0FBSyxFQUFFLEdBQUcsQ0FBQyxLQUFLO3FCQUNqQixDQUFDLENBQUE7b0JBQ0YsUUFBUSxHQUFHLElBQUksQ0FBQTtnQkFDakIsQ0FBQztZQUNILENBQUM7WUFFRCxnQ0FBZ0M7WUFDaEMsSUFBSSxHQUFHLENBQUMsb0JBQW9CLElBQUksR0FBRyxDQUFDLG9CQUFvQixDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDO2dCQUN2RSxJQUFJLENBQUM7b0JBQ0gsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQTtnQkFDdEMsQ0FBQztnQkFBQyxNQUFNLENBQUM7b0JBQ1AsTUFBTSxDQUFDLElBQUksQ0FBQzt3QkFDVixJQUFJLEVBQUUsVUFBVTt3QkFDaEIsS0FBSyxFQUFFLHNCQUFzQjt3QkFDN0IsTUFBTSxFQUFFLGNBQWM7d0JBQ3RCLEtBQUssRUFBRSxHQUFHLENBQUMsb0JBQW9CLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxLQUFLO3FCQUN6RCxDQUFDLENBQUE7b0JBQ0YsUUFBUSxHQUFHLElBQUksQ0FBQTtnQkFDakIsQ0FBQztZQUNILENBQUM7WUFFRCxJQUFJLFFBQVEsRUFBRSxDQUFDO2dCQUNiLFVBQVUsRUFBRSxDQUFBO1lBQ2QsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLFVBQVUsRUFBRSxDQUFBO1lBQ2QsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFBO1FBRUYsZ0JBQWdCO1FBQ2hCLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQTtRQUNyQyxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsVUFBVSxFQUFFLENBQUMsQ0FBQTtRQUN2QyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsVUFBVSxFQUFFLENBQUMsQ0FBQTtRQUN4QyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBRWYsSUFBSSxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQ3RCLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQTtZQUNoQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ2xDLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxLQUFLLENBQUMsSUFBSSxLQUFLLEtBQUssQ0FBQyxLQUFLLE1BQU0sS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUE7Z0JBQ3JFLElBQUksS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDO29CQUNoQixPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsS0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUE7Z0JBQzFDLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQTtZQUVGLElBQUksTUFBTSxDQUFDLE1BQU0sR0FBRyxFQUFFLEVBQUUsQ0FBQztnQkFDdkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLE1BQU0sQ0FBQyxNQUFNLEdBQUcsRUFBRSxjQUFjLENBQUMsQ0FBQTtZQUM1RCxDQUFDO1lBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUNqQixDQUFDO1FBRUQscUJBQXFCO1FBQ3JCLE1BQU0sVUFBVSxHQUFHLElBQUksR0FBRyxFQUFrQixDQUFBO1FBQzVDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDcEIsTUFBTSxLQUFLLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFBO1lBQ2xELFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUE7UUFDNUMsQ0FBQyxDQUFDLENBQUE7UUFFRixPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixDQUFDLENBQUE7UUFDdkMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsRUFBRTtZQUNyQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssUUFBUSxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUE7UUFDakQsQ0FBQyxDQUFDLENBQUE7UUFDRixPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBRWYsa0JBQWtCO1FBQ2xCLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsQ0FBQTtRQUNsQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDaEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLE1BQU0sR0FBRyxDQUFDLE9BQU8sS0FBSyxHQUFHLENBQUMsS0FBSyxPQUFPLENBQUMsQ0FBQTtRQUNqRSxDQUFDLENBQUMsQ0FBQTtRQUNGLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUE7UUFFZixJQUFJLFVBQVUsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNyQixPQUFPLENBQUMsR0FBRyxDQUFDLHNDQUFzQyxDQUFDLENBQUE7UUFDckQsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLENBQUMsR0FBRyxDQUFDLHNDQUFzQyxDQUFDLENBQUE7WUFDbkQsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUNqQixDQUFDO0lBRUgsQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsT0FBTyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFBO1FBQ3hDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDakIsQ0FBQztBQUNILENBQUM7QUFFRCxVQUFVLEVBQUUsQ0FBQSJ9