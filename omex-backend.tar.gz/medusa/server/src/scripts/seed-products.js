"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = seedProducts;
const fs_1 = require("fs");
const sync_1 = require("csv-parse/sync");
async function seedProducts({ container }) {
    console.log('🚀 Seeding products from CSV...\n');
    const productModule = container.resolve('productModuleService');
    try {
        const fileContent = (0, fs_1.readFileSync)('./sample-products-120.csv', 'utf-8');
        const records = (0, sync_1.parse)(fileContent, {
            columns: true,
            skip_empty_lines: true,
            trim: true,
        });
        console.log(`📊 Found ${records.length} products to import\n`);
        let count = 0;
        for (const row of records) {
            try {
                // Parse technical specs
                let specs = {};
                if (row.technical_specs_json) {
                    try {
                        specs = JSON.parse(row.technical_specs_json);
                    }
                    catch (e) {
                        // Skip invalid JSON
                    }
                }
                // Create product
                const product = await productModule.createProducts({
                    title: row.name_pl,
                    handle: row.sku.toLowerCase(),
                    status: 'published',
                    description: row.desc_pl || '',
                    metadata: {
                        sku: row.sku,
                        name_en: row.name_en,
                        name_de: row.name_de,
                        desc_en: row.desc_en,
                        desc_de: row.desc_de,
                        category_id: row.category_id,
                        equipment_type: row.equipment_type,
                        min_order_qty: parseInt(row.min_order_qty) || 1,
                        cost: parseFloat(row.cost) || 0,
                        technical_specs: specs,
                    },
                });
                // Create variant
                await productModule.createProductVariants({
                    product_id: product.id,
                    title: 'Default',
                    sku: row.sku,
                    manage_inventory: false,
                    prices: [{
                            amount: Math.round(parseFloat(row.price) * 100),
                            currency_code: 'pln',
                        }],
                });
                count++;
                console.log(`✓ ${count}. ${row.sku} - ${row.name_pl}`);
            }
            catch (error) {
                console.log(`✗ ${row.sku} - ${error.message}`);
            }
        }
        console.log(`\n✅ Imported ${count}/${records.length} products`);
    }
    catch (error) {
        console.error('❌ Seed failed:', error.message);
        throw error;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VlZC1wcm9kdWN0cy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zY3JpcHRzL3NlZWQtcHJvZHVjdHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFHQSwrQkEyRUM7QUE5RUQsMkJBQWlDO0FBQ2pDLHlDQUFzQztBQUV2QixLQUFLLFVBQVUsWUFBWSxDQUFDLEVBQUUsU0FBUyxFQUFPO0lBQzNELE9BQU8sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLENBQUMsQ0FBQTtJQUVoRCxNQUFNLGFBQWEsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUE7SUFFL0QsSUFBSSxDQUFDO1FBQ0gsTUFBTSxXQUFXLEdBQUcsSUFBQSxpQkFBWSxFQUFDLDJCQUEyQixFQUFFLE9BQU8sQ0FBQyxDQUFBO1FBQ3RFLE1BQU0sT0FBTyxHQUFHLElBQUEsWUFBSyxFQUFDLFdBQVcsRUFBRTtZQUNqQyxPQUFPLEVBQUUsSUFBSTtZQUNiLGdCQUFnQixFQUFFLElBQUk7WUFDdEIsSUFBSSxFQUFFLElBQUk7U0FDWCxDQUFDLENBQUE7UUFFRixPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksT0FBTyxDQUFDLE1BQU0sdUJBQXVCLENBQUMsQ0FBQTtRQUU5RCxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUE7UUFFYixLQUFLLE1BQU0sR0FBRyxJQUFJLE9BQU8sRUFBRSxDQUFDO1lBQzFCLElBQUksQ0FBQztnQkFDSCx3QkFBd0I7Z0JBQ3hCLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQTtnQkFDZCxJQUFJLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO29CQUM3QixJQUFJLENBQUM7d0JBQ0gsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUE7b0JBQzlDLENBQUM7b0JBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQzt3QkFDWCxvQkFBb0I7b0JBQ3RCLENBQUM7Z0JBQ0gsQ0FBQztnQkFFRCxpQkFBaUI7Z0JBQ2pCLE1BQU0sT0FBTyxHQUFHLE1BQU0sYUFBYSxDQUFDLGNBQWMsQ0FBQztvQkFDakQsS0FBSyxFQUFFLEdBQUcsQ0FBQyxPQUFPO29CQUNsQixNQUFNLEVBQUUsR0FBRyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUU7b0JBQzdCLE1BQU0sRUFBRSxXQUFXO29CQUNuQixXQUFXLEVBQUUsR0FBRyxDQUFDLE9BQU8sSUFBSSxFQUFFO29CQUM5QixRQUFRLEVBQUU7d0JBQ1IsR0FBRyxFQUFFLEdBQUcsQ0FBQyxHQUFHO3dCQUNaLE9BQU8sRUFBRSxHQUFHLENBQUMsT0FBTzt3QkFDcEIsT0FBTyxFQUFFLEdBQUcsQ0FBQyxPQUFPO3dCQUNwQixPQUFPLEVBQUUsR0FBRyxDQUFDLE9BQU87d0JBQ3BCLE9BQU8sRUFBRSxHQUFHLENBQUMsT0FBTzt3QkFDcEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxXQUFXO3dCQUM1QixjQUFjLEVBQUUsR0FBRyxDQUFDLGNBQWM7d0JBQ2xDLGFBQWEsRUFBRSxRQUFRLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUM7d0JBQy9DLElBQUksRUFBRSxVQUFVLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7d0JBQy9CLGVBQWUsRUFBRSxLQUFLO3FCQUN2QjtpQkFDRixDQUFDLENBQUE7Z0JBRUYsaUJBQWlCO2dCQUNqQixNQUFNLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQztvQkFDeEMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxFQUFFO29CQUN0QixLQUFLLEVBQUUsU0FBUztvQkFDaEIsR0FBRyxFQUFFLEdBQUcsQ0FBQyxHQUFHO29CQUNaLGdCQUFnQixFQUFFLEtBQUs7b0JBQ3ZCLE1BQU0sRUFBRSxDQUFDOzRCQUNQLE1BQU0sRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxDQUFDOzRCQUMvQyxhQUFhLEVBQUUsS0FBSzt5QkFDckIsQ0FBQztpQkFDSCxDQUFDLENBQUE7Z0JBRUYsS0FBSyxFQUFFLENBQUE7Z0JBQ1AsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEtBQUssS0FBSyxHQUFHLENBQUMsR0FBRyxNQUFNLEdBQUcsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFBO1lBRXhELENBQUM7WUFBQyxPQUFPLEtBQVUsRUFBRSxDQUFDO2dCQUNwQixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsTUFBTSxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQTtZQUNoRCxDQUFDO1FBQ0gsQ0FBQztRQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLEtBQUssSUFBSSxPQUFPLENBQUMsTUFBTSxXQUFXLENBQUMsQ0FBQTtJQUVqRSxDQUFDO0lBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztRQUNwQixPQUFPLENBQUMsS0FBSyxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQTtRQUM5QyxNQUFNLEtBQUssQ0FBQTtJQUNiLENBQUM7QUFDSCxDQUFDIn0=