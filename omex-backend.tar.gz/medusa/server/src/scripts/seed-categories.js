"use strict";
/**
 * Script to seed categories into the database
 * Run with: npm run seed:categories
 */
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const categories_seed_1 = require("../seeds/categories-seed");
async function seedCategories(container) {
    const logger = container.resolve(utils_1.ContainerRegistrationKeys.LOGGER);
    const query = container.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    logger.info("🌱 Starting category seeding...");
    logger.info(`📊 Stats: ${categories_seed_1.CATEGORY_STATS.mainCategories} main categories, ${categories_seed_1.CATEGORY_STATS.totalCategories} total`);
    try {
        // Flatten the hierarchical structure
        const flatCategories = (0, categories_seed_1.flattenCategories)(categories_seed_1.CATEGORIES_SEED);
        logger.info(`📦 Flattened ${flatCategories.length} categories`);
        // Create a map to store created category IDs
        const categoryIdMap = new Map();
        // First pass: Create all categories without parent relationships
        for (const category of flatCategories) {
            const { parent_id, ...categoryData } = category;
            // Check if category already exists
            const existing = await query.graph({
                entity: "product_category",
                fields: ["id", "handle"],
                filters: { handle: categoryData.slug },
            });
            if (existing && existing.data && existing.data.length > 0) {
                logger.info(`⏭️  Category "${categoryData.name}" already exists, skipping...`);
                categoryIdMap.set(categoryData.slug, existing.data[0].id);
                continue;
            }
            // Create category
            const result = await query.graph({
                entity: "product_category",
                fields: ["id", "name", "handle"],
                data: {
                    name: categoryData.name,
                    handle: categoryData.slug,
                    description: categoryData.description || "",
                    is_active: true,
                    is_internal: false,
                    metadata: {
                        icon: categoryData.icon || null,
                    },
                },
            }, "create");
            if (result && result.data) {
                const createdId = Array.isArray(result.data) ? result.data[0].id : result.data.id;
                categoryIdMap.set(categoryData.slug, createdId);
                logger.info(`✅ Created category: ${categoryData.name} (${createdId})`);
            }
        }
        // Second pass: Update parent relationships
        logger.info("🔗 Setting up parent relationships...");
        for (const category of flatCategories) {
            if (category.parent_id) {
                const categoryId = categoryIdMap.get(category.slug);
                const parentId = categoryIdMap.get(category.parent_id);
                if (categoryId && parentId) {
                    await query.graph({
                        entity: "product_category",
                        fields: ["id"],
                        filters: { id: categoryId },
                        data: {
                            parent_category_id: parentId,
                        },
                    }, "update");
                    logger.info(`🔗 Linked "${category.name}" to parent`);
                }
            }
        }
        logger.info("✅ Category seeding completed successfully!");
        logger.info(`📊 Created ${categoryIdMap.size} categories`);
    }
    catch (error) {
        logger.error("❌ Error seeding categories:", error);
        throw error;
    }
}
exports.default = seedCategories;
// If running directly
if (require.main === module) {
    const { medusaIntegrationTestRunner } = require("@medusajs/test-utils");
    medusaIntegrationTestRunner({
        testSuite: async ({ getContainer }) => {
            const container = getContainer();
            await seedCategories(container);
        },
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VlZC1jYXRlZ29yaWVzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3NjcmlwdHMvc2VlZC1jYXRlZ29yaWVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7O0dBR0c7O0FBR0gscURBQXFFO0FBQ3JFLDhEQUE2RjtBQUU3RixLQUFLLFVBQVUsY0FBYyxDQUFDLFNBQTBCO0lBQ3RELE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsTUFBTSxDQUFDLENBQUE7SUFDbEUsTUFBTSxLQUFLLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxpQ0FBeUIsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUVoRSxNQUFNLENBQUMsSUFBSSxDQUFDLGlDQUFpQyxDQUFDLENBQUE7SUFDOUMsTUFBTSxDQUFDLElBQUksQ0FBQyxhQUFhLGdDQUFjLENBQUMsY0FBYyxxQkFBcUIsZ0NBQWMsQ0FBQyxlQUFlLFFBQVEsQ0FBQyxDQUFBO0lBRWxILElBQUksQ0FBQztRQUNILHFDQUFxQztRQUNyQyxNQUFNLGNBQWMsR0FBRyxJQUFBLG1DQUFpQixFQUFDLGlDQUFlLENBQUMsQ0FBQTtRQUV6RCxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixjQUFjLENBQUMsTUFBTSxhQUFhLENBQUMsQ0FBQTtRQUUvRCw2Q0FBNkM7UUFDN0MsTUFBTSxhQUFhLEdBQUcsSUFBSSxHQUFHLEVBQWtCLENBQUE7UUFFL0MsaUVBQWlFO1FBQ2pFLEtBQUssTUFBTSxRQUFRLElBQUksY0FBYyxFQUFFLENBQUM7WUFDdEMsTUFBTSxFQUFFLFNBQVMsRUFBRSxHQUFHLFlBQVksRUFBRSxHQUFHLFFBQVEsQ0FBQTtZQUUvQyxtQ0FBbUM7WUFDbkMsTUFBTSxRQUFRLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO2dCQUNqQyxNQUFNLEVBQUUsa0JBQWtCO2dCQUMxQixNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDO2dCQUN4QixPQUFPLEVBQUUsRUFBRSxNQUFNLEVBQUUsWUFBWSxDQUFDLElBQUksRUFBRTthQUN2QyxDQUFDLENBQUE7WUFFRixJQUFJLFFBQVEsSUFBSSxRQUFRLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO2dCQUMxRCxNQUFNLENBQUMsSUFBSSxDQUFDLGlCQUFpQixZQUFZLENBQUMsSUFBSSwrQkFBK0IsQ0FBQyxDQUFBO2dCQUM5RSxhQUFhLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQTtnQkFDekQsU0FBUTtZQUNWLENBQUM7WUFFRCxrQkFBa0I7WUFDbEIsTUFBTSxNQUFNLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO2dCQUMvQixNQUFNLEVBQUUsa0JBQWtCO2dCQUMxQixNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFFBQVEsQ0FBQztnQkFDaEMsSUFBSSxFQUFFO29CQUNKLElBQUksRUFBRSxZQUFZLENBQUMsSUFBSTtvQkFDdkIsTUFBTSxFQUFFLFlBQVksQ0FBQyxJQUFJO29CQUN6QixXQUFXLEVBQUUsWUFBWSxDQUFDLFdBQVcsSUFBSSxFQUFFO29CQUMzQyxTQUFTLEVBQUUsSUFBSTtvQkFDZixXQUFXLEVBQUUsS0FBSztvQkFDbEIsUUFBUSxFQUFFO3dCQUNSLElBQUksRUFBRSxZQUFZLENBQUMsSUFBSSxJQUFJLElBQUk7cUJBQ2hDO2lCQUNGO2FBQ0YsRUFBRSxRQUFRLENBQUMsQ0FBQTtZQUVaLElBQUksTUFBTSxJQUFJLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDMUIsTUFBTSxTQUFTLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQTtnQkFDakYsYUFBYSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQyxDQUFBO2dCQUMvQyxNQUFNLENBQUMsSUFBSSxDQUFDLHVCQUF1QixZQUFZLENBQUMsSUFBSSxLQUFLLFNBQVMsR0FBRyxDQUFDLENBQUE7WUFDeEUsQ0FBQztRQUNILENBQUM7UUFFRCwyQ0FBMkM7UUFDM0MsTUFBTSxDQUFDLElBQUksQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFBO1FBRXBELEtBQUssTUFBTSxRQUFRLElBQUksY0FBYyxFQUFFLENBQUM7WUFDdEMsSUFBSSxRQUFRLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQ3ZCLE1BQU0sVUFBVSxHQUFHLGFBQWEsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFBO2dCQUNuRCxNQUFNLFFBQVEsR0FBRyxhQUFhLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQTtnQkFFdEQsSUFBSSxVQUFVLElBQUksUUFBUSxFQUFFLENBQUM7b0JBQzNCLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQzt3QkFDaEIsTUFBTSxFQUFFLGtCQUFrQjt3QkFDMUIsTUFBTSxFQUFFLENBQUMsSUFBSSxDQUFDO3dCQUNkLE9BQU8sRUFBRSxFQUFFLEVBQUUsRUFBRSxVQUFVLEVBQUU7d0JBQzNCLElBQUksRUFBRTs0QkFDSixrQkFBa0IsRUFBRSxRQUFRO3lCQUM3QjtxQkFDRixFQUFFLFFBQVEsQ0FBQyxDQUFBO29CQUVaLE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxRQUFRLENBQUMsSUFBSSxhQUFhLENBQUMsQ0FBQTtnQkFDdkQsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO1FBRUQsTUFBTSxDQUFDLElBQUksQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFBO1FBQ3pELE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxhQUFhLENBQUMsSUFBSSxhQUFhLENBQUMsQ0FBQTtJQUU1RCxDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE1BQU0sQ0FBQyxLQUFLLENBQUMsNkJBQTZCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDbEQsTUFBTSxLQUFLLENBQUE7SUFDYixDQUFDO0FBQ0gsQ0FBQztBQUVELGtCQUFlLGNBQWMsQ0FBQTtBQUU3QixzQkFBc0I7QUFDdEIsSUFBSSxPQUFPLENBQUMsSUFBSSxLQUFLLE1BQU0sRUFBRSxDQUFDO0lBQzVCLE1BQU0sRUFBRSwyQkFBMkIsRUFBRSxHQUFHLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFBO0lBRXZFLDJCQUEyQixDQUFDO1FBQzFCLFNBQVMsRUFBRSxLQUFLLEVBQUUsRUFBRSxZQUFZLEVBQUUsRUFBRSxFQUFFO1lBQ3BDLE1BQU0sU0FBUyxHQUFHLFlBQVksRUFBRSxDQUFBO1lBQ2hDLE1BQU0sY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFBO1FBQ2pDLENBQUM7S0FDRixDQUFDLENBQUE7QUFDSixDQUFDIn0=