"use strict";
/**
 * Seed manufacturers data
 * Usage: npx ts-node src/scripts/seed-manufacturers.ts
 */
Object.defineProperty(exports, "__esModule", { value: true });
const manufacturers = [
    {
        name: "Rexroth",
        slug: "rexroth",
        website_url: "https://www.boschrexroth.com",
        country: "Germany",
        description: "Bosch Rexroth - światowy lider w dziedzinie hydrauliki przemysłowej",
        catalog_pdf_url: "https://example.com/catalogs/rexroth-2024.pdf",
        is_active: true,
    },
    {
        name: "Parker Hannifin",
        slug: "parker",
        website_url: "https://www.parker.com",
        country: "USA",
        description: "Parker Hannifin - producent systemów hydraulicznych i pneumatycznych",
        catalog_pdf_url: "https://example.com/catalogs/parker-2024.pdf",
        is_active: true,
    },
    {
        name: "Hydac",
        slug: "hydac",
        website_url: "https://www.hydac.com",
        country: "Germany",
        description: "Hydac - specjalista w dziedzinie hydrauliki, filtracji i chłodzenia",
        catalog_pdf_url: "https://example.com/catalogs/hydac-2024.pdf",
        is_active: true,
    },
    {
        name: "Eaton",
        slug: "eaton",
        website_url: "https://www.eaton.com",
        country: "Ireland",
        description: "Eaton - rozwiązania hydrauliczne dla przemysłu",
        is_active: true,
    },
    {
        name: "Danfoss",
        slug: "danfoss",
        website_url: "https://www.danfoss.com",
        country: "Denmark",
        description: "Danfoss - innowacyjne rozwiązania hydrauliczne",
        is_active: true,
    },
    {
        name: "Bucher Hydraulics",
        slug: "bucher",
        website_url: "https://www.bucherhydraulics.com",
        country: "Switzerland",
        description: "Bucher Hydraulics - systemy hydrauliczne dla maszyn mobilnych",
        is_active: true,
    },
    {
        name: "Hawe Hydraulik",
        slug: "hawe",
        website_url: "https://www.hawe.com",
        country: "Germany",
        description: "Hawe - kompaktowe systemy hydrauliczne",
        is_active: true,
    },
    {
        name: "Atos",
        slug: "atos",
        website_url: "https://www.atos.com",
        country: "Italy",
        description: "Atos - zawory i elektronika hydrauliczna",
        is_active: true,
    },
    {
        name: "Moog",
        slug: "moog",
        website_url: "https://www.moog.com",
        country: "USA",
        description: "Moog - precyzyjne systemy sterowania hydraulicznego",
        is_active: true,
    },
    {
        name: "Yuken",
        slug: "yuken",
        website_url: "https://www.yuken.co.jp",
        country: "Japan",
        description: "Yuken - pompy i zawory hydrauliczne",
        is_active: true,
    },
];
async function seedManufacturers() {
    console.log("🌱 Seeding manufacturers...");
    try {
        // In real implementation, use ManufacturerService
        for (const mfr of manufacturers) {
            console.log(`  ✓ Creating ${mfr.name}...`);
            // await manufacturerService.createManufacturer(mfr)
        }
        console.log(`\n✅ Successfully seeded ${manufacturers.length} manufacturers`);
    }
    catch (error) {
        console.error("❌ Seeding failed:", error);
        process.exit(1);
    }
}
seedManufacturers();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VlZC1tYW51ZmFjdHVyZXJzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3NjcmlwdHMvc2VlZC1tYW51ZmFjdHVyZXJzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7O0dBR0c7O0FBRUgsTUFBTSxhQUFhLEdBQUc7SUFDcEI7UUFDRSxJQUFJLEVBQUUsU0FBUztRQUNmLElBQUksRUFBRSxTQUFTO1FBQ2YsV0FBVyxFQUFFLDhCQUE4QjtRQUMzQyxPQUFPLEVBQUUsU0FBUztRQUNsQixXQUFXLEVBQUUscUVBQXFFO1FBQ2xGLGVBQWUsRUFBRSwrQ0FBK0M7UUFDaEUsU0FBUyxFQUFFLElBQUk7S0FDaEI7SUFDRDtRQUNFLElBQUksRUFBRSxpQkFBaUI7UUFDdkIsSUFBSSxFQUFFLFFBQVE7UUFDZCxXQUFXLEVBQUUsd0JBQXdCO1FBQ3JDLE9BQU8sRUFBRSxLQUFLO1FBQ2QsV0FBVyxFQUFFLHNFQUFzRTtRQUNuRixlQUFlLEVBQUUsOENBQThDO1FBQy9ELFNBQVMsRUFBRSxJQUFJO0tBQ2hCO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsT0FBTztRQUNiLElBQUksRUFBRSxPQUFPO1FBQ2IsV0FBVyxFQUFFLHVCQUF1QjtRQUNwQyxPQUFPLEVBQUUsU0FBUztRQUNsQixXQUFXLEVBQUUscUVBQXFFO1FBQ2xGLGVBQWUsRUFBRSw2Q0FBNkM7UUFDOUQsU0FBUyxFQUFFLElBQUk7S0FDaEI7SUFDRDtRQUNFLElBQUksRUFBRSxPQUFPO1FBQ2IsSUFBSSxFQUFFLE9BQU87UUFDYixXQUFXLEVBQUUsdUJBQXVCO1FBQ3BDLE9BQU8sRUFBRSxTQUFTO1FBQ2xCLFdBQVcsRUFBRSxnREFBZ0Q7UUFDN0QsU0FBUyxFQUFFLElBQUk7S0FDaEI7SUFDRDtRQUNFLElBQUksRUFBRSxTQUFTO1FBQ2YsSUFBSSxFQUFFLFNBQVM7UUFDZixXQUFXLEVBQUUseUJBQXlCO1FBQ3RDLE9BQU8sRUFBRSxTQUFTO1FBQ2xCLFdBQVcsRUFBRSxnREFBZ0Q7UUFDN0QsU0FBUyxFQUFFLElBQUk7S0FDaEI7SUFDRDtRQUNFLElBQUksRUFBRSxtQkFBbUI7UUFDekIsSUFBSSxFQUFFLFFBQVE7UUFDZCxXQUFXLEVBQUUsa0NBQWtDO1FBQy9DLE9BQU8sRUFBRSxhQUFhO1FBQ3RCLFdBQVcsRUFBRSwrREFBK0Q7UUFDNUUsU0FBUyxFQUFFLElBQUk7S0FDaEI7SUFDRDtRQUNFLElBQUksRUFBRSxnQkFBZ0I7UUFDdEIsSUFBSSxFQUFFLE1BQU07UUFDWixXQUFXLEVBQUUsc0JBQXNCO1FBQ25DLE9BQU8sRUFBRSxTQUFTO1FBQ2xCLFdBQVcsRUFBRSx3Q0FBd0M7UUFDckQsU0FBUyxFQUFFLElBQUk7S0FDaEI7SUFDRDtRQUNFLElBQUksRUFBRSxNQUFNO1FBQ1osSUFBSSxFQUFFLE1BQU07UUFDWixXQUFXLEVBQUUsc0JBQXNCO1FBQ25DLE9BQU8sRUFBRSxPQUFPO1FBQ2hCLFdBQVcsRUFBRSwwQ0FBMEM7UUFDdkQsU0FBUyxFQUFFLElBQUk7S0FDaEI7SUFDRDtRQUNFLElBQUksRUFBRSxNQUFNO1FBQ1osSUFBSSxFQUFFLE1BQU07UUFDWixXQUFXLEVBQUUsc0JBQXNCO1FBQ25DLE9BQU8sRUFBRSxLQUFLO1FBQ2QsV0FBVyxFQUFFLHFEQUFxRDtRQUNsRSxTQUFTLEVBQUUsSUFBSTtLQUNoQjtJQUNEO1FBQ0UsSUFBSSxFQUFFLE9BQU87UUFDYixJQUFJLEVBQUUsT0FBTztRQUNiLFdBQVcsRUFBRSx5QkFBeUI7UUFDdEMsT0FBTyxFQUFFLE9BQU87UUFDaEIsV0FBVyxFQUFFLHFDQUFxQztRQUNsRCxTQUFTLEVBQUUsSUFBSTtLQUNoQjtDQUNGLENBQUE7QUFFRCxLQUFLLFVBQVUsaUJBQWlCO0lBQzlCLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLENBQUMsQ0FBQTtJQUUxQyxJQUFJLENBQUM7UUFDSCxrREFBa0Q7UUFDbEQsS0FBSyxNQUFNLEdBQUcsSUFBSSxhQUFhLEVBQUUsQ0FBQztZQUNoQyxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixHQUFHLENBQUMsSUFBSSxLQUFLLENBQUMsQ0FBQTtZQUMxQyxvREFBb0Q7UUFDdEQsQ0FBQztRQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLGFBQWEsQ0FBQyxNQUFNLGdCQUFnQixDQUFDLENBQUE7SUFDOUUsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQ3pDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDakIsQ0FBQztBQUNILENBQUM7QUFFRCxpQkFBaUIsRUFBRSxDQUFBIn0=