"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = require("fs");
const sync_1 = require("csv-parse/sync");
/**
 * Direct import script - imports products directly to console
 * This simulates the import process without requiring a running server
 */
const CSV_FILE = './sample-products-120.csv';
async function directImport() {
    console.log('🚀 Starting Direct Product Import...\n');
    try {
        // Read CSV file
        const fileContent = (0, fs_1.readFileSync)(CSV_FILE, 'utf-8');
        // Parse CSV
        const records = (0, sync_1.parse)(fileContent, {
            columns: true,
            skip_empty_lines: true,
            trim: true,
        });
        console.log(`📊 Total products to import: ${records.length}\n`);
        let successCount = 0;
        let errorCount = 0;
        const errors = [];
        // Process each product
        for (let i = 0; i < records.length; i++) {
            const row = records[i];
            const lineNumber = i + 2; // +1 for header, +1 for 0-index
            try {
                // Validate SKU
                if (!row.sku || !/^[A-Z]{3}-\d{3}$/.test(row.sku)) {
                    throw new Error(`Invalid SKU format: ${row.sku}`);
                }
                // Validate required fields
                if (!row.name_pl || !row.price || !row.category_id) {
                    throw new Error('Missing required fields');
                }
                // Validate price
                const price = parseFloat(row.price);
                if (isNaN(price) || price < 0) {
                    throw new Error(`Invalid price: ${row.price}`);
                }
                // Parse technical specs
                let technicalSpecs = {};
                if (row.technical_specs_json && row.technical_specs_json.trim() !== '') {
                    try {
                        technicalSpecs = JSON.parse(row.technical_specs_json);
                    }
                    catch {
                        throw new Error('Invalid JSON in technical specs');
                    }
                }
                // Create product object
                const product = {
                    sku: row.sku,
                    title: row.name_pl,
                    price: price,
                    cost: row.cost ? parseFloat(row.cost) : 0,
                    category_id: row.category_id,
                    equipment_type: row.equipment_type || '',
                    min_order_qty: row.min_order_qty ? parseInt(row.min_order_qty) : 1,
                    technical_specs: technicalSpecs,
                    translations: {
                        pl: {
                            title: row.name_pl,
                            description: row.desc_pl || '',
                        },
                        en: {
                            title: row.name_en || row.name_pl,
                            description: row.desc_en || row.desc_pl || '',
                        },
                        de: {
                            title: row.name_de || row.name_pl,
                            description: row.desc_de || row.desc_pl || '',
                        },
                    },
                };
                // Simulate product creation
                console.log(`✓ [${successCount + 1}/${records.length}] ${product.sku} - ${product.title} (${product.price} PLN)`);
                successCount++;
                // Show progress every 20 products
                if ((successCount) % 20 === 0) {
                    console.log(`\n📈 Progress: ${successCount}/${records.length} (${Math.round((successCount / records.length) * 100)}%)\n`);
                }
            }
            catch (error) {
                errorCount++;
                errors.push({
                    line: lineNumber,
                    sku: row.sku,
                    error: error.message,
                });
                console.log(`✗ [Line ${lineNumber}] ${row.sku} - ERROR: ${error.message}`);
            }
        }
        // Final summary
        console.log('\n' + '='.repeat(60));
        console.log('📊 IMPORT SUMMARY');
        console.log('='.repeat(60));
        console.log(`✅ Successful: ${successCount}`);
        console.log(`❌ Failed: ${errorCount}`);
        console.log(`📦 Total: ${records.length}`);
        console.log(`⏱️  Success Rate: ${((successCount / records.length) * 100).toFixed(2)}%`);
        console.log('='.repeat(60));
        if (errors.length > 0) {
            console.log('\n⚠️  Errors:');
            errors.forEach(err => {
                console.log(`  Line ${err.line}: ${err.sku} - ${err.error}`);
            });
        }
        // Category breakdown
        const categories = new Map();
        records.forEach(row => {
            const count = categories.get(row.category_id) || 0;
            categories.set(row.category_id, count + 1);
        });
        console.log('\n📦 Products by Category:');
        categories.forEach((count, category) => {
            console.log(`  ${category}: ${count} products`);
        });
        console.log('\n✅ Import simulation completed!');
        console.log('\n💡 Note: This is a simulation. To actually import to database:');
        console.log('   1. Start Medusa: npm run dev');
        console.log('   2. Use API: curl -X POST http://localhost:9000/admin/products/import -F "file=@sample-products-120.csv"');
    }
    catch (error) {
        console.error('❌ Import failed:', error.message);
        process.exit(1);
    }
}
directImport();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGlyZWN0LWltcG9ydC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zY3JpcHRzL2RpcmVjdC1pbXBvcnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSwyQkFBaUM7QUFDakMseUNBQXNDO0FBRXRDOzs7R0FHRztBQUVILE1BQU0sUUFBUSxHQUFHLDJCQUEyQixDQUFBO0FBa0I1QyxLQUFLLFVBQVUsWUFBWTtJQUN6QixPQUFPLENBQUMsR0FBRyxDQUFDLHdDQUF3QyxDQUFDLENBQUE7SUFFckQsSUFBSSxDQUFDO1FBQ0gsZ0JBQWdCO1FBQ2hCLE1BQU0sV0FBVyxHQUFHLElBQUEsaUJBQVksRUFBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUE7UUFFbkQsWUFBWTtRQUNaLE1BQU0sT0FBTyxHQUFHLElBQUEsWUFBSyxFQUFDLFdBQVcsRUFBRTtZQUNqQyxPQUFPLEVBQUUsSUFBSTtZQUNiLGdCQUFnQixFQUFFLElBQUk7WUFDdEIsSUFBSSxFQUFFLElBQUk7U0FDWCxDQUFpQixDQUFBO1FBRWxCLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLE9BQU8sQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFBO1FBRS9ELElBQUksWUFBWSxHQUFHLENBQUMsQ0FBQTtRQUNwQixJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUE7UUFDbEIsTUFBTSxNQUFNLEdBQVUsRUFBRSxDQUFBO1FBRXhCLHVCQUF1QjtRQUN2QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQ3hDLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUN0QixNQUFNLFVBQVUsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFBLENBQUMsZ0NBQWdDO1lBRXpELElBQUksQ0FBQztnQkFDSCxlQUFlO2dCQUNmLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO29CQUNsRCxNQUFNLElBQUksS0FBSyxDQUFDLHVCQUF1QixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQTtnQkFDbkQsQ0FBQztnQkFFRCwyQkFBMkI7Z0JBQzNCLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQztvQkFDbkQsTUFBTSxJQUFJLEtBQUssQ0FBQyx5QkFBeUIsQ0FBQyxDQUFBO2dCQUM1QyxDQUFDO2dCQUVELGlCQUFpQjtnQkFDakIsTUFBTSxLQUFLLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQTtnQkFDbkMsSUFBSSxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxHQUFHLENBQUMsRUFBRSxDQUFDO29CQUM5QixNQUFNLElBQUksS0FBSyxDQUFDLGtCQUFrQixHQUFHLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQTtnQkFDaEQsQ0FBQztnQkFFRCx3QkFBd0I7Z0JBQ3hCLElBQUksY0FBYyxHQUFHLEVBQUUsQ0FBQTtnQkFDdkIsSUFBSSxHQUFHLENBQUMsb0JBQW9CLElBQUksR0FBRyxDQUFDLG9CQUFvQixDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRSxDQUFDO29CQUN2RSxJQUFJLENBQUM7d0JBQ0gsY0FBYyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUE7b0JBQ3ZELENBQUM7b0JBQUMsTUFBTSxDQUFDO3dCQUNQLE1BQU0sSUFBSSxLQUFLLENBQUMsaUNBQWlDLENBQUMsQ0FBQTtvQkFDcEQsQ0FBQztnQkFDSCxDQUFDO2dCQUVELHdCQUF3QjtnQkFDeEIsTUFBTSxPQUFPLEdBQUc7b0JBQ2QsR0FBRyxFQUFFLEdBQUcsQ0FBQyxHQUFHO29CQUNaLEtBQUssRUFBRSxHQUFHLENBQUMsT0FBTztvQkFDbEIsS0FBSyxFQUFFLEtBQUs7b0JBQ1osSUFBSSxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3pDLFdBQVcsRUFBRSxHQUFHLENBQUMsV0FBVztvQkFDNUIsY0FBYyxFQUFFLEdBQUcsQ0FBQyxjQUFjLElBQUksRUFBRTtvQkFDeEMsYUFBYSxFQUFFLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ2xFLGVBQWUsRUFBRSxjQUFjO29CQUMvQixZQUFZLEVBQUU7d0JBQ1osRUFBRSxFQUFFOzRCQUNGLEtBQUssRUFBRSxHQUFHLENBQUMsT0FBTzs0QkFDbEIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxPQUFPLElBQUksRUFBRTt5QkFDL0I7d0JBQ0QsRUFBRSxFQUFFOzRCQUNGLEtBQUssRUFBRSxHQUFHLENBQUMsT0FBTyxJQUFJLEdBQUcsQ0FBQyxPQUFPOzRCQUNqQyxXQUFXLEVBQUUsR0FBRyxDQUFDLE9BQU8sSUFBSSxHQUFHLENBQUMsT0FBTyxJQUFJLEVBQUU7eUJBQzlDO3dCQUNELEVBQUUsRUFBRTs0QkFDRixLQUFLLEVBQUUsR0FBRyxDQUFDLE9BQU8sSUFBSSxHQUFHLENBQUMsT0FBTzs0QkFDakMsV0FBVyxFQUFFLEdBQUcsQ0FBQyxPQUFPLElBQUksR0FBRyxDQUFDLE9BQU8sSUFBSSxFQUFFO3lCQUM5QztxQkFDRjtpQkFDRixDQUFBO2dCQUVELDRCQUE0QjtnQkFDNUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLFlBQVksR0FBRyxDQUFDLElBQUksT0FBTyxDQUFDLE1BQU0sS0FBSyxPQUFPLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxLQUFLLEtBQUssT0FBTyxDQUFDLEtBQUssT0FBTyxDQUFDLENBQUE7Z0JBRWpILFlBQVksRUFBRSxDQUFBO2dCQUVkLGtDQUFrQztnQkFDbEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLEVBQUUsQ0FBQztvQkFDOUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsWUFBWSxJQUFJLE9BQU8sQ0FBQyxNQUFNLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLFlBQVksR0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFBO2dCQUN2SCxDQUFDO1lBRUgsQ0FBQztZQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7Z0JBQ3BCLFVBQVUsRUFBRSxDQUFBO2dCQUNaLE1BQU0sQ0FBQyxJQUFJLENBQUM7b0JBQ1YsSUFBSSxFQUFFLFVBQVU7b0JBQ2hCLEdBQUcsRUFBRSxHQUFHLENBQUMsR0FBRztvQkFDWixLQUFLLEVBQUUsS0FBSyxDQUFDLE9BQU87aUJBQ3JCLENBQUMsQ0FBQTtnQkFDRixPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsVUFBVSxLQUFLLEdBQUcsQ0FBQyxHQUFHLGFBQWEsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUE7WUFDNUUsQ0FBQztRQUNILENBQUM7UUFFRCxnQkFBZ0I7UUFDaEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFBO1FBQ2xDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQTtRQUNoQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQTtRQUMzQixPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixZQUFZLEVBQUUsQ0FBQyxDQUFBO1FBQzVDLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxVQUFVLEVBQUUsQ0FBQyxDQUFBO1FBQ3RDLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQTtRQUMxQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLENBQUMsWUFBWSxHQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFBO1FBQ25GLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFBO1FBRTNCLElBQUksTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUN0QixPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFBO1lBQzVCLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ25CLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxHQUFHLENBQUMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxHQUFHLE1BQU0sR0FBRyxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUE7WUFDOUQsQ0FBQyxDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQscUJBQXFCO1FBQ3JCLE1BQU0sVUFBVSxHQUFHLElBQUksR0FBRyxFQUFrQixDQUFBO1FBQzVDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDcEIsTUFBTSxLQUFLLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFBO1lBQ2xELFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUE7UUFDNUMsQ0FBQyxDQUFDLENBQUE7UUFFRixPQUFPLENBQUMsR0FBRyxDQUFDLDRCQUE0QixDQUFDLENBQUE7UUFDekMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsRUFBRTtZQUNyQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssUUFBUSxLQUFLLEtBQUssV0FBVyxDQUFDLENBQUE7UUFDakQsQ0FBQyxDQUFDLENBQUE7UUFFRixPQUFPLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxDQUFDLENBQUE7UUFDL0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrRUFBa0UsQ0FBQyxDQUFBO1FBQy9FLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLENBQUMsQ0FBQTtRQUM5QyxPQUFPLENBQUMsR0FBRyxDQUFDLDRHQUE0RyxDQUFDLENBQUE7SUFFM0gsQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsT0FBTyxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUE7UUFDaEQsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUNqQixDQUFDO0FBQ0gsQ0FBQztBQUVELFlBQVksRUFBRSxDQUFBIn0=