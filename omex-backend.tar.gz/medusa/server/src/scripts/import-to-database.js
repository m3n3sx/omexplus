"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = importToDatabase;
const fs_1 = require("fs");
const sync_1 = require("csv-parse/sync");
/**
 * Import products directly to database using Medusa services
 */
const CSV_FILE = './sample-products-120.csv';
async function importToDatabase({ container }) {
    console.log('🚀 Starting Database Import...\n');
    const productModuleService = container.resolve('productModuleService');
    try {
        // Read and parse CSV
        const fileContent = (0, fs_1.readFileSync)(CSV_FILE, 'utf-8');
        const records = (0, sync_1.parse)(fileContent, {
            columns: true,
            skip_empty_lines: true,
            trim: true,
        });
        console.log(`📊 Total products to import: ${records.length}\n`);
        let successCount = 0;
        let errorCount = 0;
        const errors = [];
        // Process each product
        for (let i = 0; i < records.length; i++) {
            const row = records[i];
            const lineNumber = i + 2;
            try {
                // Parse technical specs
                let technicalSpecs = {};
                if (row.technical_specs_json && row.technical_specs_json.trim() !== '') {
                    try {
                        technicalSpecs = JSON.parse(row.technical_specs_json);
                    }
                    catch (e) {
                        console.log(`⚠️  Invalid JSON for ${row.sku}, using empty object`);
                    }
                }
                // Create product using Medusa service
                const product = await productModuleService.createProducts({
                    title: row.name_pl,
                    handle: row.sku.toLowerCase(),
                    status: 'published',
                    metadata: {
                        sku: row.sku,
                        name_pl: row.name_pl,
                        name_en: row.name_en || row.name_pl,
                        name_de: row.name_de || row.name_pl,
                        desc_pl: row.desc_pl || '',
                        desc_en: row.desc_en || row.desc_pl || '',
                        desc_de: row.desc_de || row.desc_pl || '',
                        cost: row.cost ? parseFloat(row.cost) : 0,
                        category_id: row.category_id,
                        equipment_type: row.equipment_type || '',
                        min_order_qty: row.min_order_qty ? parseInt(row.min_order_qty) : 1,
                        technical_specs: technicalSpecs,
                    },
                });
                // Create variant with price
                await productModuleService.createProductVariants({
                    product_id: product.id,
                    title: 'Default',
                    sku: row.sku,
                    manage_inventory: false,
                    prices: [
                        {
                            amount: Math.round(parseFloat(row.price) * 100), // Convert to cents
                            currency_code: 'pln',
                        },
                    ],
                });
                successCount++;
                console.log(`✓ [${successCount}/${records.length}] ${row.sku} - ${row.name_pl}`);
                // Progress every 20 products
                if (successCount % 20 === 0) {
                    console.log(`\n📈 Progress: ${successCount}/${records.length} (${Math.round((successCount / records.length) * 100)}%)\n`);
                }
            }
            catch (error) {
                errorCount++;
                errors.push({
                    line: lineNumber,
                    sku: row.sku,
                    error: error.message,
                });
                console.log(`✗ [Line ${lineNumber}] ${row.sku} - ERROR: ${error.message}`);
            }
        }
        // Summary
        console.log('\n' + '='.repeat(60));
        console.log('📊 IMPORT SUMMARY');
        console.log('='.repeat(60));
        console.log(`✅ Successful: ${successCount}`);
        console.log(`❌ Failed: ${errorCount}`);
        console.log(`📦 Total: ${records.length}`);
        console.log(`⏱️  Success Rate: ${((successCount / records.length) * 100).toFixed(2)}%`);
        console.log('='.repeat(60));
        if (errors.length > 0) {
            console.log('\n⚠️  Errors:');
            errors.forEach(err => {
                console.log(`  Line ${err.line}: ${err.sku} - ${err.error}`);
            });
        }
        console.log('\n✅ Import completed!');
    }
    catch (error) {
        console.error('❌ Import failed:', error.message);
        throw error;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW1wb3J0LXRvLWRhdGFiYXNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3NjcmlwdHMvaW1wb3J0LXRvLWRhdGFiYXNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBeUJBLG1DQWlIQztBQTFJRCwyQkFBaUM7QUFDakMseUNBQXNDO0FBRXRDOztHQUVHO0FBRUgsTUFBTSxRQUFRLEdBQUcsMkJBQTJCLENBQUE7QUFrQjdCLEtBQUssVUFBVSxnQkFBZ0IsQ0FBQyxFQUFFLFNBQVMsRUFBTztJQUMvRCxPQUFPLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxDQUFDLENBQUE7SUFFL0MsTUFBTSxvQkFBb0IsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLHNCQUFzQixDQUFDLENBQUE7SUFFdEUsSUFBSSxDQUFDO1FBQ0gscUJBQXFCO1FBQ3JCLE1BQU0sV0FBVyxHQUFHLElBQUEsaUJBQVksRUFBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUE7UUFDbkQsTUFBTSxPQUFPLEdBQUcsSUFBQSxZQUFLLEVBQUMsV0FBVyxFQUFFO1lBQ2pDLE9BQU8sRUFBRSxJQUFJO1lBQ2IsZ0JBQWdCLEVBQUUsSUFBSTtZQUN0QixJQUFJLEVBQUUsSUFBSTtTQUNYLENBQWlCLENBQUE7UUFFbEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0MsT0FBTyxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUE7UUFFL0QsSUFBSSxZQUFZLEdBQUcsQ0FBQyxDQUFBO1FBQ3BCLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQTtRQUNsQixNQUFNLE1BQU0sR0FBVSxFQUFFLENBQUE7UUFFeEIsdUJBQXVCO1FBQ3ZCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDeEMsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFBO1lBQ3RCLE1BQU0sVUFBVSxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUE7WUFFeEIsSUFBSSxDQUFDO2dCQUNILHdCQUF3QjtnQkFDeEIsSUFBSSxjQUFjLEdBQUcsRUFBRSxDQUFBO2dCQUN2QixJQUFJLEdBQUcsQ0FBQyxvQkFBb0IsSUFBSSxHQUFHLENBQUMsb0JBQW9CLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFLENBQUM7b0JBQ3ZFLElBQUksQ0FBQzt3QkFDSCxjQUFjLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQTtvQkFDdkQsQ0FBQztvQkFBQyxPQUFPLENBQUMsRUFBRSxDQUFDO3dCQUNYLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLEdBQUcsQ0FBQyxHQUFHLHNCQUFzQixDQUFDLENBQUE7b0JBQ3BFLENBQUM7Z0JBQ0gsQ0FBQztnQkFFRCxzQ0FBc0M7Z0JBQ3RDLE1BQU0sT0FBTyxHQUFHLE1BQU0sb0JBQW9CLENBQUMsY0FBYyxDQUFDO29CQUN4RCxLQUFLLEVBQUUsR0FBRyxDQUFDLE9BQU87b0JBQ2xCLE1BQU0sRUFBRSxHQUFHLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRTtvQkFDN0IsTUFBTSxFQUFFLFdBQVc7b0JBQ25CLFFBQVEsRUFBRTt3QkFDUixHQUFHLEVBQUUsR0FBRyxDQUFDLEdBQUc7d0JBQ1osT0FBTyxFQUFFLEdBQUcsQ0FBQyxPQUFPO3dCQUNwQixPQUFPLEVBQUUsR0FBRyxDQUFDLE9BQU8sSUFBSSxHQUFHLENBQUMsT0FBTzt3QkFDbkMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxPQUFPLElBQUksR0FBRyxDQUFDLE9BQU87d0JBQ25DLE9BQU8sRUFBRSxHQUFHLENBQUMsT0FBTyxJQUFJLEVBQUU7d0JBQzFCLE9BQU8sRUFBRSxHQUFHLENBQUMsT0FBTyxJQUFJLEdBQUcsQ0FBQyxPQUFPLElBQUksRUFBRTt3QkFDekMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxPQUFPLElBQUksR0FBRyxDQUFDLE9BQU8sSUFBSSxFQUFFO3dCQUN6QyxJQUFJLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDekMsV0FBVyxFQUFFLEdBQUcsQ0FBQyxXQUFXO3dCQUM1QixjQUFjLEVBQUUsR0FBRyxDQUFDLGNBQWMsSUFBSSxFQUFFO3dCQUN4QyxhQUFhLEVBQUUsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDbEUsZUFBZSxFQUFFLGNBQWM7cUJBQ2hDO2lCQUNGLENBQUMsQ0FBQTtnQkFFRiw0QkFBNEI7Z0JBQzVCLE1BQU0sb0JBQW9CLENBQUMscUJBQXFCLENBQUM7b0JBQy9DLFVBQVUsRUFBRSxPQUFPLENBQUMsRUFBRTtvQkFDdEIsS0FBSyxFQUFFLFNBQVM7b0JBQ2hCLEdBQUcsRUFBRSxHQUFHLENBQUMsR0FBRztvQkFDWixnQkFBZ0IsRUFBRSxLQUFLO29CQUN2QixNQUFNLEVBQUU7d0JBQ047NEJBQ0UsTUFBTSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLENBQUMsRUFBRSxtQkFBbUI7NEJBQ3BFLGFBQWEsRUFBRSxLQUFLO3lCQUNyQjtxQkFDRjtpQkFDRixDQUFDLENBQUE7Z0JBRUYsWUFBWSxFQUFFLENBQUE7Z0JBQ2QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLFlBQVksSUFBSSxPQUFPLENBQUMsTUFBTSxLQUFLLEdBQUcsQ0FBQyxHQUFHLE1BQU0sR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUE7Z0JBRWhGLDZCQUE2QjtnQkFDN0IsSUFBSSxZQUFZLEdBQUcsRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDO29CQUM1QixPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixZQUFZLElBQUksT0FBTyxDQUFDLE1BQU0sS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsWUFBWSxHQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUE7Z0JBQ3ZILENBQUM7WUFFSCxDQUFDO1lBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztnQkFDcEIsVUFBVSxFQUFFLENBQUE7Z0JBQ1osTUFBTSxDQUFDLElBQUksQ0FBQztvQkFDVixJQUFJLEVBQUUsVUFBVTtvQkFDaEIsR0FBRyxFQUFFLEdBQUcsQ0FBQyxHQUFHO29CQUNaLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTztpQkFDckIsQ0FBQyxDQUFBO2dCQUNGLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxVQUFVLEtBQUssR0FBRyxDQUFDLEdBQUcsYUFBYSxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQTtZQUM1RSxDQUFDO1FBQ0gsQ0FBQztRQUVELFVBQVU7UUFDVixPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUE7UUFDbEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFBO1FBQ2hDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFBO1FBQzNCLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLFlBQVksRUFBRSxDQUFDLENBQUE7UUFDNUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLFVBQVUsRUFBRSxDQUFDLENBQUE7UUFDdEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFBO1FBQzFDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsQ0FBQyxZQUFZLEdBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUE7UUFDbkYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUE7UUFFM0IsSUFBSSxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQ3RCLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7WUFDNUIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDbkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLEdBQUcsQ0FBQyxJQUFJLEtBQUssR0FBRyxDQUFDLEdBQUcsTUFBTSxHQUFHLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQTtZQUM5RCxDQUFDLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFDLENBQUE7SUFFdEMsQ0FBQztJQUFDLE9BQU8sS0FBVSxFQUFFLENBQUM7UUFDcEIsT0FBTyxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUE7UUFDaEQsTUFBTSxLQUFLLENBQUE7SUFDYixDQUFDO0FBQ0gsQ0FBQyJ9