"use strict";
/**
 * Generate SEO fields for all products
 * Usage: npx ts-node src/scripts/generate-seo.ts
 */
Object.defineProperty(exports, "__esModule", { value: true });
async function generateSEO() {
    console.log("🔍 Generating SEO fields for all products...");
    try {
        // In real implementation:
        // 1. Fetch all products without SEO fields
        // 2. Generate meta_title, meta_description, slug
        // 3. Generate structured_data (JSON-LD)
        // 4. Update products in database
        const products = []; // Would be populated from query
        let updated = 0;
        for (const product of products) {
            console.log(`  Processing ${product.sku}...`);
            // Generate SEO fields
            const seoData = {
                meta_title: `${product.title} | OMEX`,
                meta_description: product.description?.substring(0, 160),
                slug: product.title.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
                canonical_url: `https://omex.pl/produkty/${product.sku.toLowerCase()}`,
                structured_data: {
                    "@context": "https://schema.org",
                    "@type": "Product",
                    name: product.title,
                    sku: product.sku,
                    description: product.description,
                    image: product.thumbnail,
                    offers: {
                        "@type": "Offer",
                        price: product.price,
                        priceCurrency: "PLN",
                    },
                },
            };
            // Update product
            // await productService.update(product.id, seoData)
            updated++;
        }
        console.log(`\n✅ Successfully generated SEO for ${updated} products`);
    }
    catch (error) {
        console.error("❌ SEO generation failed:", error);
        process.exit(1);
    }
}
generateSEO();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2VuZXJhdGUtc2VvLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3NjcmlwdHMvZ2VuZXJhdGUtc2VvLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7O0dBR0c7O0FBRUgsS0FBSyxVQUFVLFdBQVc7SUFDeEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4Q0FBOEMsQ0FBQyxDQUFBO0lBRTNELElBQUksQ0FBQztRQUNILDBCQUEwQjtRQUMxQiwyQ0FBMkM7UUFDM0MsaURBQWlEO1FBQ2pELHdDQUF3QztRQUN4QyxpQ0FBaUM7UUFFakMsTUFBTSxRQUFRLEdBQVUsRUFBRSxDQUFBLENBQUMsZ0NBQWdDO1FBRTNELElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQTtRQUNmLEtBQUssTUFBTSxPQUFPLElBQUksUUFBUSxFQUFFLENBQUM7WUFDL0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsT0FBTyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUE7WUFFN0Msc0JBQXNCO1lBQ3RCLE1BQU0sT0FBTyxHQUFHO2dCQUNkLFVBQVUsRUFBRSxHQUFHLE9BQU8sQ0FBQyxLQUFLLFNBQVM7Z0JBQ3JDLGdCQUFnQixFQUFFLE9BQU8sQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUM7Z0JBQ3hELElBQUksRUFBRSxPQUFPLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsR0FBRyxDQUFDO2dCQUM3RCxhQUFhLEVBQUUsNEJBQTRCLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLEVBQUU7Z0JBQ3RFLGVBQWUsRUFBRTtvQkFDZixVQUFVLEVBQUUsb0JBQW9CO29CQUNoQyxPQUFPLEVBQUUsU0FBUztvQkFDbEIsSUFBSSxFQUFFLE9BQU8sQ0FBQyxLQUFLO29CQUNuQixHQUFHLEVBQUUsT0FBTyxDQUFDLEdBQUc7b0JBQ2hCLFdBQVcsRUFBRSxPQUFPLENBQUMsV0FBVztvQkFDaEMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxTQUFTO29CQUN4QixNQUFNLEVBQUU7d0JBQ04sT0FBTyxFQUFFLE9BQU87d0JBQ2hCLEtBQUssRUFBRSxPQUFPLENBQUMsS0FBSzt3QkFDcEIsYUFBYSxFQUFFLEtBQUs7cUJBQ3JCO2lCQUNGO2FBQ0YsQ0FBQTtZQUVELGlCQUFpQjtZQUNqQixtREFBbUQ7WUFDbkQsT0FBTyxFQUFFLENBQUE7UUFDWCxDQUFDO1FBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQ0FBc0MsT0FBTyxXQUFXLENBQUMsQ0FBQTtJQUN2RSxDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsMEJBQTBCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDaEQsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUNqQixDQUFDO0FBQ0gsQ0FBQztBQUVELFdBQVcsRUFBRSxDQUFBIn0=