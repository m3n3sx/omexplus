"use strict";
/**
 * Seed script for full category hierarchy
 * Run: npm run seed:full-categories
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = seedFullCategories;
const utils_1 = require("@medusajs/framework/utils");
const full_categories_hierarchy_1 = require("../seeds/full-categories-hierarchy");
async function seedFullCategories(container) {
    const logger = container.resolve(utils_1.ContainerRegistrationKeys.LOGGER);
    const productCategoryService = container.resolve("productCategoryService");
    logger.info("🌱 Starting full category hierarchy seed...");
    try {
        // Create a map to store created categories by their ID
        const createdCategories = new Map();
        // First pass: Create all top-level categories (no parent)
        const topLevelCategories = full_categories_hierarchy_1.FULL_CATEGORY_HIERARCHY.filter(cat => !cat.parent_id);
        logger.info(`📦 Creating ${topLevelCategories.length} top-level categories...`);
        for (const category of topLevelCategories) {
            try {
                const created = await productCategoryService.create({
                    name: category.name,
                    handle: category.slug,
                    is_active: true,
                    is_internal: false,
                    metadata: {
                        name_en: category.name_en,
                        icon: category.icon,
                        description: category.description,
                        priority: category.priority,
                        ...category.metadata,
                    },
                });
                createdCategories.set(category.id, created);
                logger.info(`  ✓ Created: ${category.name} (${category.icon})`);
            }
            catch (error) {
                logger.error(`  ✗ Failed to create ${category.name}:`, error.message);
            }
        }
        // Second pass: Create subcategories
        const subcategories = full_categories_hierarchy_1.FULL_CATEGORY_HIERARCHY.filter(cat => cat.parent_id);
        logger.info(`📦 Creating ${subcategories.length} subcategories...`);
        for (const category of subcategories) {
            try {
                const parentCategory = createdCategories.get(category.parent_id);
                if (!parentCategory) {
                    logger.warn(`  ⚠ Parent not found for ${category.name}, skipping...`);
                    continue;
                }
                const created = await productCategoryService.create({
                    name: category.name,
                    handle: category.slug,
                    parent_category_id: parentCategory.id,
                    is_active: true,
                    is_internal: false,
                    metadata: {
                        name_en: category.name_en,
                        icon: category.icon,
                        description: category.description,
                        priority: category.priority,
                        ...category.metadata,
                    },
                });
                createdCategories.set(category.id, created);
                logger.info(`  ✓ Created: ${category.name} (${category.icon}) under ${parentCategory.name}`);
            }
            catch (error) {
                logger.error(`  ✗ Failed to create ${category.name}:`, error.message);
            }
        }
        logger.info(`✅ Successfully seeded ${createdCategories.size} categories!`);
        // Summary
        logger.info("\n📊 SUMMARY:");
        logger.info(`  Total categories: ${full_categories_hierarchy_1.FULL_CATEGORY_HIERARCHY.length}`);
        logger.info(`  Created: ${createdCategories.size}`);
        logger.info(`  Top-level: ${topLevelCategories.length}`);
        logger.info(`  Subcategories: ${subcategories.length}`);
        // Top priority categories
        const topPriority = full_categories_hierarchy_1.FULL_CATEGORY_HIERARCHY.filter(cat => cat.metadata?.topPriority);
        logger.info(`\n⭐ TOP PRIORITY CATEGORIES:`);
        topPriority.forEach(cat => {
            logger.info(`  ${cat.icon} ${cat.name} - ${cat.metadata?.salesPercentage}% sprzedaży`);
        });
    }
    catch (error) {
        logger.error("❌ Error seeding categories:", error);
        throw error;
    }
}
// If running directly
if (require.main === module) {
    const { container } = require("@medusajs/framework");
    seedFullCategories(container)
        .then(() => {
        console.log("✅ Seed completed successfully");
        process.exit(0);
    })
        .catch((error) => {
        console.error("❌ Seed failed:", error);
        process.exit(1);
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VlZC1mdWxsLWNhdGVnb3JpZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvc2NyaXB0cy9zZWVkLWZ1bGwtY2F0ZWdvcmllcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7OztHQUdHOztBQU1ILHFDQThGQztBQWpHRCxxREFBcUU7QUFDckUsa0ZBQTRFO0FBRTdELEtBQUssVUFBVSxrQkFBa0IsQ0FBQyxTQUEwQjtJQUN6RSxNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQ2xFLE1BQU0sc0JBQXNCLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFBO0lBRTFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsNkNBQTZDLENBQUMsQ0FBQTtJQUUxRCxJQUFJLENBQUM7UUFDSCx1REFBdUQ7UUFDdkQsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLEdBQUcsRUFBZSxDQUFBO1FBRWhELDBEQUEwRDtRQUMxRCxNQUFNLGtCQUFrQixHQUFHLG1EQUF1QixDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFBO1FBRWhGLE1BQU0sQ0FBQyxJQUFJLENBQUMsZUFBZSxrQkFBa0IsQ0FBQyxNQUFNLDBCQUEwQixDQUFDLENBQUE7UUFFL0UsS0FBSyxNQUFNLFFBQVEsSUFBSSxrQkFBa0IsRUFBRSxDQUFDO1lBQzFDLElBQUksQ0FBQztnQkFDSCxNQUFNLE9BQU8sR0FBRyxNQUFNLHNCQUFzQixDQUFDLE1BQU0sQ0FBQztvQkFDbEQsSUFBSSxFQUFFLFFBQVEsQ0FBQyxJQUFJO29CQUNuQixNQUFNLEVBQUUsUUFBUSxDQUFDLElBQUk7b0JBQ3JCLFNBQVMsRUFBRSxJQUFJO29CQUNmLFdBQVcsRUFBRSxLQUFLO29CQUNsQixRQUFRLEVBQUU7d0JBQ1IsT0FBTyxFQUFFLFFBQVEsQ0FBQyxPQUFPO3dCQUN6QixJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUk7d0JBQ25CLFdBQVcsRUFBRSxRQUFRLENBQUMsV0FBVzt3QkFDakMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxRQUFRO3dCQUMzQixHQUFHLFFBQVEsQ0FBQyxRQUFRO3FCQUNyQjtpQkFDRixDQUFDLENBQUE7Z0JBRUYsaUJBQWlCLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUE7Z0JBQzNDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLFFBQVEsQ0FBQyxJQUFJLEtBQUssUUFBUSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUE7WUFDakUsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsTUFBTSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsUUFBUSxDQUFDLElBQUksR0FBRyxFQUFFLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQTtZQUN2RSxDQUFDO1FBQ0gsQ0FBQztRQUVELG9DQUFvQztRQUNwQyxNQUFNLGFBQWEsR0FBRyxtREFBdUIsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUE7UUFFMUUsTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLGFBQWEsQ0FBQyxNQUFNLG1CQUFtQixDQUFDLENBQUE7UUFFbkUsS0FBSyxNQUFNLFFBQVEsSUFBSSxhQUFhLEVBQUUsQ0FBQztZQUNyQyxJQUFJLENBQUM7Z0JBQ0gsTUFBTSxjQUFjLEdBQUcsaUJBQWlCLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxTQUFVLENBQUMsQ0FBQTtnQkFFakUsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO29CQUNwQixNQUFNLENBQUMsSUFBSSxDQUFDLDRCQUE0QixRQUFRLENBQUMsSUFBSSxlQUFlLENBQUMsQ0FBQTtvQkFDckUsU0FBUTtnQkFDVixDQUFDO2dCQUVELE1BQU0sT0FBTyxHQUFHLE1BQU0sc0JBQXNCLENBQUMsTUFBTSxDQUFDO29CQUNsRCxJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUk7b0JBQ25CLE1BQU0sRUFBRSxRQUFRLENBQUMsSUFBSTtvQkFDckIsa0JBQWtCLEVBQUUsY0FBYyxDQUFDLEVBQUU7b0JBQ3JDLFNBQVMsRUFBRSxJQUFJO29CQUNmLFdBQVcsRUFBRSxLQUFLO29CQUNsQixRQUFRLEVBQUU7d0JBQ1IsT0FBTyxFQUFFLFFBQVEsQ0FBQyxPQUFPO3dCQUN6QixJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUk7d0JBQ25CLFdBQVcsRUFBRSxRQUFRLENBQUMsV0FBVzt3QkFDakMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxRQUFRO3dCQUMzQixHQUFHLFFBQVEsQ0FBQyxRQUFRO3FCQUNyQjtpQkFDRixDQUFDLENBQUE7Z0JBRUYsaUJBQWlCLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDLENBQUE7Z0JBQzNDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLFFBQVEsQ0FBQyxJQUFJLEtBQUssUUFBUSxDQUFDLElBQUksV0FBVyxjQUFjLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQTtZQUM5RixDQUFDO1lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztnQkFDZixNQUFNLENBQUMsS0FBSyxDQUFDLHdCQUF3QixRQUFRLENBQUMsSUFBSSxHQUFHLEVBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFBO1lBQ3ZFLENBQUM7UUFDSCxDQUFDO1FBRUQsTUFBTSxDQUFDLElBQUksQ0FBQyx5QkFBeUIsaUJBQWlCLENBQUMsSUFBSSxjQUFjLENBQUMsQ0FBQTtRQUUxRSxVQUFVO1FBQ1YsTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQTtRQUM1QixNQUFNLENBQUMsSUFBSSxDQUFDLHVCQUF1QixtREFBdUIsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFBO1FBQ3BFLE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFBO1FBQ25ELE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLGtCQUFrQixDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUE7UUFDeEQsTUFBTSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsYUFBYSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUE7UUFFdkQsMEJBQTBCO1FBQzFCLE1BQU0sV0FBVyxHQUFHLG1EQUF1QixDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUE7UUFDcEYsTUFBTSxDQUFDLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxDQUFBO1FBQzNDLFdBQVcsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7WUFDeEIsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUFJLElBQUksR0FBRyxDQUFDLElBQUksTUFBTSxHQUFHLENBQUMsUUFBUSxFQUFFLGVBQWUsYUFBYSxDQUFDLENBQUE7UUFDeEYsQ0FBQyxDQUFDLENBQUE7SUFFSixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE1BQU0sQ0FBQyxLQUFLLENBQUMsNkJBQTZCLEVBQUUsS0FBSyxDQUFDLENBQUE7UUFDbEQsTUFBTSxLQUFLLENBQUE7SUFDYixDQUFDO0FBQ0gsQ0FBQztBQUVELHNCQUFzQjtBQUN0QixJQUFJLE9BQU8sQ0FBQyxJQUFJLEtBQUssTUFBTSxFQUFFLENBQUM7SUFDNUIsTUFBTSxFQUFFLFNBQVMsRUFBRSxHQUFHLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxDQUFBO0lBQ3BELGtCQUFrQixDQUFDLFNBQVMsQ0FBQztTQUMxQixJQUFJLENBQUMsR0FBRyxFQUFFO1FBQ1QsT0FBTyxDQUFDLEdBQUcsQ0FBQywrQkFBK0IsQ0FBQyxDQUFBO1FBQzVDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDakIsQ0FBQyxDQUFDO1NBQ0QsS0FBSyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUU7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQ3RDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDakIsQ0FBQyxDQUFDLENBQUE7QUFDTixDQUFDIn0=