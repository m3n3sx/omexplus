"use strict";
/**
 * OMEX Categories Seed Data
 * 18+ głównych kategorii z podkategoriami
 * Based on szukajka.md specification
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.CATEGORY_STATS = exports.CATEGORIES_SEED = void 0;
exports.flattenCategories = flattenCategories;
exports.getCategoryCount = getCategoryCount;
exports.CATEGORIES_SEED = [
    {
        name: "Podwozia & Gąsienice",
        slug: "podwozia-gasienice",
        icon: "🚜",
        description: "Podwozia gąsienicowe, kołowe, gąsienice gumowe",
        children: [
            {
                name: "Podwozia gąsienicowe",
                slug: "podwozia-gasienicowe",
                children: [
                    { name: "Do koparek (CAT, Komatsu, Hitachi, Volvo, JCB)", slug: "do-koparek" },
                    { name: "Do minikoparek (do 6 ton)", slug: "do-minikoparek" },
                    { name: "Do ładowarek gąsienicowych", slug: "do-ladowarek-gasienicowych" },
                    { name: "OEM + zamienniki", slug: "oem-zamienniki" },
                ],
            },
            {
                name: "Gąsienice gumowe",
                slug: "gasienice-gumowe",
                children: [
                    { name: "Groty gąsienic", slug: "groty-gasienic" },
                    { name: "Bolce gąsienic", slug: "bolce-gasienic" },
                    { name: "Łączniki gąsienic", slug: "laczniki-gasienic" },
                    { name: "Napinacze", slug: "napinacze" },
                ],
            },
            {
                name: "Podwozia kołowe",
                slug: "podwozia-kolowe",
                children: [
                    { name: "Koła do koparek kołowych", slug: "kola-koparek-kolowych" },
                    { name: "Osie", slug: "osie" },
                    { name: "Połowiska", slug: "polowiska" },
                    { name: "Zawieszenia", slug: "zawieszenia" },
                ],
            },
        ],
    },
    {
        name: "Hydraulika",
        slug: "hydraulika",
        icon: "💧",
        description: "Pompy, silniki, zawory, cylindry hydrauliczne - 40% sprzedaży",
        children: [
            {
                name: "Pompy hydrauliczne",
                slug: "pompy-hydrauliczne",
                children: [
                    { name: "Pompy tłokowe", slug: "pompy-tlokowe" },
                    { name: "Pompy zębate", slug: "pompy-zebate" },
                    { name: "Pompy śrubowe", slug: "pompy-srubowe" },
                    { name: "OEM: Rexroth, Parker, Vickers", slug: "oem-rexroth-parker-vickers" },
                ],
            },
            {
                name: "Silniki hydrauliczne",
                slug: "silniki-hydrauliczne",
                children: [
                    { name: "Silniki obrotowe", slug: "silniki-obrotowe" },
                    { name: "Siłowniki", slug: "silowniki" },
                    { name: "Do różnych marek maszyn", slug: "do-roznych-marek" },
                ],
            },
            {
                name: "Zawory hydrauliczne",
                slug: "zawory-hydrauliczne",
                children: [
                    { name: "Zawory zwrotne", slug: "zawory-zwrotne" },
                    { name: "Zawory ciśnieniowe", slug: "zawory-cisnieniowe" },
                    { name: "Zawory rozdzielacze", slug: "zawory-rozdzielacze" },
                    { name: "Zawory sterowania", slug: "zawory-sterowania" },
                ],
            },
            {
                name: "Cylindry hydrauliczne",
                slug: "cylindry-hydrauliczne",
                children: [
                    { name: "Cylindry ryzeru", slug: "cylindry-ryzeru" },
                    { name: "Cylindry wysięgnika", slug: "cylindry-wysiegnika" },
                    { name: "Cylindry świdra", slug: "cylindry-swidra" },
                    { name: "Custom cylindry", slug: "custom-cylindry" },
                ],
            },
            {
                name: "Węże hydrauliczne",
                slug: "weze-hydrauliczne",
                children: [
                    { name: "Tłoczne", slug: "tloczne" },
                    { name: "Ssące", slug: "ssace" },
                    { name: "Sterowania", slug: "sterowania" },
                    { name: "Złączki i końcówki", slug: "zlaczki-koncowki" },
                ],
            },
            { name: "Zbiorniki hydrauliczne", slug: "zbiorniki-hydrauliczne" },
            { name: "Filtry hydrauliczne (HF, HG, HH)", slug: "filtry-hydrauliczne" },
            { name: "Płyny hydrauliczne", slug: "plyny-hydrauliczne" },
            { name: "Garny i złączki hydrauliczne", slug: "garny-zlaczki" },
        ],
    },
    {
        name: "Silnik & Osprzęt",
        slug: "silnik-osprzet",
        icon: "⚙️",
        description: "Silniki spalinowe, turbosprężarki, filtry, układy chłodzenia",
        children: [
            {
                name: "Silniki spalinowe",
                slug: "silniki-spalinowe",
                children: [
                    { name: "Silniki Perkins", slug: "silniki-perkins" },
                    { name: "Silniki Yanmar", slug: "silniki-yanmar" },
                    { name: "Silniki Mitsubishi", slug: "silniki-mitsubishi" },
                    { name: "OEM dla każdej marki maszyny", slug: "oem-wszystkie-marki" },
                ],
            },
            { name: "Turbosprężarki", slug: "turbosprezarki" },
            {
                name: "Filtry powietrza",
                slug: "filtry-powietrza",
                children: [
                    { name: "Główne", slug: "glowne" },
                    { name: "Wstępne", slug: "wstepne" },
                    { name: "Kabinowe", slug: "kabinowe" },
                ],
            },
            { name: "Filtry paliwa", slug: "filtry-paliwa" },
            { name: "Filtry oleju", slug: "filtry-oleju" },
            { name: "Wymienniki ciepła", slug: "wymienniki-ciepla" },
            {
                name: "Układy chłodzenia",
                slug: "uklady-chlodzenia",
                children: [
                    { name: "Termostaty", slug: "termostaty" },
                    { name: "Pompy wody", slug: "pompy-wody" },
                    { name: "Zawory termostatyczne", slug: "zawory-termostatyczne" },
                ],
            },
            { name: "Paski klinowe", slug: "paski-klinowe" },
            { name: "Rozruszniki", slug: "rozruszniki" },
            { name: "Alternatory", slug: "alternatory" },
        ],
    },
    {
        name: "Skrzynia biegów & Przeniesienie",
        slug: "skrzynia-biegow-przeniesienie",
        icon: "⚡",
        description: "Skrzynie biegów, sprzęgła, wałki napędowe",
        children: [
            {
                name: "Skrzynia biegów",
                slug: "skrzynia-biegow",
                children: [
                    { name: "Skrzynio-reduktory", slug: "skrzynio-reduktory" },
                    { name: "Przekładnie", slug: "przekladnie" },
                    { name: "Zwolnice", slug: "zwolnice" },
                    { name: "Olejniki przepustowe", slug: "olejniki-przepustowe" },
                ],
            },
            { name: "Sprzęgła", slug: "sprzegla" },
            { name: "Wałki napędowe", slug: "walki-napedowe" },
            { name: "Łańcuchy napędowe", slug: "lancuchy-napedowe" },
            { name: "Koła zębate", slug: "kola-zebate" },
        ],
    },
    {
        name: "Elektryka & Elektronika",
        slug: "elektryka-elektronika",
        icon: "🔌",
        description: "Silniki elektryczne, przetworniki, oświetlenie, baterie",
        children: [
            { name: "Silniki elektryczne", slug: "silniki-elektryczne" },
            { name: "Przetworniki", slug: "przetworniki" },
            { name: "Wyłączniki", slug: "wylaczniki" },
            { name: "Rozdzielnice", slug: "rozdzielnice" },
            { name: "Kable i przewody", slug: "kable-przewody" },
            { name: "Złączki elektryczne", slug: "zlaczki-elektryczne" },
            {
                name: "Oświetlenie",
                slug: "oswietlenie",
                children: [
                    { name: "Halogeny", slug: "halogeny" },
                    { name: "LED", slug: "led" },
                    { name: "Światła ostrzegawcze", slug: "swiatla-ostrzegawcze" },
                ],
            },
            { name: "Urządzenia pomiarowe", slug: "urzadzenia-pomiarowe" },
            { name: "Baterie i akumulatory", slug: "baterie-akumulatory" },
        ],
    },
    {
        name: "Elementy obrotu & Ramion",
        slug: "elementy-obrotu-ramion",
        icon: "🔄",
        description: "Pierścienie obrotu, łożyska, ramiona wysięgnika",
        children: [
            { name: "Pierścienie obrotu (slewing ring)", slug: "pierscienie-obrotu" },
            { name: "Łożyska obrotu", slug: "lozyska-obrotu" },
            { name: "Zęby obrotu", slug: "zeby-obrotu" },
            {
                name: "Ramiona wysięgnika",
                slug: "ramiona-wysiegnika",
                children: [
                    { name: "Główne", slug: "glowne" },
                    { name: "Pomocnicze", slug: "pomocnicze" },
                    { name: "Teleskopowe", slug: "teleskopowe" },
                ],
            },
            { name: "Ramiona ładowcze", slug: "ramiona-ladowcze" },
            { name: "Układy zawieszenia", slug: "uklady-zawieszenia" },
            { name: "Bolce przegubowe", slug: "bolce-przegubowe" },
        ],
    },
    {
        name: "Filtry & Uszczelnienia",
        slug: "filtry-uszczelnienia",
        icon: "🔧",
        description: "Wszystkie typy filtrów i uszczelek - TOP PRIORITY",
        children: [
            {
                name: "Filtry",
                slug: "filtry",
                children: [
                    {
                        name: "Filtry powietrza",
                        slug: "filtry-powietrza-all",
                        children: [
                            { name: "Primary", slug: "primary" },
                            { name: "Secondary", slug: "secondary" },
                            { name: "Cabin", slug: "cabin" },
                        ],
                    },
                    { name: "Filtry paliwa", slug: "filtry-paliwa-all" },
                    { name: "Filtry oleju", slug: "filtry-oleju-all" },
                    {
                        name: "Filtry hydrauliczne",
                        slug: "filtry-hydrauliczne-all",
                        children: [
                            { name: "Typ HF (najczęstszy)", slug: "typ-hf" },
                            { name: "Typ HG", slug: "typ-hg" },
                            { name: "Typ HH", slug: "typ-hh" },
                        ],
                    },
                    { name: "Filtry wody/separatory", slug: "filtry-wody-separatory" },
                ],
            },
            {
                name: "Uszczelnienia",
                slug: "uszczelnienia",
                children: [
                    { name: "Pierścienie tłokowe", slug: "pierscienie-tlokowe" },
                    { name: "Uszczelki głowicy", slug: "uszczelki-glowicy" },
                    { name: "Uszczelki pokryw", slug: "uszczelki-pokryw" },
                    { name: "O-ringi (ISO 3384)", slug: "o-ringi" },
                    { name: "Uszczelki wałów", slug: "uszczelki-walow" },
                    { name: "Uszczelki cylindrów", slug: "uszczelki-cylindrow" },
                    { name: "Kity uszczelniające", slug: "kity-uszczelniajace" },
                ],
            },
        ],
    },
    {
        name: "Nadwozie & Oprawa",
        slug: "nadwozie-oprawa",
        icon: "🏗️",
        description: "Kabiny, szyby, osłony, fotele operatora",
        children: [
            { name: "Kabiny i drzwi", slug: "kabiny-drzwi" },
            { name: "Szyby", slug: "szyby" },
            { name: "Osłony", slug: "oslony" },
            { name: "Osłonki zderzaka", slug: "oslonki-zderzaka" },
            { name: "Kierownica", slug: "kierownica" },
            { name: "Pedały", slug: "pedaly" },
            { name: "Fotele operatora", slug: "fotele-operatora" },
            { name: "Wyposażenie kabiny", slug: "wyposazenie-kabiny" },
        ],
    },
    {
        name: "Osprzęt & Wymienne części robocze",
        slug: "osprzet-wymienne-czesci",
        icon: "🔨",
        description: "Łyżki, zęby, młoty hydrauliczne, wiertła",
        children: [
            {
                name: "Łyżki",
                slug: "lyzki",
                children: [
                    { name: "Standardowe", slug: "standardowe" },
                    { name: "Wzmocnione", slug: "wzmocnione" },
                    { name: "Różne szerokości (600-1600mm)", slug: "rozne-szerokosci" },
                    { name: "Specjalistyczne", slug: "specjalistyczne" },
                ],
            },
            { name: "Zęby do łyżek", slug: "zeby-do-lyzek" },
            { name: "Adaptery do łyżek", slug: "adaptery-do-lyzek" },
            {
                name: "Młoty hydrauliczne",
                slug: "mloty-hydrauliczne",
                children: [
                    { name: "Małe (do 1 tony)", slug: "male-do-1-tony" },
                    { name: "Średnie (1-3 tony)", slug: "srednie-1-3-tony" },
                    { name: "Duże (3+ tony)", slug: "duze-3-plus-tony" },
                    { name: "Groty zamienialne", slug: "groty-zamienialne" },
                ],
            },
            { name: "Wiertła", slug: "wiertla" },
            { name: "Kompaktory", slug: "kompaktory" },
            { name: "Haki chwytające", slug: "haki-chwytajace" },
            { name: "Magnesy", slug: "magnesy" },
            { name: "Wymienne karty robocze", slug: "wymienne-karty-robocze" },
        ],
    },
    {
        name: "Normalia warsztatowe",
        slug: "normalia-warsztatowe",
        icon: "🔩",
        description: "Śruby, nakrętki, podkładki, kołki",
        children: [
            {
                name: "Śruby (M6 - M42)",
                slug: "sruby",
                children: [
                    { name: "Zwykłe", slug: "zwykle" },
                    { name: "Imbusowe", slug: "imbusowe" },
                    { name: "Stopniowe", slug: "stopniowe" },
                    { name: "Specjalne", slug: "specjalne" },
                ],
            },
            {
                name: "Nakrętki",
                slug: "nakretki",
                children: [
                    { name: "Zwykłe", slug: "zwykle" },
                    { name: "Samozabezpieczające", slug: "samozabezpieczajace" },
                    { name: "Koronowe", slug: "koronowe" },
                ],
            },
            {
                name: "Podkładki",
                slug: "podkladki",
                children: [
                    { name: "Płaskie", slug: "plaskie" },
                    { name: "Sprężyste", slug: "sprezyste" },
                    { name: "Specjalne", slug: "specjalne" },
                ],
            },
            { name: "Kołki podziałowe", slug: "kolki-podzialowe" },
            { name: "Sworzeń", slug: "sworzen" },
            { name: "Pierścienie zabezpieczające", slug: "pierscienie-zabezpieczajace" },
            { name: "Pierścienie zaporowe", slug: "pierscienie-zaporowe" },
            { name: "Zestawy naprawcze", slug: "zestawy-naprawcze" },
        ],
    },
    {
        name: "Wtryski & Systemy paliwowe",
        slug: "wtryski-systemy-paliwowe",
        icon: "⛽",
        description: "Wtryski, pompy paliwowe, filtry, czujniki",
        children: [
            { name: "Wtryski paliwowe", slug: "wtryski-paliwowe" },
            { name: "Pompy paliwowe", slug: "pompy-paliwowe" },
            { name: "Filtry paliwowe", slug: "filtry-paliwowe-wtryski" },
            { name: "Części systemu zasilania", slug: "czesci-systemu-zasilania" },
            { name: "Czujniki paliwa", slug: "czujniki-paliwa" },
        ],
    },
    {
        name: "Układ hamulcowy",
        slug: "uklad-hamulcowy",
        icon: "🛑",
        description: "Klocki, tarcze, bomby, siłowniki hamulcowe",
        children: [
            {
                name: "Klocki hamulcowe",
                slug: "klocki-hamulcowe",
                children: [
                    { name: "Organiczne", slug: "organiczne" },
                    { name: "Semi-metallic", slug: "semi-metallic" },
                    { name: "Ceramiczne", slug: "ceramiczne" },
                    { name: "Hartowane", slug: "hartowane" },
                ],
            },
            { name: "Tarcze hamulcowe", slug: "tarcze-hamulcowe" },
            { name: "Bomby hamulcowe", slug: "bomby-hamulcowe" },
            { name: "Pompy hamulcowe", slug: "pompy-hamulcowe" },
            { name: "Siłowniki hamulcowe", slug: "silowniki-hamulcowe" },
            { name: "Przewody hamulcowe", slug: "przewody-hamulcowe" },
            { name: "Płyn hamulcowy", slug: "plyn-hamulcowy" },
            { name: "Czujniki zużycia", slug: "czujniki-zuzycia" },
        ],
    },
    {
        name: "Układ sterowania & Czujniki",
        slug: "uklad-sterowania-czujniki",
        icon: "📡",
        description: "Czujniki pozycji, ciśnienia, temperatury, prędkości",
        children: [
            { name: "Czujniki pozycji", slug: "czujniki-pozycji" },
            { name: "Czujniki ciśnienia", slug: "czujniki-cisnienia" },
            { name: "Czujniki temperatury", slug: "czujniki-temperatury" },
            { name: "Czujniki prędkości", slug: "czujniki-predkosci" },
            { name: "Czujniki poziomu", slug: "czujniki-poziomu" },
            { name: "Czujniki level", slug: "czujniki-level" },
            { name: "Przełączniki", slug: "przelaczniki" },
            { name: "Elektroniczne moduły sterowania", slug: "elektroniczne-moduly-sterowania" },
        ],
    },
    {
        name: "Akcesoria",
        slug: "akcesoria",
        icon: "🎯",
        description: "Lampy, manetki, joysticki, wyłączniki bezpieczeństwa",
        children: [
            { name: "Lampy ostrzegawcze", slug: "lampy-ostrzegawcze" },
            { name: "Manetki sterowania", slug: "manetki-sterowania" },
            { name: "Drążki", slug: "drazki" },
            { name: "Dźwignie", slug: "dzwignie" },
            { name: "Joysticki", slug: "joysticki" },
            { name: "Przyciski", slug: "przyciski" },
            { name: "Wyłączniki bezpieczeństwa", slug: "wylaczniki-bezpieczenstwa" },
            { name: "Pasy bezpieczeństwa", slug: "pasy-bezpieczenstwa" },
            { name: "Uchwyty", slug: "uchwyty" },
            { name: "Dodatkowe wyposażenie", slug: "dodatkowe-wyposazenie" },
        ],
    },
    {
        name: "Części do konkretnych marek",
        slug: "czesci-do-marek",
        icon: "🏭",
        description: "CAT, Komatsu, Hitachi, Volvo, JCB i inne",
        children: [
            {
                name: "CAT (Caterpillar)",
                slug: "cat-caterpillar",
                children: [
                    { name: "Serie mini (301, 305, 308)", slug: "serie-mini" },
                    { name: "Koparki 320-390", slug: "koparki-320-390" },
                    { name: "Koparki 390F-420F", slug: "koparki-390f-420f" },
                    { name: "Ładowarki", slug: "ladowarki" },
                    { name: "Spycharki", slug: "spycharki" },
                ],
            },
            {
                name: "KOMATSU",
                slug: "komatsu",
                children: [
                    { name: "PC50 - PC200", slug: "pc50-pc200" },
                    { name: "PC300+", slug: "pc300-plus" },
                    { name: "WA (ładowarka)", slug: "wa-ladowarka" },
                    { name: "D (spychacz)", slug: "d-spychacz" },
                ],
            },
            {
                name: "HITACHI",
                slug: "hitachi",
                children: [
                    { name: "ZX (seria koparka)", slug: "zx-seria-koparka" },
                    { name: "WH (ładowarka)", slug: "wh-ladowarka" },
                    { name: "Części specjalne", slug: "czesci-specjalne" },
                ],
            },
            { name: "VOLVO", slug: "volvo" },
            { name: "JCB", slug: "jcb" },
            { name: "KOBELCO", slug: "kobelco" },
            { name: "HYUNDAI", slug: "hyundai" },
            { name: "BOBCAT", slug: "bobcat" },
            { name: "DOOSAN", slug: "doosan" },
            { name: "YUCHAI", slug: "yuchai" },
            { name: "ATLAS", slug: "atlas" },
        ],
    },
    {
        name: "Części wycinkowe (Special)",
        slug: "czesci-wycinkowe",
        icon: "⭐",
        description: "Zęby do młotów, groty, ścierżyny, adaptery",
        children: [
            { name: "Zęby do młotów (OEM numery)", slug: "zeby-do-mlotow" },
            { name: "Groty do wycinarek", slug: "groty-do-wycinarek" },
            { name: "Ścierżyny", slug: "scierzyny" },
            { name: "Adaptery uniwersalne", slug: "adaptery-uniwersalne" },
            { name: "Części zamiennego zastosowania", slug: "czesci-zamiennego-zastosowania" },
        ],
    },
    {
        name: "Części rolnicze",
        slug: "czesci-rolnicze",
        icon: "🌾",
        description: "Do ciągników, maszyn rolniczych, pługów",
        children: [
            { name: "Do ciągników (JCB 3CX, etc)", slug: "do-ciagnikow" },
            { name: "Do maszyn rolniczych", slug: "do-maszyn-rolniczych" },
            { name: "Części do pługów", slug: "czesci-do-plugow" },
            { name: "Lemiesze", slug: "lemiesze" },
        ],
    },
    {
        name: "Części drogowe & Specjalne",
        slug: "czesci-drogowe-specjalne",
        icon: "🛣️",
        description: "Do walcarek, werterin, kopiarek asfaltu",
        children: [
            { name: "Do walcarek", slug: "do-walcarek" },
            { name: "Do werterin", slug: "do-werterin" },
            { name: "Do kopiarek asfaltu", slug: "do-kopiarek-asfaltu" },
            { name: "Części specjalistyczne", slug: "czesci-specjalistyczne" },
        ],
    },
];
/**
 * Helper function to flatten category tree for database insertion
 */
function flattenCategories(categories, parentId = null, result = []) {
    for (const category of categories) {
        const { children, ...categoryData } = category;
        result.push({ ...categoryData, parent_id: parentId });
        if (children && children.length > 0) {
            flattenCategories(children, category.slug, result);
        }
    }
    return result;
}
/**
 * Get total count of categories (including subcategories)
 */
function getCategoryCount(categories) {
    let count = 0;
    for (const category of categories) {
        count++;
        if (category.children) {
            count += getCategoryCount(category.children);
        }
    }
    return count;
}
// Export stats
exports.CATEGORY_STATS = {
    mainCategories: exports.CATEGORIES_SEED.length,
    totalCategories: getCategoryCount(exports.CATEGORIES_SEED),
    maxDepth: 4, // Maximum nesting level
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2F0ZWdvcmllcy1zZWVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3NlZWRzL2NhdGVnb3JpZXMtc2VlZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7R0FJRzs7O0FBMmdCSCw4Q0FlQztBQUtELDRDQVNDO0FBOWhCWSxRQUFBLGVBQWUsR0FBdUI7SUFDakQ7UUFDRSxJQUFJLEVBQUUsc0JBQXNCO1FBQzVCLElBQUksRUFBRSxvQkFBb0I7UUFDMUIsSUFBSSxFQUFFLElBQUk7UUFDVixXQUFXLEVBQUUsZ0RBQWdEO1FBQzdELFFBQVEsRUFBRTtZQUNSO2dCQUNFLElBQUksRUFBRSxzQkFBc0I7Z0JBQzVCLElBQUksRUFBRSxzQkFBc0I7Z0JBQzVCLFFBQVEsRUFBRTtvQkFDUixFQUFFLElBQUksRUFBRSxnREFBZ0QsRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFO29CQUM5RSxFQUFFLElBQUksRUFBRSwyQkFBMkIsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7b0JBQzdELEVBQUUsSUFBSSxFQUFFLDRCQUE0QixFQUFFLElBQUksRUFBRSw0QkFBNEIsRUFBRTtvQkFDMUUsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO2lCQUNyRDthQUNGO1lBQ0Q7Z0JBQ0UsSUFBSSxFQUFFLGtCQUFrQjtnQkFDeEIsSUFBSSxFQUFFLGtCQUFrQjtnQkFDeEIsUUFBUSxFQUFFO29CQUNSLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRTtvQkFDbEQsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO29CQUNsRCxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7b0JBQ3hELEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFO2lCQUN6QzthQUNGO1lBQ0Q7Z0JBQ0UsSUFBSSxFQUFFLGlCQUFpQjtnQkFDdkIsSUFBSSxFQUFFLGlCQUFpQjtnQkFDdkIsUUFBUSxFQUFFO29CQUNSLEVBQUUsSUFBSSxFQUFFLDBCQUEwQixFQUFFLElBQUksRUFBRSx1QkFBdUIsRUFBRTtvQkFDbkUsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUU7b0JBQzlCLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFO29CQUN4QyxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtpQkFDN0M7YUFDRjtTQUNGO0tBQ0Y7SUFDRDtRQUNFLElBQUksRUFBRSxZQUFZO1FBQ2xCLElBQUksRUFBRSxZQUFZO1FBQ2xCLElBQUksRUFBRSxJQUFJO1FBQ1YsV0FBVyxFQUFFLCtEQUErRDtRQUM1RSxRQUFRLEVBQUU7WUFDUjtnQkFDRSxJQUFJLEVBQUUsb0JBQW9CO2dCQUMxQixJQUFJLEVBQUUsb0JBQW9CO2dCQUMxQixRQUFRLEVBQUU7b0JBQ1IsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7b0JBQ2hELEVBQUUsSUFBSSxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO29CQUM5QyxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtvQkFDaEQsRUFBRSxJQUFJLEVBQUUsK0JBQStCLEVBQUUsSUFBSSxFQUFFLDRCQUE0QixFQUFFO2lCQUM5RTthQUNGO1lBQ0Q7Z0JBQ0UsSUFBSSxFQUFFLHNCQUFzQjtnQkFDNUIsSUFBSSxFQUFFLHNCQUFzQjtnQkFDNUIsUUFBUSxFQUFFO29CQUNSLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRTtvQkFDdEQsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUU7b0JBQ3hDLEVBQUUsSUFBSSxFQUFFLHlCQUF5QixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRTtpQkFDOUQ7YUFDRjtZQUNEO2dCQUNFLElBQUksRUFBRSxxQkFBcUI7Z0JBQzNCLElBQUksRUFBRSxxQkFBcUI7Z0JBQzNCLFFBQVEsRUFBRTtvQkFDUixFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7b0JBQ2xELEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtvQkFDMUQsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFO29CQUM1RCxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7aUJBQ3pEO2FBQ0Y7WUFDRDtnQkFDRSxJQUFJLEVBQUUsdUJBQXVCO2dCQUM3QixJQUFJLEVBQUUsdUJBQXVCO2dCQUM3QixRQUFRLEVBQUU7b0JBQ1IsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO29CQUNwRCxFQUFFLElBQUksRUFBRSxxQkFBcUIsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUU7b0JBQzVELEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtvQkFDcEQsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO2lCQUNyRDthQUNGO1lBQ0Q7Z0JBQ0UsSUFBSSxFQUFFLG1CQUFtQjtnQkFDekIsSUFBSSxFQUFFLG1CQUFtQjtnQkFDekIsUUFBUSxFQUFFO29CQUNSLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFO29CQUNwQyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRTtvQkFDaEMsRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFLElBQUksRUFBRSxZQUFZLEVBQUU7b0JBQzFDLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRTtpQkFDekQ7YUFDRjtZQUNELEVBQUUsSUFBSSxFQUFFLHdCQUF3QixFQUFFLElBQUksRUFBRSx3QkFBd0IsRUFBRTtZQUNsRSxFQUFFLElBQUksRUFBRSxrQ0FBa0MsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUU7WUFDekUsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1lBQzFELEVBQUUsSUFBSSxFQUFFLDhCQUE4QixFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7U0FDaEU7S0FDRjtJQUNEO1FBQ0UsSUFBSSxFQUFFLGtCQUFrQjtRQUN4QixJQUFJLEVBQUUsZ0JBQWdCO1FBQ3RCLElBQUksRUFBRSxJQUFJO1FBQ1YsV0FBVyxFQUFFLDhEQUE4RDtRQUMzRSxRQUFRLEVBQUU7WUFDUjtnQkFDRSxJQUFJLEVBQUUsbUJBQW1CO2dCQUN6QixJQUFJLEVBQUUsbUJBQW1CO2dCQUN6QixRQUFRLEVBQUU7b0JBQ1IsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO29CQUNwRCxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7b0JBQ2xELEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtvQkFDMUQsRUFBRSxJQUFJLEVBQUUsOEJBQThCLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFO2lCQUN0RTthQUNGO1lBQ0QsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQ2xEO2dCQUNFLElBQUksRUFBRSxrQkFBa0I7Z0JBQ3hCLElBQUksRUFBRSxrQkFBa0I7Z0JBQ3hCLFFBQVEsRUFBRTtvQkFDUixFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRTtvQkFDbEMsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUU7b0JBQ3BDLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFO2lCQUN2QzthQUNGO1lBQ0QsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUU7WUFDaEQsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxjQUFjLEVBQUU7WUFDOUMsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFO1lBQ3hEO2dCQUNFLElBQUksRUFBRSxtQkFBbUI7Z0JBQ3pCLElBQUksRUFBRSxtQkFBbUI7Z0JBQ3pCLFFBQVEsRUFBRTtvQkFDUixFQUFFLElBQUksRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRTtvQkFDMUMsRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFLElBQUksRUFBRSxZQUFZLEVBQUU7b0JBQzFDLEVBQUUsSUFBSSxFQUFFLHVCQUF1QixFQUFFLElBQUksRUFBRSx1QkFBdUIsRUFBRTtpQkFDakU7YUFDRjtZQUNELEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRSxJQUFJLEVBQUUsZUFBZSxFQUFFO1lBQ2hELEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1lBQzVDLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1NBQzdDO0tBQ0Y7SUFDRDtRQUNFLElBQUksRUFBRSxpQ0FBaUM7UUFDdkMsSUFBSSxFQUFFLCtCQUErQjtRQUNyQyxJQUFJLEVBQUUsR0FBRztRQUNULFdBQVcsRUFBRSwyQ0FBMkM7UUFDeEQsUUFBUSxFQUFFO1lBQ1I7Z0JBQ0UsSUFBSSxFQUFFLGlCQUFpQjtnQkFDdkIsSUFBSSxFQUFFLGlCQUFpQjtnQkFDdkIsUUFBUSxFQUFFO29CQUNSLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtvQkFDMUQsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7b0JBQzVDLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFO29CQUN0QyxFQUFFLElBQUksRUFBRSxzQkFBc0IsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7aUJBQy9EO2FBQ0Y7WUFDRCxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRTtZQUN0QyxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDbEQsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFO1lBQ3hELEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO1NBQzdDO0tBQ0Y7SUFDRDtRQUNFLElBQUksRUFBRSx5QkFBeUI7UUFDL0IsSUFBSSxFQUFFLHVCQUF1QjtRQUM3QixJQUFJLEVBQUUsSUFBSTtRQUNWLFdBQVcsRUFBRSx5REFBeUQ7UUFDdEUsUUFBUSxFQUFFO1lBQ1IsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFO1lBQzVELEVBQUUsSUFBSSxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQzlDLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFO1lBQzFDLEVBQUUsSUFBSSxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQzlDLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRTtZQUNwRCxFQUFFLElBQUksRUFBRSxxQkFBcUIsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUU7WUFDNUQ7Z0JBQ0UsSUFBSSxFQUFFLGFBQWE7Z0JBQ25CLElBQUksRUFBRSxhQUFhO2dCQUNuQixRQUFRLEVBQUU7b0JBQ1IsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUU7b0JBQ3RDLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFO29CQUM1QixFQUFFLElBQUksRUFBRSxzQkFBc0IsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7aUJBQy9EO2FBQ0Y7WUFDRCxFQUFFLElBQUksRUFBRSxzQkFBc0IsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7WUFDOUQsRUFBRSxJQUFJLEVBQUUsdUJBQXVCLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFO1NBQy9EO0tBQ0Y7SUFDRDtRQUNFLElBQUksRUFBRSwwQkFBMEI7UUFDaEMsSUFBSSxFQUFFLHdCQUF3QjtRQUM5QixJQUFJLEVBQUUsSUFBSTtRQUNWLFdBQVcsRUFBRSxpREFBaUQ7UUFDOUQsUUFBUSxFQUFFO1lBQ1IsRUFBRSxJQUFJLEVBQUUsbUNBQW1DLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1lBQ3pFLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRTtZQUNsRCxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUM1QztnQkFDRSxJQUFJLEVBQUUsb0JBQW9CO2dCQUMxQixJQUFJLEVBQUUsb0JBQW9CO2dCQUMxQixRQUFRLEVBQUU7b0JBQ1IsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUU7b0JBQ2xDLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFO29CQUMxQyxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRTtpQkFDN0M7YUFDRjtZQUNELEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRTtZQUN0RCxFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDMUQsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1NBQ3ZEO0tBQ0Y7SUFDRDtRQUNFLElBQUksRUFBRSx3QkFBd0I7UUFDOUIsSUFBSSxFQUFFLHNCQUFzQjtRQUM1QixJQUFJLEVBQUUsSUFBSTtRQUNWLFdBQVcsRUFBRSxtREFBbUQ7UUFDaEUsUUFBUSxFQUFFO1lBQ1I7Z0JBQ0UsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsUUFBUSxFQUFFO29CQUNSO3dCQUNFLElBQUksRUFBRSxrQkFBa0I7d0JBQ3hCLElBQUksRUFBRSxzQkFBc0I7d0JBQzVCLFFBQVEsRUFBRTs0QkFDUixFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRTs0QkFDcEMsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUU7NEJBQ3hDLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFO3lCQUNqQztxQkFDRjtvQkFDRCxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFO29CQUNwRCxFQUFFLElBQUksRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO29CQUNsRDt3QkFDRSxJQUFJLEVBQUUscUJBQXFCO3dCQUMzQixJQUFJLEVBQUUseUJBQXlCO3dCQUMvQixRQUFRLEVBQUU7NEJBQ1IsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRTs0QkFDaEQsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUU7NEJBQ2xDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFO3lCQUNuQztxQkFDRjtvQkFDRCxFQUFFLElBQUksRUFBRSx3QkFBd0IsRUFBRSxJQUFJLEVBQUUsd0JBQXdCLEVBQUU7aUJBQ25FO2FBQ0Y7WUFDRDtnQkFDRSxJQUFJLEVBQUUsZUFBZTtnQkFDckIsSUFBSSxFQUFFLGVBQWU7Z0JBQ3JCLFFBQVEsRUFBRTtvQkFDUixFQUFFLElBQUksRUFBRSxxQkFBcUIsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUU7b0JBQzVELEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRTtvQkFDeEQsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO29CQUN0RCxFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFO29CQUMvQyxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7b0JBQ3BELEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFLElBQUksRUFBRSxxQkFBcUIsRUFBRTtvQkFDNUQsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFO2lCQUM3RDthQUNGO1NBQ0Y7S0FDRjtJQUNEO1FBQ0UsSUFBSSxFQUFFLG1CQUFtQjtRQUN6QixJQUFJLEVBQUUsaUJBQWlCO1FBQ3ZCLElBQUksRUFBRSxLQUFLO1FBQ1gsV0FBVyxFQUFFLHlDQUF5QztRQUN0RCxRQUFRLEVBQUU7WUFDUixFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQ2hELEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFO1lBQ2hDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFO1lBQ2xDLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRTtZQUN0RCxFQUFFLElBQUksRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRTtZQUMxQyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRTtZQUNsQyxFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDdEQsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1NBQzNEO0tBQ0Y7SUFDRDtRQUNFLElBQUksRUFBRSxtQ0FBbUM7UUFDekMsSUFBSSxFQUFFLHlCQUF5QjtRQUMvQixJQUFJLEVBQUUsSUFBSTtRQUNWLFdBQVcsRUFBRSwwQ0FBMEM7UUFDdkQsUUFBUSxFQUFFO1lBQ1I7Z0JBQ0UsSUFBSSxFQUFFLE9BQU87Z0JBQ2IsSUFBSSxFQUFFLE9BQU87Z0JBQ2IsUUFBUSxFQUFFO29CQUNSLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFO29CQUM1QyxFQUFFLElBQUksRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRTtvQkFDMUMsRUFBRSxJQUFJLEVBQUUsK0JBQStCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO29CQUNuRSxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7aUJBQ3JEO2FBQ0Y7WUFDRCxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtZQUNoRCxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7WUFDeEQ7Z0JBQ0UsSUFBSSxFQUFFLG9CQUFvQjtnQkFDMUIsSUFBSSxFQUFFLG9CQUFvQjtnQkFDMUIsUUFBUSxFQUFFO29CQUNSLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRTtvQkFDcEQsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO29CQUN4RCxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7b0JBQ3BELEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRTtpQkFDekQ7YUFDRjtZQUNELEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFO1lBQ3BDLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFO1lBQzFDLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUNwRCxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRTtZQUNwQyxFQUFFLElBQUksRUFBRSx3QkFBd0IsRUFBRSxJQUFJLEVBQUUsd0JBQXdCLEVBQUU7U0FDbkU7S0FDRjtJQUNEO1FBQ0UsSUFBSSxFQUFFLHNCQUFzQjtRQUM1QixJQUFJLEVBQUUsc0JBQXNCO1FBQzVCLElBQUksRUFBRSxJQUFJO1FBQ1YsV0FBVyxFQUFFLG1DQUFtQztRQUNoRCxRQUFRLEVBQUU7WUFDUjtnQkFDRSxJQUFJLEVBQUUsa0JBQWtCO2dCQUN4QixJQUFJLEVBQUUsT0FBTztnQkFDYixRQUFRLEVBQUU7b0JBQ1IsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUU7b0JBQ2xDLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFO29CQUN0QyxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRTtvQkFDeEMsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUU7aUJBQ3pDO2FBQ0Y7WUFDRDtnQkFDRSxJQUFJLEVBQUUsVUFBVTtnQkFDaEIsSUFBSSxFQUFFLFVBQVU7Z0JBQ2hCLFFBQVEsRUFBRTtvQkFDUixFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRTtvQkFDbEMsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFO29CQUM1RCxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRTtpQkFDdkM7YUFDRjtZQUNEO2dCQUNFLElBQUksRUFBRSxXQUFXO2dCQUNqQixJQUFJLEVBQUUsV0FBVztnQkFDakIsUUFBUSxFQUFFO29CQUNSLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFO29CQUNwQyxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRTtvQkFDeEMsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUU7aUJBQ3pDO2FBQ0Y7WUFDRCxFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDdEQsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUU7WUFDcEMsRUFBRSxJQUFJLEVBQUUsNkJBQTZCLEVBQUUsSUFBSSxFQUFFLDZCQUE2QixFQUFFO1lBQzVFLEVBQUUsSUFBSSxFQUFFLHNCQUFzQixFQUFFLElBQUksRUFBRSxzQkFBc0IsRUFBRTtZQUM5RCxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUU7U0FDekQ7S0FDRjtJQUNEO1FBQ0UsSUFBSSxFQUFFLDRCQUE0QjtRQUNsQyxJQUFJLEVBQUUsMEJBQTBCO1FBQ2hDLElBQUksRUFBRSxHQUFHO1FBQ1QsV0FBVyxFQUFFLDJDQUEyQztRQUN4RCxRQUFRLEVBQUU7WUFDUixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7WUFDdEQsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQ2xELEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSx5QkFBeUIsRUFBRTtZQUM1RCxFQUFFLElBQUksRUFBRSwwQkFBMEIsRUFBRSxJQUFJLEVBQUUsMEJBQTBCLEVBQUU7WUFDdEUsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFO1NBQ3JEO0tBQ0Y7SUFDRDtRQUNFLElBQUksRUFBRSxpQkFBaUI7UUFDdkIsSUFBSSxFQUFFLGlCQUFpQjtRQUN2QixJQUFJLEVBQUUsSUFBSTtRQUNWLFdBQVcsRUFBRSw0Q0FBNEM7UUFDekQsUUFBUSxFQUFFO1lBQ1I7Z0JBQ0UsSUFBSSxFQUFFLGtCQUFrQjtnQkFDeEIsSUFBSSxFQUFFLGtCQUFrQjtnQkFDeEIsUUFBUSxFQUFFO29CQUNSLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFO29CQUMxQyxFQUFFLElBQUksRUFBRSxlQUFlLEVBQUUsSUFBSSxFQUFFLGVBQWUsRUFBRTtvQkFDaEQsRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFLElBQUksRUFBRSxZQUFZLEVBQUU7b0JBQzFDLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFO2lCQUN6QzthQUNGO1lBQ0QsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQ3RELEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUNwRCxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRSxJQUFJLEVBQUUsaUJBQWlCLEVBQUU7WUFDcEQsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFO1lBQzVELEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtZQUMxRCxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDbEQsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1NBQ3ZEO0tBQ0Y7SUFDRDtRQUNFLElBQUksRUFBRSw2QkFBNkI7UUFDbkMsSUFBSSxFQUFFLDJCQUEyQjtRQUNqQyxJQUFJLEVBQUUsSUFBSTtRQUNWLFdBQVcsRUFBRSxxREFBcUQ7UUFDbEUsUUFBUSxFQUFFO1lBQ1IsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQ3RELEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtZQUMxRCxFQUFFLElBQUksRUFBRSxzQkFBc0IsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7WUFDOUQsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1lBQzFELEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRTtZQUN0RCxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7WUFDbEQsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxjQUFjLEVBQUU7WUFDOUMsRUFBRSxJQUFJLEVBQUUsaUNBQWlDLEVBQUUsSUFBSSxFQUFFLGlDQUFpQyxFQUFFO1NBQ3JGO0tBQ0Y7SUFDRDtRQUNFLElBQUksRUFBRSxXQUFXO1FBQ2pCLElBQUksRUFBRSxXQUFXO1FBQ2pCLElBQUksRUFBRSxJQUFJO1FBQ1YsV0FBVyxFQUFFLHNEQUFzRDtRQUNuRSxRQUFRLEVBQUU7WUFDUixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7WUFDMUQsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO1lBQzFELEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFO1lBQ2xDLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFO1lBQ3RDLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFO1lBQ3hDLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFO1lBQ3hDLEVBQUUsSUFBSSxFQUFFLDJCQUEyQixFQUFFLElBQUksRUFBRSwyQkFBMkIsRUFBRTtZQUN4RSxFQUFFLElBQUksRUFBRSxxQkFBcUIsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUU7WUFDNUQsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUU7WUFDcEMsRUFBRSxJQUFJLEVBQUUsdUJBQXVCLEVBQUUsSUFBSSxFQUFFLHVCQUF1QixFQUFFO1NBQ2pFO0tBQ0Y7SUFDRDtRQUNFLElBQUksRUFBRSw2QkFBNkI7UUFDbkMsSUFBSSxFQUFFLGlCQUFpQjtRQUN2QixJQUFJLEVBQUUsSUFBSTtRQUNWLFdBQVcsRUFBRSwwQ0FBMEM7UUFDdkQsUUFBUSxFQUFFO1lBQ1I7Z0JBQ0UsSUFBSSxFQUFFLG1CQUFtQjtnQkFDekIsSUFBSSxFQUFFLGlCQUFpQjtnQkFDdkIsUUFBUSxFQUFFO29CQUNSLEVBQUUsSUFBSSxFQUFFLDRCQUE0QixFQUFFLElBQUksRUFBRSxZQUFZLEVBQUU7b0JBQzFELEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRTtvQkFDcEQsRUFBRSxJQUFJLEVBQUUsbUJBQW1CLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixFQUFFO29CQUN4RCxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRTtvQkFDeEMsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUU7aUJBQ3pDO2FBQ0Y7WUFDRDtnQkFDRSxJQUFJLEVBQUUsU0FBUztnQkFDZixJQUFJLEVBQUUsU0FBUztnQkFDZixRQUFRLEVBQUU7b0JBQ1IsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxZQUFZLEVBQUU7b0JBQzVDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFO29CQUN0QyxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsY0FBYyxFQUFFO29CQUNoRCxFQUFFLElBQUksRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFLFlBQVksRUFBRTtpQkFDN0M7YUFDRjtZQUNEO2dCQUNFLElBQUksRUFBRSxTQUFTO2dCQUNmLElBQUksRUFBRSxTQUFTO2dCQUNmLFFBQVEsRUFBRTtvQkFDUixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUU7b0JBQ3hELEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFLElBQUksRUFBRSxjQUFjLEVBQUU7b0JBQ2hELEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxrQkFBa0IsRUFBRTtpQkFDdkQ7YUFDRjtZQUNELEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFO1lBQ2hDLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFO1lBQzVCLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFO1lBQ3BDLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFO1lBQ3BDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFO1lBQ2xDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFO1lBQ2xDLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFO1lBQ2xDLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFO1NBQ2pDO0tBQ0Y7SUFDRDtRQUNFLElBQUksRUFBRSw0QkFBNEI7UUFDbEMsSUFBSSxFQUFFLGtCQUFrQjtRQUN4QixJQUFJLEVBQUUsR0FBRztRQUNULFdBQVcsRUFBRSw0Q0FBNEM7UUFDekQsUUFBUSxFQUFFO1lBQ1IsRUFBRSxJQUFJLEVBQUUsNkJBQTZCLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFO1lBQy9ELEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtZQUMxRCxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRTtZQUN4QyxFQUFFLElBQUksRUFBRSxzQkFBc0IsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7WUFDOUQsRUFBRSxJQUFJLEVBQUUsZ0NBQWdDLEVBQUUsSUFBSSxFQUFFLGdDQUFnQyxFQUFFO1NBQ25GO0tBQ0Y7SUFDRDtRQUNFLElBQUksRUFBRSxpQkFBaUI7UUFDdkIsSUFBSSxFQUFFLGlCQUFpQjtRQUN2QixJQUFJLEVBQUUsSUFBSTtRQUNWLFdBQVcsRUFBRSx5Q0FBeUM7UUFDdEQsUUFBUSxFQUFFO1lBQ1IsRUFBRSxJQUFJLEVBQUUsNkJBQTZCLEVBQUUsSUFBSSxFQUFFLGNBQWMsRUFBRTtZQUM3RCxFQUFFLElBQUksRUFBRSxzQkFBc0IsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUU7WUFDOUQsRUFBRSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFO1lBQ3RELEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUUsVUFBVSxFQUFFO1NBQ3ZDO0tBQ0Y7SUFDRDtRQUNFLElBQUksRUFBRSw0QkFBNEI7UUFDbEMsSUFBSSxFQUFFLDBCQUEwQjtRQUNoQyxJQUFJLEVBQUUsS0FBSztRQUNYLFdBQVcsRUFBRSx5Q0FBeUM7UUFDdEQsUUFBUSxFQUFFO1lBQ1IsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDNUMsRUFBRSxJQUFJLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDNUMsRUFBRSxJQUFJLEVBQUUscUJBQXFCLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFO1lBQzVELEVBQUUsSUFBSSxFQUFFLHdCQUF3QixFQUFFLElBQUksRUFBRSx3QkFBd0IsRUFBRTtTQUNuRTtLQUNGO0NBQ0YsQ0FBQTtBQUVEOztHQUVHO0FBQ0gsU0FBZ0IsaUJBQWlCLENBQy9CLFVBQThCLEVBQzlCLFdBQTBCLElBQUksRUFDOUIsU0FBaUUsRUFBRTtJQUVuRSxLQUFLLE1BQU0sUUFBUSxJQUFJLFVBQVUsRUFBRSxDQUFDO1FBQ2xDLE1BQU0sRUFBRSxRQUFRLEVBQUUsR0FBRyxZQUFZLEVBQUUsR0FBRyxRQUFRLENBQUE7UUFDOUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsWUFBWSxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFBO1FBRXJELElBQUksUUFBUSxJQUFJLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDcEMsaUJBQWlCLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUE7UUFDcEQsQ0FBQztJQUNILENBQUM7SUFFRCxPQUFPLE1BQU0sQ0FBQTtBQUNmLENBQUM7QUFFRDs7R0FFRztBQUNILFNBQWdCLGdCQUFnQixDQUFDLFVBQThCO0lBQzdELElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQTtJQUNiLEtBQUssTUFBTSxRQUFRLElBQUksVUFBVSxFQUFFLENBQUM7UUFDbEMsS0FBSyxFQUFFLENBQUE7UUFDUCxJQUFJLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUN0QixLQUFLLElBQUksZ0JBQWdCLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFBO1FBQzlDLENBQUM7SUFDSCxDQUFDO0lBQ0QsT0FBTyxLQUFLLENBQUE7QUFDZCxDQUFDO0FBRUQsZUFBZTtBQUNGLFFBQUEsY0FBYyxHQUFHO0lBQzVCLGNBQWMsRUFBRSx1QkFBZSxDQUFDLE1BQU07SUFDdEMsZUFBZSxFQUFFLGdCQUFnQixDQUFDLHVCQUFlLENBQUM7SUFDbEQsUUFBUSxFQUFFLENBQUMsRUFBRSx3QkFBd0I7Q0FDdEMsQ0FBQSJ9