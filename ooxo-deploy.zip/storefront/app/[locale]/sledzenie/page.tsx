import { redirect } from 'next/navigation'

export default function SledzeniePage() {
  redirect('/pl/tracking')
}
