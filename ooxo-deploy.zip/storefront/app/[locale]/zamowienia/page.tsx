import { redirect } from 'next/navigation'

export default function ZamowieniaPage() {
  redirect('/pl/orders')
}
